"""Einen neuen Kurs im Lehrerpult anlegen (Kurse im Pult anlegen, K2, 24.11.2026).

Entschieden (Lehrer 24.11.2026, Skizze „Kurse im Pult anlegen“, „1 passt, 2 passt, 3 passt, 4 passt“):
  1  Die Schuelerfassung entsteht im Pult, sofort -- aus den Bausteinen, die das Projekt gebaut und geprueft hat
     (zusammensetzen.py, derselbe Schritt wie in bauen.py).
  2  Ein Kurs ist in der Q-Phase ein Jahrgang („Abitur 2029“, waechst je Halbjahr), in Klasse 11 ein Schuljahr.
  3  Neue Fassungen kommen weiter aus dem Projekt: Es uebernimmt den Kurs aus _angelegt/ beim naechsten Abzug (K4).
  4  Kennwoerter je Kurs und Thema neu; die Liste nur im Pult.

Ergebnis in <pult>/_angelegt/<kennung>/ (der Abzug bewahrt den Ordner wie die anderen Spuren):
    Lernraum <titel>.zip      der Lernraum fuer die Klasse, darin der Ordner „Lernraum <titel>“ samt Info-Datei
                              („Kurs - … .txt“) -- zugleich Fassung 1
    kennwortliste.html        nur fuer den Lehrer: je Thema das Kennwort, zum Ausdrucken
    kurs.json                 was das Projekt fuer die Uebernahme braucht (Auswahl, Fassung, Kennwoerter)

Nur die Standardbibliothek (das Pult laeuft am Schulrechner in Thonny).
"""
import datetime
import html
import json
import pathlib
import re
import secrets
import shutil
import tempfile

from . import zusammensetzen as zs

ANGELEGT = "_angelegt"
BAUSTEINE = "bausteine"
SYSTEM = "_schuelersystem"
STUFEN = ("11", "Q1", "Q2", "Q3", "Q4")
ARTEN = {"jahrgang": "Informatik Q-Phase", "schuljahr": "Informatik 11"}   # Art -> Titel des Lernraums
WOERTER_JE_KENNWORT = 4                                                     # wie werkstatt/lernraum/kennwort.py


class Abgelehnt(Exception):
    pass


def _katalog(pult):
    return json.loads((pathlib.Path(pult) / "_system" / "katalog.json").read_text("utf-8"))


def kennung_vorschlag(art, name, schuljahr=""):
    """„Abitur 2029“ -> iqabi29; ein Schuljahr 11 „2027/28“ -> i11s27."""
    if art == "jahrgang":
        m = re.search(r"(20\d\d)", name)
        if not m:
            raise Abgelehnt("Im Namen eines Jahrgangs steht das Abiturjahr, z. B. „Abitur 2029“.")
        return "iqabi" + m.group(1)[2:]
    m = re.search(r"20(\d\d)", schuljahr or name)
    if not m:
        raise Abgelehnt("Für Klasse 11 das Schuljahr angeben, z. B. „2027/28“.")
    return "i11s" + m.group(1)


def vergeben(pult):
    """Kennungen, die es schon gibt: die Kurse des Pults und alles, was hier angelegt wurde."""
    pult = pathlib.Path(pult)
    kat = _katalog(pult)
    da = set(kat.get("kennungen", []))
    if (pult / ANGELEGT).is_dir():
        da.update(p.name for p in (pult / ANGELEGT).iterdir() if p.is_dir())
    return da


def kennwort(woerter):
    return "-".join(secrets.choice(woerter) for _ in range(WOERTER_JE_KENNWORT))


def _woerter(pult):
    p = pathlib.Path(pult) / BAUSTEINE / SYSTEM / "kennwort_woerter.txt"
    w = [x for z in p.read_text("utf-8").split("\n") if not z.startswith("#") for x in z.split()]
    if len(w) < 1500 or len(set(w)) != len(w):
        raise Abgelehnt("Der Wortvorrat der Kennwörter im Pult ist unvollständig -- das Pult neu abziehen.")
    return w


def plan(pult, art, kapitel, freigegeben=None):
    """Welche Kapitel in welcher Reihenfolge, mit Zugabe und Halbjahr -- und welche erst spaeter kommen.
    Reihenfolge: die des Katalogs (Stufe, dann wie im Jahresplan). Ein Jahrgang baut nur bis „freigegeben“;
    spaetere Halbjahre bringt eine Fassung aus dem Projekt (Entscheidung 2 der Q-Phase, 24.11.2026)."""
    if art not in ARTEN:
        raise Abgelehnt("Unbekannte Art: %s" % art)
    kat = _katalog(pult)
    nach_kennung = {e["kennung"]: e for s in kat["stufen"] for e in s["kapitel"]}
    unbekannt = [k for k in kapitel if k not in nach_kennung]
    if unbekannt:
        raise Abgelehnt("Diese Kapitel kennt das Pult nicht: %s" % ", ".join(unbekannt))
    gewaehlt = [e for s in kat["stufen"] for e in s["kapitel"] if e["kennung"] in set(kapitel)]
    if art == "schuljahr":
        falsch = [e["kennung"] for e in gewaehlt if e["stufe"] != "11"]
        if falsch:
            raise Abgelehnt("Ein Schuljahr Klasse 11 trägt nur Kapitel der 11: nicht %s" % ", ".join(falsch))
        jetzt, spaeter = gewaehlt, []
    else:
        falsch = [e["kennung"] for e in gewaehlt if e["stufe"] == "11"]
        if falsch:
            raise Abgelehnt("Ein Jahrgang der Q-Phase trägt keine Kapitel der 11: %s" % ", ".join(falsch))
        if freigegeben not in STUFEN[1:]:
            raise Abgelehnt("Freigegeben bis Q1, Q2, Q3 oder Q4.")
        jetzt = [e for e in gewaehlt if STUFEN.index(e["stufe"]) <= STUFEN.index(freigegeben)]
        spaeter = [e for e in gewaehlt if e not in jetzt]
    nicht_gebaut = [e["kennung"] for e in jetzt if not e["gebaut"]]
    if nicht_gebaut:
        raise Abgelehnt("Noch nicht gebaut: %s -- später freigeben, dann kommt es mit einer Fassung." % ", ".join(nicht_gebaut))
    if not [e for e in jetzt if not e["zugabe"]]:
        raise Abgelehnt("Mindestens ein Kapitel, das keine Zugabe ist.")
    return jetzt, spaeter


def anlegen(pult, art, name, kapitel, freigegeben=None, schuljahr="", heute=None, _kennwoerter=None):
    """Legt den Kurs an und gibt kurs.json zurueck (ohne Kennwoerter). _kennwoerter: nur fuer den Test (Gegenprobe
    mit dem Projekt bei gleichen Kennwoertern)."""
    pult = pathlib.Path(pult)
    name = (name or "").strip()
    if not name:
        raise Abgelehnt("Der Kurs braucht einen Namen.")
    jetzt, spaeter = plan(pult, art, kapitel, freigegeben)
    kennung = kennung_vorschlag(art, name, schuljahr)
    if kennung in vergeben(pult):
        raise Abgelehnt("Den Kurs %s gibt es schon." % kennung)
    kat = _katalog(pult)
    heute = heute or datetime.date.today().isoformat()
    bst = pult / BAUSTEINE
    themen = []                       # (kapitel, thema, nr, titel, hat_loesung) in Kursreihenfolge
    for e in jetzt:
        b = zs.baustein_lesen(bst / e["kennung"])
        themen += [(e["kennung"], t["kennung"], t["nr"], t["titel"], bool(t.get("hat_loesung")), b["reihe"]["titel"]) for t in b["reihe"]["themen"]]
    if _kennwoerter is None:
        woerter = _woerter(pult)
        kw = {"%s/%s" % (k, t): kennwort(woerter) for k, t, _, _, mit, _ in themen if mit}
    else:
        kw = dict(_kennwoerter)
    repo = "abi20" + kennung[5:] if art == "jahrgang" else "11-20" + kennung[4:]
    kopf = {"kurs": kennung, "titel": ARTEN[art], "untertitel": name, "version": kat.get("version", heute), "schuljahr": schuljahr,
            "fassung_nr": 1, "fassung_datum": heute,
            "aktualisierung": kat["aktualisierung_vorlage"].format(repo=repo) if kat.get("aktualisierung_vorlage") else ""}
    if art == "jahrgang":
        kopf["halbjahr"] = freigegeben
    auswahl = [{"kennung": e["kennung"], "zugabe": e["zugabe"], "halbjahr": e["stufe"] if art == "jahrgang" else None} for e in jetzt]
    ziel = pult / ANGELEGT / kennung
    tmp = pathlib.Path(tempfile.mkdtemp(prefix="kurs_anlegen_"))
    try:
        lr = tmp / "lernraum"
        inhalt = zs.zusammensetzen(bst, bst / SYSTEM, kopf, auswahl, kw, lr)
        anleitung = bst / SYSTEM / "_anleitung" / (art + ".pdf")      # K5: eine Anleitung je Art
        mit_anleitung = anleitung.is_file()
        if mit_anleitung:
            shutil.copy2(anleitung, lr / "SO_FAENGST_DU_AN.pdf")
        inhalt["fassung_entwurf"] = False
        (lr / "_system" / "inhalt.json").write_text(json.dumps(inhalt, ensure_ascii=False, indent=0), "utf-8")
        fassung = {"nr": 1, "datum": heute, "aenderungen": ["Erste Ausgabe an die Klasse"]}
        zs.manifest_schreiben(lr, inhalt, fassung)
        ziel.mkdir(parents=True)
        zipname = zs.zipname(kopf["titel"])              # „Lernraum Informatik 11.zip“ -- darin der Ordner und die Info-Datei
        sha, groesse = zs.zip_bauen(lr, ziel / zipname)
        kurs = {"kennung": kennung, "art": art, "name": name, "titel": kopf["titel"], "schuljahr": schuljahr,
                "freigegeben": freigegeben if art == "jahrgang" else None, "aktualisierung": kopf["aktualisierung"],
                "kapitel": [dict(a, stufe=e["stufe"], titel=e["titel"]) for a, e in zip(auswahl, jetzt)],
                "spaeter": [{"kennung": e["kennung"], "zugabe": e["zugabe"], "halbjahr": e["stufe"], "titel": e["titel"]} for e in spaeter],
                "fassung": dict(fassung, zip=zipname, sha256=sha, groesse=groesse), "anleitung": mit_anleitung,
                "bausteine_vom": kat.get("version", ""), "angelegt": datetime.datetime.now().isoformat(timespec="seconds")}
        (ziel / "kennwortliste.html").write_text(kennwortliste(kurs, themen, kw), "utf-8")
        # kurs.json zuletzt: erst mit ihr gilt der Kurs als angelegt (die Startseite und die Uebernahme lesen sie)
        (ziel / "kurs.json").write_text(json.dumps(dict(kurs, kennwoerter=kw), ensure_ascii=False, indent=1) + "\n", "utf-8")
    except BaseException:
        shutil.rmtree(ziel, ignore_errors=True)       # nichts Halbes: sonst hiesse es beim zweiten Versuch „gibt es schon“
        raise
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    return kurs


def kennwortliste(kurs, themen, kw):
    """Je Thema mit Loesung das Kennwort -- fuer den Lehrer, zum Ausdrucken (die Kette: wer das Kennwort eines Themas
    eingibt, oeffnet alle davor mit)."""
    z = ['<!doctype html><html lang="de"><meta charset="utf-8"><title>Kennwörter · %s</title>' % html.escape(kurs["name"]),
         "<style>body{font-family:-apple-system,system-ui,'Segoe UI',sans-serif;max-width:46em;margin:2em auto;padding:0 1em;color:#1c1b1a}"
         "h1{font-size:1.4em;margin:0}p{color:#5e5953}table{border-collapse:collapse;width:100%;margin-top:1em}"
         "td,th{text-align:left;padding:.4em .5em;border-bottom:1px solid #e6e1d8;vertical-align:top}"
         "th{font-size:.85em;color:#5e5953}td.kw{font-family:ui-monospace,Menlo,Consolas,monospace;white-space:nowrap}"
         "h2{font-size:1.05em;margin:1.6em 0 0}@media print{body{margin:0}}</style>",
         "<h1>Kennwörter · %s</h1>" % html.escape(kurs["name"]),
         "<p>%s · Kurs <b>%s</b> · Fassung 1 vom %s. Nur für dich. Ein Kennwort öffnet auch alle Lösungen davor.</p>"
         % (html.escape(kurs["titel"]), html.escape(kurs["kennung"]), html.escape(kurs["fassung"]["datum"]))]
    zuletzt = None
    for k, t, nr, titel, mit, ktitel in themen:
        if k != zuletzt:
            if zuletzt is not None:
                z.append("</table>")
            z.append("<h2>%s</h2><table><tr><th>Thema</th><th>Kennwort</th></tr>" % html.escape(ktitel))
            zuletzt = k
        z.append("<tr><td>%d · %s</td><td class=\"kw\">%s</td></tr>" % (nr, html.escape(titel), html.escape(kw.get(k + "/" + t, "— ohne Lösung"))))
    if zuletzt is not None:
        z.append("</table>")
    return "\n".join(z) + "\n"
