"""Wie in der Klausur -- die Pruefung der getippten Texte (Lauf i11, Schritt 3, Lehrer 09.11.2026: „wenn die
Schueler es abgeben, kann ich mit dir die Uebungen durchgehen und sie pruefen lassen“).

Die Klasse hakt ihre BE selbst ab; Sterne gibt es erst fuer GEPRUEFTE BE (★ ab der Haelfte, ★★ bei voll -- Claude
entschieden, Lehrer „entscheide du“). Der Weg:

  1. Uebersicht: Abgaben laden, „Klausurtexte fuer Claude bereitstellen“ -> _bewertung/zu_pruefen.json (ohne
     Namen, je Text eine Nummer, mit Auftrag, Muster und Raster) und _bewertung/zuordnung.json (Nummer -> Person).
  2. Claude liest zu_pruefen.json und schreibt _bewertung/vorschlag.json:
        {"<nummer>": {"raster": [true, false, …], "gruende": ["…", "…", …]}}
  3. Uebersicht: je Text der Vorschlag neben der Selbsteinschaetzung; die Lehrkraft kippt, was sie anders sieht,
     und bestaetigt -> _bewertung/klausuren.json. NUR Bestaetigtes gibt Sterne.

Eine Bewertung gehoert zu einem TEXT (Abdruck): Kommt eine neuere Abgabe mit anderem Text, gilt sie nicht mehr.
_bewertung/ ist lebende Lehrerdatenhaltung wie _durchsicht/ -- der Abzug laesst sie stehen.
"""
import hashlib
import json

from .stand import jetzt, schreiben

ORDNER = "_bewertung"


def text_abdruck(text):
    return hashlib.sha256((text or "").strip().encode("utf-8")).hexdigest()[:16]


def schluessel(name, kennung):
    """Person (normalisierter Name) und Klausur-Kennung <reihe>/<thema>/<name>."""
    return "%s|%s" % (" ".join((name or "").lower().split()), kennung)


def _lesen(wurzel, datei):
    p = wurzel / ORDNER / datei
    try:
        return json.loads(p.read_text("utf-8")) if p.exists() else {}
    except (OSError, ValueError):
        return {}


def _schreiben(wurzel, datei, daten):
    p = wurzel / ORDNER / datei
    p.parent.mkdir(parents=True, exist_ok=True)
    schreiben(p, json.dumps(daten, ensure_ascii=False, indent=1))
    return p


def bereitstellen(wurzel, eintraege):
    """eintraege: [{name, thema, aufgabe, klausur, kennung, auftrag, muster, raster, be, text, selbst}] -> die zwei
    Dateien. Nummern laufen je Bereitstellung neu; die Zuordnung bleibt auf der Platte des Pults."""
    zu, zuordnung = {"erzeugt": jetzt(), "anleitung": __doc__.split("  2.")[1].split("  3.")[0].strip(), "aufgaben": {}}, {}
    for i, e in enumerate(sorted(eintraege, key=lambda x: (x["kennung"], text_abdruck(x["text"]))), 1):
        nr = "%03d" % i
        a = zu["aufgaben"].setdefault(e["kennung"], {k: e[k] for k in ("thema", "aufgabe", "auftrag", "muster", "raster", "be")})
        a.setdefault("texte", []).append({"nummer": nr, "text": e["text"], "selbst": e["selbst"]})
        zuordnung[nr] = {"name": e["name"], "kennung": e["kennung"], "abdruck": text_abdruck(e["text"]), "be": e["be"]}
    _schreiben(wurzel, "zuordnung.json", zuordnung)
    return _schreiben(wurzel, "zu_pruefen.json", zu), len(zuordnung)


def fuer_person(wurzel, name, kennung, text, be):
    """Was zu diesem Text vorliegt: {"vorschlag": {...}?, "bestaetigt": {...}?} -- nur, was zum TEXT passt."""
    abd = text_abdruck(text)
    aus = {}
    b = _lesen(wurzel, "klausuren.json").get(schluessel(name, kennung))
    if b and b.get("abdruck") == abd and len(b.get("raster") or []) == be:
        aus["bestaetigt"] = b
    zuordnung, vorschlag = _lesen(wurzel, "zuordnung.json"), _lesen(wurzel, "vorschlag.json")
    for nr, z in zuordnung.items():
        v = vorschlag.get(nr)
        if v and z.get("kennung") == kennung and z.get("abdruck") == abd and schluessel(z.get("name"), kennung) == schluessel(name, kennung):
            r = [bool(x) for x in (v.get("raster") or [])]
            if len(r) == be:
                aus["vorschlag"] = {"raster": r, "gruende": [str(x) for x in (v.get("gruende") or [])][:be] + [""] * max(0, be - len(v.get("gruende") or []))}
    return aus


def bestaetigen(wurzel, name, kennung, text, raster):
    alle = _lesen(wurzel, "klausuren.json")
    alle[schluessel(name, kennung)] = {"name": name, "kennung": kennung, "abdruck": text_abdruck(text),
                                        "raster": [bool(x) for x in raster], "zeit": jetzt()}
    _schreiben(wurzel, "klausuren.json", alle)
    return alle[schluessel(name, kennung)]


def geprueft_je(wurzel, name, pfad, stand):
    """Fuer sterne.thema_sterne: {klausur-name: geprüfte BE} -- nur BESTAETIGTE, nur zum abgegebenen Text."""
    aus = {}
    for kennung, k in (stand.get("klausuren") or {}).items():
        if not kennung.startswith(pfad + "/"):
            continue
        b = _lesen(wurzel, "klausuren.json").get(schluessel(name, kennung))
        if b and b.get("abdruck") == text_abdruck(k.get("text", "")):
            aus[kennung.rsplit("/", 1)[-1]] = sum(1 for x in b.get("raster") or [] if x)
    return aus
