"""Indizien an einer Abgabe (I1, 25.11.2026): Gruende statt Score.

Lehrerfrage 24.11.: *„Am Ende könnte zu einer Abgabe ein Score stehen, der angibt, wie wahrscheinlich die Abgabe mit
KI erstellt wurde“* -> Skizze „Indizien“ -> keine Zahl, sondern Gruende mit Staerke (stark · mittel · schwach), Beleg
und einem Satz zum Nachfragen (werkstatt/informatik/qphase/LIESMICH.md, „Indizien statt Score“). Hier die zwei
Spuren, die ohne neue Daten auskommen -- sie wirken auf jede Abgabe, auch aus aelteren Fassungen:

  * NOCH NICHT DRAN -- der Python-Code einer Abgabe wird zerlegt (ast) und mit allem verglichen, was der Lernraum bis
    zu diesem Thema zeigt: Startdateien, Code-Film, gegebene Module, Codestellen in Erklaerung, Vortrag und Uebung,
    die Loesungen (nicht die Regie). Was dort nie vorkommt -- eine Bauform, eine eingebaute Funktion, eine Methode,
    ein Modul, englische Kommentare --, faellt auf. Taeuscht bei allen, die Python schon kennen; darum heisst es
    „noch nicht dran“, nicht „KI“.
  * GLEICHE ABGABEN -- je zwei Abgaben eines Themas, ohne Kommentare, Docstrings, Leerraum und ohne die Zeilen der
    Startdatei; ab GLEICH (Anteil gleicher Zeichen nach difflib) und mindestens MIN_ZEILEN eigenen Zeilen. Partner
    sind ausgenommen. Dazu der Vergleich mit der Musterloesung.

Dazu seit I2 (25.11.2026), aus dem Stand der Abgabe:

  * FERTIG OHNE PROBIEREN -- der Lernraum zaehlt je Thema die Laeufe, die Fehler dabei und die Selbstchecks
    (stand.laeufe, erst ab der Fassung mit I2). Fertig (Selbstcheck ganz gruen) mit hoechstens einem Lauf und ohne
    Fehler, waehrend der Kurs fuer dieses Thema im Median mindestens MEDIAN_AB Laeufe braucht -- oder, solange es zu
    wenige Abgaben fuer einen Median gibt, mit keinem einzigen Lauf. Mittel, nie stark: Wer im Kopf testet, kommt
    auch so durch.
  * VERSTEHEN UND ERGEBNIS -- die Pruefragen der Erklaerung zur Haelfte und mehr beim ersten Versuch daneben, oder
    „Ich kann …“ mit „noch nicht“ bei einem Satz des Themas, das Ergebnis aber stark (Expertenaufgabe geloest oder
    alle Sterne). Schwach: Wer erst beim Ueben versteht, sieht genauso aus -- und genau dafuer ist Ueben da.

Nichts davon wird gespeichert: gerechnet wird beim Bericht ueber die geladenen Abgaben (Entscheidung 5).
"""
import ast
import builtins
import difflib
import html
import io
import json
import re
import tokenize
import warnings

GLEICH = 0.9
MIN_ZEILEN = 8
MEDIAN_AB = 3          # „fertig ohne Probieren“: erst ab diesem Median der Laeufe im Kurs
MEDIAN_MIN = 4         # … und erst ab so vielen Abgaben mit Laufzaehlung gibt es einen Median

# Bauformen, die eine KI gern schreibt und ein Kurs nach drei Wochen selten -- eine davon macht die Spur „stark“
KI_TYPISCH = {"lambda", "listcomp", "dictcomp", "setcomp", "genexp", "typangabe", "docstring", "englisch", "walrus",
              "decorator", "match", "async", "keyfn", "yield", "try"}

NAMEN = {
    "lambda": "lambda", "listcomp": "List-Comprehension [… for …]", "dictcomp": "Dict-Comprehension {…: … for …}",
    "setcomp": "Set-Comprehension", "genexp": "Generator-Ausdruck (… for …)", "try": "try/except", "with": "with",
    "assert": "assert", "global": "global", "nonlocal": "nonlocal", "yield": "yield", "walrus": "Zuweisung im Ausdruck :=",
    "fstring": "f-String", "ifexp": "bedingter Ausdruck a if b else c", "match": "match/case", "async": "async/await",
    "while": "while-Schleife", "class": "eigene Klasse (class)", "del": "del", "decorator": "Dekorator @",
    "typangabe": "Typangaben (x: int, -> int)", "docstring": "Docstring", "keyfn": "key= (Sortierschlüssel)",
    "slice": "Slice [a:b]", "englisch": "englischer Kommentar oder Docstring",
}

BUILTIN_FUNKTIONEN = {n for n in dir(builtins) if not n.startswith("_") and n[:1].islower() and callable(getattr(builtins, n))}
TYPMETHODEN = {m for t in (str, list, dict, set, tuple, int, float, bytes) for m in dir(t) if not m.startswith("_")}

EN = {"the", "and", "of", "to", "is", "returns", "this", "that", "with", "are", "each", "which", "an", "it", "be",
      "from", "we", "will", "should", "otherwise", "number", "value", "check", "whether"}
DE = {"der", "die", "das", "und", "ist", "ein", "eine", "wenn", "nicht", "mit", "für", "fuer", "zu", "den", "dem",
      "im", "wird", "gibt", "sonst", "noch", "auf", "aus", "alle", "jede", "jeder", "zahl", "liste"}


def name(m):
    """Lesbarer Name eines Merkmals fuer die Seite."""
    art, _, wer = m.partition(":")
    if art == "aufruf":
        return "%s()" % wer
    if art == "methode":
        return ".%s()" % wer
    if art == "import":
        return "import %s" % wer
    return NAMEN.get(m, m)


def _ist_code(s):
    """Auskommentierter Code („# while zuege > 0 and …“) ist kein englischer Kommentar."""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        for versuch in (s, s.rstrip() + "\n    pass"):
            try:
                ast.parse(versuch)
                return True
            except (SyntaxError, ValueError, RecursionError):
                continue
    return False


def _englisch(text, zeile, aus):
    woerter = re.findall(r"[a-zäöüß]+", text.lower())
    if len(woerter) >= 4:
        en, de = sum(w in EN for w in woerter), sum(w in DE for w in woerter)
        if en >= 2 and en > de:
            aus.setdefault("englisch", zeile)


def _baum(baum, aus):
    eigene = {n.name for n in ast.walk(baum) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))}

    def merk(k, n):
        z = getattr(n, "lineno", 1)
        if k not in aus or z < aus[k]:
            aus[k] = z
    einfach = {ast.Lambda: "lambda", ast.ListComp: "listcomp", ast.DictComp: "dictcomp", ast.SetComp: "setcomp",
               ast.GeneratorExp: "genexp", ast.Try: "try", ast.With: "with", ast.Assert: "assert", ast.Global: "global",
               ast.Nonlocal: "nonlocal", ast.Yield: "yield", ast.YieldFrom: "yield", ast.NamedExpr: "walrus",
               ast.JoinedStr: "fstring", ast.IfExp: "ifexp", ast.While: "while", ast.ClassDef: "class", ast.Delete: "del",
               ast.AsyncFunctionDef: "async", ast.Await: "async", ast.AsyncFor: "async", ast.AsyncWith: "async",
               ast.AnnAssign: "typangabe"}
    for t in ("Match", "TryStar"):
        if hasattr(ast, t):
            einfach[getattr(ast, t)] = "match" if t == "Match" else "try"
    for n in ast.walk(baum):
        k = einfach.get(type(n))
        if k:
            merk(k, n)
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Module)):
            if not isinstance(n, ast.Module) and n.decorator_list:
                merk("decorator", n)
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                a = n.args
                if n.returns is not None or any(x.annotation is not None for x in a.posonlyargs + a.args + a.kwonlyargs):
                    merk("typangabe", n)
            if n.body and isinstance(n.body[0], ast.Expr) and isinstance(getattr(n.body[0], "value", None), ast.Constant) \
                    and isinstance(n.body[0].value.value, str):
                merk("docstring", n.body[0])
                _englisch(n.body[0].value.value, n.body[0].lineno, aus)
        elif isinstance(n, ast.Call):
            f = n.func
            if isinstance(f, ast.Name) and f.id in BUILTIN_FUNKTIONEN:
                merk("aufruf:" + f.id, n)
            elif isinstance(f, ast.Attribute) and f.attr in TYPMETHODEN and f.attr not in eigene:
                merk("methode:" + f.attr, n)
            if any(k.arg == "key" for k in n.keywords):
                merk("keyfn", n)
        elif isinstance(n, ast.Import):
            for a in n.names:
                merk("import:" + a.name.split(".")[0], n)
        elif isinstance(n, ast.ImportFrom) and n.module:
            merk("import:" + n.module.split(".")[0], n)
        elif isinstance(n, ast.Subscript) and isinstance(n.slice, ast.Slice):
            merk("slice", n)


def merkmale(text):
    """-> {merkmal: erste Zeile}. Ganze Dateien als Ganzes; Bruchstuecke (Codestellen in der Erklaerung, ein
    Programm mit Syntaxfehler) Zeile fuer Zeile, eine offene Zeile („for x in liste:“) mit einem pass dahinter."""
    aus = {}
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        _merkmale_parsen(text, aus)
    try:
        for tok in tokenize.generate_tokens(io.StringIO(text).readline):
            if tok.type == tokenize.COMMENT and not _ist_code(tok.string.lstrip("#").strip()):
                _englisch(tok.string.lstrip("#"), tok.start[0], aus)
    except (tokenize.TokenError, IndentationError, SyntaxError):
        pass
    return aus


def _merkmale_parsen(text, aus):
    try:
        _baum(ast.parse(text), aus)
    except (SyntaxError, ValueError, RecursionError):
        for i, z in enumerate(text.splitlines(), 1):
            s = z.strip()
            if not s or s.startswith("#"):
                continue
            for versuch in (s, s + "\n    pass"):
                try:
                    teil = {}
                    _baum(ast.parse(versuch), teil)
                    for k in teil:
                        aus.setdefault(k, i)
                    break
                except (SyntaxError, ValueError, RecursionError):
                    continue


# -- Was der Lernraum bis zu einem Thema zeigt ------------------------------------------------------------------------
CODESTELLE = re.compile(r"<(pre|code)\b[^>]*>(.*?)</\1>", re.S)


def _texte(wert, schluessel=""):
    """Codestellen aus den Texten eines Themas -- ohne die Regie, die sieht die Klasse nie."""
    if schluessel == "regie":
        return
    if isinstance(wert, dict):
        for k, v in wert.items():
            yield from _texte(v, k)
    elif isinstance(wert, list):
        for v in wert:
            yield from _texte(v, schluessel)
    elif isinstance(wert, str) and ("<pre" in wert or "<code" in wert):
        for m in CODESTELLE.finditer(wert):
            yield html.unescape(re.sub(r"<[^>]+>", "", m.group(2)))


def thema_merkmale(Z, reihe, thema):
    """Alle Merkmale eines Themas, so wie die Klasse es sieht."""
    ordner = Z.themenordner(reihe["kennung"] + "/" + thema["kennung"])
    m = set()
    quellen = [p.read_text("utf-8", "replace") for p in sorted(ordner.rglob("*.py"))
               if "__pycache__" not in p.parts and p.name != "pruefung.py"] if ordner.is_dir() else []
    lo = ordner / "loesung.json"
    if lo.is_file():
        try:
            quellen += [v for k, v in (json.loads(lo.read_text("utf-8")).get("dateien") or {}).items() if k.endswith(".py") and isinstance(v, str)]
        except ValueError:
            pass
    quellen += list(_texte(thema))
    for q in quellen:
        m.update(merkmale(q))
    return m


def vorrat(Z, kennung, speicher):
    """Merkmale aller Themen bis einschliesslich <kennung>, in der Reihenfolge des Kurses (Kapitel, dann Themen)."""
    if kennung in speicher:
        return speicher[kennung]
    v = set()
    for r in Z.inhalt.get("reihen", []):
        for t in r["themen"]:
            k = r["kennung"] + "/" + t["kennung"]
            if ("thema", k) not in speicher:
                speicher[("thema", k)] = thema_merkmale(Z, r, t)
            v |= speicher[("thema", k)]
            if k == kennung:
                speicher[kennung] = v
                return v
    speicher[kennung] = v
    return v


def noch_nicht_dran(dateien, v):
    """dateien: {name: code} der Abgabe -> ein Indiz oder None."""
    funde = []
    for datei, code in sorted(dateien.items()):
        zeilen = code.splitlines()
        for m, z in sorted(merkmale(code).items(), key=lambda x: x[1]):
            if m not in v:
                funde.append({"merkmal": m, "name": name(m), "datei": datei, "zeile": z,
                              "code": zeilen[z - 1].strip()[:120] if 0 < z <= len(zeilen) else ""})
    if not funde:
        return None
    ki = [f for f in funde if f["merkmal"] in KI_TYPISCH]
    staerke = "stark" if ki else "mittel" if len({f["merkmal"] for f in funde}) >= 2 else "schwach"
    # Nachfragen an einer Zeile Code, nicht am Kommentar: erst eine KI-typische Bauform, dann irgendein Merkmal im Code
    im_code = [f for f in funde if f["merkmal"] not in ("englisch", "docstring")]
    erst = ([f for f in ki if f in im_code] or im_code or ki or funde)[0]
    mehrere = len(dateien) > 1
    # Belege je Zeile einmal, mit allen Merkmalen dieser Zeile (gesehen 25.11.: dieselbe Zeile dreimal untereinander)
    belege = []
    for f in funde:
        b = next((x for x in belege if (x["datei"], x["zeile"]) == (f["datei"], f["zeile"])), None)
        if b:
            b["merkmale"].append(f["name"])
        else:
            belege.append(dict(f, merkmale=[f["name"]]))
    return {"art": "neu", "staerke": staerke, "kurz": "noch nicht dran",
            "text": "Kam im Lernraum bis zu diesem Thema nicht vor: " + ", ".join(
                "%s (%sZeile %d)" % (f["name"], f["datei"] + " " if mehrere else "", f["zeile"]) for f in funde[:8])
                    + (" und %d weitere" % (len(funde) - 8) if len(funde) > 8 else "") + ".",
            "belege": belege[:8],
            "frage": "Erklär mir Zeile %d: Was macht %s – und warum brauchst du es hier?" % (
                erst["zeile"], "„" + erst["code"] + "“" if erst["code"] else erst["name"])}


# -- Gleiche Abgaben ------------------------------------------------------------------------------------------------
def _logisch(code):
    """Die Zeilen eines Programms ohne Kommentare, Docstrings und Leerraum (je logische Zeile ein Eintrag)."""
    try:
        baum = ast.parse(code)
        doc = {n.body[0].lineno for n in ast.walk(baum)
               if isinstance(n, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and n.body
               and isinstance(n.body[0], ast.Expr) and isinstance(getattr(n.body[0], "value", None), ast.Constant)
               and isinstance(n.body[0].value.value, str)}
    except (SyntaxError, ValueError, RecursionError):
        doc = set()
    aus, zeile, start = [], [], None
    try:
        for tok in tokenize.generate_tokens(io.StringIO(code).readline):
            if tok.type in (tokenize.COMMENT, tokenize.NL, tokenize.INDENT, tokenize.DEDENT, tokenize.ENCODING):
                continue
            if tok.type in (tokenize.NEWLINE, tokenize.ENDMARKER):
                if zeile and start not in doc:
                    aus.append(" ".join(zeile))
                zeile, start = [], None
                continue
            if start is None:
                start = tok.start[0]
            zeile.append(tok.string)
    except (tokenize.TokenError, IndentationError, SyntaxError):
        aus = [" ".join(z.split()) for z in code.splitlines() if z.strip() and not z.strip().startswith("#")]
    return aus


def eigene_zeilen(dateien, start):
    """Die logischen Zeilen der Abgabe, die nicht schon in der Startdatei stehen."""
    s = set()
    for code in start:
        s.update(_logisch(code))
    return [z for _, code in sorted(dateien.items()) for z in _logisch(code) if z not in s]


def aehnlich(a, b):
    if not a or not b:
        return 0.0
    return difflib.SequenceMatcher(None, "\n".join(a), "\n".join(b), autojunk=False).ratio()


def gleiche(abgaben, start, loesungen):
    """abgaben: [{nr, name, partner_norm, name_norm, zeilen}] EINES Themas; start: [code]; loesungen: [code].
    -> {nr: [indiz, …]}"""
    aus = {}
    gross = [a for a in abgaben if len(a["zeilen"]) >= MIN_ZEILEN]
    for i, a in enumerate(gross):
        for b in gross[i + 1:]:
            if a["partner_norm"] and a["partner_norm"] == b["name_norm"] or b["partner_norm"] and b["partner_norm"] == a["name_norm"]:
                continue
            q = aehnlich(a["zeilen"], b["zeilen"])
            if q >= GLEICH:
                for x, y in ((a, b), (b, a)):
                    aus.setdefault(x["nr"], []).append({
                        "art": "gleich", "staerke": "mittel", "kurz": "gleich wie " + y["name"], "mit": y["nr"],
                        "text": "Fast gleich wie die Abgabe von %s (%d von 100 gleich, ohne Startdatei, Kommentare und Leerraum; %d eigene Zeilen). "
                                "Die beiden haben sich nicht als Partner eingetragen." % (y["name"], round(q * 100), len(x["zeilen"])),
                        "frage": "Wie seid ihr auf diese Lösung gekommen – wer hat was beigetragen?"})
    lz = [z for z in (eigene_zeilen({"l": c}, start) for c in loesungen) if z]
    for a in gross:
        if not lz:
            break
        q = max(aehnlich(a["zeilen"], z) for z in lz)
        if q >= GLEICH:
            offen = a.get("loesung_offen")
            aus.setdefault(a["nr"], []).append({
                "art": "loesung", "staerke": "mittel" if offen else "stark", "kurz": "wie die Lösung",
                "text": "Fast gleich wie die Musterlösung (%d von 100 gleich). %s" % (
                    round(q * 100), "Die Lösung war vor der Abgabe offen." if offen else
                    "Die Lösung war in diesem Lernraum NICHT offen – vielleicht aus einem anderen."),
                "frage": "Erklär mir, was dein Programm Schritt für Schritt tut."})
    return aus


# -- I2: fertig ohne Probieren, Verstehen und Ergebnis ----------------------------------------------------------------
def _median(werte):
    w = sorted(werte)
    if not w:
        return None
    m = len(w) // 2
    return w[m] if len(w) % 2 else (w[m - 1] + w[m]) / 2


def ohne_probieren(abgaben):
    """abgaben: [{nr, laeufe (dict|None), fertig (bool), zeilen (eigene)}] EINES Themas -> {nr: indiz}."""
    mit = [a for a in abgaben if a.get("laeufe") is not None]
    med = _median([int(a["laeufe"].get("anzahl") or 0) for a in mit]) if len(mit) >= MEDIAN_MIN else None
    aus = {}
    for a in mit:
        lf = a["laeufe"]
        n, f = int(lf.get("anzahl") or 0), int(lf.get("fehler") or 0)
        if not a.get("fertig") or len(a.get("zeilen") or []) < MIN_ZEILEN or f:
            continue
        if (med is not None and med >= MEDIAN_AB and n <= 1) or (med is None and n == 0):
            vergleich = ("im Kurs für dieses Thema im Median %s Läufe" % (int(med) if med == int(med) else ("%.1f" % med).replace(".", ","))) if med is not None \
                else "zu wenige Abgaben für einen Vergleich im Kurs"
            aus[a["nr"]] = {"art": "lauf", "staerke": "mittel", "kurz": "fertig ohne Probieren",
                            "text": "Selbstcheck ganz grün nach %s, ohne einen einzigen Fehler (%s; Selbstcheck %d×)." % (
                                "keinem Lauf" if n == 0 else "einem Lauf", vergleich, int(lf.get("checks") or 0)),
                            "frage": "Wie hast du herausgefunden, dass dein Programm stimmt, ohne es laufen zu lassen?"}
    return aus


def _letzte_stufe(runden):
    """Die Stufe der spaetesten Runde mit Eintrag (1 = noch nicht … 4 = sicher) oder None."""
    beste = None
    for r, w in (runden or {}).items():
        if isinstance(w, dict) and w.get("stufe") and (beste is None or str(r) > beste[0]):
            beste = (str(r), int(w["stufe"]))
    return beste[1] if beste else None


def verstehen_ergebnis(reihe, thema, stand, zeile):
    """Ein Indiz (schwach) oder None. reihe/thema aus dem Inhalt, stand der Abgabe, zeile aus dem Bericht (Sterne)."""
    kennung = reihe["kennung"] + "/" + thema["kennung"]
    in_uebung = {x for a in thema["uebung"]["aufgaben"] for s in (a.get("sterne") or []) for x in s.get("fragen", [])}
    erkl = {k: v for k, v in (thema.get("fragen") or {}).items() if k not in in_uebung}
    beantwortet = {k: (stand.get("fragen") or {}).get(kennung + "/" + k) for k in erkl}
    beantwortet = {k: v for k, v in beantwortet.items() if isinstance(v, dict) and "erste" in v}
    daneben = sorted(k for k, v in beantwortet.items() if v["erste"] != erkl[k]["richtig"])
    schwach_fragen = len(beantwortet) >= 2 and 2 * len(daneben) >= len(beantwortet)
    noch_nicht = []
    for g in reihe.get("raster") or []:
        for s in g.get("saetze") or []:
            if thema["kennung"] in (s.get("themen") or []):
                st = _letzte_stufe((stand.get("einschaetzung") or {}).get(reihe["kennung"] + "/" + s["kennung"]))
                if st == 1:
                    noch_nicht.append(re.sub(r"<[^>]+>", "", s.get("html", "")).strip())
    if not (schwach_fragen or noch_nicht):
        return None
    # das Ergebnis: Expertenaufgabe (eine Stufe 4) voll -- sonst alle Sterne des Themas
    sterne = (zeile.get("sterne") or {})
    experten = [a["nr"] for a in thema["uebung"]["aufgaben"] if any(int(s.get("stufe", 0)) >= 4 for s in (a.get("sterne") or []))]
    geloest = [nr for nr in experten if ((zeile.get("aufgaben") or {}).get(nr) or {}).get("sterne") and zeile["aufgaben"][nr]["sterne"][0] >= 4]
    alle = bool(sterne) and sterne.get("max") and sterne.get("summe") == sterne.get("max")
    if not (geloest or alle):
        return None
    verstehen = []
    if schwach_fragen:
        verstehen.append("Prüffragen der Erklärung: %d von %d beim ersten Versuch daneben (%s)" % (len(daneben), len(beantwortet), ", ".join(daneben)))
    if noch_nicht:
        verstehen.append("„Ich kann …“: „noch nicht“ bei „%s“" % ("“, „".join(x[:70] + ("…" if len(x) > 70 else "") for x in noch_nicht[:2])))
    ergebnis = ("Expertenaufgabe %s gelöst" % ", ".join(geloest)) if geloest else "alle Sterne des Themas"
    return {"art": "verstehen", "staerke": "schwach", "kurz": "Verstehen und Ergebnis",
            "text": "%s – aber %s." % ("; ".join(verstehen), ergebnis),
            "frage": "Erklär mir an Aufgabe %s, warum deine Lösung funktioniert." % (geloest[0] if geloest else
                                                                                     (experten[-1] if experten else "der letzten Aufgabe"))}


# -- I3: die Mappe fuer Claude -- ohne Namen, gelesen NUR auf Nachfrage der Lehrkraft ----------------------------------
ANLEITUNG = """Claude liest diese Mappe NUR, wenn die Lehrkraft danach fragt („lies die Abgaben“, Entscheidung 3 der
Skizze „Indizien“, 25.11.2026). Je Abgabe (Nummer) und Person (P-Nummer, gleich ueber alle Themen dieser Mappe):
Beobachtungen an den TEXTEN, jede mit woertlichem Zitat -- kein Urteil, keine Prozentzahl, kein „KI“.
Worauf achten: Begriffe, die weder im Glossar bis zu diesem Thema noch im Muster stehen; ein Bruch zu den anderen
Texten derselben Person (Laenge, Ton, Fachsprache, Gliederung, Schlussformeln); englische Kommentare im Code.
NICHT: Rechtschreibung oder Laenge allein; die Datei indizien_zuordnung.json (Namen) wird nie gelesen.
Antwort in indizien_beobachtungen.json daneben:
  {"<nummer>": {"beobachtungen": [{"was": "ein Satz", "zitat": "woertlich aus dem Text"}]}}
Nichts gefunden: {"<nummer>": {"beobachtungen": []}} -- auch das ist eine Antwort."""

MAPPE_ORDNER = "_bewertung"
MAPPE = "indizien_zu_lesen.json"
ZUORDNUNG = "indizien_zuordnung.json"
BEOBACHTUNGEN = "indizien_beobachtungen.json"


def kommentare(dateien):
    """Kommentare und Docstrings aus dem Python-Code: [(datei, zeile, text)]."""
    aus = []
    for datei, code in sorted(dateien.items()):
        try:
            for tok in tokenize.generate_tokens(io.StringIO(code).readline):
                if tok.type == tokenize.COMMENT and not _ist_code(tok.string.lstrip("#").strip()) and len(tok.string.strip("# ")) >= 3:
                    aus.append((datei, tok.start[0], tok.string.lstrip("#").strip()))
        except (tokenize.TokenError, IndentationError, SyntaxError):
            pass
        try:
            for n in ast.walk(ast.parse(code)):
                if isinstance(n, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and n.body \
                        and isinstance(n.body[0], ast.Expr) and isinstance(getattr(n.body[0], "value", None), ast.Constant) \
                        and isinstance(n.body[0].value.value, str):
                    aus.append((datei, n.body[0].lineno, n.body[0].value.value.strip()))
        except (SyntaxError, ValueError, RecursionError):
            pass
    return sorted(aus, key=lambda x: (x[0], x[1]))


def texte(stand, thema_k, thema, dateien, start):
    """Was eine Abgabe an eigenem TEXT enthaelt: [{art, wo, text}] -- Klausurtexte, Mini-Exit, Kommentare im Code
    (ohne die der Startdatei)."""
    aus = []
    nr_von = {k["name"]: a["nr"] for a in thema["uebung"]["aufgaben"] for k in a.get("klausur") or []}
    for k, g in sorted((stand.get("klausuren") or {}).items()):
        if k.startswith(thema_k + "/") and (g or {}).get("text", "").strip():
            aus.append({"art": "klausur", "wo": "Aufgabe %s · wie in der Klausur" % nr_von.get(k.rsplit("/", 1)[-1], "?"), "text": g["text"].strip()})
    me = ((stand.get("aufgaben") or {}).get(thema_k + "/miniexit") or {}).get("miniexit", "")
    if isinstance(me, str) and me.strip():
        aus.append({"art": "miniexit", "wo": "Mini-Exit", "text": me.strip()})
    vorgabe = {t for _, _, t in kommentare({"s%d" % i: c for i, c in enumerate(start)})}
    for datei, zeile, t in kommentare(dateien):
        if t not in vorgabe:
            aus.append({"art": "kommentar", "wo": "%s Zeile %d" % (datei, zeile), "text": t})
    return aus


def abdruck(liste):
    import hashlib
    return hashlib.sha256(json.dumps([x["text"] for x in liste], ensure_ascii=False).encode("utf-8")).hexdigest()[:16]


def mappe_schreiben(wurzel, eintraege, themen):
    """eintraege: [{name, thema, texte}] (nur mit Text); themen: {kennung: {titel, begriffe, aufgaben}}.
    Nummern und P-Nummern zufaellig -- die Reihenfolge der Kursliste verriete die Namen."""
    import random
    zufall = random.SystemRandom()
    personen = sorted({e["name"] for e in eintraege})
    zufall.shuffle(personen)
    pnr = {n: "P%02d" % i for i, n in enumerate(personen, 1)}
    folge = list(eintraege)
    zufall.shuffle(folge)
    mappe = {"erzeugt": _jetzt(), "anleitung": ANLEITUNG, "themen": themen, "abgaben": []}
    zuordnung = {}
    for i, e in enumerate(folge, 1):
        nr = "%03d" % i
        mappe["abgaben"].append({"nummer": nr, "person": pnr[e["name"]], "thema": e["thema"], "texte": e["texte"]})
        zuordnung[nr] = {"name": e["name"], "thema": e["thema"], "abdruck": abdruck(e.get("roh", e["texte"]))}
    o = wurzel / MAPPE_ORDNER
    o.mkdir(parents=True, exist_ok=True)
    (o / ZUORDNUNG).write_text(json.dumps(zuordnung, ensure_ascii=False, indent=1), "utf-8")
    (o / MAPPE).write_text(json.dumps(mappe, ensure_ascii=False, indent=1), "utf-8")
    alt = o / BEOBACHTUNGEN
    if alt.exists():                       # Beobachtungen gehoeren zu den Nummern der alten Mappe
        alt.rename(o / ("indizien_beobachtungen_bis_%s.json" % _jetzt().replace(":", "-")))
    return o / MAPPE, len(folge), len(personen)


def _jetzt():
    import datetime
    return datetime.datetime.now().replace(microsecond=0).isoformat()


def beobachtungen(wurzel, name, thema, texte_jetzt):
    """Claudes Beobachtungen zu dieser Abgabe -- nur, wenn sie zu genau diesen Texten gehoeren. -> Indiz oder None."""
    o = wurzel / MAPPE_ORDNER
    try:
        zu = json.loads((o / ZUORDNUNG).read_text("utf-8"))
        be = json.loads((o / BEOBACHTUNGEN).read_text("utf-8"))
    except (OSError, ValueError):
        return None
    for nr, z in zu.items():
        if z.get("name") == name and z.get("thema") == thema and z.get("abdruck") == abdruck(texte_jetzt) and nr in be:
            liste = [b for b in (be[nr] or {}).get("beobachtungen") or [] if isinstance(b, dict) and b.get("was")]
            if not liste:
                return None
            return {"art": "claude", "staerke": "claude", "kurz": "Claude: %d Beobachtung%s" % (len(liste), "" if len(liste) == 1 else "en"),
                    "text": "Beobachtungen an den Texten (Abgabe %s der Mappe) – kein Urteil." % nr,
                    "beobachtungen": [{"was": str(b["was"])[:400], "zitat": str(b.get("zitat", ""))[:400]} for b in liste[:8]]}
    return None
