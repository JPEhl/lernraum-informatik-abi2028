"""Die Regeln der Klassendiagramme wie im Abitur -- EINE Fassung in Python fuer den Zeichner und den Server.

Seit 13.11.2026 (Aufgabenart „Diagramm“, Lehrer: „es soll dafuer auch Sterne und Selbstchecks geben“): Der Server
des Lernraums rechnet den Stern einer Diagramm-Aufgabe aus der Abgabe nach, wie bei „Plan“ -- also muss er die
Konvention kennen und gegen die Aufgabe pruefen. Bewusst eigenstaendig (wie plan.py): Der Server laeuft auch auf dem
Stick der Klasse, ohne werkstatt/_scripts/. Der Zeichner werkstatt/_scripts/uml.py holt seine Regeln VON HIER
(vorher standen sie dort).

DER ZWEITE LAEUFER ist der Kern der Werkstatt im Browser (werkstatt/lernraum/werkstatt/klassendiagramm.js): dieselben
Codes, dieselbe Pruefung gegen die Aufgabe. test/uml_gleichlauf.py haelt beide gleich; wer hier eine Regel aendert,
aendert sie dort mit.

    befunde(text)                      [(zeile, code)] einer .uml-Quelle
    eintrag_befunde(text, methode)     die Codes einer Zeile (die Quelle weiss Methode aus den Klammern)
    zeile_pruefen(text, methode, k)    wie die Werkstatt: das FACH weiss, ob die Zeile Methode sein soll
    modell(text)                       nachsichtig gelesen: {klassen, beziehungen, lage, titel, namen, nicht}
    vergleichen(ist, soll, stufe)      {ok, meldungen} -- Pruefen gegen die Aufgabe (verraet nicht, WAS fehlt)
"""
import re
from dataclasses import dataclass, field

ERLAUBTE_TYPEN = {"String", "integer", "float", "boolean"}
FALSCHE_TYPEN = {
    "Integer": "integer", "Int": "integer", "int": "integer", "Boolean": "boolean", "bool": "boolean",
    "Bool": "boolean", "Float": "float", "Double": "float", "double": "float", "str": "String",
    "string": "String", "Str": "String", "List": "list[…]", "None": "(nichts)", "void": "(nichts)",
}
BEZIEHUNG = re.compile(r"^(\w+)\s*(<>-|->|--\|>)\s*(\w+)$")
NAME = re.compile(r"^[A-Za-zÄÖÜäöüß_][\wÄÖÜäöüß]*$")


class Verstoss(Exception):
    """Die Meldungen stehen im Text (eine je Zeile) und als Liste `befunde` (Befund: Text mit .code und .zeile)."""

    def __init__(self, befunde):
        super().__init__("\n".join(befunde))
        self.befunde = list(befunde)


class Befund(str):
    """Eine Meldung -- als Text wie bisher, dazu ein fester Code und die Zeile der Quelle (0 = ohne Zeile). Die Codes
    teilt sich der Zeichner mit dem zweiten Laeufer in werkstatt/lernraum/werkstatt/klassendiagramm.js (die Werkstatt
    sagt dieselbe Regel freundlicher); test/uml_gleichlauf.py haelt beide gleich."""
    code = ""
    zeile = 0


def _melden(fehler: list, code: str, text: str) -> None:
    b = Befund(text)
    b.code = code
    m = re.match(r"Zeile (\d+)", text)
    b.zeile = int(m.group(1)) if m else 0
    fehler.append(b)


@dataclass
class Eintrag:
    zeile: int
    text: str
    methode: bool


@dataclass
class Klasse:
    name: str
    zeile: int
    eintraege: list = field(default_factory=list)


@dataclass
class Diagramm:
    klassen: list = field(default_factory=list)
    beziehungen: list = field(default_factory=list)      # (von, art, nach, zeile)
    lage: str = "untereinander"
    spalten: int = 1
    titel: str = ""
    loesung: bool = False


# --- Lesen und Pruefen ---------------------------------------------------------------------------------------
def _typ_pruefen(typ: str, wo: str, fehler: list, klassen: set) -> None:
    typ = typ.strip()
    if not typ:
        _melden(fehler, "typ_fehlt", "%s: ein Typ fehlt" % wo)
        return
    m = re.fullmatch(r"(\w+)\[(.+)\]", typ)
    if m:
        if m.group(1) != "list":
            _melden(fehler, "typ_liste", "%s: Typ %s -- im Abitur list[…]" % (wo, typ))
        _typ_pruefen(m.group(2), wo, fehler, klassen)
        return
    if typ in FALSCHE_TYPEN:
        _melden(fehler, "typ_falsch", "%s: Typ %s -- im Abitur %s" % (wo, typ, FALSCHE_TYPEN[typ]))
        return
    if typ in ERLAUBTE_TYPEN or typ in klassen:
        return
    if not NAME.match(typ) or not typ[0].isupper():
        _melden(fehler, "typ_unbekannt", "%s: Typ %r -- erlaubt sind String, integer, float, boolean, list[…] und Klassennamen" % (wo, typ))


def _eintrag_pruefen(e: Eintrag, klasse: str, fehler: list, klassen: set) -> None:
    wo = "Zeile %d (%s)" % (e.zeile, klasse)
    t = e.text
    if " :" in t:
        _melden(fehler, "leer_vor_doppelpunkt", "%s: Leerzeichen vor dem Doppelpunkt -- `name: Typ`" % wo)
    if not t[:1] in ("+", "-", "#") or t[1:2] != " ":
        _melden(fehler, "sichtbarkeit", "%s: vorn steht die Sichtbarkeit und ein Leerzeichen (`- `, `+ `, `# `): %r" % (wo, t))
        return
    sicht, rest = t[0], t[2:].strip()
    if e.methode:
        m = re.fullmatch(r"(\w+)\((.*)\)(?::\s*(.+))?", rest)
        if not m:
            _melden(fehler, "methode_form", "%s: keine Methode der Form `name(p: Typ): Typ`: %r" % (wo, t))
            return
        name, par, rueck = m.groups()
        if name == "__init__":
            if sicht != "-":
                _melden(fehler, "init_plus", "%s: der Konstruktor ist `- __init__(…)` (mit Minus), nicht %s" % (wo, sicht))
            if rueck is not None:
                _melden(fehler, "init_rueckgabe", "%s: der Konstruktor hat keine Rueckgabe" % wo)
        elif name.startswith("__"):
            _melden(fehler, "dunder_name", "%s: `%s` -- im Diagramm ohne __ (die Sichtbarkeit sagt das Minus)" % (wo, name))
        if rueck is not None:
            if rueck.strip() == "None":
                _melden(fehler, "none", "%s: `: None` -- eine Methode ohne Rueckgabe hat keinen Typ dahinter" % wo)
            else:
                _typ_pruefen(rueck, wo + " Rueckgabe", fehler, klassen)
        for p in [x.strip() for x in _teilen(par)] if par.strip() else []:
            if p == "self":
                _melden(fehler, "self", "%s: `self` steht nicht im Diagramm" % wo)
                continue
            pm = re.fullmatch(r"(\w+):\s*(.+)", p)
            if not pm:
                _melden(fehler, "parameter_ohne_typ", "%s: Parameter %r ohne Typ -- `name: Typ`" % (wo, p))
                continue
            if pm.group(1) == "self":
                _melden(fehler, "self", "%s: `self` steht nicht im Diagramm" % wo)
            if pm.group(1).startswith("__"):
                _melden(fehler, "dunder_parameter", "%s: Parameter `%s` mit __" % (wo, pm.group(1)))
            _typ_pruefen(pm.group(2), wo + " Parameter " + pm.group(1), fehler, klassen)
    else:
        m = re.fullmatch(r"(\w+)(?::\s*(.*))?", rest)
        if not m:
            _melden(fehler, "attribut_form", "%s: kein Attribut der Form `name: Typ`: %r" % (wo, t))
            return
        name, typ = m.groups()
        if name.startswith("__"):
            _melden(fehler, "dunder_name", "%s: `%s` -- im Diagramm ohne __ (im Code `self.%s`, im Diagramm `- %s`)"
                          % (wo, name, name, name.lstrip("_")))
        if typ is None:
            _melden(fehler, "attribut_ohne_typ", "%s: Attribut `%s` ohne Typ" % (wo, name))
        else:
            _typ_pruefen(typ, wo, fehler, klassen)


def _teilen(par: str) -> list:
    """Parameter an Kommas trennen, nicht in list[…]."""
    teile, tiefe, aktuell = [], 0, ""
    for c in par:
        if c == "[":
            tiefe += 1
        elif c == "]":
            tiefe -= 1
        if c == "," and tiefe == 0:
            teile.append(aktuell)
            aktuell = ""
        else:
            aktuell += c
    teile.append(aktuell)
    return teile


def lesen(text: str) -> Diagramm:
    d = Diagramm()
    fehler = []
    aktuell = None
    for nr, roh in enumerate(text.splitlines(), 1):
        # Kommentar ist nur ein # am Zeilenanfang -- eingerueckt ist `# wurzel: Knoten` ein geschuetztes Attribut
        if not roh.strip() or roh.startswith("#"):
            continue
        if roh[:1] in (" ", "\t"):
            if aktuell is None:
                _melden(fehler, "ohne_klasse", "Zeile %d: eingerueckt, aber keine `klasse` darueber" % nr)
                continue
            t = roh.strip()
            e = Eintrag(nr, t, "(" in t)
            if not e.methode and any(x.methode for x in aktuell.eintraege):
                _melden(fehler, "attribut_nach_methode", "Zeile %d (%s): Attribut nach einer Methode -- erst die Attribute, dann die Methoden" % (nr, aktuell.name))
            aktuell.eintraege.append(e)
            continue
        aktuell = None
        t = roh.strip()
        if t.startswith("klasse "):
            name = t[len("klasse "):].strip()
            if not NAME.match(name):
                _melden(fehler, "klassenname", "Zeile %d: Klassenname %r" % (nr, name))
            elif any(k.name == name for k in d.klassen):
                _melden(fehler, "klasse_doppelt", "Zeile %d: die Klasse %s steht zweimal da" % (nr, name))
            aktuell = Klasse(name, nr)
            d.klassen.append(aktuell)
        elif t.startswith("lage:"):
            w = t[5:].split()
            if w == ["untereinander"] or w == ["nebeneinander"]:
                d.lage = w[0]
            elif len(w) == 2 and w[0] == "raster" and w[1].isdigit() and int(w[1]) >= 1:
                d.lage, d.spalten = "raster", int(w[1])
            else:
                _melden(fehler, "lage", "Zeile %d: `lage:` untereinander · nebeneinander · raster <Spalten>" % nr)
        elif t.startswith("titel:"):
            d.titel = t[6:].strip()
        elif t.startswith("art:"):
            if t[4:].strip() != "loesung":
                _melden(fehler, "art", "Zeile %d: `art:` kennt nur loesung" % nr)
            d.loesung = True
        else:
            m = BEZIEHUNG.match(t)
            if not m:
                _melden(fehler, "unbekannt", "Zeile %d: unbekannt: %r (klasse …, lage:, titel:, art:, A <>- B, A -> B, A --|> B)" % (nr, t))
            else:
                d.beziehungen.append((m.group(1), m.group(2), m.group(3), nr))
    namen = {k.name for k in d.klassen}
    if not d.klassen:
        _melden(fehler, "keine_klasse", "keine Klasse in der Quelle")
    for k in d.klassen:
        for e in k.eintraege:
            _eintrag_pruefen(e, k.name, fehler, namen)
    gesehen = set()
    for von, art, nach, nr in d.beziehungen:
        for x in dict.fromkeys((von, nach)):
            if x not in namen:
                _melden(fehler, "beziehung_klasse", "Zeile %d: die Beziehung nennt %s, eine solche Klasse steht nicht in der Quelle" % (nr, x))
        # zu sich selbst nur der Pfeil (seit 17.11.2026): Element -> Element wie LA 2026 LK Beispielaufgabe AP,
        # Loesung 5.1 (Knoten und Element je mit einer Schleife, offene Pfeilspitze). Raute oder Dreieck zu sich
        # selbst steht in keinem Jahrgang.
        if von == nach and art != "->":
            _melden(fehler, "beziehung_selbst", "Zeile %d: zu sich selbst zeichnet das Abitur nur den Pfeil (`%s -> %s`), keine Raute und kein Dreieck" % (nr, von, von))
        if frozenset((von, nach)) in gesehen:
            _melden(fehler, "beziehung_doppelt", "Zeile %d: zwischen %s und %s steht schon eine Beziehung" % (nr, von, nach))
        gesehen.add(frozenset((von, nach)))
    if fehler:
        raise Verstoss(fehler)
    return d


def befunde(text: str) -> list:
    """[(zeile, code), …] einer Quelle, leer = nach Konvention (fuer den Gleichlauf mit der Werkstatt)."""
    try:
        lesen(text)
    except Verstoss as e:
        return [(b.zeile, b.code) for b in e.befunde]
    return []


def eintrag_befunde(text: str, methode: bool, klassen=()) -> list:
    """Die Codes zu EINER Zeile eines Fachs -- wie die Werkstatt sie beim Verlassen der Zeile prueft. Dort weiss das Fach,
    ob die Zeile eine Methode sein soll; in der Quelle sagen es die Klammern."""
    fehler = []
    _eintrag_pruefen(Eintrag(1, text, methode), "K", fehler, set(klassen))
    return [b.code for b in fehler]


# --- Wie die Werkstatt: das Fach, das Modell, das Pruefen gegen die Aufgabe (13.11.2026) --------------------------
def zeile_pruefen(text: str, methode: bool, klassen=()) -> list:
    """Codes einer Zeile in ihrem Fach -- wie K.zeilePruefen im Browser. Oben eine Zeile mit „(“: gehoert ins untere
    Fach; unten ohne Klammern: „Klammern“; ein Leerzeichen vor dem Doppelpunkt ohne seine Folgemeldungen."""
    k = set(klassen)
    if not methode and "(" in text:
        return ["methode_im_attributfach"]
    f = eintrag_befunde(text, methode, k)
    if "leer_vor_doppelpunkt" in f:
        f = ["leer_vor_doppelpunkt"] + eintrag_befunde(re.sub(r"\s+:", ":", text), methode, k)
    if methode and "(" not in text:
        f = ["methode_ohne_klammern" if c == "methode_form" else c for c in f]
    return f


_NAMEN = re.compile(r"^#\s*namen:\s*(.+)$")
_NICHT = re.compile(r"^#\s*nicht:\s*([^=]+?)\s*=\s*(.+)$")


def modell(text: str) -> dict:
    """Die Quelle nachsichtig als Modell (wie K.modell): Zeilen mit „(“ ins untere Fach."""
    d = {"klassen": [], "beziehungen": [], "lage": "", "titel": "", "namen": [], "nicht": {}}
    akt = None
    for roh in re.split(r"\r\n|\r|\n", str(text or "")):
        if not roh.strip():
            continue
        if roh.startswith("#"):
            m = _NAMEN.match(roh)
            if m:
                d["namen"].append(m.group(1).strip().split())
                continue
            m = _NICHT.match(roh)
            if m:
                d["nicht"][m.group(1).strip()] = m.group(2).strip()
            continue
        if roh[:1] in (" ", "\t") and akt is not None:
            t = roh.strip()
            akt["methoden" if "(" in t else "attribute"].append(t)
            continue
        akt = None
        t = roh.strip()
        if t.startswith("klasse "):
            akt = {"name": t[7:].strip(), "attribute": [], "methoden": []}
            d["klassen"].append(akt)
        elif t.startswith("lage:"):
            d["lage"] = t[5:].strip()
        elif t.startswith("titel:"):
            d["titel"] = t[6:].strip()
        else:
            m = BEZIEHUNG.match(t)
            if m:
                d["beziehungen"].append({"von": m.group(1), "art": m.group(2), "nach": m.group(3)})
    return d


def _zerlegen(t: str, methode: bool) -> dict:
    sicht, rest = t[0], t[2:].strip()
    if methode:
        m = re.fullmatch(r"(\w+)\((.*)\)(?::\s*(.+))?", rest)
        params = []
        if m.group(2).strip():
            for p in _teilen(m.group(2)):
                pm = re.fullmatch(r"(\w+):\s*(.+)", p.strip())
                params.append({"name": pm.group(1), "typ": pm.group(2).strip()})
        return {"sicht": sicht, "name": m.group(1), "methode": True, "rueck": (m.group(3) or "").strip(), "params": params}
    m = re.fullmatch(r"(\w+)(?::\s*(.*))?", rest)
    return {"sicht": sicht, "name": m.group(1), "typ": (m.group(2) or "").strip(), "methode": False}


STUFEN = ["klassen", "kapsel", "beziehung", "erben"]


def _norm(s: str) -> str:
    s = str(s).lower().replace("ä", "ae").replace("ö", "oe").replace("ü", "ue").replace("ß", "ss")
    return re.sub(r"^setze_", "set_", re.sub(r"^(gib|hole)_", "get_", s))


def _sichtfrage(name: str, eintrag: str, a: str, b: str) -> str:
    """Die Sichtbarkeit passt nicht zum Text. `#` (geschuetzt) steht im Abitur (LA 2026 LK Beispielaufgabe AP,
    `# wurzel: Knoten`, im Code `self._wurzel`) -- ist es im Spiel, nennt die Frage alle drei; sonst bleibt sie bei
    privat oder oeffentlich (geschuetzt ist in iq1 nur ein Rand in `erben`, LT9)."""
    wahl = "privat, geschützt oder öffentlich" if "#" in (a, b) else "privat oder öffentlich"
    return "%s: %s – %s? Lies im Text nach." % (name, eintrag, wahl)


def vergleichen(ist: dict, soll: dict, stufe: str = "klassen") -> dict:
    """Pruefen gegen die Aufgabe -- wortgleich mit K.vergleichen (Browser). ist/soll: Modelle (klassen mit attribute
    und methoden getrennt, wie die Werkstatt sie haelt). Gibt {"ok": bool, "meldungen": [text, …]}."""
    st = STUFEN.index(stufe) if stufe in STUFEN else 0
    m = []
    alt = {}
    for g in soll.get("namen") or []:
        for n in g:
            alt[_norm(n)] = _norm(g[0])

    def nn(s):
        return alt.get(_norm(s), _norm(s))
    namen_ist = {k["name"] for k in ist["klassen"]}
    rot = any(zeile_pruefen(t, False, namen_ist) for k in ist["klassen"] for t in k["attribute"]) or \
        any(zeile_pruefen(t, True, namen_ist) for k in ist["klassen"] for t in k["methoden"])
    if rot:
        return {"ok": False, "meldungen": ["Erst die rot markierten Zeilen richtig schreiben – dann prüft die Werkstatt gegen die Aufgabe."]}
    sk = {}
    for k in soll["klassen"]:
        sk.setdefault(nn(k["name"]), k)
    ik = {}
    for k in ist["klassen"]:
        ik.setdefault(nn(k["name"]), k)
    fehlend = sum(1 for n in sk if n not in ik)
    if fehlend:
        m.append("Im Text steht noch eine Klasse, die im Diagramm fehlt." if fehlend == 1 else
                 "Im Text stehen noch %d Klassen, die im Diagramm fehlen." % fehlend)
    for k in ist["klassen"]:
        if nn(k["name"]) in sk:
            continue
        h = next((x for x in (soll.get("nicht") or {}) if nn(x) == nn(k["name"])), None)
        m.append(soll["nicht"][h] if h else "Eine Klasse %s steht so nicht im Text." % k["name"])
    for n, s in sk.items():
        k = ik.get(n)
        if not k:
            continue
        name = k["name"]
        sa = [_zerlegen(t, False) for t in s["attribute"]]
        ia = [_zerlegen(t, False) for t in k["attribute"]]
        sm = [_zerlegen(t, True) for t in s["methoden"]]
        im = [_zerlegen(t, True) for t in k["methoden"]]
        fa = fm = 0
        for a in sa:
            b = next((x for x in ia if nn(x["name"]) == nn(a["name"])), None)
            if not b:
                fa += 1
                continue
            b["gefunden"] = True
            if b["typ"] != a["typ"]:
                m.append("%s: Der Typ von %s passt nicht zum Text." % (name, b["name"]))
            elif st >= 1 and b["sicht"] != a["sicht"]:
                m.append(_sichtfrage(name, b["name"], a["sicht"], b["sicht"]))
        for x in ia:
            if not x.get("gefunden"):
                m.append("%s: %s steht so nicht im Text." % (name, x["name"]))
        for a in sm:
            b = next((x for x in im if nn(x["name"]) == nn(a["name"])), None)
            if not b:
                fm += 1
                continue
            b["gefunden"] = True
            ta, tb = [p["typ"] for p in a["params"]], [p["typ"] for p in b["params"]]
            gleich = sorted(ta) == sorted(tb) if a["name"] == "__init__" else ta == tb
            if not gleich:
                m.append("%s: %s laut Text andere Werte mit." % (name, "Der Konstruktor bekommt" if a["name"] == "__init__" else b["name"] + " bekommt"))
            if a["rueck"] != b["rueck"]:
                m.append("%s: Was gibt %s zurück? Lies im Text nach." % (name, b["name"]))
            if st >= 1 and a["name"] != "__init__" and a["sicht"] != b["sicht"]:
                m.append(_sichtfrage(name, b["name"], a["sicht"], b["sicht"]))
        for x in im:
            if not x.get("gefunden"):
                m.append("%s: %s verlangt der Text nicht." % (name, "Einen Konstruktor" if x["name"] == "__init__" else x["name"]))
        if fa:
            m.append("Im Text steht noch eine Angabe zu %s, die im Diagramm fehlt." % name if fa == 1 else
                     "Im Text stehen noch %d Angaben zu %s, die im Diagramm fehlen." % (fa, name))
        if fm:
            m.append("%s kann laut Text noch etwas, das im Diagramm fehlt." % name if fm == 1 else
                     "%s kann laut Text noch %d Dinge, die im Diagramm fehlen." % (name, fm))
    sb = [{"von": nn(b["von"]), "nach": nn(b["nach"]), "art": b["art"]} for b in soll["beziehungen"]]
    namen_n = {nn(k["name"]): k["name"] for k in reversed(ist["klassen"])}
    gefunden = set()
    fehlt_b = fehlt_s = 0
    for s in sb:
        paar = sorted([s["von"], s["nach"]])
        i = next((j for j, x in enumerate(ist["beziehungen"]) if sorted([nn(x["von"]), nn(x["nach"])]) == paar), None)
        if i is None:
            if s["von"] in ik and s["nach"] in ik:
                if s["von"] == s["nach"]:
                    fehlt_s += 1        # zu sich selbst (17.11.): nicht „zwischen zwei Klassen“
                else:
                    fehlt_b += 1
            continue
        gefunden.add(i)
        b = ist["beziehungen"][i]
        if b["art"] != s["art"]:
            m.append("Zwischen %s und %s: hält das eine das andere (Raute) oder kennt es es nur (Pfeil)?"
                     % (namen_n.get(s["von"], s["von"]), namen_n.get(s["nach"], s["nach"])))
        elif nn(b["von"]) != s["von"]:
            m.append("Die Raute sitzt falsch herum: Sie gehört an den Kasten, der den anderen hält." if b["art"] == "<>-" else
                     "Der Pfeil zeigt falsch herum: Er zeigt auf die Klasse, die gekannt wird." if b["art"] == "->" else
                     "Das Dreieck sitzt an der allgemeineren Klasse.")
    for j, b in enumerate(ist["beziehungen"]):
        if j not in gefunden:
            m.append("Die Beziehung zwischen %s und %s steht nicht im Text." % (b["von"], b["nach"]))
    if fehlt_b:
        m.append("Zwischen zwei Klassen fehlt noch eine Beziehung." if fehlt_b == 1 else "Es fehlen noch %d Beziehungen." % fehlt_b)
    if fehlt_s:
        m.append("Eine Klasse hat laut Text noch eine Beziehung zu sich selbst." if fehlt_s == 1 else
                 "%d Klassen haben laut Text noch eine Beziehung zu sich selbst." % fehlt_s)
    if m:
        return {"ok": False, "meldungen": m}
    return {"ok": True, "meldungen": ["Alle Klassen, Attribute und Methoden aus dem Text, in der Form des Abiturs."
                                      + (" Die Beziehungen stimmen." if st >= 2 and sb else "")]}
