"""pruefen -- der Selbstcheck ohne pytest (nur Standardbibliothek).

Eine Pruefdatei (pruefung.py im Themenordner) sieht so aus:

    from pruefen import erwarte, noch_nicht_dran, arbeit, quelltext

    def pruefe_10_liste_da():
        \"\"\"Aufgabe 1 · Es gibt eine Liste namens rucksack\"\"\"
        erwarte(isinstance(getattr(arbeit(), "rucksack", None), list),
                "Noch keine Liste namens rucksack gefunden.")

Drei Zustaende, nicht zwei (wie seit dem 2026-09-01 in conftest.py):
    passt            -- hingesehen, zufrieden
    offen            -- hingesehen, etwas gefunden (erwarte() schlug an)
    spaeter          -- konnte nicht hinsehen, Voraussetzung fehlt (noch_nicht_dran())

Diagnose, keine Wegweisung: Die Meldung sagt, WAS nicht stimmt, nie wo der
Ausweg steht (sonst spielt der Check die gestufte Hilfe aus).

Aufruf (so ruft es der Server, isoliert, mit Zeitlimit von aussen):
    python -I pruefen.py <pruefung.py> <arbeitsdatei.py> [--json | --text]

Die Arbeitsdatei laeuft EINMAL in diesem Prozess, mit stillgelegtem
tkinter-mainloop und ohne input(); die Pruefungen sehen genau das Fenster,
das die Klasse gebaut hat, kein zweites.

HTML (29.10.2026, Kapitel webseite): Ist die Arbeitsdatei ein ORDNER (die
Gepaecksuche), laeuft nichts; die Pruefungen lesen ihre Seiten mit seite():

    def pruefe_10_ueberschrift():
        \"\"\"Aufgabe 2 · Keflavík: eine Überschrift h1\"\"\"
        s = seite("keflavik.html")
        erwarte(not s.offen(), s.meldung_offen())
        erwarte(s.text("h1") == "Keflavík", "Noch keine Überschrift h1 mit dem Namen der Station.")

Geprueft wird der QUELLTEXT, strenger als der Browser: jedes geoeffnete Tag
braucht sein Ende (auch p und li), sonst meldet offen() es mit Zeile.

Klassen (11.11.2026, fuer iq1 schach): Die Pruefung baut eigene Objekte und
ruft ihre Methoden -- ueber die Helfer, nicht ueber arbeit().Figur, damit ein
falscher Konstruktor oder ein Abbruch eine Meldung mit Datei und Zeile wird:

    def pruefe_10_merkt_sich():
        \"\"\"Aufgabe 1 · Die Figur merkt sich ihr neues Feld\"\"\"
        figur = erzeuge("Figur", "Probe", 1, 1)
        rufe(figur, "ziehe", 5, 2)
        erwarte(rufe(figur, "get_zeile") == 5, "Nach ziehe(5, 2) sagt get_zeile() noch nicht 5.")

klasse(name) · erzeuge(klasse, ...) · rufe(objekt, "methode", ...) ·
gedruckt() · attribute(objekt) · angaben(klasse, "methode") ·
quelltext("figur.py") · bilder() und bild_auf(x, y) auf der Zeichenflaeche.

Klick auf die Zeichenflaeche (15.11.2026, iq1 schach ab `brett`): klick_auf(x, y)
klickt wie die Maus auf eine Stelle der Flaeche und gibt zurueck, was dabei
in der Shell erschien; danach liest die Pruefung die Flaeche wie sonst.
"""
import inspect
import json
import os
import pathlib
import re
import runpy
import sys
import textwrap
import time
import traceback
import types


class NochNichtDran(Exception):
    pass


class Offen(AssertionError):
    pass


class _ZuLang(BaseException):
    """Die Arbeitsdatei laeuft laenger als die Zeitgrenze -- fast immer eine Endlosschleife.
    BaseException, damit ein `except Exception` der Klasse sie nicht verschluckt."""


# Zeitgrenze je Lauf (Laden, jedes Anspielen, jede Pruefung). Vorher brach erst der Server nach 30 s
# den GANZEN Selbstcheck ab -- eine Endlosschleife in der Kuer kostete auch die Pflicht (Reihensichtung
# Teil I, 25.10., T8 Quersumme mit `z // 10` ohne Zuweisung).
ZEITGRENZE = 4.0
ENDLOS = ("Das Programm läuft hier endlos weiter. Ändert sich in der Schleife etwas, "
          "das die Bedingung irgendwann falsch macht?")


def _mit_zeitgrenze(fn, sekunden=None):
    """fn() ausfuehren; dauert es laenger als die Zeitgrenze, fliegt _ZuLang (ueber sys.settrace,
    also auch unter Windows, wo es kein SIGALRM gibt)."""
    ende = time.monotonic() + (ZEITGRENZE if sekunden is None else sekunden)
    zaehler = [0]

    def spur(frame, ereignis, arg):
        zaehler[0] += 1
        if zaehler[0] % 1000 == 0 and time.monotonic() > ende:
            raise _ZuLang()
        return spur
    alt = sys.gettrace()
    sys.settrace(spur)
    try:
        return fn()
    finally:
        sys.settrace(alt)


_ARBEIT = None
_ORDNER = None          # HTML: der Ordner der Seiten (die Arbeitsdatei ist ein Ordner)
_SEITEN = {}
_QUELLE = ""
_ARBEITSDATEI = None
_PRUEFUNG = None        # die Pruefdatei selbst -- eine Abbruchstelle liegt nie in ihr
_MODULE = {}            # Python-Ordner: die Module, die das Programm beim ersten Lauf aus seinem Ordner geladen hat
_GEDRUCKT = ""          # was der letzte Aufruf ueber erzeuge()/rufe() in die Shell geschrieben hat
_EINGABEN = []
_AUSGABE = None


def ausgabe():
    """Alles, was die Arbeitsdatei beim Anspielen gedruckt hat."""
    return _AUSGABE.getvalue() if _AUSGABE is not None else ""


def erwarte(bedingung, meldung="passt noch nicht"):
    """Wie assert, aber mit Pflicht zur Meldung."""
    if not bedingung:
        raise Offen(meldung)


def noch_nicht_dran(grund=""):
    """Die Pruefung kann noch nicht hinsehen -- dritter Zustand."""
    raise NochNichtDran(grund)


def braucht(bedingung, grund=""):
    if not bedingung:
        noch_nicht_dran(grund)


def arbeit():
    """Das Modul der Arbeitsdatei, so wie sie gelaufen ist."""
    return _ARBEIT


def _programmordner():
    """Der Ordner des Programms: bei HTML der Arbeitsordner, sonst der Ordner der Startdatei."""
    if _ORDNER is not None:
        return _ORDNER
    return _ARBEITSDATEI.parent if _ARBEITSDATEI is not None else pathlib.Path.cwd()


def quelltext(datei=None):
    """Der Quelltext der Startdatei -- mit datei="figur.py" der einer anderen Datei im Ordner des Programms
    (11.11.2026; "" , wenn es sie nicht gibt)."""
    if datei is None:
        return _QUELLE
    try:
        return (_programmordner() / datei).read_text("utf-8", errors="replace")
    except OSError:
        return ""


def ohne_kommentare(datei=None):
    return "\n".join(z for z in quelltext(datei).splitlines() if not z.strip().startswith("#"))


def eigene_kommentare(vorgegeben=(), mindestlaenge=12, datei=None):
    """Kommentarzeilen, die nicht aus der Vorlage stammen -- fuer Aufgaben,
    die eine Beobachtung verlangen (geprueft wird, DASS etwas dasteht)."""
    return [z.strip() for z in quelltext(datei).splitlines()
            if z.strip().startswith("#") and len(z.strip()) > mindestlaenge
            and not any(v in z for v in vorgegeben)]


def anspielen(eingaben):
    """Die Arbeitsdatei noch einmal laufen lassen, mit anderen Eingaben (Sterne, 16.10.): So
    prueft eine Kuer das VERHALTEN an mehreren Befehlen, nicht eine hingeschriebene Antwort.
    Gibt (ausgabe, namen) zurueck; bricht das Programm ab, endet die Ausgabe dort.

    Python-Ordner (11.11.2026): Die Module des Ordners werden dabei neu geladen -- vorher lief `from figur import
    Figur` gegen das Modul vom ersten Lauf, und was es sich gemerkt hatte (eine Liste oben in figur.py), stand beim
    zweiten Lauf noch da."""
    import io
    global _AUSGABE
    for name in [n for n, m in sys.modules.items() if _im_ordner_geladen(m)]:
        del sys.modules[name]
    alt_ein, alt_aus, alt_out, alt_fenster = list(_EINGABEN), _AUSGABE, sys.stdout, _standardfenster()
    _EINGABEN[:] = [str(x) for x in eingaben]
    puffer = io.StringIO()
    _AUSGABE = puffer
    ns = {"__name__": "anspielen", "__file__": str(_ARBEITSDATEI)}
    sys.stdout = puffer
    endlos = False
    try:
        _mit_zeitgrenze(lambda: exec(compile(_QUELLE, str(_ARBEITSDATEI), "exec"), ns))      # noqa: S102
    except _ZuLang:
        endlos = True
    except BaseException:       # noqa: BLE001 -- Abbruch oder Ende der Eingaben: so weit ist es gekommen
        pass
    finally:
        sys.stdout, _AUSGABE = alt_out, alt_aus
        _EINGABEN[:] = alt_ein
        _standardfenster(alt_fenster)
    if endlos:
        raise Offen(ENDLOS)
    return puffer.getvalue(), ns


# -- Fenster (Teil III, 25.10.) --------------------------------------------------------------------------
# Die Pruefung klickt wie die Klasse: ueber die BESCHRIFTUNG eines Knopfs, nicht ueber Variablennamen. Kein
# Fenster geht dabei auf (_still_stellen); ein Fehler in einer Knopf-Funktion wird zum Befund, nicht zum Absturz.
_TK_WURZELN = []
_TK_FEHLER = []
_FENSTER = None


def fenster():
    """Das Fenster (tk.Tk), das die Arbeitsdatei gebaut hat -- oder None."""
    return _FENSTER


def elemente(art=None):
    """Alle Elemente im Fenster, der Reihe nach; art = "Button", "Label", "Entry", "Text" filtert."""
    if _FENSTER is None:
        return []
    aus, offen = [], list(_FENSTER.winfo_children())
    while offen:
        w = offen.pop(0)
        if art is None or w.winfo_class() == art:
            aus.append(w)
        offen[0:0] = list(w.winfo_children())
    return aus


def _gleich(a, b):
    return str(a).strip().lower() == str(b).strip().lower()


def knopf(beschriftung):
    """Der Knopf mit dieser Beschriftung (gross/klein egal) -- oder None."""
    for b in elemente("Button"):
        if _gleich(b.cget("text"), beschriftung):
            return b
    return None


def knoepfe():
    """Die Beschriftungen aller Knoepfe."""
    return [str(b.cget("text")) for b in elemente("Button")]


def labeltexte():
    """Was in den Labels steht, der Reihe nach."""
    return [str(w.cget("text")) for w in elemente("Label")]


def textflaeche():
    """Der Inhalt der ersten Textflaeche (tk.Text), sonst ""."""
    t = elemente("Text")
    return t[0].get("1.0", "end-1c") if t else ""


# -- Zeichenflaeche (Thema 17 *Die Karte*, 26.10.) ---------------------------------------------------------------
# Die Pruefung liest die Flaeche wie ein Mensch: ein Raum ist das Rechteck, in dem sein Name steht -- nicht die
# genauen Zahlen (die plant jedes Paar selbst). Liegen nach einem vergessenen delete("all") mehrere Rechtecke
# uebereinander, zaehlt, was man SIEHT: die oberste Fuellung (ein Rechteck ohne fill ist durchsichtig).

def flaeche():
    """Die erste Zeichenflaeche (tk.Canvas) im Fenster -- oder None."""
    c = elemente("Canvas")
    return c[0] if c else None


def dinge():
    """Wie viele Dinge auf der Zeichenflaeche liegen (Rechtecke, Linien, Texte ...), 0 ohne Flaeche."""
    c = flaeche()
    return len(c.find_all()) if c is not None else 0


def _koord(c, i):
    return [float(v) for v in c.coords(i)]


def rechtecke():
    """Alle Rechtecke, von unten nach oben: (x1, y1, x2, y2, fill) mit x1 <= x2 und y1 <= y2."""
    c = flaeche()
    if c is None:
        return []
    aus = []
    for i in c.find_all():
        if c.type(i) == "rectangle":
            k = _koord(c, i)
            aus.append((min(k[0], k[2]), min(k[1], k[3]), max(k[0], k[2]), max(k[1], k[3]), str(c.itemcget(i, "fill"))))
    return aus


def linien():
    """Alle Linien, von unten nach oben: (x1, y1, x2, y2) -- bei einem Linienzug Anfang und Ende."""
    c = flaeche()
    if c is None:
        return []
    return [tuple(_koord(c, i)[:2] + _koord(c, i)[-2:]) for i in c.find_all() if c.type(i) == "line"]


def flaechentexte():
    """Alle Texte auf der Flaeche: (text, x, y)."""
    c = flaeche()
    if c is None:
        return []
    return [(str(c.itemcget(i, "text")), *_koord(c, i)[:2]) for i in c.find_all() if c.type(i) == "text"]


# Bilder (11.11.2026, fuer das Schachbrett der Q1): bis dahin schrieb sich jede Pruefung das selbst
def _bilddatei(c, name):
    """Der Name der Datei hinter einem PhotoImage („dame.png“) -- "" fuer ein Bild ohne Datei."""
    if not name:
        return ""
    try:
        return pathlib.Path(str(c.tk.call(name, "cget", "-file"))).name
    except Exception:       # noqa: BLE001 -- ein Bild aus data= oder ein geloeschtes
        return ""


def bilder():
    """Alle Bilder auf der Zeichenflaeche, von unten nach oben: (x, y, datei) -- (x, y) ist der Punkt, an dem das
    Bild haengt (ohne anchor= seine Mitte), datei der Name der Bilddatei („dame.png“, "" ohne Datei)."""
    c = flaeche()
    if c is None:
        return []
    return [(*_koord(c, i)[:2], _bilddatei(c, c.itemcget(i, "image"))) for i in c.find_all() if c.type(i) == "image"]


def bild_auf(x, y):
    """Das Bild, das man an der Stelle (x, y) SIEHT: der Name seiner Datei („dame.png“; "" ohne Datei) -- None, wenn
    dort keins liegt. Gefragt wird nach der Lage, nicht nach dem Punkt, an dem es haengt (LC6)."""
    c = flaeche()
    if c is None:
        return None
    for i in reversed(c.find_all()):
        if c.type(i) == "image":
            b = c.bbox(i)
            if b and b[0] <= x < b[2] and b[1] <= y < b[3]:
                return _bilddatei(c, c.itemcget(i, "image"))
    return None


def raum_auf_karte(name):
    """Das Rechteck, in dem der Text name steht (gross/klein egal), als (x1, y1, x2, y2) -- oder None.
    Liegen mehrere uebereinander, ist es das oberste."""
    for text, x, y in flaechentexte():
        if _gleich(text, name):
            for r in reversed(rechtecke()):
                if r[0] <= x <= r[2] and r[1] <= y <= r[3]:
                    return r[:4]
    return None


def farbe_auf_karte(name):
    """Die Farbe, die man im Raum name SIEHT: die oberste Fuellung unter seinem Namen ("" = keine, None = kein Raum)."""
    for text, x, y in flaechentexte():
        if _gleich(text, name):
            gefunden = False
            for r in reversed(rechtecke()):
                if r[0] <= x <= r[2] and r[1] <= y <= r[3]:
                    gefunden = True
                    if r[4]:
                        return r[4]
            return "" if gefunden else None
    return None


def ist_rot(farbe):
    """Ist das (ungefaehr) Rot? "red", "#f00", "#ff0000", "tomato" ... -- ueber die RGB-Werte des Fensters."""
    if not farbe or _FENSTER is None:
        return False
    try:
        r, g, b = (v / 257 for v in _FENSTER.winfo_rgb(farbe))
    except Exception:
        return False
    return r >= 150 and g <= 110 and b <= 110


def tippe(text):
    """Schreibt text ins erste Textfeld (tk.Entry), wie die Klasse es tippt."""
    felder = elemente("Entry")
    if not felder:
        raise Offen("Im Fenster gibt es noch kein Textfeld.")
    felder[0].delete(0, "end")
    felder[0].insert(0, str(text))


def klick(beschriftung):
    """Ein Klick auf den Knopf mit dieser Beschriftung. Gibt zurueck, was dabei in der Shell erschien.
    Befund (Offen), wenn es den Knopf nicht gibt, wenn er keine Funktion bekommen hat (command=f() statt f)
    oder wenn die Funktion abbricht."""
    import io
    b = knopf(beschriftung)
    if b is None:
        raise Offen("Es gibt keinen Knopf „%s“." % beschriftung)
    if not str(b.cget("command")):
        raise Offen("Der Knopf „%s“ hat keine Funktion bekommen -- ein Klick tut nichts." % beschriftung)
    puffer, alt = io.StringIO(), sys.stdout
    _TK_FEHLER.clear()
    sys.stdout = puffer
    try:
        b.invoke()
    finally:
        sys.stdout = alt
    if _TK_FEHLER:
        art, wert, tb = _TK_FEHLER[-1]
        zeile = None
        for fr in traceback.extract_tb(tb):
            if _ARBEITSDATEI and pathlib.Path(fr.filename).resolve() == _ARBEITSDATEI:
                zeile = fr.lineno
        if art is _ZuLang:
            raise Offen(ENDLOS)
        raise Offen("Ein Klick auf „%s“ bricht%s ab (%s)." % (beschriftung, " in Zeile %d" % zeile if zeile else "",
                                                              art.__name__))
    return puffer.getvalue()


# Klick auf die Zeichenflaeche (15.11.2026, fuer das Schachbrett der Q1: ab `brett` wird am Brett geklickt). Der Klick
# geht den Weg der Maus: ein echtes Tk-Ereignis <Button-1> an der Stelle (x, y), also durch alles, was die Klasse
# gebunden hat (bind auf der Flaeche -- auch ueber ein gegebenes Modul wie bei_klick --, auf dem Fenster, an einem Ding
# der Flaeche). Das Fenster bleibt unsichtbar; Tk stellt ein Ereignis aber nur einem Fenster zu, das es schon
# angelegt hat -- winfo_id() erzwingt das (gemessen 15.11.: ohne es kommt nichts an, update() allein reicht nicht).
# Ob der Klick ankam, sieht der Helfer an einer eigenen Marke in den bindtags der Flaeche: Kommt er auf einem Rechner
# nicht an, sagt die Meldung das -- und nicht „falsches Feld“ (ein Fehler der Maschine wird kein Befund der Klasse).
_KLICKMARKE = "LernraumKlick"
_KLICK_GESEHEN = []
_KLICKFOLGEN = ("<Button-1>", "<Button>", "<ButtonRelease-1>", "<ButtonRelease>")


def _klick_gebunden(c):
    """Hat die Klasse (oder ein gegebenes Modul) irgendetwas an einen Klick mit der linken Taste gebunden?"""
    for marke in c.bindtags():
        if marke != _KLICKMARKE and any(c.tk.call("bind", marke, folge) for folge in _KLICKFOLGEN):
            return True
    return any(c.tag_bind(i, folge) for i in c.find_all() for folge in _KLICKFOLGEN)


def klick_auf(x, y, wo="die Zeichenfläche"):
    """Ein Klick mit der linken Maustaste auf die Zeichenflaeche, an der Stelle (x, y) in Pixeln -- gezaehlt wie im
    Programm von der Ecke oben links. Gibt zurueck, was dabei in der Shell erschien; danach liest die Pruefung die
    Flaeche wie sonst (bild_auf, rechtecke, linien ...). Ein Feld rechnet die Pruefung selbst aus (die Feldgroesse
    gehoert der Klasse): klick_auf(spalte * g + g // 2, zeile * g + g // 2). wo nennt die Stelle in der Meldung
    („das Feld der Dame“).
    Befund (Offen), wenn es keine Zeichenflaeche gibt, wenn sie auf einen Klick noch nicht reagiert (nichts gebunden)
    oder wenn die Funktion hinter dem Klick abbricht -- mit Datei und Zeile."""
    import io
    c = flaeche()
    if c is None:
        raise Offen("Im Fenster gibt es noch keine Zeichenfläche.")
    if not _klick_gebunden(c):
        raise Offen("Ein Klick auf %s tut noch nichts -- die Zeichenfläche hat keine Funktion für den Klick bekommen."
                    % wo)
    if _KLICKMARKE not in c.bindtags():
        c.bindtags((_KLICKMARKE,) + tuple(c.bindtags()))
        c.bind_class(_KLICKMARKE, "<Button-1>", lambda ereignis: _KLICK_GESEHEN.append(1))
    c.winfo_id()
    puffer, alt = io.StringIO(), sys.stdout
    _TK_FEHLER.clear()
    _KLICK_GESEHEN.clear()
    sys.stdout = puffer
    try:
        c.event_generate("<Button-1>", x=int(x), y=int(y))
        c.event_generate("<ButtonRelease-1>", x=int(x), y=int(y))
    finally:
        sys.stdout = alt
    if not _KLICK_GESEHEN:
        raise RuntimeError("Der Klick des Selbstchecks kommt auf diesem Rechner nicht bei der Zeichenfläche an "
                           "(kein Fehler in eurem Programm).")
    if _TK_FEHLER:
        art, wert, tb = _TK_FEHLER[-1]
        if art is _ZuLang:
            raise Offen(ENDLOS)
        text = str(wert)
        was = art.__name__ + (": " + (text if len(text) <= 70 else text[:67] + "...") if text else "")
        raise Offen("Ein Klick auf %s bricht ab%s (%s)." % (wo, _bei(_abbruchstelle(tb)), was))
    return puffer.getvalue()


def funktion(name):
    f = getattr(_ARBEIT, name, None)
    return f if isinstance(f, types.FunctionType) else None


# -- Klassen (Ordnung Informatik Schritt 9, Teil 3, 11.11.2026; fuer iq1 schach) -------------------------------------
# Die Pruefung arbeitet ueber OBJEKTE, nicht ueber Namen im Quelltext (LC2): Sie baut eigene Objekte mit eigenen
# Werten, ruft ihre Methoden und sieht nach, was herauskommt. Was dabei schiefgeht, wird eine Meldung mit Datei und
# Zeile (LC3) -- bis dahin wurde ein falscher Konstruktor „Beim Pruefen ging etwas schief: TypeError“.

def _im_ordner_geladen(m):
    """Ist m ein Modul, das das Programm aus seinem Ordner geladen hat (nicht die Startdatei, nicht die Pruefung)?"""
    f = getattr(m, "__file__", None)
    if not f or m is _ARBEIT or _ARBEITSDATEI is None:
        return False
    try:
        p = pathlib.Path(f).resolve()
    except (OSError, ValueError):
        return False
    return p.parent == _ARBEITSDATEI.parent and p not in (_ARBEITSDATEI, _PRUEFUNG) and p.suffix == ".py"


def klasse(name):
    """Die Klasse name aus dem Programm -- aus der Startdatei oder aus einem Modul, das es aus seinem Ordner geladen
    hat (`from figur import Figur` wie `import figur`) --, sonst None."""
    k = getattr(_ARBEIT, name, None)
    if isinstance(k, type):
        return k
    for m in _MODULE.values():
        k = getattr(m, name, None)
        if isinstance(k, type):
            return k
    return None


def _klasse_aus(k):
    if isinstance(k, type):
        return k
    c = klasse(str(k))
    if c is None:
        raise Offen("Im Programm gibt es noch keine Klasse %s -- weder in %s noch in einem Modul, das es lädt."
                    % (k, _ARBEITSDATEI.name if _ARBEITSDATEI else "der Startdatei"))
    return c


_ZAHLWORT = ["keine", "eine", "zwei", "drei", "vier", "fünf", "sechs"]


def _zahlwort(n):
    return _ZAHLWORT[n] if n < len(_ZAHLWORT) else str(n)


def _klassendatei(c):
    """Die Datei, in der die Klasse steht („figur.py“) -- oder None."""
    f = getattr(sys.modules.get(c.__module__), "__file__", None)
    if f:
        return pathlib.Path(f).name
    stelle = next((_stelle(v) for v in vars(c).values() if isinstance(v, types.FunctionType)), None)
    return stelle[0] if stelle else None


def _in_datei(c):
    d = _klassendatei(c)
    return " (Klasse %s in %s)" % (c.__name__, d) if d else ""


def _wert(x):
    """Ein Wert in einer Meldung: Zahlen und Texte wie im Code, ein Objekt als „eine Figur“."""
    if type(x).__repr__ is object.__repr__:
        return "ein %s-Objekt" % type(x).__name__
    r = repr(x)
    return r if len(r) <= 30 else r[:27] + "..."


def _aufruf(name, angaben, benannt):
    teile = [_wert(a) for a in angaben] + ["%s=%s" % (k, _wert(v)) for k, v in benannt.items()]
    return "%s(%s)" % (name, ", ".join(teile))


def _stelle(f):
    """(datei, zeile) einer Funktion -- None, wenn sie nicht aus einer Datei stammt (object.__init__)."""
    code = getattr(inspect.unwrap(f), "__code__", None)
    return (pathlib.Path(code.co_filename).name, code.co_firstlineno) if code is not None else None


def _abbruchstelle(tb):
    """Die letzte Stelle im Ordner des Programms, an der ein Abbruch vorbeikam: (datei, zeile) -- auch in einem
    gegebenen Modul, nie in der Pruefdatei."""
    stelle = None
    for fr in traceback.extract_tb(tb):
        try:
            p = pathlib.Path(fr.filename).resolve()
        except (OSError, ValueError):
            continue
        if p.parent == _programmordner() and p != _PRUEFUNG and p.suffix == ".py":
            stelle = (p.name, fr.lineno)
    return stelle


def _bei(stelle):
    return " -- in %s, Zeile %d" % stelle if stelle else ""


def _passt_zu(f, angaben, benannt, aufruf, was, erste=None):
    """Passen die Angaben des Selbstchecks zu den Parametern von f? Sonst ein Befund mit beiden Seiten."""
    try:
        sig = inspect.signature(f)
    except (TypeError, ValueError):
        return
    try:
        sig.bind(*([erste] if erste is not None else []), *angaben, **benannt)
        return
    except TypeError:
        pass
    namen = [p.name for p in sig.parameters.values()][1 if erste is not None else 0:]
    n = len(angaben) + len(benannt)
    stelle = _stelle(f)
    raise Offen("Der Selbstcheck %s %s (%s) -- %s%s erwartet %s%s." % (
        "baut" if was == "der Konstruktor" else "ruft", aufruf,
        "ohne Angaben" if n == 0 else _zahlwort(n) + (" Angabe" if n == 1 else " Angaben"),
        was, " in %s, Zeile %d," % stelle if stelle else "", _zahlwort(len(namen)),
        ": " + ", ".join(namen) if namen else ""))


def _rufen(fn, aufruf, wo):
    """fn() mit gefangener Ausgabe (gedruckt()); ein Abbruch wird ein Befund mit seiner Stelle."""
    import io
    global _GEDRUCKT
    puffer, alt, alt_fenster = io.StringIO(), sys.stdout, _standardfenster()
    sys.stdout = puffer
    try:
        return fn()
    except SystemExit:
        raise Offen("%s hält das Programm an -- exit() oder input() ohne Eingabe%s."
                    % (aufruf, _bei(_abbruchstelle(sys.exc_info()[2])).replace(" -- in", ", in"))) from None
    except Exception as e:      # noqa: BLE001 -- der Abbruch im Code der Klasse ist ein Befund
        text = str(e)
        art = type(e).__name__ + (": " + (text if len(text) <= 70 else text[:67] + "...") if text else "")
        raise Offen("%s bricht %sab%s (%s)." % (aufruf, wo, _bei(_abbruchstelle(e.__traceback__)), art)) from None
    finally:
        sys.stdout = alt
        _GEDRUCKT = puffer.getvalue()
        _standardfenster(alt_fenster)


def erzeuge(klasse_, *angaben_, **benannt):
    """Ein neues Objekt der Klasse (der Name oder die Klasse selbst) mit den Angaben des Selbstchecks. Befund statt
    TypeError: Passen die Angaben nicht zum Konstruktor, nennt die Meldung beide Seiten mit Datei und Zeile; bricht
    der Konstruktor ab, die Stelle. Was er druckt, steht danach in gedruckt()."""
    c = _klasse_aus(klasse_)
    aufruf = _aufruf(c.__name__, angaben_, benannt)
    if c.__init__ is object.__init__:
        if angaben_ or benannt:
            raise Offen("Der Selbstcheck baut %s -- die Klasse %s hat aber noch keinen Konstruktor (__init__)%s."
                        % (aufruf, c.__name__, " in " + _klassendatei(c) if _klassendatei(c) else ""))
    else:
        _passt_zu(c.__init__, angaben_, benannt, aufruf, "der Konstruktor", erste=object())
    return _rufen(lambda: c(*angaben_, **benannt), aufruf, "im Konstruktor ")


def _methodenname(c, name):
    """__pruefe -> _Figur__pruefe, wenn eine Klasse der Kette die Methode privat traegt."""
    if name.startswith("__") and not name.endswith("__"):
        for k in c.__mro__:
            if "_%s%s" % (k.__name__.lstrip("_"), name) in vars(k):
                return "_%s%s" % (k.__name__.lstrip("_"), name)
    return name


def rufe(objekt, methode, *angaben_, **benannt):
    """objekt.methode(...) mit den Angaben des Selbstchecks; gibt zurueck, was die Methode zurueckgibt. Befund, wenn
    es die Methode nicht gibt, die Angaben nicht passen oder sie abbricht -- mit Methode, Datei und Zeile. Was sie in
    die Shell schreibt, steht danach in gedruckt() (fuer „druckt, statt zurueckzugeben“)."""
    c = type(objekt)
    try:
        m = getattr(objekt, _methodenname(c, methode))
    except AttributeError:
        raise Offen("Ein %s-Objekt hat keine Methode %s%s." % (c.__name__, methode, _in_datei(c))) from None
    if not callable(m):
        raise Offen("%s ist bei einem %s-Objekt ein Attribut, keine Methode%s." % (methode, c.__name__, _in_datei(c)))
    aufruf = _aufruf(methode, angaben_, benannt)
    _passt_zu(m, angaben_, benannt, aufruf, "die Methode")
    return _rufen(lambda: m(*angaben_, **benannt), aufruf, "")


def gedruckt():
    """Was der letzte Aufruf ueber erzeuge() oder rufe() in die Shell geschrieben hat."""
    return _GEDRUCKT


class Attribute(dict):
    """Die Attribute eines Objekts: Name wie im Code (`__zeile`, nicht `_Figur__zeile`) -> Wert, in der Reihenfolge,
    in der sie entstanden sind. Dazu .privat (die Namen mit __, im Klassendiagramm ein Minus) und .oeffentlich (was
    von aussen erreichbar ist: ohne Unterstrich -- und ein __x, das von aussen gesetzt wurde). Ein _x ist keins von
    beiden."""

    def __init__(self):
        super().__init__()
        self.privat, self.oeffentlich = [], []


def attribute(objekt):
    """Die Attribute des Objekts (nicht die der Klasse) -- siehe Attribute."""
    a = Attribute()
    klassen = [k.__name__.lstrip("_") for k in type(objekt).__mro__ if k.__name__.lstrip("_")]
    for roh, wert in (vars(objekt).items() if hasattr(objekt, "__dict__") else ()):
        name = next((roh[len(k) + 1:] for k in klassen if roh.startswith("_%s__" % k) and not roh.endswith("__")), None)
        if name is not None:
            a.privat.append(name)
            a[name] = wert
            continue
        if not roh.startswith("_") or (roh.startswith("__") and not roh.endswith("__")):
            a.oeffentlich.append(roh)
        a.setdefault(roh, wert)
    return a


class Angaben:
    """Die Parameter einer Methode, wie sie im Code stehen -- zum Vergleich mit dem Klassendiagramm.
    .parameter: [(name, typ oder None)] ohne self · .namen · .typen · .rueckgabe (Text oder None) · .datei · .zeile;
    str() ist die Kopfzeile ohne self: „ziehe(zeile: int, spalte: int) -> None“."""

    def __init__(self, name, parameter, rueckgabe, stelle):
        self.name, self.parameter, self.rueckgabe = name, parameter, rueckgabe
        self.datei, self.zeile = stelle if stelle else (None, None)

    @property
    def namen(self):
        return [n for n, _ in self.parameter]

    @property
    def typen(self):
        return [t for _, t in self.parameter]

    def __str__(self):
        kopf = "%s(%s)" % (self.name, ", ".join(n + (": " + t if t else "") for n, t in self.parameter))
        return kopf + (" -> " + self.rueckgabe if self.rueckgabe else "")

    __repr__ = __str__


def angaben(klasse_, methode):
    """Angaben der Methode (auch __init__, auch eine private wie __pruefe) -- None, wenn es Klasse oder Methode nicht
    gibt. Die Typen stehen da, wie sie geschrieben sind („list[Figur]“), nicht wie Python sie auswertet."""
    import ast
    c = klasse_ if isinstance(klasse_, type) else klasse(str(klasse_))
    if c is None:
        return None
    roh = _methodenname(c, methode)
    f = next((vars(k)[roh] for k in c.__mro__ if roh in vars(k)), None)
    statisch = isinstance(f, staticmethod)
    f = inspect.unwrap(f.__func__ if isinstance(f, (staticmethod, classmethod)) else f) if f is not None else None
    if not isinstance(f, types.FunctionType):
        return None
    try:
        knoten = next(k for k in ast.walk(ast.parse(textwrap.dedent(inspect.getsource(f))))
                      if isinstance(k, (ast.FunctionDef, ast.AsyncFunctionDef)))
    except (OSError, TypeError, SyntaxError, StopIteration):
        knoten = None
    if knoten is not None:
        class OhneAnfuehrung(ast.NodeTransformer):
            """`andere: "Figur"` (die Klasse nennt sich selbst) heisst im Klassendiagramm Figur, nicht 'Figur'."""
            def visit_Constant(self, k):
                return ast.Name(id=k.value) if isinstance(k.value, str) else k

        def text(a):
            return ast.unparse(OhneAnfuehrung().visit(a)) if a is not None else None
        a = knoten.args
        par = [(x.arg, text(x.annotation)) for x in a.posonlyargs + a.args]
        par = par if statisch else par[1:]
        if a.vararg:
            par.append(("*" + a.vararg.arg, text(a.vararg.annotation)))
        par += [(x.arg, text(x.annotation)) for x in a.kwonlyargs]
        if a.kwarg:
            par.append(("**" + a.kwarg.arg, text(a.kwarg.annotation)))
        return Angaben(methode, par, text(knoten.returns), _stelle(f))
    # ohne Quelltext (sollte nicht vorkommen): ueber die Signatur, Typen so gut es geht als Text
    def als_text(t):
        return None if t is inspect.Parameter.empty else t if isinstance(t, str) else getattr(t, "__name__", repr(t))
    sig = inspect.signature(f)
    par = [(p.name, als_text(p.annotation)) for p in sig.parameters.values()]
    return Angaben(methode, par if statisch else par[1:], als_text(sig.return_annotation), _stelle(f))


def _standardfenster(fenster=False):
    """Ohne Angabe: das Standardfenster von tkinter (oder None). Mit Angabe: es dorthin zuruecksetzen."""
    tk = sys.modules.get("tkinter")
    if tk is None:
        return None
    if fenster is not False:
        tk._default_root = fenster
    return getattr(tk, "_default_root", None)


def _still_stellen():
    """mainloop still, input() verboten -- nur in DIESEM Prozess, der nach
    der Pruefung endet. Das Fenster der Klasse ist ein anderer Prozess."""
    try:
        import tkinter as tk
        tk.Misc.mainloop = lambda self, n=0: None
        tk.Tk.mainloop = lambda self, n=0: None
        tk.mainloop = lambda n=0: None
        bauen = tk.Tk.__init__

        def tk_still(self, *a, **kw):
            """Jedes Fenster bleibt unsichtbar (withdraw) und meldet Fehler in Knopf-Funktionen an klick().
            Das NEUESTE Fenster ist das Standardfenster (11.11.2026): Ein Programm, das anspielen() ein zweites Mal
            startet, baut ein zweites Tk -- ein PhotoImage ohne master hing sonst am ersten, und die neue Flaeche
            kannte das Bild nicht („image pyimage2 doesn't exist“). anspielen, erzeuge und rufe stellen danach das
            alte zurueck (_standardfenster)."""
            bauen(self, *a, **kw)
            self.withdraw()
            self.report_callback_exception = lambda art, wert, tb: _TK_FEHLER.append((art, wert, tb))
            _TK_WURZELN.append(self)
            tk._default_root = self
        tk.Tk.__init__ = tk_still
    except ImportError:
        pass
    import builtins

    def eingabe(frage=""):
        """input() bekommt die EINGABEN der Pruefdatei, der Reihe nach.
        Sind sie aufgebraucht, endet das Programm (wie ein geschlossenes
        Fenster) -- es haengt nie."""
        if _AUSGABE is not None:
            _AUSGABE.write(str(frage))
        if not _EINGABEN:
            raise SystemExit(0)
        antwort = _EINGABEN.pop(0)
        if _AUSGABE is not None:
            _AUSGABE.write(antwort + "\n")
        return antwort
    builtins.input = eingabe


def _arbeit_laden(pfad):
    global _ARBEIT, _QUELLE, _ARBEITSDATEI, _AUSGABE
    import io
    _ARBEITSDATEI = pathlib.Path(pfad).resolve()
    _QUELLE = _ARBEITSDATEI.read_text("utf-8", errors="replace")
    stem = _ARBEITSDATEI.stem
    sys.path.insert(0, str(_ARBEITSDATEI.parent))
    # Python-Ordner (11.11.2026): das Programm laeuft DORT, wo es liegt -- wie beim Ausfuehren (cwd = Ordner der
    # Datei). Sonst faende `PhotoImage(file="bilder/dame.png")` im Selbstcheck sein Bild nicht. Fuer ein Thema mit
    # einer Arbeitsdatei aendert sich nichts: Ihr Ordner ist der Themenordner, und dort laeuft der Check schon.
    os.chdir(_ARBEITSDATEI.parent)
    _AUSGABE = io.StringIO()
    ns = {"__name__": stem, "__file__": str(_ARBEITSDATEI)}
    code = compile(_QUELLE, str(_ARBEITSDATEI), "exec")
    alt = sys.stdout
    sys.stdout = _AUSGABE
    abbruch = None
    vorher = len(_TK_WURZELN)
    try:
        _mit_zeitgrenze(lambda: exec(code, ns))      # noqa: S102 -- die Arbeitsdatei IST der Pruefgegenstand
    except SystemExit:
        pass                # EINGABEN aufgebraucht oder eigenes exit(): so weit ist es gekommen
    except _ZuLang:
        abbruch = {"text": ENDLOS, "zeile": None, "original": "Zeitgrenze %g s" % ZEITGRENZE}
    except BaseException as e:  # noqa: BLE001 -- der Abbruch ist Befund, nicht Ende der Pruefung
        # Die Namen, die bis zum Abbruch entstanden sind, bleiben pruefbar:
        # ein Spiel, das bei 'lege lampe' abbricht, hat Aufgabe 1 vielleicht
        # schon richtig -- das soll der Check sagen koennen (gesehen an den
        # Beispielabgaben, 2026-10-13: "0 von 0" fuer eine halbe Loesung).
        tb = traceback.extract_tb(sys.exc_info()[2])
        zeile = None
        for fr in tb:
            if pathlib.Path(fr.filename).resolve() == _ARBEITSDATEI:
                zeile = fr.lineno
        abbruch = {"text": "Das Programm bricht beim Anspielen ab" + (" in Zeile %d" % zeile if zeile else "") + ".",
                   "zeile": zeile, "original": "%s: %s" % (type(e).__name__, e)}
    finally:
        sys.stdout = alt
    global _FENSTER
    _FENSTER = _TK_WURZELN[vorher] if len(_TK_WURZELN) > vorher else None
    modul = types.ModuleType(stem)
    modul.__dict__.update(ns)
    modul.__file__ = str(_ARBEITSDATEI)
    sys.modules[stem] = modul
    _ARBEIT = modul
    # klasse() sucht in den Modulen DIESES Laufs -- anspielen() laedt sie neu, die Klassen der Pruefung bleiben dieselben
    _MODULE.clear()
    _MODULE.update({n: m for n, m in sys.modules.items() if _im_ordner_geladen(m)})
    return abbruch


# -- HTML (29.10.2026): eine Seite als Baum, gelesen mit html.parser ---------------------------
# Leere Elemente haben nie ein Ende; alles andere muss geschlossen werden -- das Thema heisst
# „öffnende und schließende Tags“, und der Browser verzeiht ein fehlendes </p> still.
LEERE_ELEMENTE = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "source", "track", "wbr"}


class Knoten:
    """Ein Element der Seite: tag, attribute, kinder (Knoten oder Text), zeile, geschlossen."""

    def __init__(self, tag, attribute=(), zeile=0, eltern=None):
        self.tag, self.attribute, self.zeile, self.eltern = tag, dict(attribute), zeile, eltern
        self.kinder, self.geschlossen = [], tag in LEERE_ELEMENTE

    def text(self):
        """Aller Text darin, Leerraum zusammengezogen (wie der Browser ihn zeigt)."""
        teile = [k if isinstance(k, str) else k.text() for k in self.kinder]
        return " ".join(" ".join(teile).split())

    def alle(self):
        for k in self.kinder:
            if isinstance(k, Knoten):
                yield k
                yield from k.alle()

    def finde(self, tag):
        return [k for k in self.alle() if k.tag == tag]

    def text_roh(self):
        """Der Text darin, wie er im Quelltext steht (für <style>: das CSS, Zeilen erhalten)."""
        return "".join(k if isinstance(k, str) else k.text_roh() for k in self.kinder)

    def klassen(self):
        return (self.attribute.get("class") or "").split()

    def __repr__(self):
        return "<%s Zeile %d>" % (self.tag, self.zeile)


def _baum_lesen(quelle):
    from html.parser import HTMLParser
    wurzel = Knoten("#dokument")
    stapel, ueberkreuzt, verwaist = [wurzel], [], []

    class Leser(HTMLParser):
        def handle_starttag(self, tag, attrs):
            k = Knoten(tag, attrs, self.getpos()[0], stapel[-1])
            stapel[-1].kinder.append(k)
            if tag not in LEERE_ELEMENTE:
                stapel.append(k)

        def handle_startendtag(self, tag, attrs):
            k = Knoten(tag, attrs, self.getpos()[0], stapel[-1])
            k.geschlossen = True
            stapel[-1].kinder.append(k)

        def handle_endtag(self, tag):
            if tag in LEERE_ELEMENTE:
                return
            for i in range(len(stapel) - 1, 0, -1):
                if stapel[i].tag == tag:
                    if i != len(stapel) - 1:
                        # </p> schliesst, waehrend <strong> darin noch offen ist: ueberkreuzt
                        ueberkreuzt.append((tag, self.getpos()[0], stapel[-1].tag))
                    stapel[i].geschlossen = True
                    del stapel[i:]
                    return
            verwaist.append((tag, self.getpos()[0]))

        def handle_data(self, data):
            stapel[-1].kinder.append(data)

    leser = Leser(convert_charrefs=True)
    leser.feed(quelle)
    leser.close()
    return wurzel, ueberkreuzt, verwaist


class Seite:
    """Eine HTML-Datei der Arbeit. da: ob es sie gibt. quelle: der Text."""

    def __init__(self, name, quelle, da=True):
        self.name, self.quelle, self.da = name, quelle, da
        self.wurzel, self.ueberkreuzt, self.verwaist = _baum_lesen(quelle)
        # Fingerabdruck des Textes (Leerraum am Ende egal): Gleicht er dem der Startdatei, hat noch niemand angefangen --
        # dann sagt die Pruefung „noch nicht dran“ statt „falsch“ (drei Zustaende: genau EINE Pflichtpruefung steht aus)
        import hashlib
        self.abdruck = hashlib.sha256(quelle.strip().encode("utf-8")).hexdigest()[:12]

    def elemente(self, tag):
        return self.wurzel.finde(tag)

    def erstes(self, tag):
        e = self.elemente(tag)
        return e[0] if e else None

    def text(self, tag):
        """Der Text des ersten Elements mit diesem Tag ("" ohne)."""
        e = self.erstes(tag)
        return e.text() if e else ""

    def texte(self, tag):
        return [e.text() for e in self.elemente(tag)]

    def offen(self):
        """Elemente, die geoeffnet, aber nie geschlossen werden -- in der Reihenfolge der Seite."""
        return [k for k in self.wurzel.alle() if not k.geschlossen]

    def meldung_offen(self):
        o = self.offen()
        if not o:
            return ""
        k = o[-1]       # das innerste zuerst: hinter ihm wird alles zu seinem Inhalt
        return ("In Zeile %d öffnet <%s>, bis zum Ende kommt kein </%s>. Schaut in die Vorschau: "
                "Was gehört jetzt alles dazu?" % (k.zeile, k.tag, k.tag))

    def lose_texte(self, in_tag="body"):
        """Text, der direkt in <body> steht (nicht in einem Absatz, einer Ueberschrift …)."""
        b = self.erstes(in_tag)
        if b is None:
            return []
        return [" ".join(k.split()) for k in b.kinder if isinstance(k, str) and k.strip()]

    def meldung_lose(self):
        lose = self.lose_texte()
        return ("Ein Text steht ohne Tag in body: „%s“." % lose[0][:60]) if lose else ""

    def ausserhalb(self):
        """Text, der nicht in <head> oder <body> steht (davor, dazwischen, danach)."""
        aus = []
        for k in self.wurzel.kinder:
            if isinstance(k, str):
                if k.strip():
                    aus.append(" ".join(k.split()))
            elif k.tag == "html":
                aus += [" ".join(x.split()) for x in k.kinder if isinstance(x, str) and x.strip()]
        return aus

    def links(self):
        """Die Links der Seite: [(href, Text, Zeile)] -- auch ein a ohne href (dann href "")."""
        return [(e.attribute.get("href") or "", e.text(), e.zeile) for e in self.elemente("a")]

    def bilder(self):
        """Die Bilder der Seite: [(src, alt, Zeile)] -- alt None, wenn das Attribut fehlt."""
        return [(e.attribute.get("src") or "", e.attribute.get("alt"), e.zeile) for e in self.elemente("img")]

    def fehlende_bilder(self):
        """Bilder, deren Datei es im Ordner nicht gibt (Tippfehler im src): [(src, Zeile)]."""
        return [(s, z) for s, _, z in self.bilder() if _im_ordner(s) and not (_ORDNER / s).is_file()]

    def kaputte_links(self):
        """Links auf eine Datei, die es im Ordner nicht gibt (Tippfehler im Namen): [(href, Zeile)]."""
        return [(h, z) for h, _, z in self.links() if _im_ordner(h) and not (_ORDNER / h).is_file()]

    def geruest_fehlt(self):
        """Was am Grundgeruest fehlt: html, head, title (in head), body (nach head)."""
        kopf = self.erstes("head")
        da = {"html": self.erstes("html") is not None, "head": kopf is not None,
              "title": kopf is not None and bool(kopf.finde("title")), "body": self.erstes("body") is not None}
        return [t for t in ("html", "head", "title", "body") if not da[t]]

    def meldung_geruest(self):
        f = self.geruest_fehlt()
        return ("Am Grundgerüst fehlt noch: " + ", ".join(f) + ".") if f else ""

    # -- CSS (09.11.2026, Thema fundbuero): was die Seite an Regeln hat und was sie bewirken -------------------------

    def css_dateien(self):
        """Die eingebundenen Stylesheets: [href] in der Folge der Seite (<link rel="stylesheet" href="…">)."""
        return [k.attribute.get("href") or "" for k in self.elemente("link")
                if "stylesheet" in (k.attribute.get("rel") or "").lower().split()]

    def eingebunden(self, name):
        """Bindet die Seite diese CSS-Datei ein? (rel="stylesheet" und href genau der Name)"""
        return name in self.css_dateien()

    def stilbloecke(self):
        """Die <style>-Elemente der Seite als Stilblätter (Zeilen wie in der HTML-Datei)."""
        return [_stilblatt_aus(self.name, k.text_roh(), k.zeile) for k in self.elemente("style")]

    def regeln(self):
        """Alle Regeln, die auf dieser Seite gelten, in der Folge der Kaskade: eingebundene Dateien und <style>-Blöcke,
        so wie sie im Quelltext stehen. Eine eingebundene Datei, die es nicht gibt, bringt keine Regeln."""
        aus = []
        for k in self.wurzel.alle():
            if k.tag == "link" and "stylesheet" in (k.attribute.get("rel") or "").lower().split():
                href = k.attribute.get("href") or ""
                if _im_ordner(href):
                    aus += css(href).regeln
            elif k.tag == "style":
                aus += _stilblatt_aus(self.name, k.text_roh(), k.zeile).regeln
        return aus

    def css_fehler(self):
        """Schreibfehler im CSS der Seite: erst die <style>-Blöcke, dann die eingebundenen Dateien. [(Datei, Zeile, Text)]"""
        aus = [f for b in self.stilbloecke() for f in b.fehler]
        for href in self.css_dateien():
            if _im_ordner(href) and css(href).da:
                aus += css(href).fehler
        return aus

    def meldung_css(self):
        f = self.css_fehler()
        return ("%s, Zeile %d: %s" % f[0]) if f else ""

    def trifft(self, selektor):
        """Die Elemente, die ein Selektor auf dieser Seite trifft (Zustände wie :hover zählen als getroffen)."""
        teile = _selektor_zerlegen(selektor)
        if teile is None:
            return []
        teile = [(v, t, kl, i, ()) for v, t, kl, i, _ in teile]
        return [k for k in self.wurzel.alle() if _selektor_passt(k, teile)]

    def stil(self, knoten, eigenschaft):
        """Der Wert, den eine Eigenschaft für dieses Element hat, wie der Browser ihn ausrechnet: die Regel mit der
        höchsten Spezifität gewinnt, bei Gleichstand die spätere; style="…" am Element schlägt jede Regel, !important
        schlägt alles. Erbt die Eigenschaft (color, font-…), zählt sonst das Elternelement. Kein Wert: "".
        Nicht nachgebaut: Zustände (:hover), @media, Kurzschreibweisen (background statt background-color)."""
        eigenschaft = eigenschaft.lower()
        if isinstance(knoten, str):
            knoten = self.erstes(knoten)
        regeln = self.regeln()
        while knoten is not None and knoten.tag != "#dokument":
            best = None
            for nr, r in enumerate(regeln):
                if r.bedingung or eigenschaft not in r.eigenschaften:
                    continue
                wert, wichtig = r.eigenschaften[eigenschaft]
                for sel in r.selektoren:
                    teile = _selektor_zerlegen(sel)
                    if teile is not None and _selektor_passt(knoten, teile):
                        rang = (wichtig, 0, _spezifitaet(teile), nr)
                        if best is None or rang > best[0]:
                            best = (rang, wert)
            inline = _deklarationen_lesen(knoten.attribute.get("style") or "", knoten.zeile, self.name, [])
            if eigenschaft in inline:
                wert, wichtig = inline[eigenschaft]
                rang = (wichtig, 1, (0, 0, 0), 0)
                if best is None or rang > best[0]:
                    best = (rang, wert)
            if best is not None:
                return best[1]
            if eigenschaft not in VERERBT:
                return ""
            knoten = knoten.eltern
        return ""

    # -- Formulare (09.11.2026, Thema meldung): was ein Formular abschickt -------------------------------------------

    def formulare(self):
        """Die Formulare der Seite (<form>) in ihrer Folge, je eines als Formular."""
        return [Formular(k, self) for k in self.elemente("form")]

    def formular(self):
        """Das erste Formular der Seite oder None."""
        f = self.formulare()
        return f[0] if f else None

    def meldung_formular(self):
        """Woran es beim ersten Formular hängt -- nennt die Stelle, nicht die fehlende Zeile. "" wenn alles da ist."""
        f = self.formular()
        if f is None:
            return "Auf %s steht noch kein Formular (form)." % self.name
        if not f.action:
            return "Das Formular in Zeile %d sagt nicht, wohin es die Eingaben schickt." % f.zeile
        ohne = f.ohne_namen()
        if ohne:
            return ("Die Eingabe aus Zeile %d (%s) kommt beim Server nicht an. Schickt das Formular ab: "
                    "Was steht auf dem Abholschein?" % (ohne[0].zeile, ohne[0].tag))
        if not f.knoepfe:
            return "Das Formular in Zeile %d hat noch keinen Knopf zum Abschicken." % f.zeile
        return ""


# Was ein Feld ist und was ein Knopf (input type=…): Knöpfe schicken ab, sie reisen nicht mit (ausser mit name -- das
# braucht hier niemand); hidden reist mit, braucht aber keine Beschriftung.
_KNOPF_TYPEN = {"submit", "button", "reset", "image"}


class Feld:
    """Ein Eingabefeld eines Formulars: tag (input, textarea, select), typ, name ("" ohne), id, zeile, beschriftung
    (Text des label, "" ohne), wert (was beim Abschicken drinsteht, ohne Eingabe: value bzw. Inhalt)."""

    def __init__(self, knoten, beschriftung):
        a = knoten.attribute
        self.knoten, self.tag, self.zeile = knoten, knoten.tag, knoten.zeile
        self.typ = (a.get("type") or ("text" if knoten.tag == "input" else knoten.tag)).lower()
        self.name, self.id = a.get("name") or "", a.get("id") or ""
        self.beschriftung = beschriftung
        if knoten.tag == "textarea":
            self.wert = knoten.text_roh()
        elif knoten.tag == "select":
            opt = [o for o in knoten.finde("option")]
            wahl = [o for o in opt if "selected" in o.attribute] or opt[:1]
            self.wert = (wahl[0].attribute.get("value") if wahl and wahl[0].attribute.get("value") is not None
                         else (wahl[0].text() if wahl else ""))
        else:
            self.wert = a.get("value") or ""

    def __repr__(self):
        return "<%s name=%r Zeile %d>" % (self.tag, self.name, self.zeile)


class Formular:
    """Ein <form>: action, methode ("get"/"post", ohne Angabe "get" wie im Browser), zeile, felder, knoepfe."""

    def __init__(self, knoten, seite):
        self.knoten, self.zeile = knoten, knoten.zeile
        self.action = (knoten.attribute.get("action") or "").strip()
        self.methode = (knoten.attribute.get("method") or "get").strip().lower()
        beschriftet = {}
        for lab in seite.elemente("label"):
            if lab.attribute.get("for"):
                beschriftet[lab.attribute["for"]] = lab.text()
        self.felder, self.knoepfe = [], []
        for k in knoten.alle():
            typ = (k.attribute.get("type") or "").lower()
            if k.tag == "button" or (k.tag == "input" and typ in _KNOPF_TYPEN):
                self.knoepfe.append(k)
            elif k.tag in ("input", "textarea", "select"):
                text = beschriftet.get(k.attribute.get("id") or "", "")
                e = k.eltern
                while not text and e is not None and e is not knoten:
                    if e.tag == "label":
                        text = e.text()
                    e = e.eltern
                self.felder.append(Feld(k, text))

    def namen(self):
        """Die Namen, die beim Abschicken mitreisen, in der Folge des Formulars."""
        return [f.name for f in self.felder if f.name]

    def feld(self, name):
        for f in self.felder:
            if f.name == name:
                return f
        return None

    def ohne_namen(self):
        """Felder ohne name: Ihre Eingabe reist nicht mit."""
        return [f for f in self.felder if not f.name]

    def ohne_beschriftung(self):
        """Sichtbare Felder ohne label (weder label for=… noch darum herum)."""
        return [f for f in self.felder if f.typ != "hidden" and not f.beschriftung]

    def daten(self, werte=None):
        """Was beim Abschicken mitreist, wie der Browser es schreibt: name=Wert&…, Leerzeichen als +.
        werte: {name: eingetippter Text}; ohne Eintrag zählt, was im Feld schon steht."""
        import urllib.parse
        werte = werte or {}
        paare = [(f.name, str(werte.get(f.name, f.wert))) for f in self.felder if f.name]
        return urllib.parse.urlencode(paare)

    def anfrage(self, werte=None):
        """Die erste Zeile der Anfrage: GET /melden?name=…  (POST: POST /melden, die Daten stehen dahinter)."""
        ziel = "/" + self.action.lstrip("/")
        if self.methode == "post":
            return "POST " + ziel
        d = self.daten(werte)
        return "GET " + ziel + ("?" + d if d else "?")

    def __repr__(self):
        return "<form action=%r Zeile %d>" % (self.action, self.zeile)


def _im_ordner(href):
    """Zeigt ein href auf eine Datei in diesem Ordner (relativ, ohne http:// und ohne #)?"""
    return bool(href) and "://" not in href and not href.startswith(("#", "/", "mailto:"))


def weg(start, ziel):
    """Kommt man von der Seite start über Links zur Seite ziel? Gibt den Weg als Liste von Dateinamen oder None.
    Gefolgt wird nur Links auf Dateien, die es im Ordner gibt (so wie der Browser auch nicht weiterkommt)."""
    vorher, schlange = {start: None}, [start]
    while schlange:
        jetzt = schlange.pop(0)
        if jetzt == ziel:
            w = []
            while jetzt:
                w.append(jetzt)
                jetzt = vorher[jetzt]
            return w[::-1]
        s = seite(jetzt)
        for h, _, _ in s.links() if s.da else []:
            h = h.split("#")[0]
            if _im_ordner(h) and h not in vorher and (_ORDNER / h).is_file():
                vorher[h] = jetzt
                schlange.append(h)
    return None


def seite(name):
    """Eine Seite aus dem Ordner der Arbeit (HTML-Themen); gibt es sie nicht, ist da False."""
    if name not in _SEITEN:
        p = (_ORDNER or pathlib.Path(".")) / name
        da = p.is_file()
        _SEITEN[name] = Seite(name, p.read_text("utf-8", errors="replace") if da else "", da)
    return _SEITEN[name]


# -- CSS (09.11.2026, Thema webseite/fundbuero „Zwölf rote Koffer“) ------------------------------------------------
# Gelesen wird der QUELLTEXT wie bei seite(): Der Browser überliest eine kaputte Deklaration still, der Selbstcheck
# sagt Zeile und Art (fehlender Doppelpunkt, zwei Deklarationen ohne Semikolon, { ohne }). Regeln haben selektoren
# (Komma getrennt), eigenschaften {name: (wert, wichtig)} -- die letzte Nennung gewinnt -- und eine zeile.
#
#     def pruefe_20_eingebunden():
#         """Aufgabe 1 · Jede Station bindet flughafen.css ein"""
#         fehlt = [n for n in STATIONEN if not seite(n).eingebunden("flughafen.css")]
#         erwarte(not fehlt, "%s bindet flughafen.css noch nicht ein." % (fehlt[0] if fehlt else ""))
#
#     css("flughafen.css").wert("h1", "color")          # was in der Datei steht
#     seite("keflavik.html").stil("h1", "color")         # was der Browser daraus macht (Kaskade, Erben)

VERERBT = {"color", "font-family", "font-size", "font-style", "font-weight", "line-height", "text-align",
           "letter-spacing", "visibility", "list-style", "list-style-type"}


class Regel:
    def __init__(self, selektor, eigenschaften, zeile, datei, bedingung=""):
        self.selektor = " ".join(selektor.split())
        self.selektoren = [" ".join(s.split()) for s in self.selektor.split(",") if s.strip()]
        self.eigenschaften, self.zeile, self.datei, self.bedingung = eigenschaften, zeile, datei, bedingung

    def wert(self, eigenschaft):
        return self.eigenschaften.get(eigenschaft.lower(), ("", False))[0]

    def __repr__(self):
        return "<Regel %s Zeile %d>" % (self.selektor, self.zeile)


class Stilblatt:
    """Eine CSS-Datei (oder ein <style>-Block). da: ob es sie gibt. regeln, fehler [(Datei, Zeile, Text)], abdruck."""

    def __init__(self, name, quelle, da=True, zeile0=1):
        import hashlib
        self.name, self.quelle, self.da = name, quelle, da
        self.regeln, self.fehler = _css_lesen(quelle, name, zeile0)
        self.abdruck = hashlib.sha256(quelle.strip().encode("utf-8")).hexdigest()[:12]

    def regel(self, selektor):
        """Die letzte Regel, die genau diesen Selektor nennt (auch in einer Liste mit Komma), sonst None."""
        selektor = " ".join(selektor.split())
        treffer = [r for r in self.regeln if selektor in r.selektoren and not r.bedingung]
        return treffer[-1] if treffer else None

    def wert(self, selektor, eigenschaft):
        """Was in der Datei für diesen Selektor steht (die letzte Nennung), sonst ""."""
        eigenschaft = eigenschaft.lower()
        werte = [r.wert(eigenschaft) for r in self.regeln
                 if " ".join(selektor.split()) in r.selektoren and eigenschaft in r.eigenschaften and not r.bedingung]
        return werte[-1] if werte else ""

    def selektoren(self):
        return [s for r in self.regeln for s in r.selektoren]

    def meldung_fehler(self):
        return ("%s, Zeile %d: %s" % self.fehler[0]) if self.fehler else ""


def css(name):
    """Eine CSS-Datei aus dem Ordner der Arbeit; gibt es sie nicht, ist da False."""
    schluessel = "css:" + name
    if schluessel not in _SEITEN:
        p = (_ORDNER or pathlib.Path(".")) / name
        da = p.is_file()
        _SEITEN[schluessel] = Stilblatt(name, p.read_text("utf-8", errors="replace") if da else "", da)
    return _SEITEN[schluessel]


def _stilblatt_aus(datei, text, zeile0):
    return Stilblatt(datei, text, True, zeile0)


def _ohne_kommentare_css(text):
    """/* … */ durch Leerzeichen ersetzen, Zeilenumbrüche bleiben (die Zeilennummern stimmen weiter)."""
    return re.sub(r"/\*.*?(\*/|\Z)", lambda m: re.sub(r"[^\n]", " ", m.group(0)), text, flags=re.S)


def _an_semikolon(text):
    """An ; trennen, aber nicht in Klammern oder Anführungszeichen (url(data:…;base64,…), content: "a;b")."""
    teile, jetzt, tiefe, zeichen = [], [], 0, ""
    for c in text:
        if zeichen:
            zeichen = "" if c == zeichen else zeichen
        elif c in "\"'":
            zeichen = c
        elif c == "(":
            tiefe += 1
        elif c == ")":
            tiefe = max(0, tiefe - 1)
        elif c == ";" and not tiefe:
            teile.append("".join(jetzt))
            jetzt = []
            continue
        jetzt.append(c)
    teile.append("".join(jetzt))
    return teile


def _deklarationen_lesen(text, zeile, datei, fehler):
    """'color: red; margin: 0' -> {name: (wert, wichtig)}; Fehler mit Zeile nach fehler."""
    aus = {}
    for teil in _an_semikolon(text):
        z = zeile + len(re.match(r"\s*", teil).group(0).split("\n")) - 1
        zeile += teil.count("\n")
        roh = " ".join(teil.split())
        if not roh:
            continue
        if ":" not in roh:
            fehler.append((datei, z, "Zwischen Eigenschaft und Wert fehlt der Doppelpunkt: „%s“." % roh[:50]))
            continue
        name, wert = (x.strip() for x in roh.split(":", 1))
        if re.search(r"[a-z-]+\s*:", wert) and not re.search(r"(url|data)\s*\(", wert):
            fehler.append((datei, z, "Hier stehen zwei Angaben ohne Semikolon dazwischen: „%s“." % roh[:50]))
            continue
        if not name or not wert:
            fehler.append((datei, z, "Hier fehlt %s: „%s“." % ("der Wert" if name else "die Eigenschaft", roh[:50])))
            continue
        wichtig = wert.lower().replace(" ", "").endswith("!important")
        if wichtig:
            wert = re.sub(r"\s*!\s*important\s*$", "", wert, flags=re.I)
        aus[name.lower()] = (wert, wichtig)
    return aus


def _css_lesen(quelle, datei="", zeile0=1, bedingung=""):
    """Der Text eines Stylesheets -> ([Regel], [(Datei, Zeile, Text)])."""
    text = _ohne_kommentare_css(quelle)
    regeln, fehler = [], []
    i, zeile, n = 0, zeile0, len(text)
    while i < n:
        auf, zu = text.find("{", i), text.find("}", i)
        if zu != -1 and (auf == -1 or zu < auf):
            fehler.append((datei, zeile + text.count("\n", i, zu), "Hier steht } ohne { davor."))
            zeile += text.count("\n", i, zu + 1)
            i = zu + 1
            continue
        if auf == -1:
            rest = text[i:]
            if rest.strip():
                z = zeile + len(re.match(r"\s*", rest).group(0).split("\n")) - 1
                if not rest.strip().startswith("@"):
                    fehler.append((datei, z, "„%s“ steht ohne { … } da." % " ".join(rest.split())[:40]))
            break
        selektor = text[i:auf]
        z = zeile + len(re.match(r"\s*", selektor).group(0).split("\n")) - 1
        zeile_auf = zeile + selektor.count("\n")
        sel = " ".join(selektor.split())
        if sel.startswith("@"):
            # @media { Regeln }: das passende } über die Tiefe
            tiefe, j = 1, auf + 1
            while j < n and tiefe:
                tiefe += {"{": 1, "}": -1}.get(text[j], 0)
                j += 1
            if tiefe:
                fehler.append((datei, zeile_auf, "Hier öffnet {, bis zum Ende kommt kein }."))
            koerper, ende = (text[auf + 1:], n) if tiefe else (text[auf + 1:j - 1], j)
            if sel.lower().startswith(("@media", "@supports")):
                innen, f2 = _css_lesen(koerper, datei, zeile_auf, sel)
                regeln += innen
                fehler += f2
        else:
            naechste_auf, naechste_zu = text.find("{", auf + 1), text.find("}", auf + 1)
            if naechste_zu == -1 or (naechste_auf != -1 and naechste_auf < naechste_zu):
                # das } fehlt: die Regel endet an der letzten Zeile vor der nächsten Regel (oder am Ende)
                fehler.append((datei, zeile_auf, "Hier öffnet {, bis zur nächsten Regel kommt kein }."
                               if naechste_auf != -1 else "Hier öffnet {, bis zum Ende kommt kein }."))
                if naechste_auf == -1:
                    ende = n
                else:
                    umbruch = text.rfind("\n", auf, naechste_auf)
                    ende = umbruch if umbruch > auf else naechste_auf
                koerper = text[auf + 1:ende]
            else:
                koerper, ende = text[auf + 1:naechste_zu], naechste_zu + 1
            if not sel:
                fehler.append((datei, zeile_auf, "Vor { steht kein Selektor."))
            else:
                regeln.append(Regel(sel, _deklarationen_lesen(koerper, zeile_auf, datei, fehler), z, datei, bedingung))
        zeile = zeile_auf + text.count("\n", auf, ende)
        i = ende
    return regeln, fehler


_EINFACH = re.compile(r"^(?P<tag>[a-zA-Z][\w-]*|\*)?(?P<rest>(?:[.#][\w-]+|::?[\w-]+(?:\([^)]*\))?)*)$")


def _selektor_zerlegen(selektor):
    """'nav > a.aktiv' -> [(' ', 'nav', [], [], []), ('>', 'a', ['aktiv'], [], [])] -- None, wenn er unbekannte Teile hat
    (Attribut-Selektoren, +, ~): dann trifft er im Selbstcheck nichts."""
    teile, verb = [], " "
    for t in re.sub(r"\s*>\s*", " > ", selektor.strip()).split():
        if t == ">":
            verb = ">"
            continue
        m = _EINFACH.match(t)
        if not m or not t:
            return None
        rest = m.group("rest")
        pseudo = re.findall(r"::?([\w-]+)", rest)
        rest = re.sub(r"::?[\w-]+(\([^)]*\))?", "", rest)
        teile.append((verb, (m.group("tag") or "*").lower(), re.findall(r"\.([\w-]+)", rest),
                      re.findall(r"#([\w-]+)", rest), pseudo))
        verb = " "
    return teile or None


def _einfach_passt(k, teil):
    _, tag, klassen, ids, pseudo = teil
    if pseudo:
        return False        # Zustände (:hover, ::first-line) gelten im ruhenden Quelltext nicht
    return ((tag == "*" or k.tag == tag) and all(c in k.klassen() for c in klassen)
            and all(k.attribute.get("id") == i for i in ids))


def _selektor_passt(k, teile):
    if k.tag.startswith("#") or not _einfach_passt(k, teile[-1]):
        return False
    if len(teile) == 1:
        return True
    e = k.eltern
    if teile[-1][0] == ">":
        return e is not None and not e.tag.startswith("#") and _selektor_passt(e, teile[:-1])
    while e is not None and not e.tag.startswith("#"):
        if _selektor_passt(e, teile[:-1]):
            return True
        e = e.eltern
    return False


def _spezifitaet(teile):
    return (sum(len(t[3]) for t in teile), sum(len(t[2]) + len(t[4]) for t in teile),
            sum(1 for t in teile if t[1] != "*"))


def _pruefungen_laden(pfad):
    global _PRUEFUNG
    pfad = pathlib.Path(pfad).resolve()
    _PRUEFUNG = pfad
    sys.modules["pruefen"] = sys.modules[__name__]
    ns = runpy.run_path(str(pfad), run_name="pruefung")
    funktionen = [(n, f) for n, f in ns.items()
                  if n.startswith("pruefe_") and isinstance(f, types.FunctionType)]
    funktionen.sort(key=lambda nf: nf[1].__code__.co_firstlineno)
    titel = ns.get("TITEL", "Selbstcheck")
    _EINGABEN[:] = list(ns.get("EINGABEN", []))
    return titel, funktionen


def _titel(f, name):
    doc = (f.__doc__ or "").strip().splitlines()
    if doc:
        return doc[0].strip()
    return name.replace("pruefe_", "").replace("_", " ").capitalize()


def laufen(pruefung, arbeitsdatei):
    """Gibt das Ergebnis als Dict: {titel, ergebnisse: [...], fehler: ...}."""
    _still_stellen()
    aus = {"titel": "Selbstcheck", "ergebnisse": [], "fehler": None}
    try:
        titel, funktionen = _pruefungen_laden(pruefung)
    except Exception as e:  # noqa: BLE001
        aus["fehler"] = {"text": "Die Pruefdatei selbst ist kaputt (kein Fehler der Klasse).",
                         "zeile": None, "original": "%s: %s" % (type(e).__name__, e)}
        return aus
    aus["titel"] = titel
    global _ORDNER
    if pathlib.Path(arbeitsdatei).is_dir():
        _ORDNER = pathlib.Path(arbeitsdatei).resolve()      # HTML: nichts laeuft, seite() liest
        aus["abbruch"] = None
        funktionen_laufen(funktionen, aus)
        return aus
    try:
        aus["abbruch"] = _arbeit_laden(arbeitsdatei)
    except SyntaxError as e:
        aus["fehler"] = {"text": "Die Datei laesst sich nicht lesen: Python versteht Zeile %s nicht." % e.lineno,
                         "zeile": e.lineno, "original": "%s: %s" % (type(e).__name__, e.msg)}
        return aus
    except BaseException as e:  # noqa: BLE001 -- der Fehler der Arbeitsdatei ist Inhalt
        tb = traceback.extract_tb(sys.exc_info()[2])
        zeile = None
        for fr in tb:
            if pathlib.Path(fr.filename).resolve() == _ARBEITSDATEI:
                zeile = fr.lineno
        aus["fehler"] = {"text": "Die Datei bricht beim Start ab" + (" in Zeile %d" % zeile if zeile else "") + ".",
                         "zeile": zeile, "original": "%s: %s" % (type(e).__name__, e)}
        return aus
    funktionen_laufen(funktionen, aus)
    return aus


def funktionen_laufen(funktionen, aus):
    for name, f in funktionen:
        eintrag = {"name": name, "titel": _titel(f, name), "stand": "passt", "text": ""}
        try:
            _mit_zeitgrenze(f, ZEITGRENZE * 2)
        except _ZuLang:
            eintrag["stand"] = "offen"
            eintrag["text"] = ENDLOS
        except NochNichtDran as e:
            eintrag["stand"] = "spaeter"
            eintrag["text"] = str(e)
        except AssertionError as e:
            eintrag["stand"] = "offen"
            eintrag["text"] = str(e) or "passt noch nicht"
        except Exception as e:  # noqa: BLE001 -- Fehler IN der Pruefung: ehrlich melden
            eintrag["stand"] = "offen"
            eintrag["text"] = "Beim Pruefen ging etwas schief: %s: %s" % (type(e).__name__, e)
        aus["ergebnisse"].append(eintrag)
    return aus


def gruppe(titel):
    # „Aufgabe 3 ★★ · …“: die Sterne gehoeren zur Gruppe (Stufe der Aufgabe, 16.10.)
    m = re.match(r"(Aufgabe \d+\w?(?:\s*\u2605+)?|K\xfcr|Kuer|Vorrat|Grundlage)\s*\xb7\s*(.*)", titel)
    return (m.group(1), m.group(2)) if m else (titel, "")


def als_text(ergebnis, breite=46, zeile=66):
    """Die Klartextfassung -- wie der pytest-Nachspann seit dem 02.09.:
    je Aufgabe eine Zeile, genau EIN naechster Schritt im Detail."""
    z = []
    z.append("  " + ergebnis["titel"])
    z.append("  " + "-" * (breite + 18))
    if ergebnis["fehler"]:
        z.append("  " + ergebnis["fehler"]["text"])
        for t in textwrap.wrap(ergebnis["fehler"]["original"], zeile):
            z.append("      " + t)
        z.append("  " + "-" * (breite + 18))
        return "\n".join(z)
    if ergebnis.get("abbruch"):
        z.append("  !! " + ergebnis["abbruch"]["text"])
        for t in textwrap.wrap(ergebnis["abbruch"]["original"], zeile):
            z.append("      " + t)
    gruppen, folge = {}, []
    for e in ergebnis["ergebnisse"]:
        g, rest = gruppe(e["titel"])
        if g not in gruppen:
            gruppen[g] = []
            folge.append(g)
        gruppen[g].append(e)
    for g in folge:
        ee = gruppen[g]
        passt = sum(1 for e in ee if e["stand"] == "passt")
        offen = sum(1 for e in ee if e["stand"] == "offen")
        if passt == len(ee):
            stand = "passt"
        elif passt == 0 and offen == 0:
            stand = "noch nicht dran"
        elif passt == 0:
            stand = "steht noch aus"
        else:
            stand = "%d von %d %s" % (passt, len(ee), "passt" if passt == 1 else "passen")
        z.append("  %-*s  %s" % (breite, g, stand))
    naechste = next((e for e in ergebnis["ergebnisse"] if e["stand"] == "offen"), None)
    if naechste:
        z.append("")
        z.append("  Der naechste Schritt -- " + naechste["titel"] + ":")
        for t in textwrap.wrap(naechste["text"], zeile):
            z.append("      " + t)
    z.append("  " + "-" * (breite + 18))
    alle = len(ergebnis["ergebnisse"])
    passt = sum(1 for e in ergebnis["ergebnisse"] if e["stand"] == "passt")
    spaeter = sum(1 for e in ergebnis["ergebnisse"] if e["stand"] == "spaeter")
    if passt == alle and alle:
        z.append("  Alle %d passen -- fertig!" % alle)
    else:
        satz = "  %d von %d passen." % (passt, alle - spaeter)
        if spaeter:
            satz += " %d %s noch nicht dran." % (spaeter, "ist" if spaeter == 1 else "sind")
        z.append(satz)
    return "\n".join(z)


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 2
    form = "--json" if "--json" in argv else "--text"
    pruefung, arbeitsdatei = argv[0], argv[1]
    ergebnis = laufen(pruefung, arbeitsdatei)
    if form == "--json":
        sys.__stdout__.write("\n@@SELBSTCHECK@@" + json.dumps(ergebnis, ensure_ascii=False) + "\n")
    else:
        sys.__stdout__.write("\n" + als_text(ergebnis) + "\n")
    sys.__stdout__.flush()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
