"""Die Uebersicht der Lehrerfassung: Abgaben aus dem Schulportal + Kursliste
hineinziehen -> Tabelle Schueler x Aufgabe, wer fehlt, Selbstchecks am
abgegebenen Code NACHGELAUFEN (isoliert, Zeitlimit je Abgabe).

Das gemessene Muster des Schulportal-Downloads (VORGEMERKT 2026-10-05):
  * ein FLACHER Ordner (oder eine ZIP), jede Datei heisst
    "Nachname Vorname <Originalname>"; Doppel als "... (1).zip"
  * keine Metadaten, kein Abgabezeitpunkt -- "neuer gilt" kommt aus dem Inhalt
  * die Kursliste ist ein Export "Kursliste_<Kurs>_<Zeit>.doc": in Wahrheit
    HTML, eine Tabelle mit # · Nachname · Vorname · Klasse
  * unsere Datei hat einen festen Namen (abgabe_<kurs>_<thema>_...zip):
    alles vor " abgabe_" ist der Name; Fremddateien (Fotos) gehen an die
    laengste passende Namens-Vorsilbe; Rest "nicht zugeordnet"

Alles bleibt im Speicher und in einem temporaeren Ordner: schliessen = weg.
"""
import base64
import concurrent.futures
import html.parser
import io
import json
import pathlib
import re
import shutil
import tempfile
import time
import unicodedata
import zipfile

from . import ausfuehren

HIER = pathlib.Path(__file__).resolve().parent
ZEITLIMIT = 10


def norm(t):
    t = unicodedata.normalize("NFC", t).lower()
    for a, b in (("ä", "ae"), ("ö", "oe"), ("ü", "ue"), ("ß", "ss")):
        t = t.replace(a, b)
    t = unicodedata.normalize("NFKD", t)
    t = "".join(c for c in t if not unicodedata.combining(c))
    return re.sub(r"[\s\-_]+", " ", t).strip()


class KurslisteLeser(html.parser.HTMLParser):
    def __init__(self):
        super().__init__()
        self.reihen, self._reihe, self._zelle, self._in = [], None, None, False

    def handle_starttag(self, tag, attrs):
        if tag == "tr":
            self._reihe = []
        elif tag in ("td", "th") and self._reihe is not None:
            self._zelle = []

    def handle_endtag(self, tag):
        if tag in ("td", "th") and self._zelle is not None and self._reihe is not None:
            self._reihe.append(" ".join("".join(self._zelle).split()))
            self._zelle = None
        elif tag == "tr" and self._reihe is not None:
            if self._reihe:
                self.reihen.append(self._reihe)
            self._reihe = None

    def handle_data(self, d):
        if self._zelle is not None:
            self._zelle.append(d)


def stand_name(daten: bytes):
    """„Nachname Vorname“ aus dem stand.json einer Abgabe-ZIP -- oder None."""
    try:
        with zipfile.ZipFile(io.BytesIO(daten)) as z:
            st = json.loads(z.read("stand.json").decode("utf-8"))
    except (zipfile.BadZipFile, KeyError, ValueError):
        return None
    n = (str(st.get("nachname", "")).strip() + " " + str(st.get("vorname", "")).strip()).strip()
    return n or None


def gleiche_person(a, b):
    """Derselbe Mensch, auch wenn einer der beiden Namen den zweiten Vornamen weglaesst."""
    a, b = norm(a), norm(b)
    return a == b or a.startswith(b + " ") or b.startswith(a + " ")


def kursliste_lesen(daten: bytes):
    """-> [{"nachname", "vorname", "klasse"}] aus der .doc (HTML)."""
    for enc in ("utf-8", "cp1252", "latin-1"):
        try:
            text = daten.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    p = KurslisteLeser()
    p.feed(text)
    personen = []
    spalten = None
    for r in p.reihen:
        if spalten is None:
            kleine = [norm(c) for c in r]
            if "nachname" in kleine and "vorname" in kleine:
                spalten = {"nachname": kleine.index("nachname"), "vorname": kleine.index("vorname"),
                           "klasse": kleine.index("klasse") if "klasse" in kleine else None}
            continue
        if len(r) <= max(spalten["nachname"], spalten["vorname"]):
            continue
        personen.append({"nachname": r[spalten["nachname"]], "vorname": r[spalten["vorname"]],
                         "klasse": r[spalten["klasse"]] if spalten["klasse"] is not None and spalten["klasse"] < len(r) else ""})
    if spalten is None:
        raise ValueError("In der Kursliste ist keine Tabelle mit den Spalten Nachname und Vorname.")
    return personen


class Uebersicht:
    def __init__(self, Z):
        self.Z = Z
        self.tmp = pathlib.Path(tempfile.mkdtemp(prefix="lernraum_uebersicht_"))
        self.personen = []          # aus der Kursliste
        self.abgaben = []           # je Datei: {datei, name, person, thema, stand, code, selbstcheck, hinweis}
        self.fehler_liste = []
        self.nachgelaufen = False
        self.dauer = None
        self._indizien = None      # I1: einmal je geladener Menge gerechnet

    # -- Laden ---------------------------------------------------------------
    def dateien_aufnehmen(self, dateien):
        """dateien: [(name, bytes)]. ZIPs mit mehreren Abgaben (der Portal-Download
        als ZIP) werden ausgepackt; eine ZIP mit stand.json ist eine Abgabe."""
        flach = []
        for name, daten in dateien:
            if name.lower().endswith(".zip"):
                try:
                    with zipfile.ZipFile(io.BytesIO(daten)) as z:
                        namen = z.namelist()
                        if "stand.json" in namen:
                            flach.append((name, daten))
                            continue
                        for n in namen:
                            if n.endswith("/") or "/." in n or n.startswith("__MACOSX"):
                                continue
                            flach.append((pathlib.PurePosixPath(n).name, z.read(n)))
                except zipfile.BadZipFile:
                    self.fehler_liste.append("%s: keine lesbare ZIP" % name)
            else:
                flach.append((name, daten))
        return flach

    def name_aus_datei(self, name):
        m = re.match(r"^(.*?)\s+abgabe_", name)
        return m.group(1).strip() if m else None

    def person_finden(self, namenstext):
        """Laengster Treffer gewinnt: 'Nachname Vorname' voll, dann nur erster Vorname."""
        n = norm(namenstext)
        beste, laenge = None, 0
        for p in self.personen:
            voll = norm(p["nachname"] + " " + p["vorname"])
            erster = norm(p["nachname"] + " " + p["vorname"].split()[0]) if p["vorname"].split() else voll
            for kandidat in (voll, erster):
                if n == kandidat or n.startswith(kandidat + " "):
                    if len(kandidat) > laenge:
                        beste, laenge = p, len(kandidat)
        return beste

    def laden(self, dateien, kursliste, nachlaufen=True):
        t0 = time.time()
        if kursliste is not None:
            try:
                self.personen = kursliste_lesen(kursliste)
            except ValueError as e:
                self.fehler_liste.append(str(e))
        flach = self.dateien_aufnehmen(dateien)
        for name, daten in flach:
            eintrag = {"datei": name, "name": None, "person": None, "thema": None, "stand": None,
                       "code": None, "selbstcheck": None, "hinweis": None, "fremd": False}
            nt = self.name_aus_datei(name)
            # Lehrer 16.10.: der Name steht auch IN der Abgabe (stand.json, aus dem Zahnrad). Der Dateiname
            # aus dem Portal fuehrt (er kommt aus dem Login); ohne ihn -- per Mail, vom Stick -- gilt der Name im Stand.
            im_stand = stand_name(daten) if name.lower().endswith(".zip") else None
            if nt is None and im_stand:
                nt = im_stand
                eintrag["hinweis"] = "ohne Portal-Namen – zugeordnet nach dem Namen im Stand"
                self.fehler_liste.append("%s: kein Name aus dem Portal – zugeordnet nach dem Namen im Stand (%s)" % (name, im_stand))
            if nt is None:
                # Fremddatei (Foto o.ae.): laengste passende Namens-Vorsilbe
                p = self.person_finden(name) if self.personen else None
                if p is None:
                    self.fehler_liste.append("%s: kein lesbarer Name im Dateinamen -- nicht zugeordnet" % name)
                    continue
                eintrag.update(name=p["nachname"] + " " + p["vorname"], person=p, fremd=True)
                self.abgaben.append(eintrag)
                continue
            eintrag["name"] = nt
            if self.personen:
                p = self.person_finden(nt)
                if p is None:
                    self.fehler_liste.append("%s: '%s' steht nicht in der Kursliste" % (name, nt))
                    eintrag["hinweis"] = "nicht in der Kursliste"
                else:
                    eintrag["person"] = p
                    eintrag["name"] = p["nachname"] + " " + p["vorname"]
            if im_stand and not eintrag["hinweis"] and not gleiche_person(im_stand, eintrag["name"]):
                # Portal sagt A, im Stand steht B: Spitzname, Tippfehler -- oder die Abgabe der Partnerin
                eintrag["hinweis"] = "im Stand steht „%s“" % im_stand
                self.fehler_liste.append("%s: hochgeladen von %s, im Stand steht „%s“ – bitte nachsehen" % (name, eintrag["name"], im_stand))
            try:
                with zipfile.ZipFile(io.BytesIO(daten)) as z:
                    stand = json.loads(z.read("stand.json").decode("utf-8"))
                    eintrag["stand"] = stand
                    eintrag["thema"] = stand.get("thema")
                    if "anmerkungen.json" in z.namelist():
                        try:
                            from .server import anmerkungen_pruefen
                            eintrag["anmerkungen"] = anmerkungen_pruefen(json.loads(z.read("anmerkungen.json").decode("utf-8")).get("anmerkungen", []))
                        except Exception:   # kaputte Anmerkungen kosten nie die ganze Abgabe
                            self.fehler_liste.append("%s: Anmerkungen nicht lesbar -- uebergangen" % name)
                    for n in z.namelist():
                        if n.endswith(".py") and n.startswith("themen/") and len(n.split("/")) == 5 and "/vortrag/" not in n:
                            # Python-Ordner (11.11.2026): themen/<reihe>/<thema>/<ordner>/<datei>.py -- jede Datei
                            # der Klasse; gegebene Module und Bilder reisen nicht mit, sie kommen beim Nachlaufen
                            # aus dem Thema
                            (eintrag.setdefault("module", {}))["/".join(n.split("/")[3:])] = z.read(n).decode("utf-8", "replace")
                        elif n.endswith(".py") and "/vortrag/" not in n:
                            eintrag["code"] = z.read(n).decode("utf-8", "replace")
                            eintrag["codedatei"] = pathlib.PurePosixPath(n).name
                        elif n.endswith((".html", ".css")) and n.startswith("themen/") and "/vortrag/" not in n:
                            # HTML (29.10.): die Seiten des Ordners -- themen/<reihe>/<thema>/<ordner>/<datei>
                            (eintrag.setdefault("seiten", {}))["/".join(n.split("/")[3:])] = z.read(n).decode("utf-8", "replace")
                    if eintrag.get("seiten") and not eintrag.get("code"):
                        eintrag["code"] = "\n\n".join("<!-- %s -->\n%s" % (k, v) for k, v in sorted(eintrag["seiten"].items()))
                    if eintrag.get("module"):
                        eintrag["code"] = "\n\n".join("# ── %s ──\n%s" % (k.split("/", 1)[-1], v) for k, v in sorted(eintrag["module"].items()))
            except (zipfile.BadZipFile, KeyError, ValueError) as e:
                self.fehler_liste.append("%s: kein gueltiger Stand in der ZIP (%s)" % (name, type(e).__name__))
                eintrag["hinweis"] = "ZIP ohne gueltigen Stand"
                self.abgaben.append(eintrag)
                continue
            if eintrag["thema"] and self.Z.thema(eintrag["thema"])[1] is None:
                self.fehler_liste.append("%s: Stand aus einem unbekannten Thema '%s'" % (name, eintrag["thema"]))
                eintrag["hinweis"] = "unbekanntes Thema"
            elif eintrag["thema"]:
                _, th = self.Z.thema(eintrag["thema"])
                if stand.get("hash") and th.get("hash") and stand["hash"] != th["hash"]:
                    eintrag["hinweis"] = "aeltere Fassung des Themas (%s)" % stand["hash"]
                    self.fehler_liste.append("%s: beantwortet eine andere Fassung des Themas (Hash %s, aktuell %s)" % (name, stand["hash"], th["hash"]))
                for k in stand.get("aufgaben", {}):
                    nr = k.rsplit("/", 1)[-1]
                    if nr != "miniexit" and not any(a["nr"] == nr for a in th["uebung"]["aufgaben"]):
                        self.fehler_liste.append("%s: Aufgabenkennung %s gibt es nicht (mehr)" % (name, k))
            self.abgaben.append(eintrag)
        # Doppel: dieselbe Person + dasselbe Thema -> die neuere Abgabe gilt
        gesehen = {}
        for e in list(self.abgaben):
            if e["stand"] is None:
                continue
            k = (norm(e["name"] or ""), e["thema"])
            if k in gesehen:
                alt = gesehen[k]
                neuer, aelter = (e, alt) if (e["stand"].get("abgegeben", "") > alt["stand"].get("abgegeben", "")) else (alt, e)
                self.abgaben.remove(aelter)
                gesehen[k] = neuer
                self.fehler_liste.append("%s: zwei Abgaben von %s zu %s -- die neuere (%s) gilt" % (aelter["datei"], e["name"], e["thema"], neuer["stand"].get("abgegeben", "?")))
            else:
                gesehen[k] = e
        if nachlaufen:
            self.nachlaufen(True)
        self.dauer = round(time.time() - t0, 1)
        return self

    # -- Nachlaufen -------------------------------------------------------------------
    def _einen_pruefen(self, e):
        _, th = self.Z.thema(e["thema"])
        pruefung = self.Z.themenordner(e["thema"]) / "pruefung.py"
        if not pruefung.exists():
            return None
        ordner = pathlib.Path(tempfile.mkdtemp(prefix="abgabe_", dir=self.tmp))
        if e.get("module") and th.get("arbeitsart") == "python":
            # Python-Ordner (11.11.2026): der Ordner des Themas (gegebene Module, Bilder), darueber die Dateien der
            # Abgabe; geprueft wird das Programm, das „Ausführen“ startet
            name = th["arbeitsdatei"]
            vorlage = self.Z.themenordner(e["thema"]) / name
            if vorlage.is_dir():
                shutil.copytree(vorlage, ordner / name, ignore=shutil.ignore_patterns("__pycache__"))
            for rel, text in e["module"].items():
                if rel in th.get("arbeitsdateien", []):      # nur, was Arbeit der Klasse ist -- nie ein gegebenes Modul
                    (ordner / rel).parent.mkdir(parents=True, exist_ok=True)
                    (ordner / rel).write_text(text, "utf-8")
            arbeit = ordner / th["arbeitsstart"]
        elif e.get("seiten"):
            arbeit = ordner / (th.get("arbeitsdatei") or "seiten")
            for rel, text in e["seiten"].items():
                (ordner / rel).parent.mkdir(parents=True, exist_ok=True)
                (ordner / rel).write_text(text, "utf-8")
            arbeit.mkdir(exist_ok=True)
        else:
            arbeit = ordner / (e.get("codedatei") or th.get("arbeitsdatei") or "arbeit.py")
            arbeit.write_text(e["code"], "utf-8")
        shutil.copyfile(pruefung, ordner / "pruefung.py")
        code, text, zu_lang = ausfuehren.einmal(
            [str(HIER / "pruefen.py"), str(ordner / "pruefung.py"), str(arbeit), "--json"], cwd=ordner, zeitlimit=ZEITLIMIT)
        if zu_lang:
            return {"passt": 0, "von": 0, "fehler": True, "text": "Zeitlimit (%d s) -- laeuft das Programm endlos?" % ZEITLIMIT, "je": {}}
        marke = "@@SELBSTCHECK@@"
        if marke not in text:
            return {"passt": 0, "von": 0, "fehler": True, "text": "Selbstcheck lief nicht: " + text[-200:], "je": {}}
        erg = json.loads(text.split(marke, 1)[1].splitlines()[0])
        from .sterne import selbstcheck_je
        je = selbstcheck_je(erg.get("ergebnisse", []))       # je Aufgabe und Stufe (Sterne, 16.10.)
        return {"passt": sum(1 for r in erg.get("ergebnisse", []) if r["stand"] == "passt"),
                "von": len(erg.get("ergebnisse", [])), "fehler": bool(erg.get("fehler")),
                "text": (erg.get("fehler") or {}).get("text", ""), "je": je}

    def nachlaufen(self, an=True):
        if not an:
            for e in self.abgaben:
                e["selbstcheck"] = None
            self.nachgelaufen = False
            return
        kandidaten = [e for e in self.abgaben if e["code"] and e["thema"] and self.Z.thema(e["thema"])[1] is not None]
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            for e, erg in zip(kandidaten, pool.map(self._einen_pruefen, kandidaten)):
                e["selbstcheck"] = erg
        self.nachgelaufen = True

    # -- Bericht -------------------------------------------------------------------
    def bericht(self):
        themen = sorted({e["thema"] for e in self.abgaben if e["thema"]})
        aufgaben = []
        for t in themen:
            _, th = self.Z.thema(t)
            if th:
                for a in th["uebung"]["aufgaben"]:
                    if a["nr"] not in aufgaben:
                        aufgaben.append(a["nr"])
        zeilen, abgegeben = [], 0
        zugeordnet = set()
        reihenfolge = [p["nachname"] + " " + p["vorname"] for p in self.personen] or sorted({e["name"] for e in self.abgaben if e["name"]})
        for i, name in enumerate(reihenfolge):
            eigene = [e for e in self.abgaben if e["name"] == name and e["stand"] is not None]
            fremde = [e for e in self.abgaben if e["name"] == name and e["fremd"]]
            if not eigene:
                zeilen.append({"nr": None, "name": name, "fehlt": True, "fremd": [f["datei"] for f in fremde]})
                continue
            for e in eigene:
                abgegeben += 1
                nr = self.abgaben.index(e)
                zugeordnet.add(nr)
                st = e["stand"]
                je = {}
                hilfen_summe = 0
                for k, a in st.get("aufgaben", {}).items():
                    anr = k.rsplit("/", 1)[-1]
                    if anr == "miniexit":
                        continue
                    z = je.setdefault(anr, {})
                    if a.get("hilfen"):
                        z["hilfen"] = len(a["hilfen"])
                        hilfen_summe += len(a["hilfen"])
                    if a.get("haken"):
                        z["haken"] = a["haken"]
                    if a.get("selbstcheck") and not e["selbstcheck"]:
                        z["sc"] = a["selbstcheck"]           # Selbstauskunft, wenn nicht nachgelaufen
                if e["selbstcheck"]:
                    for anr, sc in e["selbstcheck"]["je"].items():
                        je.setdefault(anr, {})["sc"] = sc
                # Plaene (19.10.2026): aus der Abgabe nachgerechnet -- die Zelle sagt „Plan 3/4“, aufgeklappt
                # das Bild (die Seite zeichnet es aus der Quelle) und der erste Fall, der nicht stimmt
                _, thp = self.Z.thema(e["thema"]) if e["thema"] else (None, None)
                # (09.11.: hiess die Schleifenvariable „name“, ueberschrieb sie die Person -- die Zeile hiess dann wie der
                # Plan, „rekord“ statt „Testerin Mira“, und alles danach (Sterne, Partner) lief unter falschem Namen)
                for a in (thp or {}).get("uebung", {}).get("aufgaben", []):
                    for pname in a.get("plan") or []:
                        spec = ((thp or {}).get("plaene") or {}).get(pname)
                        gemerkt = (st.get("plaene") or {}).get(e["thema"] + "/" + pname)
                        if not spec or not gemerkt:
                            continue
                        from . import plan as planlauf
                        r = planlauf.pruefen(gemerkt.get("quelle", ""), spec["proben"])
                        falsch = [{"zeigen": p["zeigen"], "soll": p["soll"], "aus": x["ausgaben"], "grund": x["grund"], "fehler": x["fehler"]}
                                  for p, x in zip(spec["proben"], r["proben"]) if not x["ok"]]
                        je.setdefault(a["nr"], {})["plan"] = {"ok": r["ok"], "von": r["von"], "lesbar": r["lesbar"], "quelle": gemerkt.get("quelle", ""),
                                                             "titel": gemerkt.get("titel", ""), "zeit": gemerkt.get("zeit", ""), "falsch": falsch[:1],
                                                             "name": pname}
                # Diagramme (13.11.2026): aus der Abgabe gegen die Aufgabe nachgerechnet -- die Zelle sagt „Diagramm ✓“
                # oder „Diagramm ✗“, aufgeklappt das Bild (die Seite zeichnet es aus dem Modell) und die erste Meldung
                from .server import diagramm_finden, diagramm_modell
                from . import klassenregeln
                for a in (thp or {}).get("uebung", {}).get("aufgaben", []):
                    for dname in a.get("diagramm") or []:
                        spec = diagramm_finden(e["thema"] + "/" + dname, self.Z.pruefstoff)
                        gemerkt = (st.get("diagramme") or {}).get(e["thema"] + "/" + dname)
                        if not spec or not gemerkt or not gemerkt.get("modell"):
                            continue
                        modell = diagramm_modell(gemerkt["modell"])
                        r = klassenregeln.vergleichen(modell, spec[1], spec[0])
                        je.setdefault(a["nr"], {})["diagramm"] = {"ok": r["ok"], "meldungen": r["meldungen"][:3], "modell": modell,
                                                                 "zeit": gemerkt.get("zeit", ""), "versuche": gemerkt.get("versuche", 0), "name": dname}
                # Wie in der Klausur (09.11.2026): je Text die selbst gegebenen BE, Claudes Vorschlag und was die
                # Lehrkraft bestaetigt hat (bewertung.py). Die Zelle sagt „geprüft 3/4“ oder „selbst 4/4“, aufgeklappt
                # stehen Text, Raster, Vorschlag mit Gruenden und „bestätigen“.
                from . import bewertung as bw
                from .abdruck import entschleiern
                for a in (thp or {}).get("uebung", {}).get("aufgaben", []):
                    for k in a.get("klausur") or []:
                        kk = e["thema"] + "/" + k["name"]
                        g = (st.get("klausuren") or {}).get(kk)
                        if not g:
                            continue
                        geheim = (self.Z.pruefstoff.get("klausuren") or {}).get(kk)
                        raster = json.loads(entschleiern(kk, "klausur", geheim["geheim"]))["raster"] if geheim else []
                        zk = je.setdefault(a["nr"], {}).setdefault("klausur", {"teile": []})
                        zk["teile"].append(dict({"name": k["name"], "kennung": kk, "text": g.get("text", ""), "verglichen": bool(g.get("verglichen")),
                                                "selbst": [bool(x) for x in (g.get("raster") or [])] + [False] * (k["be"] - len(g.get("raster") or [])),
                                                "raster": raster, "be": k["be"]},
                                               **bw.fuer_person(self.Z.wurzel, name, kk, g.get("text", ""), k["be"])))
                pa = st.get("partner") or {}
                # Sterne (16.10.): aus der Abgabe nachgerechnet -- Selbstcheck neu gelaufen, Antworten
                # gegen den Pruefstoff; ohne Nachlauf nur die Selbstauskunft des Stands (markiert)
                from .sterne import thema_sterne
                _, th = self.Z.thema(e["thema"]) if e["thema"] else (None, None)
                sterne = None
                if th and any(a.get("sterne") for a in th["uebung"]["aufgaben"]):
                    from .bewertung import geprueft_je
                    sterne = thema_sterne(e["thema"], th, st, self.Z.pruefstoff, sc_je=(e["selbstcheck"] or {}).get("je") if e["selbstcheck"] else None,
                                          geprueft=geprueft_je(self.Z.wurzel, name, e["thema"], st))
                    # ohne Arbeitsdatei (netz, klassen: kein Code zum Nachlaufen) ist alles aus Stand und Pruefstoff nachgerechnet --
                    # bis 13.11. stand dort trotzdem „(?)“ (Selbstauskunft), am Diagrammtest gesehen
                    sterne["nachgerechnet"] = bool(e["selbstcheck"]) or not th.get("arbeitsdatei")
                    for anr, s in sterne["aufgaben"].items():
                        # [geschafft, hoechste moegliche, hoechste versuchte] -- versucht nur zur Information
                        je.setdefault(anr, {})["sterne"] = [s["sterne"], s["max"], max(s.get("versucht") or [0])]
                zeilen.append({"nr": nr, "name": name, "thema": e["thema"], "aufgaben": je, "hilfen": hilfen_summe, "sterne": sterne,
                               "partner": pa.get("name", ""), "partner_norm": norm((pa.get("nachname", "") + " " + pa.get("vorname", "")).strip()),
                               "selbstcheck": e["selbstcheck"] or (st.get("themen", {}).get(e["thema"], {}) or {}).get("selbstcheck"),
                               "miniexit": (st.get("aufgaben", {}).get(e["thema"] + "/miniexit", {}) or {}).get("miniexit", ""),
                               "hinweis": e["hinweis"], "fremd": [f["datei"] for f in fremde], "fehlt": False,
                               # Loesung (16.11.2026): None bei Abgaben aus aelteren Fassungen
                               "loesung": (st.get("loesung_spur") or {}).get(e["thema"]) if "loesung_spur" in st else None,
                               # Einfuege-Spur (KI-A): {} = getippt, None = Abgabe aus einer Fassung ohne die Spur
                               "eingefuegt": ((st.get("einfuegen") or {}).get(e["thema"]) or {}) if "einfuegen" in st else None,
                               # Laufzaehlung (I2): {} = nie ausgefuehrt, None = Abgabe aus einer Fassung ohne die Zaehlung
                               "laeufe": ((st.get("laeufe") or {}).get(e["thema"]) or {}) if "laeufe" in st else None,
                               "abgegeben": st.get("abgegeben", "")})
        for nr, e in enumerate(self.abgaben):
            if nr not in zugeordnet and e["stand"] is not None and e["name"] not in reihenfolge:
                st_ = e["stand"] or {}
                zeilen.append({"nr": nr, "name": e["name"] or e["datei"], "thema": e["thema"], "aufgaben": {}, "hilfen": 0,
                               "selbstcheck": e["selbstcheck"], "miniexit": "", "hinweis": e["hinweis"] or "nicht in der Kursliste", "fehlt": False,
                               "eingefuegt": ((st_.get("einfuegen") or {}).get(e["thema"]) or {}) if "einfuegen" in st_ else None})
        self.indizien_eintragen(zeilen)
        # Partnerarbeit (Weg 3): wer fehlt, aber von einer Abgabe als Partner(in) genannt wird.
        # Lokal anhaengen -- bericht() laeuft je Abruf, self.fehler_liste wuerde sonst wachsen.
        hinweise = list(self.fehler_liste)
        for z in zeilen:
            if not z.get("fehlt"):
                continue
            nenner = [y for y in zeilen if not y.get("fehlt") and y.get("partner_norm") and y["partner_norm"] == norm(z["name"])]
            if nenner:
                z["partner_von"] = nenner[0]["name"]
                hinweise.append("%s: keine eigene Abgabe, aber %s nennt %s als Partner(in) zu %s -- die Stand-ZIP von %s holen und selbst abgeben"
                                         % (z["name"], nenner[0]["name"], z["name"], nenner[0]["thema"] or "?", nenner[0]["name"]))
        for z in zeilen:
            z.pop("partner_norm", None)
        fehlend = [z["name"] for z in zeilen if z.get("fehlt")]
        # Summen fuer die Klasse
        summen = {}
        mit = [z for z in zeilen if not z.get("fehlt")]
        for a in aufgaben:
            n_alle = sum(1 for z in mit if a in z["aufgaben"] and z["aufgaben"][a].get("sc"))
            n_passt = sum(1 for z in mit if a in z["aufgaben"] and z["aufgaben"][a].get("sc") and z["aufgaben"][a]["sc"]["passt"] == z["aufgaben"][a]["sc"]["von"])
            n_h2 = sum(1 for z in mit if a in z["aufgaben"] and (z["aufgaben"][a].get("hilfen") or 0) >= 2)
            n_frage = sum(1 for z in mit if a in z["aufgaben"] and z["aufgaben"][a].get("haken") == "?")
            teile = []
            if n_alle:
                teile.append("%d von %d ganz gruen" % (n_passt, n_alle))
            if n_h2:
                teile.append("%d haben die zweite Hilfe geoeffnet" % n_h2)
            if n_frage:
                teile.append("%d sagen '?'" % n_frage)
            if teile:
                summen["Aufgabe " + a] = " · ".join(teile)
        return {"personen": [p["nachname"] + " " + p["vorname"] for p in self.personen], "zeilen": zeilen,
                "fehlend": fehlend, "abgegeben": abgegeben, "aufgaben": aufgaben, "fehler_liste": hinweise,
                "summen": summen, "nachgelaufen": self.nachgelaufen, "dauer": self.dauer,
                "anmerkungen": [{k: a[k] for k in ("thema", "route", "titel", "art", "text", "ausschnitt")} for a in self.alle_anmerkungen()],
                "fehlerbuch": self.fehlerbuch_klasse(),
                "einschaetzung": self.einschaetzung_klasse(zeilen),
                "ablauf": self.ablauf_klasse(),
                "lernkarten": self.lernkarten_klasse()}

    # -- Indizien (I1, 25.11.2026) --------------------------------------------------------------------------------
    def _dateien(self, e):
        """Der Python-Code einer Abgabe als {datei: code} -- HTML-Seiten nicht (I1 prueft nur Python)."""
        if e.get("module"):
            return {k.split("/", 1)[-1]: v for k, v in e["module"].items() if k.endswith(".py")}
        if e.get("code") and not e.get("seiten"):
            return {e.get("codedatei") or "arbeit.py": e["code"]}
        return {}

    def _start_und_loesung(self, kennung):
        _, th = self.Z.thema(kennung)
        ordner = self.Z.themenordner(kennung)
        start, loesung = [], []
        ad = (th or {}).get("arbeitsdatei") or ""
        if ad:
            p = ordner / ad
            if p.is_file() and p.suffix == ".py":
                start.append(p.read_text("utf-8", "replace"))
            elif p.is_dir():
                start += [q.read_text("utf-8", "replace") for q in sorted(p.rglob("*.py")) if "__pycache__" not in q.parts]
        lo = ordner / "loesung.json"
        if lo.is_file():
            try:
                loesung = [v for k, v in (json.loads(lo.read_text("utf-8")).get("dateien") or {}).items() if k.endswith(".py") and isinstance(v, str)]
            except ValueError:
                pass
        return start, loesung

    def indizien_eintragen(self, zeilen):
        """Je Zeile mit Abgabe: z["indizien"] = [{art, staerke, kurz, text, frage, belege?}] -- gerechnet, nie gespeichert
        (Entscheidung 5). Einmal je geladener Menge; der Bericht laeuft je Abruf."""
        from . import indizien as ind
        if getattr(self, "_indizien", None) is None:
            speicher, je, themen = {}, {}, {}
            for z in zeilen:
                if z.get("fehlt") or z.get("nr") is None or not z.get("thema"):
                    continue
                e = self.abgaben[z["nr"]]
                # Verstehen und Ergebnis (I2) gilt fuer jedes Thema, auch ohne Python (netz, webseite)
                reihe, th = self.Z.thema(z["thema"])
                if reihe and th and e.get("stand"):
                    i = ind.verstehen_ergebnis(reihe, th, e["stand"], z)
                    if i:
                        je.setdefault(z["nr"], []).append(i)
                dateien = self._dateien(e)
                if not dateien:
                    continue
                liste = je.setdefault(z["nr"], [])
                i = ind.noch_nicht_dran(dateien, ind.vorrat(self.Z, z["thema"], speicher))
                if i:
                    liste.append(i)
                sc = e.get("selbstcheck") or (e.get("stand", {}).get("themen", {}).get(z["thema"], {}) or {}).get("selbstcheck") or {}
                themen.setdefault(z["thema"], []).append({"nr": z["nr"], "name": z["name"], "name_norm": norm(z["name"]),
                                                          "partner_norm": z.get("partner_norm") or "", "dateien": dateien,
                                                          "loesung_offen": bool((z.get("loesung") or {}).get("geoeffnet")),
                                                          "laeufe": z.get("laeufe"),
                                                          "fertig": bool(sc.get("von")) and sc.get("passt") == sc.get("von") and not sc.get("fehler")})
            for kennung, abg in themen.items():
                start, loesung = self._start_und_loesung(kennung)
                for a in abg:
                    a["zeilen"] = ind.eigene_zeilen(a["dateien"], start)
                for nr, li in ind.gleiche(abg, start, loesung).items():
                    je.setdefault(nr, []).extend(li)
                for nr, i in ind.ohne_probieren(abg).items():
                    je.setdefault(nr, []).append(i)
            rang = {"stark": 0, "mittel": 1, "schwach": 2}
            self._indizien = {nr: sorted(li, key=lambda x: rang[x["staerke"]]) for nr, li in je.items()}
        for z in zeilen:
            if z.get("nr") is not None and not z.get("fehlt"):
                z["indizien"] = self._indizien.get(z["nr"], [] if self._dateien(self.abgaben[z["nr"]]) else None)
                # I3: Claudes Beobachtungen -- frisch je Bericht gelesen (Claude schreibt sie, waehrend das Pult offen ist)
                e = self.abgaben[z["nr"]]
                if e.get("stand") and z.get("thema"):
                    b = ind.beobachtungen(self.Z.wurzel, z["name"], z["thema"], self._texte(e))
                    if b:
                        z["indizien"] = list(z["indizien"] or []) + [b]

    def _texte(self, e):
        from . import indizien as ind
        _, th = self.Z.thema(e["thema"]) if e.get("thema") else (None, None)
        if th is None:
            return []
        start, _ = self._start_und_loesung(e["thema"])
        return ind.texte(e["stand"], e["thema"], th, self._dateien(e), start)

    def indizien_mappe(self):
        """I3: die Texte der geladenen Abgaben OHNE Namen fuer Claude (_bewertung/indizien_zu_lesen.json), dazu je Thema
        Titel, die Begriffe des Glossars bis dahin und Auftrag und Muster der Klausuraufgaben. -> (pfad, abgaben, personen)"""
        from . import indizien as ind
        from .abdruck import entschleiern
        reihenfolge = [r["kennung"] + "/" + t["kennung"] for r in self.Z.inhalt.get("reihen", []) for t in r["themen"]]
        eintraege, themen = [], {}
        # Namen, die jemand in einen Text schreibt („# Lena und ich …“), kommen nicht mit: jeder Teil jedes bekannten
        # Namens (Kursliste, Abgaben, Partner) wird „[Name]“
        teile = set()
        for n in [p["nachname"] + " " + p["vorname"] for p in self.personen] + [e.get("name") or "" for e in self.abgaben] + \
                [((e.get("stand") or {}).get("partner") or {}).get("name", "") for e in self.abgaben]:
            teile |= {w for w in re.split(r"[\s\-]+", n or "") if len(w) >= 3}
        namen_re = re.compile(r"\b(%s)\b" % "|".join(sorted(map(re.escape, teile), key=len, reverse=True)), re.I) if teile else None
        ohne = lambda s: namen_re.sub("[Name]", s) if namen_re else s  # noqa: E731
        for e in self.abgaben:
            if not e.get("stand") or not e.get("thema") or e.get("fremd"):
                continue
            tx = self._texte(e)
            if not tx:
                continue
            eintraege.append({"name": e["name"], "thema": e["thema"], "roh": tx, "texte": [dict(x, text=ohne(x["text"])) for x in tx]})
            if e["thema"] not in themen:
                _, th = self.Z.thema(e["thema"])
                bis = set(reihenfolge[:reihenfolge.index(e["thema"]) + 1]) if e["thema"] in reihenfolge else {e["thema"]}
                begriffe = sorted(g["begriff"] for g in self.Z.inhalt.get("glossar", [])
                                  if ((g.get("eingefuehrt") or {}).get("thema") in bis))
                aufg = {}
                for a in th["uebung"]["aufgaben"]:
                    for k in a.get("klausur") or []:
                        kk = e["thema"] + "/" + k["name"]
                        geheim = (self.Z.pruefstoff.get("klausuren") or {}).get(kk)
                        muster = json.loads(entschleiern(kk, "klausur", geheim["geheim"])).get("muster", "") if geheim else ""
                        auftrag = re.sub(r"\s+", " ", re.sub(r"<figure.*?</figure>|<[^>]+>", " ", a.get("html", ""), flags=re.S)).strip()
                        aufg[a["nr"]] = {"auftrag": auftrag[:1500], "muster": muster}
                themen[e["thema"]] = {"titel": th.get("titel", ""), "begriffe_bis_hier": begriffe, "klausuraufgaben": aufg}
        if not eintraege:
            raise ValueError("In den geladenen Abgaben steht kein eigener Text (Klausurtext, Mini-Exit, Kommentar im Code).")
        return ind.mappe_schreiben(self.Z.wurzel, eintraege, themen)

    def ablauf_klasse(self):
        """Wie lief das Kapitel? (P6) -- je Kapitel und Aussage, wie viele auf Stufe 1-4, dazu die Texte in gemischter
        Reihenfolge. Je Person zaehlt ihre NEUESTE Abgabe. OHNE Namen: heraus gehen nur Zahlen und Texte."""
        import random
        neueste = {}
        for e in self.abgaben:
            st = e.get("stand")
            if st is None or not e["name"] or not isinstance(st.get("ablauf"), dict):
                continue
            if e["name"] not in neueste or str(st.get("abgegeben", "")) > str(neueste[e["name"]].get("abgegeben", "")):
                neueste[e["name"]] = st
        aus = []
        for r in self.Z.inhalt.get("reihen", []):
            zaehlung, texte, personen = {"1": [0, 0, 0, 0], "2": [0, 0, 0, 0], "3": [0, 0, 0, 0]}, [], 0
            for st in neueste.values():
                a = (st["ablauf"].get(r["kennung"]) or {})
                if not a:
                    continue
                personen += 1
                for f in ("1", "2", "3"):
                    try:
                        w = int(a.get(f, 0))
                    except (TypeError, ValueError):
                        continue
                    if 1 <= w <= 4:
                        zaehlung[f][w - 1] += 1
                if str(a.get("text", "")).strip():
                    texte.append(str(a["text"]).strip())
            if personen:
                random.shuffle(texte)          # die Reihenfolge verriete sonst, wer was schrieb
                aus.append({"kennung": r["kennung"], "titel": r.get("titel", ""), "personen": personen, "fragen": zaehlung, "texte": texte})
        return aus

    def einschaetzung_klasse(self, zeilen):
        """„Ich kann …“ der Klasse (Galerie Rang 12, Lehrer 16.10.: nur anonym): je Satz und Runde, wie
        viele sich auf Stufe 1-4 sehen -- je Person zaehlt ihre NEUESTE Abgabe (sie traegt die ganze
        Einschaetzung der Reihe). Daneben, wer sich in der letzten Runde „meistens“/„sicher“ sieht,
        in einem Uebungsthema des Satzes aber das Ziel nicht erreicht oder nicht abgegeben hat.
        OHNE Namen: heraus gehen nur Zahlen."""
        neueste = {}
        for e in self.abgaben:
            st = e.get("stand")
            if st is None or not e["name"] or not isinstance(st.get("einschaetzung"), dict):
                continue
            if e["name"] not in neueste or str(st.get("abgegeben", "")) > str(neueste[e["name"]].get("abgegeben", "")):
                neueste[e["name"]] = st
        # je Person und Thema: Ziel erreicht? (Sterne nachgerechnet, sonst Selbstcheck ganz gruen)
        erreicht = {}
        for z in zeilen:
            if z.get("fehlt") or not z.get("thema"):
                continue
            sz, sc = z.get("sterne"), z.get("selbstcheck")
            ok = bool(sz["geschafft"]) if sz else bool(sc and sc.get("von") and sc.get("passt") == sc.get("von"))
            erreicht[(z["name"], z["thema"])] = erreicht.get((z["name"], z["thema"]), False) or ok
        aus = []
        for r in self.Z.inhalt.get("reihen", []):
            nummer = {r["kennung"] + "/" + th["kennung"]: th.get("nr") for th in r.get("themen", [])}
            bis_nr = max([nummer[th] for (_, th) in erreicht if nummer.get(th) is not None] or [0])
            saetze = []
            for g in r.get("raster") or []:
                for s in g["saetze"]:
                    k = r["kennung"] + "/" + s["kennung"]
                    runden, letzte = {}, {}
                    for name, st in neueste.items():
                        for runde, w in (st["einschaetzung"].get(k) or {}).items():
                            try:
                                stufe = int((w or {}).get("stufe", 0))
                            except (TypeError, ValueError):
                                continue
                            if runde in ("1", "2", "3") and 1 <= stufe <= 4:
                                runden.setdefault(runde, [0, 0, 0, 0])[stufe - 1] += 1
                                if runde > letzte.get(name, ("0", 0))[0]:
                                    letzte[name] = (runde, stufe)
                    if not runden:
                        continue
                    passt_nicht = []
                    for t in s["themen"]:
                        voll = r["kennung"] + "/" + t
                        # nur Themen bis zum letzten, zu dem es eine Abgabe gibt: Ein neu gebautes Thema im Raster
                        # meldete sonst alle als „nicht abgegeben“, bevor die Klasse dort ist (Bau T10, 21.10.)
                        nr_t = nummer.get(voll)
                        if nr_t is not None and nr_t > bis_nr:
                            continue
                        hoch = [n for n, (_, stufe) in letzte.items() if stufe >= 3]
                        ohne_ziel = sum(1 for n in hoch if (n, voll) in erreicht and not erreicht[(n, voll)])
                        ohne_abgabe = sum(1 for n in hoch if (n, voll) not in erreicht)
                        if ohne_ziel or ohne_abgabe:
                            nr = next((th["nr"] for th in r["themen"] if th["kennung"] == t), None)
                            passt_nicht.append({"thema": voll, "nr": nr, "ohne_ziel": ohne_ziel, "ohne_abgabe": ohne_abgabe})
                    saetze.append({"kennung": k, "gruppe": g["titel"], "html": s["html"], "runden": runden,
                                   "personen": len(letzte), "passt_nicht": passt_nicht})
            if saetze:
                aus.append({"reihe": r["kennung"], "titel": r["titel"], "saetze": saetze})
        return aus

    def lernkarten_klasse(self):
        """Lernkarten der Klasse (Galerie Rang 15, 16.10.): welche Karten bei den meisten in Fach 1 haengen
        -- dort sitzt eine Fehlvorstellung fest. Je Person ihre NEUESTE Abgabe (sie traegt alle Karten).
        OHNE Namen: heraus gehen nur Zahlen je Karte, sortiert nach dem Anteil in Fach 1."""
        neueste = {}
        for e in self.abgaben:
            st = e.get("stand")
            if st is None or not e["name"] or not isinstance(st.get("lernkarten"), dict) or not st["lernkarten"]:
                continue
            if e["name"] not in neueste or str(st.get("abgegeben", "")) > str(neueste[e["name"]].get("abgegeben", "")):
                neueste[e["name"]] = st
        karten = []
        for c in self.Z.inhalt.get("lernkarten") or []:
            faecher, nicht, personen = [0] * 5, 0, 0
            for st in neueste.values():
                w = st["lernkarten"].get(c["id"])
                if not isinstance(w, dict):
                    continue
                try:
                    fach = min(5, max(1, int(w.get("fach", 1))))
                    n = int(w.get("nicht", 0))
                except (TypeError, ValueError):
                    continue
                faecher[fach - 1] += 1
                nicht += n
                personen += 1
            if personen:
                karten.append({"id": c["id"], "art": c["art"], "thema": c["thema"], "kurz": c["kurz"],
                               "personen": personen, "faecher": faecher, "nicht": nicht})
        karten.sort(key=lambda k: (-k["faecher"][0] / k["personen"], -k["nicht"], k["id"]))
        return {"personen": len(neueste), "karten": karten} if neueste else None

    def fehlerbuch_klasse(self):
        """Mein Fehlerbuch, fuer die Klasse gezaehlt (Galerie Rang 9): je Fehlerart und Thema,
        wie viele Personen sie getroffen haben und wie oft -- OHNE Namen, auch ohne Notizen
        (die Notiz gehoert der Person)."""
        zaehler = {}
        for e in self.abgaben:
            st = e.get("stand")
            if st is None or not isinstance(st.get("fehlerbuch"), dict):
                continue
            for art, f in st["fehlerbuch"].items():
                try:
                    n = int(f.get("anzahl", 0))
                except (TypeError, ValueError, AttributeError):
                    continue
                if n <= 0:
                    continue
                z = zaehler.setdefault((e["thema"] or "", art), {"thema": e["thema"] or "", "art": art, "satz": "", "personen": 0, "meldungen": 0})
                z["personen"] += 1
                z["meldungen"] += n
                z["satz"] = z["satz"] or str(f.get("satz", ""))[:200]
        return sorted(zaehler.values(), key=lambda z: (z["thema"], -z["personen"], -z["meldungen"], z["art"]))

    def alle_anmerkungen(self):
        """Alle Anmerkungen der geltenden Abgaben, OHNE Namen, nach Ansicht und Stelle
        geordnet -- so steht nichts mehr in der Reihenfolge der Personen."""
        alle = [dict(a, thema=e["thema"]) for e in self.abgaben if e.get("stand") is not None for a in e.get("anmerkungen") or []]
        return sorted(alle, key=lambda a: (a["thema"] or "", a["route"], a["anker"] or "", a["art"], a["text"]))

    def code(self, nr):
        e = self.abgaben[nr]
        return {"name": e["name"], "thema": e["thema"], "code": e["code"], "selbstcheck": e["selbstcheck"]}

    def anonym(self, nummern, plaene=None, diagramme=None):
        """Stuecke fuer die Besprechung: fortlaufend nummeriert, ohne Namen. plaene = [[nr, name], …]
        (19.10.2026): Plaene aus Abgaben -- die Besprechung zeichnet sie nebeneinander."""
        aus = []
        for i, nr in enumerate(nummern, 1):
            if 0 <= nr < len(self.abgaben):
                e = self.abgaben[nr]
                aus.append({"name": "Abgabe %d" % i, "thema": e["thema"], "code": e["code"],
                            "selbstcheck": {"passt": e["selbstcheck"]["passt"], "von": e["selbstcheck"]["von"]} if e["selbstcheck"] else None})
        from . import plan as planlauf
        for i, (nr, name) in enumerate(plaene or [], 1):
            if not (isinstance(nr, int) and 0 <= nr < len(self.abgaben)):
                continue
            e = self.abgaben[nr]
            gemerkt = ((e.get("stand") or {}).get("plaene") or {}).get((e["thema"] or "") + "/" + str(name))
            _, th = self.Z.thema(e["thema"]) if e["thema"] else (None, None)
            spec = ((th or {}).get("plaene") or {}).get(str(name))
            if not gemerkt or not spec:
                continue
            r = planlauf.pruefen(gemerkt.get("quelle", ""), spec["proben"])
            aus.append({"art": "plan", "name": "Plan %d" % i, "thema": e["thema"], "quelle": gemerkt.get("quelle", ""),
                        "titel": gemerkt.get("titel", "") or spec["algorithmus"], "ok": r["ok"], "von": r["von"], "proben": spec["proben"]})
        # Diagramme (13.11.2026): wie die Plaene -- ohne Namen, mit dem Urteil des Selbstchecks
        from .server import diagramm_finden, diagramm_modell
        from . import klassenregeln
        for i, (nr, name) in enumerate(diagramme or [], 1):
            if not (isinstance(nr, int) and 0 <= nr < len(self.abgaben)):
                continue
            e = self.abgaben[nr]
            kennung = (e["thema"] or "") + "/" + str(name)
            gemerkt = ((e.get("stand") or {}).get("diagramme") or {}).get(kennung)
            spec = diagramm_finden(kennung, self.Z.pruefstoff)
            if not gemerkt or not gemerkt.get("modell") or not spec:
                continue
            modell = diagramm_modell(gemerkt["modell"])
            r = klassenregeln.vergleichen(modell, spec[1], spec[0])
            aus.append({"art": "diagramm", "name": "Diagramm %d" % i, "thema": e["thema"], "modell": modell, "ok": r["ok"], "meldungen": r["meldungen"][:3]})
        return aus

    def aufraeumen(self):
        shutil.rmtree(self.tmp, ignore_errors=True)


def laden(Z, d):
    """Einstieg fuer die API: d = {abgaben: [{name, daten(b64)}], kursliste: {name, daten} | None,
    nachlaufen: bool, ordner: Pfad (optional, fuer Tests)}."""
    if Z.uebersicht is not None:
        Z.uebersicht.aufraeumen()
    u = Uebersicht(Z)
    dateien = []
    for a in d.get("abgaben", []) or []:
        try:
            dateien.append((str(a["name"]), base64.b64decode(a["daten"])))
        except (KeyError, ValueError):
            u.fehler_liste.append("eine Datei liess sich nicht lesen")
    kursliste = None
    if d.get("kursliste"):
        try:
            kursliste = base64.b64decode(d["kursliste"]["daten"])
        except (KeyError, ValueError):
            u.fehler_liste.append("die Kursliste liess sich nicht lesen")
    ordner = d.get("ordner")
    if ordner:
        o = pathlib.Path(ordner)
        if o.is_dir():
            for p in sorted(o.iterdir()):
                if p.is_file() and not p.name.startswith("."):
                    if p.name.startswith("Kursliste") and kursliste is None:
                        kursliste = p.read_bytes()
                    else:
                        dateien.append((p.name, p.read_bytes()))
        else:
            u.fehler_liste.append("Ordner nicht gefunden: " + str(o))
    return u.laden(dateien, kursliste, nachlaufen=bool(d.get("nachlaufen", True)))
