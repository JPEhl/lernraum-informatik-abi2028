# CodeMirror 6 — gebündelt

`codemirror.js` ist ein Bündel (esbuild, IIFE, `window.CM`) aus
codemirror 6.0.1, @codemirror/lang-python 6.1.6, @codemirror/lang-html 6.4.9
und ihren Abhängigkeiten, seit dem 2026-11-16 dazu @replit/codemirror-vim 6.4.0 mit
@replit/codemirror-vim-core 0.1.0 (alle MIT — Texte in `LIZENZ.txt`).
Gebaut am 2026-10-12, neu gebündelt am 2026-10-21 mit `WidgetType` (Zwischenstände im Fahrplan:
gelöschte Zeilen als Widget), **neu gebündelt am 2026-11-16** mit `vim` und `Vim` (Vim-Tasten als Schalter
im Zahnrad, Wunsch aus dem Kurs; LIESMICH „Vim-Tasten im Editor“). Der Eingang liegt seitdem in `werkstatt/lernraum/codemirror_eingang.js` (vorher nur im Scratchpad; nicht unter `seite/`, das geht an die Klasse):

```js
import { EditorState, Compartment } from "@codemirror/state";
import { EditorView, keymap, lineNumbers, ... } from "@codemirror/view";
...
window.CM = { ... };
```

Neu bündeln: Der genaue Paketstand liegt als `werkstatt/lernraum/codemirror_paketstand.json` (das
`package-lock.json` des Baus vom 2026-11-16). In einem leeren Ordner: die Datei als `package-lock.json`
ablegen, dazu eine `package.json` mit den fünf Paketen (codemirror 6.0.1, @codemirror/lang-python 6.1.6,
@codemirror/lang-html 6.4.9, @replit/codemirror-vim 6.4.0, esbuild 0.24.0), dann `npm ci` und
`npx esbuild eingang.js --bundle --minify --format=iife --target=es2020 --outfile=codemirror.js`.
Zweimal hintereinander gebaut ist das Bündel byte-gleich (geprüft am 16.11.).

Im Bündel stecken 24 Pakete (esbuild `--metafile`): @codemirror/autocomplete 6.20.3 · commands 6.11.1 ·
lang-css 6.3.1 · lang-html 6.4.9 · lang-javascript 6.2.5 · lang-python 6.1.6 · language 6.13.1 · search 6.7.2 ·
state 6.7.6 · streamparser 6.0.0 · view 6.43.14 · @lezer/common 1.5.3 · css 1.3.9 · highlight 1.2.5 ·
html 1.3.13 · javascript 1.5.6 · lr 1.4.11 · python 1.1.19 · @marijn/find-cluster-break 1.0.4 ·
@replit/codemirror-vim 6.4.0 · @replit/codemirror-vim-core 0.1.0 · crelt 1.0.7 · style-mod 4.1.4 ·
w3c-keyname 2.2.8. `LIZENZ.txt` nennt drei mehr (codemirror, lint, theme-one-dark): installiert, nicht gebündelt.

**Der frühere Hinweis, `npm i --before=2026-10-12` halte dieselben Paketstände, stimmte nicht** (16.11.
nachgemessen: ohne Vim 595 468 statt 593 202 Bytes). Darum liegt jetzt der Paketstand im Repo. Nach jedem
neuen Bündel läuft der ganze Browsertest — er ist das Netz, nicht der Bytevergleich.

Die Lizenzdatei wird um den Text jedes neuen Pakets ergänzt (`node_modules/<paket>/LICENSE`).
Kein CDN, kein Netz zur Laufzeit.
