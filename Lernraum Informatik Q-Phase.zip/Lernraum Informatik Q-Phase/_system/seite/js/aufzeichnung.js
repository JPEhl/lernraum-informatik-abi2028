/* Lernraum · aufzeichnung.js -- die Aufzeichnung (Schritt für Schritt durch einen Lauf).
   Teil der Arbeitsseite; alle Teile teilen einen Namensraum und laden in der
   Reihenfolge von index.html (kein Bündler, CSP 'self'). */
"use strict";
// ─── Aufzeichnung ────────────────────────────────────────────────────────────────
// Namen der Objekte: die Variable, die darauf zeigt (mehrere: „a = b"), sonst der Weg dorthin
// („raeume[2]") -- statt der Adresse (Lehrer 14.10.: „list #6688" sagt nichts).
function objektNamen(s) {
  const namen = {}, direkt = {};
  for (const bereich of [s.lokal || {}, s.global || {}]) for (const [k, w] of Object.entries(bereich)) if (w && w.art === "ref") (direkt[w.id] = direkt[w.id] || []).includes(k) || direkt[w.id].push(k);
  for (const [oid, ks] of Object.entries(direkt)) namen[oid] = ks.join(" = ");
  const besuchen = (w, weg) => {
    if (!w || w.art !== "ref") return;
    if (!(w.id in namen)) namen[w.id] = weg;
    const o = (s.objekte || {})[w.id]; if (!o || !o.inhalt || o._besucht) return; o._besucht = true;
    if (["list", "tuple"].includes(o.typ)) o.inhalt.forEach((x, i) => besuchen(x, namen[w.id] + "[" + i + "]"));
    else if (o.typ === "dict") o.inhalt.forEach(([k, v]) => besuchen(v, namen[w.id] + "[" + k.text + "]"));
    else if (o.typ !== "set") o.inhalt.forEach(([k, v]) => besuchen(v, namen[w.id] + "." + k.text));
  };
  for (const bereich of [s.lokal || {}, s.global || {}]) for (const [k, w] of Object.entries(bereich)) besuchen(w, k);
  for (const o of Object.values(s.objekte || {})) delete o._besucht;
  return namen;
}
// ─── Der Zeichner für Zeichenflächen ──────────────────────────────────────────────────────────
// EIN Weg für das Fenster im Debugger (12.11.) und das Fenster beim Ausführen (13.11.2026, „Fenster im Browser“,
// Lehrer: Vortrag A, Übung B): Eine Zeichenfläche kommt als {b, h, bg, dinge: [{was, k, fill, …}]}, Bilder als Daten
// je Dateiname. Zwei Zeichner hätten auseinanderlaufen können -- der Anker-Fehler vom 12.11. hätte dann nur einen getroffen.
function zeichnungEsc(t) { return String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
// Eine Linie mit Pfeilspitze wie in Tk (iq1 beziehung W1, 14.11.2026: „als Pfeil darstellen mit Pfeilspitze“ -- die Seite
// kannte arrow= nicht und malte nur die Linie). arrow: none · first · last · both; arrowshape „d1 d2 d3“ (Tk: 8 10 3):
// d1 von der Spitze zum Hals, d2 von der Spitze zu den hinteren Ecken, d3 so weit stehen die Ecken über die Linie hinaus.
// Wie Tk endet die Linie am Hals, sonst stünde ihr breites Ende über die schmale Spitze hinaus.
function zeichnungLinie(z, k, farbe, breite) {
  const p = []; for (let i = 0; i + 1 < k.length; i += 2) p.push([k[i], k[i + 1]]);
  const pfeil = String(z.arrow || "none"), form = String(z.arrowshape || "8 10 3").split(/\s+/).map(Number);
  const [d1, d2, d3] = form.length === 3 && form.every(v => isFinite(v)) ? form : [8, 10, 3];
  const spitzen = [];
  const spitze = (ende, davor) => {
    const dx = ende[0] - davor[0], dy = ende[1] - davor[1], l = Math.hypot(dx, dy) || 1, ux = dx / l, uy = dy / l;
    const hals = [ende[0] - ux * d1, ende[1] - uy * d1], w = d3 + breite / 2;
    const hinten = [ende[0] - ux * d2, ende[1] - uy * d2];
    spitzen.push('<polygon points="' + [ende, [hinten[0] - uy * w, hinten[1] + ux * w], hals, [hinten[0] + uy * w, hinten[1] - ux * w]].map(q => q[0] + "," + q[1]).join(" ") + '" fill="' + farbe + '"/>');
    return hals;
  };
  if (p.length >= 2) {
    if (pfeil === "last" || pfeil === "both") p[p.length - 1] = spitze(p[p.length - 1], p[p.length - 2]);
    if (pfeil === "first" || pfeil === "both") p[0] = spitze(p[0], p[1]);
  }
  return '<polyline points="' + p.map(q => q[0] + "," + q[1]).join(" ") + '" fill="none" stroke="' + farbe + '" stroke-width="' + breite + '"/>' + spitzen.join("");
}
function zeichnungDing(z, bildDaten) {
  const k = z.k || [], farbe = f => (f ? zeichnungEsc(f) : "none"), breite = w => (parseFloat(w) || 1);
  if (z.was === "rechteck") return '<rect x="' + Math.min(k[0], k[2]) + '" y="' + Math.min(k[1], k[3]) + '" width="' + Math.abs(k[2] - k[0]) + '" height="' + Math.abs(k[3] - k[1]) + '" fill="' + farbe(z.fill) + '" stroke="' + farbe(z.outline) + '" stroke-width="' + breite(z.width) + '"/>';
  if (z.was === "oval") return '<ellipse cx="' + (k[0] + k[2]) / 2 + '" cy="' + (k[1] + k[3]) / 2 + '" rx="' + Math.abs(k[2] - k[0]) / 2 + '" ry="' + Math.abs(k[3] - k[1]) / 2 + '" fill="' + farbe(z.fill) + '" stroke="' + farbe(z.outline) + '" stroke-width="' + breite(z.width) + '"/>';
  if (z.was === "linie") return zeichnungLinie(z, k, farbe(z.fill || "black"), breite(z.width));
  if (z.was === "vieleck") {
    const punkte = []; for (let i = 0; i + 1 < k.length; i += 2) punkte.push(k[i] + "," + k[i + 1]);
    return '<polygon points="' + punkte.join(" ") + '" fill="' + farbe(z.fill) + '" stroke="' + farbe(z.outline) + '" stroke-width="' + breite(z.width) + '"/>';
  }
  // "center" ist kein Osten: "center".includes("e") schob Bilder und Texte um ihre halbe Breite nach links
  // (12.11.2026, Film-Fotos iq1 benutzen: die Dame neben ihrem Rahmen)
  const anker = (z.anchor && z.anchor !== "center") ? z.anchor : "", x0 = anker.includes("w") ? "start" : anker.includes("e") ? "end" : "middle";
  if (z.was === "text") {
    const g = (String(z.font).match(/(\d+)/) || [, 12])[1] * 1.33;
    const basis = anker.startsWith("n") ? "hanging" : anker.startsWith("s") ? "auto" : "central";
    return '<text x="' + k[0] + '" y="' + k[1] + '" fill="' + farbe(z.fill || "black") + '" font-size="' + g + '" font-family="sans-serif" text-anchor="' + x0 + '" dominant-baseline="' + basis + '">' + zeichnungEsc(z.text) + "</text>";
  }
  if (z.was === "bild" && bildDaten[z.datei]) {
    const w = z.breite, hh = z.hoehe;
    const x = anker.includes("w") ? k[0] : anker.includes("e") ? k[0] - w : k[0] - w / 2;
    const y = anker.startsWith("n") ? k[1] : anker.startsWith("s") ? k[1] - hh : k[1] - hh / 2;
    return '<image x="' + x + '" y="' + y + '" width="' + w + '" height="' + hh + '" href="data:image/png;base64,' + bildDaten[z.datei] + '"/>';
  }
  return "";
}
function zeichnungSvg(f, bildDaten, beschreibung) {
  const dinge = Array.isArray(f.dinge) ? f.dinge : [...f.dinge.values()];
  return '<svg viewBox="0 0 ' + f.b + " " + f.h + '" role="img" aria-label="' + zeichnungEsc(beschreibung || "Die Zeichenfläche") + '"><rect width="' + f.b + '" height="' + f.h + '" fill="' + zeichnungEsc(f.bg || "white") + '"/>' + dinge.map(z => zeichnungDing(z, bildDaten || {})).join("") + "</svg>";
}
// Der Debugger (Lehrer 17.10., Durchsicht T5 W3: „Läuft die Shell auch mit, wenn der Debugger läuft? …
// Einzelschritt, Eintreten etc. … und ich würde den Debugger auch Debugger nennen“). Das Programm läuft
// EINMAL durch und wird aufgezeichnet (aufzeichnen.py); danach geht man durch die Schritte -- auch zurück.
// Die Knöpfe nach den üblichen Namen (step over/into/out): Schritt über · Schritt hinein · Schritt heraus · Weiter (bis zum
// nächsten Haltepunkt, Klick auf eine Zeilennummer). Die Shell des Editors bleibt sichtbar und zeigt die
// Ausgabe BIS zum aktuellen Schritt: die markierte Zeile ist die, die als Nächstes läuft -- ihre Ausgabe
// erscheint erst einen Schritt später (bis 17.10. stand sie einen Schritt zu früh in einem kleinen Kasten).
function aufzeichnung(edIch, opts) {
  const ziel = opts.aufzeichnungsZiel ? opts.aufzeichnungsZiel() : edIch.konsole.parentElement;
  const konsole = edIch.konsole;
  // was die Shell vorher zeigte -- beim Schließen zurück. Zeigt sie schon einen Debugger (ein zweiter Start im Film),
  // ist das nicht „vorher“: Sonst stand „Debugger · Ausgabe bis Schritt … (Ende)“ nach dem Schließen weiter da
  // (Durchsicht iq1 benutzen, W4, 13.11.2026).
  const vorher = konsole.querySelector(".dbg-shell") ? [] : [...konsole.childNodes];
  const wrap = h("div", { class: "aufzeichnung" });
  const steuerung = h("div", { class: "steuerung" });
  const ablaeufeEl = h("div", { class: "ablaeufe" });
  const schieber = h("input", { type: "range", min: 0, max: 0, value: 0, "aria-label": "Schritt wählen" });
  const zaehler = h("span", { class: "zaehler" }, "");
  const codeansicht = h("div", { class: "codeansicht", title: "Klick auf eine Zeilennummer: Haltepunkt setzen oder entfernen" });
  const tafel = h("div", { class: "tafel" });
  const satzEl = h("div", { class: "dbg-satz" }); satzEl.hidden = true;   // der Satz eines Film-Halts (24.10.)
  const meld = h("div", { class: "meldung hinweis" }, "Der Debugger lässt das Programm einmal laufen und merkt sich jeden Schritt … Bei einem Fenster: klicke darin – jeder Klick wird ein eigener Ablauf. Fenster schließen beendet den Lauf.");
  // Breit (Vortrag, Lehrer 24.10.: „optisch im Vortrag noch eine Katastrophe: so groß, dass man gar nichts erkennt“ --
  // in der rechten Spalte standen die Knoepfe riesig, Code und Variablen unter dem Bildrand): der Debugger nimmt die
  // ganze Breite, links der Code und darunter die Shell (die Shell des Editors wird hinuebergehaengt und beim
  // Schliessen zurueckgestellt), rechts die Variablen.
  const breit = !!opts.aufzeichnungBreit;
  const shellHeim = { el: konsole.parentElement, nach: konsole.nextSibling };
  const shellStil = konsole.style.cssText;   // die Hoehe der Shell im Editor -- im Debugger hat sie eine eigene
  const shellZurueck = () => { konsole.classList.remove("dbg-leer"); if (breit && konsole.parentElement !== shellHeim.el) { shellHeim.el.insertBefore(konsole, shellHeim.nach && shellHeim.nach.parentElement === shellHeim.el ? shellHeim.nach : null); konsole.style.cssText = shellStil; } };
  const zu = h("button", { class: "ruhig", onclick: () => { shellZurueck(); wrap.remove(); konsole.textContent = ""; konsole.append(...vorher); if (id) api("aufzeichnen/stopp", { id }); if (opts.onAufzeichnungZu) opts.onAufzeichnungZu(); } }, "✕ schließen");
  const knopf = (text, titel, f) => h("button", { title: titel, onclick: f }, text);
  const kZurueck = knopf("◀ zurück", "Einen Schritt zurück", () => gehe(pos - 1));
  const kUeber = knopf("Schritt über", "Die markierte Zeile ganz ausführen – ruft sie eine Funktion auf, läuft die ganz durch", () => gehe(ueber()));
  const kHinein = knopf("Schritt hinein", "Einen einzelnen Schritt – ruft die Zeile eine Funktion auf, geht es in die Funktion hinein", () => gehe(pos + 1));
  const kHeraus = knopf("Schritt heraus", "Die Funktion zu Ende laufen lassen und zurück, wo sie aufgerufen wurde", () => gehe(heraus()));
  const kWeiter = knopf("Weiter ▶▶", "Bis zum nächsten Haltepunkt laufen (Klick auf eine Zeilennummer setzt einen) – ohne Haltepunkt bis zum Ende", () => gehe(weiter()));
  // Schriftgroessen (24.10.): Code und Shell wie im Editor, dazu die Variablen -- je Beamer einstellbar, gemerkt
  const schrift = (art, name) => h("span", { class: "schrift", "data-art": art }, h("span", { class: "schrift-name" }, name),
    h("button", { class: "ruhig", title: name + ": Schrift kleiner", onclick: () => schriftAendern(-1, art) }, "A−"),
    h("button", { class: "ruhig", title: name + ": Schrift größer", onclick: () => schriftAendern(1, art) }, "A+"));
  const schriften = h("span", { class: "dbg-schriften" }, schrift("code", "Code"), schrift("debugger", "Variablen"), schrift("shell", "Shell"));
  steuerung.append(h("b", { class: "dbg-titel" }, zeichen(KAEFER_ZEICHEN, "z-kaefer"), "Debugger"), kZurueck, kUeber, kHinein, kHeraus, kWeiter, schieber, zaehler, ablaeufeEl, schriften, zu);
  // Fenstergroessen (24.10.): ein Trenner zwischen Code und Variablen; im Vortrag einer zwischen Code und Shell, in der
  // Uebung ein Griff unter beiden fuer die Hoehe -- je Beamer einstellbar, gemerkt, Doppelklick setzt zurueck
  const links = h("div", { class: "dbg-links" }, codeansicht);
  const spalt = spaltenTrenner(wrap, breit ? "debugger-vortrag" : "debugger", "--dbg-teilung");
  if (breit) {
    wrap.classList.add("breit");
    wrap.append(steuerung, satzEl, links, spalt, tafel, meld);
    if (ziel._shellZurueck) ziel._shellZurueck();      // ein zweiter Start: die Shell erst aus dem alten Debugger holen
    ziel.textContent = "";
    konsole.style.cssText = "";
    links.append(hoehenTrenner(konsole, "shell-debugger", "Shell"), konsole);
    ziel._shellZurueck = shellZurueck;
  } else {
    wrap.append(steuerung, satzEl, links, spalt, tafel, hoehenGriff(wrap, "debugger", "--dbg-hoehe", "Höhe"), meld);
    if (opts.aufzeichnungsZiel) ziel.textContent = "";
  }
  konsole.hidden = false;
  ziel.append(wrap);

  // Python-Ordner (11.11.2026, Ordnung Informatik Schritt 9 Teil 4): je Datei der Klasse eine Codeansicht; der Schritt
  // sagt, in welcher Datei er steht (s.datei), Ansicht und Editor des Arbeitsplatzes wechseln mit (opts.dateiZeigen).
  // Haltepunkte gelten je Datei. Ohne Ordner (opts.startDatei fehlt) gibt es nur die eine Datei, wie vorher.
  const haupt = opts.startDatei || "";
  const dateiVon = s => s.datei || haupt;
  const dateiEl = h("div", { class: "dbg-datei" }); dateiEl.hidden = !haupt;
  links.insertBefore(dateiEl, codeansicht);
  const halt = new Set();   // "datei:zeile"
  const ansichten = {};     // datei -> Zeilen
  function ansichtBauen(datei, text) {
    ansichten[datei] = text.split("\n").map((z, i) => {
      const schluessel = datei + ":" + (i + 1);
      const n = h("span", { class: "n", onclick: () => { halt.has(schluessel) ? halt.delete(schluessel) : halt.add(schluessel); el.classList.toggle("halt", halt.has(schluessel)); } }, String(i + 1));
      const el = h("div", { class: "z" }, n, h("span", {}, z || " "));
      return el;
    });
  }
  let gezeigt = null, zeilenEl = [];
  function ansichtZeigen(datei, mitEditor) {
    if (gezeigt === datei) return;
    gezeigt = datei; zeilenEl = ansichten[datei] || [];
    codeansicht.textContent = "";
    codeansicht.append(...zeilenEl);
    dateiEl.textContent = "";
    dateiEl.append(datei);
    if (datei === haupt) dateiEl.append(h("small", {}, " · das Programm"));
    if (mitEditor && haupt && opts.dateiZeigen) opts.dateiZeigen(datei);
  }
  ansichtBauen(haupt, edIch.text());
  ansichtZeigen(haupt, false);

  const ablaeufe = []; let aktiv = 0, pos = 0, id = null, grenze = null, fehler = null, fertig = false;
  // input() (24.10.): Die Aufzeichnung wartet an einem input(), bis in der Shell eine Zeile getippt wird --
  // wartet = {frage, ablauf}; das Feld erscheint, sobald man im Debugger am letzten Schritt steht
  let wartet = null, nachEingabe = false;
  const ausgaben = []; // {ablauf, schritt, text}: schritt = der Schritt, dessen Zeile gerade lief
  // Das Fenster im Debugger (12.11.2026, iq1 brett W7): jede Zeichnung auf einer Zeichenfläche, wie eine Ausgabe dem
  // Schritt zugeordnet, der gerade lief -- gezeigt wird die Fläche so, wie sie bis zum gezeigten Schritt aussah
  const zeichnungen = [], bildDaten = {};
  function fensterBild(s, letzter) {
    if (!zeichnungen.length) return null;
    const flaechen = {}; let erste = null;
    for (const z of zeichnungen) {
      if (!(z.ablauf < aktiv || (z.ablauf === aktiv && (z.schritt < s.nr || letzter)))) continue;
      if (z.was === "flaeche") { flaechen[z.flaeche] = { b: z.breite, h: z.hoehe, bg: z.bg, dinge: new Map() }; erste = erste || z.flaeche; continue; }
      const f = flaechen[z.flaeche]; if (!f) continue;
      if (z.was === "weg") { if (!z.ziel.length || z.ziel.includes("all")) f.dinge.clear(); else z.ziel.forEach(i => f.dinge.delete(i)); }
      else f.dinge.set(z.id, z);
    }
    const r = h("div", { class: "rahmen fensterbild" }, h("div", { class: "rt" }, "Fenster – so weit gezeichnet"));
    if (!erste) { r.append(h("div", { class: "leer" }, "noch keine Zeichenfläche")); return r; }
    const f = flaechen[erste], bild = h("div", { class: "fb-flaeche" });
    bild.innerHTML = zeichnungSvg(f, bildDaten, "Die Zeichenfläche bis zu diesem Schritt");
    r.append(bild, h("div", { class: "fb-zahl" }, f.dinge.size + (f.dinge.size === 1 ? " Ding" : " Dinge") + " auf der Fläche"));
    return r;
  }

  function schritte() { return (ablaeufe[aktiv] || { schritte: [] }).schritte; }
  function tiefe(i) { const s = schritte()[i]; return s ? (s.stapel || []).length : 0; }
  function ueber() { const a = schritte(), t = tiefe(pos); for (let i = pos + 1; i < a.length; i++) if (tiefe(i) <= t) return i; return a.length - 1; }
  function heraus() { const a = schritte(), t = tiefe(pos); for (let i = pos + 1; i < a.length; i++) if (tiefe(i) < t) return i; return a.length - 1; }
  function weiter() { const a = schritte(); for (let i = pos + 1; i < a.length; i++) if (a[i].ereignis === "line" && halt.has(dateiVon(a[i]) + ":" + a[i].zeile)) return i; return a.length - 1; }
  function gehe(i) { const a = schritte(); if (!a.length) return; pos = Math.max(0, Math.min(a.length - 1, i)); zeigen(); }

  function ablaufKnoepfe() {
    ablaeufeEl.textContent = "";
    if (ablaeufe.length < 2) return;
    ablaeufe.forEach((a, i) => ablaeufeEl.append(h("button", { class: i === aktiv ? "aktiv" : "", onclick: () => { aktiv = i; pos = 0; zeigen(); } }, a.name + " (" + a.schritte.length + ")")));
  }
  let namen = {};
  // Marken eines Film-Halts (Durchsicht iq1 figuren, W2, 14.11.2026: „die entscheidenden Daten im Debugger markiert“):
  // Namen wie weiss, __figuren oder weiss.__figuren. Getroffen wird eine Zeile der Variablen oder eines Objekts mit
  // diesem Namen, ein Kasten mit diesem Namen, und bei a.b die Zeile b im Kasten a.
  let markiert = [], ersteMarke = null;
  function markenSetzen() {
    ersteMarke = null;
    if (!markiert.length) return;
    const kastenName = b => ((b.querySelector(".ot b") || {}).textContent || "").split(" = ");
    for (const m of markiert) {
      const [vor, nach] = m.includes(".") ? [m.slice(0, m.lastIndexOf(".")), m.slice(m.lastIndexOf(".") + 1)] : [null, m];
      const vorher = new Set(tafel.querySelectorAll(".dbg-marke"));
      // hilfe(): der Rahmen der laufenden Funktion („in hilfe()“, „in spiel → hilfe()“) -- i11 funktion, antwort
      if (m.endsWith("()")) for (const r of tafel.querySelectorAll(".rahmen")) {
        const rt = r.querySelector(".rt"); if (rt && rt.textContent.startsWith("in ") && rt.textContent.endsWith(m.slice(0, -2) + "()")) r.classList.add("dbg-marke");
      }
      for (const b of tafel.querySelectorAll(".objekt")) if (kastenName(b).includes(m)) b.classList.add("dbg-marke");
      const bereiche = vor ? [...tafel.querySelectorAll(".objekt")].filter(b => kastenName(b).includes(vor)) : [tafel];
      for (const bereich of bereiche) for (const v of bereich.querySelectorAll(".var")) {
        const vn = v.querySelector(".vn");
        if (vn && vn.textContent === nach) v.classList.add("dbg-marke");
      }
      // die Marke des ERSTEN Namens aus zeige rollt ins Bild (beziehung: das Fach __figur im Kasten zug, nicht die
      // Variable dame, die im Bild vorher kommt)
      if (!ersteMarke) ersteMarke = [...tafel.querySelectorAll(".dbg-marke")].find(e => !vorher.has(e)) || null;
    }
  }
  function wertEl(w, objekte, tiefe) {
    if (!w) return h("span", {}, "?");
    if (w.art === "wert") return h("span", { class: "vw" }, w.text);
    const typ = ((objekte || {})[w.id] || {}).typ || "Objekt";
    return h("span", { class: "ref", title: "zeigt auf den Kasten " + (namen[w.id] || typ) + " unten" }, "→ " + (namen[w.id] || typ));
  }
  function objektEl(oid, o, objekte) {
    const box = h("div", { class: "objekt" }, h("div", { class: "ot" }, namen[oid] ? h("b", {}, namen[oid]) : null, " " + o.typ));
    if (o.inhalt && (o.typ === "list" || o.typ === "tuple" || o.typ === "set")) o.inhalt.forEach((x, i) => box.append(h("span", { class: "fach" }, h("span", { class: "fn" }, String(i)), wertEl(x, objekte, 1))));
    else if (o.inhalt) o.inhalt.forEach(([k, v]) => box.append(h("div", { class: "var" }, h("span", { class: "vn" }, k.text), wertEl(v, objekte, 1))));
    else box.append(h("span", {}, o.text || ""));
    if (o.mehr) box.append(h("span", { class: "leer" }, " … " + o.mehr + " weitere"));
    return box;
  }
  // Die Shell zeigt, was bis HIER ausgegeben wurde: alles aus früheren Abläufen, im aktuellen alles aus
  // Zeilen, die schon gelaufen sind -- am letzten Schritt auch das Letzte (und die Fehlermeldung).
  function shell(s, letzter) {
    // Geschlossen ist geschlossen: Ein spätes Ereignis der Aufzeichnung (ein Programm mit Fenster läuft weiter) schrieb
    // sonst „Debugger · Ausgabe bis Schritt …“ in die Shell des Editors zurück (Durchsicht iq1 benutzen, W4, 13.11.2026)
    if (!wrap.isConnected) return;
    const text = ausgaben.filter(x => x.ablauf < aktiv || (x.ablauf === aktiv && (x.schritt < s.nr || letzter))).map(x => x.text).join("");
    konsole.textContent = "";
    konsole.append(h("span", { class: "satz dbg-shell" }, "Debugger · Ausgabe bis Schritt " + (s.nr + 1) + (letzter && fertig ? " (Ende)" : "")), "\n", text);
    if (letzter && fertig && fehler && aktiv === ablaeufe.length - 1) konsole.append(h("span", { class: "fehlertext" }, "\n" + fehler));
    // Ohne Ausgabe ist die Shell eine Zeile hoch, nicht 5,5 (Durchsicht iq1 benutzen, W3: „nimmt recht viel Platz in
    // Anspruch, obwohl da nur der Schritt steht“); eine selbst gezogene Höhe (Stil am Element) bleibt.
    konsole.classList.toggle("dbg-leer", !text && !(letzter && fertig && fehler && aktiv === ablaeufe.length - 1) && !(letzter && wartet && aktiv === wartet.ablauf));
    if (letzter && wartet && aktiv === wartet.ablauf) {
      const feld = h("input", { class: "dbg-eingabe", spellcheck: "false", "aria-label": "Eingabe für input()", placeholder: "eintippen, Enter" });
      feld.addEventListener("keydown", async ev => {
        if (ev.key !== "Enter") return;
        ev.preventDefault();
        const text = feld.value; feld.disabled = true;
        wartet = null; nachEingabe = true;
        try { await api("aufzeichnen/eingabe", { id, text }); } catch (e) { melde(e.message, true); }
      });
      konsole.append(feld);
      setTimeout(() => feld.focus(), 0);
    }
    konsole.scrollTop = 1e9;
  }
  function zeigen() {
    ablaufKnoepfe();
    const a = schritte(); if (!a.length) { tafel.textContent = ""; tafel.append(h("p", { class: "leer" }, "noch keine Schritte")); return; }
    const s = a[pos], letzter = pos === a.length - 1;
    namen = objektNamen(s);
    schieber.max = a.length - 1; schieber.value = pos;
    kZurueck.disabled = pos === 0; kUeber.disabled = kHinein.disabled = kWeiter.disabled = letzter; kHeraus.disabled = letzter || tiefe(pos) <= 1;
    ansichtZeigen(dateiVon(s), true);
    zaehler.textContent = "Schritt " + (pos + 1) + " von " + a.length + " · " + (haupt ? dateiVon(s) + ", " : "") + "Zeile " + s.zeile + (s.ereignis === "call" ? " · Aufruf " + s.funktion + "()" : s.ereignis === "return" ? (s.funktion === "<module>" ? " · Ende" : " · Rückkehr aus " + s.funktion + "()") : s.ereignis === "exception" ? " · Ausnahme" : "");
    zeilenEl.forEach((z, i) => z.classList.toggle("aktuell", i + 1 === s.zeile));
    // die markierte Zeile ins Bild -- nur in der Codeansicht scrollen (scrollIntoView schob in der Uebung die Seite und
    // liess die Zeile unten ausserhalb, 24.10.); ein Drittel Luft darueber
    const z = zeilenEl[s.zeile - 1];
    if (z) { const c = codeansicht.getBoundingClientRect(), r = z.getBoundingClientRect(); if (r.top < c.top || r.bottom > c.bottom) codeansicht.scrollTop += (r.top - c.top) - c.height / 3; }
    // die Rollposition bleibt beim Neuaufbau (W4, 14.11.2026: jede Lieferung der Aufzeichnung baute die Tafel neu und
    // warf sie nach oben -- auch die Stelle, an die der Halt im Film gerollt hatte)
    const gerollt = tafel.scrollTop;
    tafel.textContent = "";
    const fb = fensterBild(s, letzter); tafel.classList.toggle("mit-fenster", !!fb); if (fb) tafel.append(fb);
    const glob = h("div", { class: "rahmen" }, h("div", { class: "rt" }, "Variablen (Programm)"));
    // Werte und Objekte zuerst, Funktionen und Klassen danach (Durchsicht iq1 kapsel, W4, 14.11.2026: Die Dame stand
    // unter neue_flaeche, zeichne_bild, zeige … unter dem Rand -- „ich weiß nie, was ich machen soll“)
    // -- die Funktionen und Klassen stehen ganz unten in einem eigenen Kasten, die Objekte gleich unter den Variablen
    const bauteil = w => w && w.art === "wert" && /^(Funktion|Klasse|Modul) /.test(w.text);
    const alle = Object.keys(s.global || {}), gk = alle.filter(k => !bauteil(s.global[k])), bk = alle.filter(k => bauteil(s.global[k]));
    if (!gk.length) glob.append(h("div", { class: "leer" }, "noch keine"));
    for (const k of gk) glob.append(h("div", { class: "var" }, h("span", { class: "vn" }, k), wertEl(s.global[k], s.objekte)));
    tafel.append(glob);
    if (s.funktion !== "<module>") {
      const lok = h("div", { class: "rahmen" }, h("div", { class: "rt" }, "in " + s.stapel.filter(x => x !== "<module>").join(" → ") + "()"));
      for (const k of Object.keys(s.lokal || {})) lok.append(h("div", { class: "var" }, h("span", { class: "vn" }, k), wertEl(s.lokal[k], s.objekte)));
      if (s.rueckgabe) lok.append(h("div", { class: "var" }, h("span", { class: "vn" }, "↩ Rückgabe"), wertEl(s.rueckgabe, s.objekte)));
      tafel.append(lok);
    } else if (haupt && dateiVon(s) !== haupt) {
      // der Import eines Moduls der Klasse: was in figur.py bis hier entstanden ist (die Klasse Figur)
      const lok = h("div", { class: "rahmen" }, h("div", { class: "rt" }, dateiVon(s) + " (beim Import)"));
      const lk = Object.keys(s.lokal || {}); if (!lk.length) lok.append(h("div", { class: "leer" }, "noch nichts"));
      for (const k of lk) lok.append(h("div", { class: "var" }, h("span", { class: "vn" }, k), wertEl(s.lokal[k], s.objekte)));
      tafel.append(lok);
    }
    if (s.ausnahme) tafel.append(h("div", { class: "rahmen fehler" }, s.ausnahme));
    const ok = Object.keys(s.objekte || {}); if (ok.length) { const ob = h("div", { class: "rahmen" }, h("div", { class: "rt" }, "Objekte")); for (const oid of ok) ob.append(objektEl(oid, s.objekte[oid], s.objekte)); tafel.append(ob); }
    if (bk.length) {
      const fk = h("div", { class: "rahmen bauteile" }, h("div", { class: "rt" }, "Funktionen und Klassen"));
      for (const k of bk) fk.append(h("div", { class: "var" }, h("span", { class: "vn" }, k), wertEl(s.global[k], s.objekte)));
      tafel.append(fk);
    }
    markenSetzen();
    tafel.scrollTop = gerollt;
    shell(s, letzter);
    wrap.classList.toggle("wartet", !!wartet);
    if (wartet && aktiv === wartet.ablauf) { melde(letzter ? "Das Programm wartet auf eine Eingabe – tippt sie in die Shell und drückt Enter." : "Das Programm wartet bei Schritt " + a.length + " auf eine Eingabe – geht bis dorthin (Weiter ▶▶).", true); meld.dataset.warte = "1"; }
    else if (meld.dataset.warte) { delete meld.dataset.warte; melde(""); }
  }
  schieber.addEventListener("input", () => gehe(parseInt(schieber.value, 10)));

  // Die Meldung (24.10.): Im breiten Debugger steht ein blosser Hinweis nur als Tooltip am Zaehler -- als eigene Zeile
  // sprang sie beim Ziehen der Shell (Lehrer: „verschiebt sich nervig“); sichtbar bleibt nur, was wichtig ist
  // (Fehler, Grenze, Fenster-Programm)
  const melde = (text, wichtig) => { meld.textContent = text; meld.classList.toggle("wichtig", !!wichtig); zaehler.title = text; };
  melde(meld.textContent);
  // Fuer den Code-Film (24.10.): fertig (der Lauf ist aufgezeichnet), gehZu(zeile, mal) springt an das mal-te
  // Erreichen der Zeile, satz(html, impuls) zeigt den Text des Halts, schliessen() wie ✕.
  // Python-Ordner (11.11.2026): ein Halt zaehlt vorerst nur in der Hauptdatei (Bauplan Schritt 9, Teil 4)
  let fertigMelden; const fertigVersprechen = new Promise(r => { fertigMelden = r; });
  const steuer = {
    fertig: fertigVersprechen,
    offen: () => wrap.isConnected,
    gehZu(zeile, mal) {
      const a = schritte(); let n = 0;
      for (let i = 0; i < a.length; i++) if (a[i].ereignis === "line" && dateiVon(a[i]) === haupt && a[i].zeile === zeile && ++n === (mal || 1)) {
        gehe(i);
        return true;
      }
      return false;
    },
    satz(html, impuls) { satzEl.innerHTML = (html || "") + (impuls ? '<div class="impuls">' + impuls + "</div>" : ""); satzEl.hidden = !html && !impuls; },
    schliessen: () => zu.click(),
    // Der Code-Film zeigt den Debugger erst, wenn er am Halt steht (Durchsicht iq1 kapsel, W4, 14.11.2026): Vorher
    // sprang die Ansicht dreimal in einer halben Sekunde -- Leiste allein, Leiste zweizeilig mit Schritt 1, dann der
    // Halt mit Satz und Bild. Der Platz bleibt dabei stehen (visibility, nicht display).
    sichtbar(an) { wrap.style.visibility = an ? "" : "hidden"; },
    // die Marken des Halts setzen (leere Liste nimmt sie weg) und die erste ganz ins Bild rollen
    markiere(liste) { markiert = (liste || []).slice(); zeigen(); },
    // Stehen nicht alle Marken ganz im Bild, kommt die des ersten Namens oben an den Rand der Tafel (kapsel: `zeile` 99
    // lag unter `__zeile` 3 unter dem Rand, 14.11.2026)
    markeZeigen() {
      const b = ersteMarke || tafel.querySelector(".dbg-marke"); if (!b) return false;
      const t = tafel.getBoundingClientRect(), unten = t.top + tafel.clientHeight;
      const alle = [...tafel.querySelectorAll(".dbg-marke")].every(e => { const r = e.getBoundingClientRect(); return r.top >= t.top && r.bottom <= unten; });
      if (!alle) tafel.scrollTop += b.getBoundingClientRect().top - t.top - 8;
      return true;
    },
    // am Halt das erste Objekt ganz ins Bild (W4, 14.11.2026: der Kasten der Dame stand unter dem Rand) -- erst, wenn
    // der Debugger steht; vorher hatte die Tafel noch nicht ihre Hoehe im breiten Format
    objektZeigen() {
      const b = tafel.querySelector(".objekt"); if (!b || tafel.scrollHeight <= tafel.clientHeight) return;
      const unten = tafel.getBoundingClientRect().top + tafel.clientHeight, r = b.getBoundingClientRect();
      if (r.bottom > unten) tafel.scrollTop += Math.min(r.bottom - unten + 8, r.top - tafel.getBoundingClientRect().top);
    },
  };
  edIch._dbg = steuer;

  (async () => {
    const eingaben = (opts.eingaben ? opts.eingaben() : []);
    // die übrigen Dateien des Ordners, wie sie gerade gespeichert sind -- vor dem Lauf, damit jeder Schritt seine Zeile findet
    if (opts.quellen) { try { for (const [d, t] of Object.entries(await opts.quellen())) if (d !== haupt) ansichtBauen(d, t); } catch (e) { melde(e.message, true); } }
    try { id = (await api("aufzeichnen/start", { pfad: edIch.pfad, eingaben })).id; } catch (e) { melde(e.message, true); fertigMelden(false); return; }
    let ab = 0;
    while (true) {
      let b; try { b = await api("aufzeichnen/lesen", { id, ab }); } catch (e) { melde(e.message, true); fertigMelden(false); break; }
      ab = b.bis;
      for (const ev of b.ereignisse) {
        if (ev.art === "ablauf") ablaeufe[ev.nr] = { name: ev.name, schritte: [] };
        else if (ev.art === "schritt") { const a = ablaeufe[ev.ablauf] || (ablaeufe[ev.ablauf] = { name: "Ablauf " + ev.ablauf, schritte: [] }); ev.nr = a.schritte.length; a.schritte.push(ev); }
        else if (ev.art === "zeichnen") { if (ev.daten) bildDaten[ev.datei] = ev.daten; const z = Object.assign({}, ev, { schritt: (ablaeufe[ev.ablauf] || { schritte: [] }).schritte.length - 1 }); delete z.daten; zeichnungen.push(z); }
        else if (ev.art === "ausgabe") ausgaben.push({ ablauf: ev.ablauf, schritt: (ablaeufe[ev.ablauf] || { schritte: [] }).schritte.length - 1, text: ev.text });
        else if (ev.art === "grenze") grenze = ev.text;
        else if (ev.art === "fehler") fehler = ev.text;
        else if (ev.art === "mainloop") melde(ev.text, true);
        else if (ev.art === "warte") wartet = { frage: ev.frage, ablauf: ev.ablauf };
      }
      if (b.fertig) fertig = true;
      if (nachEingabe && schritte().length > pos + 1) { nachEingabe = false; pos++; }   // wie in Thonny: nach Enter geht es weiter
      // nur bei Neuem zeichnen -- sonst ersetzte jede Abfrage (alle 250 ms) das Eingabefeld in der Shell
      if (b.ereignisse.length || b.fertig) zeigen();
      if (b.fertig) fertigMelden(true);
      if (b.fertig) {
        if (grenze) { melde("⚠ " + grenze, true); meld.classList.add("fehler"); }
        else if (fehler) melde("Der Debugger ist fertig – das Programm ist mit einem Fehler geendet; der letzte Schritt zeigt die Stelle.", true);
        else melde("Der Debugger ist fertig: " + ablaeufe.reduce((n, a) => n + a.schritte.length, 0) + " Schritte" + (ablaeufe.length > 1 ? " in " + ablaeufe.length + " Abläufen" : "") + ". Die markierte Zeile läuft als Nächstes. Klick auf eine Zeilennummer setzt einen Haltepunkt für „Weiter“.");
        break;
      }
      await schlafen(250);
    }
  })();
  return steuer;
}
