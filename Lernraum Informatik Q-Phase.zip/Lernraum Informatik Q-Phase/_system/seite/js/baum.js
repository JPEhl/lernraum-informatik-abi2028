// Die Werkstatt Baum (Attrappen 30.10.2026, Lehrerwahl ① A von oben nach unten, ② B im Arbeitsplatz, ③ B Elemente und Text,
// werkstatt/informatik/planung/baum_werkstatt/): der Dokumentbaum der offenen Datei, live aus dem Editortext gerechnet --
// dieselbe Logik wie seite() im Selbstcheck (pruefen.py): Tags auf einen Stapel, leere Elemente ohne Ende, was nie geschlossen
// wird, ist rot. Ein Klick auf einen Knoten markiert seine Zeilen, die Zeile der Schreibmarke zeigt ihren Knoten.
const BAUM_LEER = new Set(["area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "source", "track", "wbr"]);
function baumLesen(text) {
  const wurzel = { tag: "#", kinder: [], von: 1, bis: 1 }, stapel = [wurzel];
  const zeileAn = (() => { let i = 0, z = 1; return p => { for (; i < p; i++) if (text[i] === "\n") z++; return z; }; })();
  for (const m of text.matchAll(/<!--[\s\S]*?-->|<![^>]*>|<(\/?)([a-zA-Z][a-zA-Z0-9]*)((?:[^>"']|"[^"]*"|'[^']*')*)>|([^<]+)|</g)) {
    const zeile = zeileAn(m.index), oben = stapel[stapel.length - 1];
    if (m[4] !== undefined) {
      const t = m[4].replace(/\s+/g, " ").trim();
      // ein Punkt hinter einem Link ist kein Knoten, den man lesen will
      if (t && !/^[\p{P}\s]+$/u.test(t)) { const vorn = m[4].length - m[4].trimStart().length; oben.kinder.push({ text: t, von: zeileAn(m.index + vorn), bis: zeileAn(m.index + m[0].trimEnd().length) }); }
      continue;
    }
    if (!m[2]) continue;
    const tag = m[2].toLowerCase();
    if (m[1]) {
      for (let k = stapel.length - 1; k > 0; k--) if (stapel[k].tag === tag) {
        stapel[k].zu = true; for (let j = k; j < stapel.length; j++) stapel[j].bis = zeile;
        stapel.length = k; break;
      }
      continue;
    }
    const n = { tag, kinder: [], von: zeile, bis: zeile, zu: BAUM_LEER.has(tag) || /\/\s*$/.test(m[3] || "") };
    oben.kinder.push(n);
    if (!n.zu) stapel.push(n);
  }
  const ende = zeileAn(text.length);
  for (let j = 1; j < stapel.length; j++) stapel[j].bis = ende;
  return wurzel;
}
// Die Fläche: zeichnet die Wurzelelemente von oben nach unten; quelle() gibt den Text, marken(liste) setzt die Zeilenmarken
function baumFlaeche(quelle, marken) {
  const box = h("div", { class: "baum-flaeche", title: "Ein Klick auf einen Knoten markiert seine Zeilen" });
  let knoten = [], gewaehlt = null, zoom = 1;
  const blatt = n => (n.kinder || []).length ? n.kinder.reduce((s, k) => s + blatt(k), 0) : 1;
  const tiefe = n => 1 + Math.max(0, ...(n.kinder || []).map(tiefe));
  const eins = t => String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  function zeichnen() {
    const text = quelle();
    if (text == null) { box.textContent = ""; knoten = []; box.append(h("p", { class: "baum-leer" }, "Eine CSS-Datei hat keinen Dokumentbaum.")); marken([]); return; }
    const oben = baumLesen(text).kinder, alle = [];   // auch loser Text ohne Tag steht oben im Baum
    const breiteJe = 50, blaetter = Math.max(1, oben.reduce((s, k) => s + blatt(k), 0)), tief = Math.max(1, ...oben.map(tiefe));
    const W = Math.max(box.clientWidth - 12, 300, blaetter * breiteJe), Z = Math.max(46, Math.min(66, (box.clientHeight - 14) / tief || 60));
    const B = W / blaetter, H = tief * Z + 4;
    let linien = "", kasten = "";
    (function setze(liste, x0, t, ex, ey) {
      let x = x0;
      for (const n of liste) {
        const w = blatt(n) * B, mx = x + w / 2, my = 20 + t * Z, i = alle.length;
        alle.push(n);
        if (ex != null) linien += `<path d="M${ex} ${ey + 13} C${ex} ${ey + 13 + Z / 3} ${mx} ${my - 13 - Z / 3} ${mx} ${my - 13}"/>`;
        const istText = n.text !== undefined, bw = istText ? Math.min(B - 4, 96) : Math.min(B - 4, 34 + n.tag.length * 8.4);
        const art = istText ? "text" : !n.zu ? "offen" : (n.tag === "head" || n.tag === "title") ? "kopf" : "element";
        const zeichen = Math.floor(bw / 6.6), wort = istText ? (n.text.length > zeichen ? n.text.slice(0, Math.max(1, zeichen - 1)) + "…" : n.text) : n.tag;
        kasten += `<g class="bk ${art}" data-i="${i}"><title>${eins(istText ? n.text : "<" + n.tag + ">")}</title><rect x="${mx - bw / 2}" y="${my - 13}" width="${bw}" height="26" rx="${istText ? 4 : 13}"/><text x="${mx}" y="${my + 4.5}">${eins(wort)}</text></g>`;
        if (n.kinder) setze(n.kinder, x, t + 1, mx, my);
        x += w;
      }
    })(oben, 0, 0, null, null);
    knoten = alle;
    box.innerHTML = `<svg class="baum" viewBox="0 0 ${W} ${H}" width="${W * zoom}" height="${H * zoom}"><g class="bl">${linien}</g>${kasten}</svg>`;
    const offen = knoten.filter(n => n.tag && !n.zu).map(n => ({ von: n.von, bis: n.von, art: "rot" }));
    // die Wahl überlebt das Neuzeichnen, solange es denselben Knoten noch gibt
    if (gewaehlt) { const g = knoten.findIndex(n => n.tag === gewaehlt.tag && n.von === gewaehlt.von); gewaehlt = g >= 0 ? knoten[g] : null; if (g >= 0) box.querySelector(`[data-i="${g}"]`).classList.add("an"); }
    marken(gewaehlt ? offen.concat([{ von: gewaehlt.von, bis: gewaehlt.bis, art: "an" }]) : offen);
  }
  function waehlen(n) { gewaehlt = n; zeichnen(); }
  box.addEventListener("click", ev => { const g = ev.target.closest && ev.target.closest(".bk"); waehlen(g ? knoten[+g.dataset.i] : null); });
  // die Breite hängt am Fenster: ziehen am Trenner rechnet neu
  let uhr = null; new ResizeObserver(() => { clearTimeout(uhr); uhr = setTimeout(() => { if (!box.hidden) zeichnen(); }, 120); }).observe(box);
  return {
    box, zeichnen,
    knoten: tag => { const n = tag ? knoten.find(k => k.tag === tag) : null; waehlen(n || null); return !!n; },
    keiner: () => { gewaehlt = null; },
    zeile: z => {   // die Schreibmarke: der innerste Knoten, der diese Zeile enthält
      box.querySelectorAll(".bk.zeile").forEach(g => g.classList.remove("zeile"));
      // steht der Text mit seinem Element in einer Zeile, zählt das Element (<title>Keflavík</title> zeigt title)
      let i = -1; knoten.forEach((n, k) => { if (n.von <= z && z <= n.bis && !(n.text !== undefined && i >= 0 && knoten[i].von === z)) i = k; });
      if (i >= 0) box.querySelector(`[data-i="${i}"]`).classList.add("zeile");
    },
    zoomen: f => { zoom = f; zeichnen(); },
  };
}
