/* Lernraum · editor.js -- CodeMirror-Editor, Arbeitsdatei im Editor, Eingaben, Trenner, Kopieren-Knöpfe.
   Teil der Arbeitsseite; alle Teile teilen einen Namensraum und laden in der
   Reihenfolge von index.html (kein Bündler, CSP 'self'). */
"use strict";
// ── Editor (CodeMirror 6) ──────────────────────────────────────────────────────
const fehlerMarke = CM.Decoration.line({ class: "cm-fehlerzeile" });
const aktuellMarke = CM.Decoration.line({ class: "cm-aktuellezeile" });
// Zwischenstände im Fahrplan (Lehrerwunsch 21.10., T11): neu grün, geändert gelb, gelöscht rot und
// durchgestrichen. Gelöschte Zeilen stehen nicht mehr im Code -- sie sind ein Widget über der Stelle.
const neuMarke = CM.Decoration.line({ class: "cm-stand-neu" });
const geaendertMarke = CM.Decoration.line({ class: "cm-stand-geaendert" });
const gehtMarke = CM.Decoration.line({ class: "cm-stand-geht" });
// Innerhalb einer geänderten Zeile nur das Stück (meldung W6, Lehrer 10.11.: „die Animation löscht die gesamte Zeile und
// schreibt sie neu. Dadurch erkennt man als Mensch nicht so gut, was sich geändert und was gleich geblieben ist“)
const gehtStueck = CM.Decoration.mark({ class: "cm-stand-geht-stueck" });
const neuStueck = CM.Decoration.mark({ class: "cm-stand-stueck" });
// + markieren: im Code-Film (meldung W5): die Stelle, auf die man schauen soll
const stelleMarke = CM.Decoration.mark({ class: "cm-stelle" });
const stelleZeile = CM.Decoration.line({ class: "cm-stelle-zeile" });
// Kopieren und Einfügen (Lehrer 22.10.: „Könnte man das Copy-Pasten auch als Copy-Pasten und nicht als Tippen
// animieren?“): die Quelle wie eine Auswahl, dann erscheint der Block auf einmal
const kopieMarke = CM.Decoration.line({ class: "cm-stand-kopie" });
const baumAnMarke = CM.Decoration.line({ class: "cm-baum-an" });       // Klick auf einen Knoten: seine Zeilen
const baumRotMarke = CM.Decoration.line({ class: "cm-baum-rot" });     // ein Element, das nie geschlossen wird
class GeloeschtWidget extends CM.WidgetType {
  constructor(zeilen) { super(); this.zeilen = zeilen; }
  eq(w) { return w.zeilen.join("\n") === this.zeilen.join("\n"); }
  toDOM() { const d = h("div", { class: "cm-stand-weg", "aria-label": "gelöscht" }); this.zeilen.forEach(z => d.append(h("div", {}, z || " "))); return d; }
  ignoreEvent() { return true; }
}
// Zeilenvergleich: gibt je Zeile des neuen Texts "gleich" | "neu" | "geaendert" und die gelöschten Zeilen
// mit der Zeile, vor der sie standen. Patience-Vergleich: Zeilen, die in beiden Texten genau einmal
// vorkommen, werden zuerst verankert (in T11 steht hilfe() zweimal -- die längste gemeinsame Folge allein
// hätte „Viel Glück“ gelöscht und neu geschrieben, statt den Aufruf ohne Klammern gelb zu zeigen);
// dazwischen die längste gemeinsame Folge. Ein Block aus Weg und Neu nebeneinander zählt paarweise als
// „geändert“; was übrig bleibt, ist neu bzw. gelöscht.
// Eine geänderte Zeile im Feinen: gleicher Anfang, gleiches Ende, dazwischen was wegfällt und was dazukommt. null,
// wenn kaum etwas gleich bleibt (dann wird die Zeile wie bisher ganz neu geschrieben).
function feinVergleich(alt, neu) {
  const max = Math.min(alt.length, neu.length);
  let p = 0; while (p < max && alt[p] === neu[p]) p++;
  let s = 0; while (s < max - p && alt[alt.length - 1 - s] === neu[neu.length - 1 - s]) s++;
  // auf ganze Wörter: „Flur“ → „Keller“ tauscht das Wort, nicht „Flu“ gegen „Kelle“ mit stehendem r
  const wort = c => /[\p{L}\p{N}_]/u.test(c || "");
  while (p > 0 && wort(neu[p - 1]) && (wort(neu[p]) || wort(alt[p]))) p--;
  while (s > 0 && wort(neu[neu.length - s]) && (wort(neu[neu.length - s - 1]) || wort(alt[alt.length - s - 1]))) s--;
  const einzug = neu.match(/^\s*/)[0].length;
  const gleich = Math.max(0, p - einzug) + s;
  if (gleich < 3 || gleich < 0.3 * neu.trim().length) return null;
  return { p, s, weg: alt.slice(p, alt.length - s), neu: neu.slice(p, neu.length - s) };
}
function zeilenVergleich(alt, neu) {
  const a = alt.split("\n"), b = neu.split("\n");
  const ops = [];   // ["=", i, j] | ["-", i] | ["+", j]
  function lcs(a0, a1, b0, b1) {
    const n = a1 - a0, m = b1 - b0;
    const t = Array.from({ length: n + 1 }, () => new Int32Array(m + 1));
    for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) t[i][j] = a[a0 + i] === b[b0 + j] ? t[i + 1][j + 1] + 1 : Math.max(t[i + 1][j], t[i][j + 1]);
    let i = 0, j = 0;
    while (i < n || j < m) {
      if (i < n && j < m && a[a0 + i] === b[b0 + j]) { ops.push(["=", a0 + i, b0 + j]); i++; j++; }
      else if (j >= m || (i < n && t[i + 1][j] >= t[i][j + 1])) { ops.push(["-", a0 + i]); i++; }
      else { ops.push(["+", b0 + j]); j++; }
    }
  }
  function patience(a0, a1, b0, b1) {
    while (a0 < a1 && b0 < b1 && a[a0] === b[b0]) { ops.push(["=", a0++, b0++]); }
    const ende = [];
    while (a1 > a0 && b1 > b0 && a[a1 - 1] === b[b1 - 1]) { a1--; b1--; ende.unshift(["=", a1, b1]); }
    const zaehle = (arr, x0, x1) => { const z = new Map(); for (let k = x0; k < x1; k++) z.set(arr[k], (z.get(arr[k]) || 0) + 1); return z; };
    const za = zaehle(a, a0, a1), zb = zaehle(b, b0, b1), posA = new Map();
    for (let k = a0; k < a1; k++) if (za.get(a[k]) === 1 && zb.get(a[k]) === 1 && a[k].trim()) posA.set(a[k], k);
    const paare = []; for (let k = b0; k < b1; k++) if (posA.has(b[k]) && zb.get(b[k]) === 1) paare.push([posA.get(b[k]), k]);
    // längste steigende Folge nach der Position im alten Text
    const vor = [], spitzen = [];
    paare.forEach((p, k) => { let lo = 0, hi = spitzen.length; while (lo < hi) { const mid = (lo + hi) >> 1; if (paare[spitzen[mid]][0] < p[0]) lo = mid + 1; else hi = mid; } vor[k] = lo ? spitzen[lo - 1] : -1; spitzen[lo] = k; });
    const anker = []; for (let k = spitzen.length ? spitzen[spitzen.length - 1] : -1; k >= 0; k = vor[k]) anker.unshift(paare[k]);
    if (!anker.length) lcs(a0, a1, b0, b1);
    else { let ia = a0, ib = b0; for (const [x, y] of anker) { patience(ia, x, ib, y); ops.push(["=", x, y]); ia = x + 1; ib = y + 1; } patience(ia, a1, ib, b1); }
    ops.push(...ende);
  }
  patience(0, a.length, 0, b.length);
  const art = new Array(b.length).fill("gleich"), weg = [], fein = {}, gehen = [];
  for (let k = 0; k < ops.length;) {
    if (ops[k][0] === "=") { k++; continue; }
    const wegZ = [], wegI = [], neuJ = [];
    while (k < ops.length && ops[k][0] !== "=") { if (ops[k][0] === "-") { wegZ.push(a[ops[k][1]]); wegI.push(ops[k][1]); } else neuJ.push(ops[k][1]); k++; }
    const naechste = k < ops.length ? ops[k][2] : b.length;
    const paare = Math.min(wegZ.length, neuJ.length);
    neuJ.forEach((jj, x) => {
      art[jj] = x < paare ? "geaendert" : "neu";
      const f = x < paare ? feinVergleich(wegZ[x], b[jj]) : null;
      if (f) fein[jj] = f;
    });
    // was im alten Text wegfällt: ganze Zeilen, bei fein verglichenen Zeilen nur das Stück (oder nichts)
    wegI.forEach((i, x) => {
      const f = x < paare ? fein[neuJ[x]] : null;
      if (!f) gehen.push({ zeile: i });
      else if (f.weg) gehen.push({ zeile: i, von: f.p, bis: f.p + f.weg.length });
    });
    if (wegZ.length > paare) weg.push([naechste, wegZ.slice(paare)]);
  }
  return { art, weg, ops, fein, gehen };
}
// Vim-Tasten (16.11.2026, Frage aus dem Kurs: „ob man im Coding nvim unterstützen könnte“): ein Schalter im Zahnrad,
// aus als Standard, gemerkt je Browser. Nur in den Editoren, in denen die Klasse selbst schreibt -- nie im Pult
// (dort tippt der Film, und der Lehrer führt vor) und nie in gegebenen Dateien. Unten im Editor steht dann die
// Betriebsart (-- NORMAL --, -- INSERT --). Esc gehört bei eingeschalteten Vim-Tasten dem Editor (vimFokus).
const VIM_SCHLUESSEL = "lernraum.vim";
let vimZustand = false; try { vimZustand = localStorage.getItem(VIM_SCHLUESSEL) === "1"; } catch (e) {}
const vimAn = () => vimZustand && !Z.lehrer && !!CM.vim;
const vimFokus = () => { const a = document.activeElement, e = a && a.closest && a.closest(".cm-editor"); return !!(e && e.vimLaeuft && e.vimLaeuft()); };
function vimSchalten(an) {
  vimZustand = !!an; try { localStorage.setItem(VIM_SCHLUESSEL, an ? "1" : "0"); } catch (e) {}
  document.querySelectorAll(".cm-editor").forEach(el => { if (el.vimAbgleich) el.vimAbgleich(); });
}
function editor(parent, text, sprache, onChange, schreibgeschuetzt) {
  const vimFach = new CM.Compartment();
  let vimIst = !schreibgeschuetzt && vimAn();
  const marken = new CM.Compartment();
  const stand = new CM.Compartment();
  const baumMarken = new CM.Compartment();
  const stelle = new CM.Compartment();
  let standSetzen = false, aufZeile = null, aufText = null;
  const ext = [
    vimFach.of(vimIst ? CM.vim({ status: true }) : []),      // vor allen anderen Tastenbelegungen
    CM.lineNumbers(), CM.highlightActiveLine(), CM.highlightActiveLineGutter(), CM.highlightSpecialChars(), CM.drawSelection(),
    CM.history(), CM.indentUnit.of("    "), CM.bracketMatching(), CM.closeBrackets(), CM.indentOnInput(),
    CM.syntaxHighlighting(CM.defaultHighlightStyle, { fallback: true }), CM.highlightSelectionMatches(),
    CM.keymap.of([...CM.closeBracketsKeymap, ...CM.defaultKeymap, ...CM.historyKeymap, ...CM.searchKeymap, CM.indentWithTab]),
    // HTML ohne automatisches Schliessen (Attrappe ⑤, Lehrer 29.10.): das Thema heisst „öffnende und
    // schließende Tags“ -- schriebe der Editor </h2> selbst, gaebe es nie ein fehlendes Ende zu finden
    sprache === "html" ? CM.html({ autoCloseTags: false }) : sprache === "text" ? [] : CM.python(),     // text: flughafen.css
    marken.of([]), stand.of([]), baumMarken.of([]), stelle.of([]),
    CM.EditorView.updateListener.of(u => {
      if (u.selectionSet && aufZeile) aufZeile(u.state.doc.lineAt(u.state.selection.main.head).number);
      if (!u.docChanged) return;
      if (aufText) aufText();
      // Der erste eigene Tastendruck nimmt die Farben des Zwischenstands weg -- ab dort tippt man normal weiter
      if (!standSetzen) setTimeout(() => view.dispatch({ effects: stand.reconfigure([]) }), 0);
      if (onChange) onChange(u.state.doc.toString());
    }),
  ];
  if (sprache === "html" || sprache === "text") ext.push(CM.EditorView.lineWrapping);   // Fliesstext der Stationen bricht um (29.10.)
  if (schreibgeschuetzt) ext.push(CM.EditorState.readOnly.of(true), CM.EditorView.editable.of(false));
  const view = new CM.EditorView({ state: CM.EditorState.create({ doc: text, extensions: ext }), parent });
  // Der Schalter im Zahnrad wirkt sofort auf jeden Editor, der im Dokument steht; einer, der gerade nicht im Dokument
  // hing, gleicht sich ab, sobald er den Fokus bekommt.
  view.dom.vimLaeuft = () => vimIst;
  if (!schreibgeschuetzt) {
    view.dom.vimAbgleich = () => { if (vimIst === vimAn()) return; vimIst = vimAn(); view.dispatch({ effects: vimFach.reconfigure(vimIst ? CM.vim({ status: true }) : []) }); };
    view.contentDOM.addEventListener("focus", () => setTimeout(view.dom.vimAbgleich, 0));
  }
  let anim = null;
  function programmatisch(spec) { standSetzen = true; try { view.dispatch(spec); } finally { standSetzen = false; } }
  function farben(art, weg, stuecke) {
    const doc = view.state.doc, deko = [];
    art.forEach((x, j) => { if (x !== "gleich" && j < doc.lines) deko.push((x === "neu" ? neuMarke : geaendertMarke).range(doc.line(j + 1).from)); });
    (stuecke || []).forEach(({ j, von, bis }) => {
      if (j >= doc.lines) return; const z = doc.line(j + 1);
      if (bis > von && z.from + bis <= z.to) deko.push(neuStueck.range(z.from + von, z.from + bis));
    });
    weg.forEach(([vor, zeilen]) => {
      const pos = vor < doc.lines ? doc.line(vor + 1).from : doc.length;
      deko.push(CM.Decoration.widget({ widget: new GeloeschtWidget(zeilen), block: true, side: vor < doc.lines ? -1 : 1 }).range(pos));
    });
    programmatisch({ effects: stand.reconfigure(CM.EditorView.decorations.of(CM.Decoration.set(deko, true))) });
  }
  function gehenMarkieren(gehen) {
    const d = view.state.doc;
    const deko = gehen.filter(g => g.zeile < d.lines).map(g => g.von == null ? gehtMarke.range(d.line(g.zeile + 1).from)
      : gehtStueck.range(d.line(g.zeile + 1).from + g.von, d.line(g.zeile + 1).from + g.bis));
    programmatisch({ effects: stand.reconfigure(CM.EditorView.decorations.of(CM.Decoration.set(deko, true))) });
  }
  const volleStuecke = fein => Object.keys(fein).map(j => ({ j: +j, von: fein[j].p, bis: fein[j].p + fein[j].neu.length }));
  // Ruhig zur Stelle (Lehrer 21.10.: „der Code ist sehr plötzlich zur korrekten Stelle gesprungen“): steht sie schon
  // im Bild, bleibt alles, wo es ist; sonst gleitet der Editor hin, mit drei Zeilen davor. Gibt die Dauer in ms.
  function sanftZu(pos, sanft) {
    const sd = view.scrollDOM, b = view.lineBlockAt(pos), oben = sd.scrollTop, hoehe = sd.clientHeight;
    const rand = b.height * 2;
    if (b.top >= oben + rand / 2 && b.bottom <= oben + hoehe - rand) return 0;
    sd.scrollTo({ top: Math.max(0, b.top - b.height * 3), behavior: sanft ? "smooth" : "auto" });
    return sanft ? 420 : 0;
  }
  return {
    view,
    text: () => view.state.doc.toString(),
    setzen(t) { view.dispatch({ changes: { from: 0, to: view.state.doc.length, insert: t } }); view.dispatch({ effects: marken.reconfigure([]) }); },
    markieren(zeile, art) {
      if (!zeile || zeile > view.state.doc.lines) { view.dispatch({ effects: marken.reconfigure([]) }); return; }
      const pos = view.state.doc.line(zeile).from;
      const deko = CM.Decoration.set([(art === "aktuell" ? aktuellMarke : fehlerMarke).range(pos)]);
      view.dispatch({ effects: marken.reconfigure(CM.EditorView.decorations.of(deko)) });
      view.dispatch({ effects: CM.EditorView.scrollIntoView(pos, { y: "center" }) });
    },
    entmarkieren() { view.dispatch({ effects: marken.reconfigure([]) }); },
    // die Werkstatt Baum (30.10.): Zeilen markieren, ohne den Editor zu bewegen; beiZeile meldet die Zeile der Schreibmarke
    zeilenMarken(liste) {
      const doc = view.state.doc, deko = [];
      for (const m of liste) for (let z = m.von; z <= Math.min(m.bis, doc.lines); z++) deko.push((m.art === "rot" ? baumRotMarke : baumAnMarke).range(doc.line(z).from));
      programmatisch({ effects: baumMarken.reconfigure(deko.length ? CM.EditorView.decorations.of(CM.Decoration.set(deko, true)) : []) });
    },
    beiZeile(f) { aufZeile = f; },
    beiText(f) { aufText = f; },
    // Setzt den Code auf einen Zwischenstand und färbt, was sich gegenüber `alt` geändert hat.
    // Ein normaler Edit: Strg+Z holt den Stand davor zurück (auch das, was man selbst getippt hatte).
    async standZeigen(neu, alt) {
      if (anim) { anim.abbrechen(); await anim.fertig; }
      programmatisch({ changes: { from: 0, to: view.state.doc.length, insert: neu }, effects: marken.reconfigure([]) });
      const { art, weg, fein } = zeilenVergleich(alt, neu);
      farben(art, weg, volleStuecke(fein));
      const erste = art.findIndex(x => x !== "gleich");
      const ziel = erste >= 0 ? erste : (weg.length ? Math.min(weg[0][0], view.state.doc.lines - 1) : -1);
      if (ziel >= 0) sanftZu(view.state.doc.line(ziel + 1).from, false);
      return { neu: art.filter(x => x === "neu").length, geaendert: art.filter(x => x === "geaendert").length, weg: weg.reduce((s, w) => s + w[1].length, 0) };
    },
    // Der Code-Film (Lehrerwunsch 21.10.): von `alt` nach `neu`, sichtbar getippt. Erst ruhig zur Stelle scrollen,
    // dann wird kurz rot, was wegfällt, dann erscheint das Neue Zeichen für Zeichen (Einrückung sofort).
    // opt.zps Zeichen je Sekunde, opt.maxSek höchstens so lange; ein zweiter Klick bricht ab (fertig sofort).
    async standAnimieren(neu, alt, opt) {
      if (anim) { anim.abbrechen(); await anim.fertig; }
      const norm = x => x.replace(/\s+$/, "");
      programmatisch(norm(view.state.doc.toString()) !== norm(alt)
        ? { changes: { from: 0, to: view.state.doc.length, insert: alt }, effects: [marken.reconfigure([]), stand.reconfigure([])] }
        : { effects: opt.schonRot ? [marken.reconfigure([])] : [marken.reconfigure([]), stand.reconfigure([])] });
      const { art, weg, ops, fein, gehen } = zeilenVergleich(alt, neu);
      if (alt === neu) return;
      let abgebrochen = false, fertigAuf = null;
      const meins = { abbrechen() { abgebrochen = true; }, fertig: new Promise(r => { fertigAuf = r; }) };
      anim = meins;
      const warte = ms => new Promise(r => setTimeout(r, ms));
      // 1. zur ersten Stelle, an der sich etwas tut (im alten Text)
      let ia = 0; for (const o of ops) { if (o[0] !== "=") break; ia = o[1] + 1; }
      const zeileAlt = Math.min(ia, view.state.doc.lines - 1);
      const dauer = sanftZu(view.state.doc.line(zeileAlt + 1).from, true);
      if (dauer) await warte(dauer);
      // 2. was wegfällt, kurz rot und durchgestrichen -- im Code selbst; in einer fein verglichenen Zeile nur das Stück
      if (gehen.length && !abgebrochen && !opt.schonRot) {
        gehenMarkieren(gehen);
        await warte(opt.rotMs || 550);
      }
      // 3. der neue Text, mit leeren Zeilen dort, wo Neues hinkommt -- dann Zeichen für Zeichen. Eine fein verglichene
      // Zeile behält Anfang und Ende, getippt wird nur das Stück dazwischen (W6, 10.11.)
      const zeilen = neu.split("\n");
      const offen = art.map((x, j) => x === "gleich" ? null : j).filter(j => j !== null);
      const gerueste = zeilen.map((z, j) => art[j] === "gleich" ? z : fein[j] ? z.slice(0, fein[j].p) + z.slice(z.length - fein[j].s) : (z.match(/^\s*/)[0]));
      programmatisch({ changes: { from: 0, to: view.state.doc.length, insert: gerueste.join("\n") } });
      const stuecke = [];
      farben(art, weg, stuecke);
      const rest = offen.map(j => fein[j] ? [j, fein[j].neu, fein[j].p] : [j, zeilen[j].slice(gerueste[j].length), gerueste[j].length]);
      const zeichen = rest.reduce((s, r) => s + r[1].length, 0);
      const zps = Math.max(opt.zps || 30, zeichen / (opt.maxSek || 2));
      const takt = 30, jeTakt = Math.max(1, Math.round(zps * takt / 1000));
      for (const [j, text, ab] of rest) {
        if (!abgebrochen && j < view.state.doc.lines) { const d = sanftZu(view.state.doc.line(j + 1).from, true); if (d) await warte(d); }
        const st = fein[j] ? { j, von: ab, bis: ab } : null; if (st) stuecke.push(st);
        for (let k = 0; k < text.length; k += jeTakt) {
          if (abgebrochen) break;
          const pos = view.state.doc.line(j + 1).from + ab + k;
          const teil = text.slice(k, k + jeTakt);
          programmatisch({ changes: { from: pos, insert: teil } });
          if (st) st.bis = ab + k + teil.length;
          farben(art, weg, stuecke);
          await warte(takt);
        }
        if (abgebrochen) break;
      }
      if (norm(view.state.doc.toString()) !== norm(neu)) programmatisch({ changes: { from: 0, to: view.state.doc.length, insert: neu } });
      farben(art, weg, volleStuecke(fein));
      if (anim === meins) anim = null;
      fertigAuf();
    },
    // Löschen und Schreiben in zwei Drücken (Lehrer 21.10.: „die Schritte, bei denen erst was gelöscht und dann was
    // neues geschrieben wird, [gehen mir] zu schnell“): Der erste Druck markiert nur, was wegfällt, und bleibt stehen.
    hatWeg: (neu, alt) => zeilenVergleich(alt, neu).gehen.length > 0,
    async wegMarkieren(neu, alt) {
      if (anim) { anim.abbrechen(); await anim.fertig; }
      const norm = x => x.replace(/\s+$/, "");
      programmatisch(norm(view.state.doc.toString()) !== norm(alt)
        ? { changes: { from: 0, to: view.state.doc.length, insert: alt }, effects: [marken.reconfigure([]), stand.reconfigure([])] }
        : { effects: [marken.reconfigure([]), stand.reconfigure([])] });
      const { gehen } = zeilenVergleich(alt, neu);
      if (!gehen.length) return;
      sanftZu(view.state.doc.line(gehen[0].zeile + 1).from, true);
      gehenMarkieren(gehen);
    },
    // + markieren: Text (meldung W5, Lehrer 10.11.: „anzeigen, wo im Code wir hinschauen müssen … farblich markiert mit
    // Sprung zur richtigen Zeile“): jedes Vorkommen bekommt eine Marke, der Editor gleitet zum ersten. null nimmt sie weg.
    async stelleMarkieren(text) {
      if (anim) await anim.fertig;   // erst, wenn der Code steht (zurück, Kapitel: der Film setzt den Stand davor)
      if (!text) { programmatisch({ effects: stelle.reconfigure([]) }); return 0; }
      const doc = view.state.doc, s = doc.toString(), deko = [];
      for (let i = s.indexOf(text); i >= 0; i = s.indexOf(text, i + text.length)) {
        deko.push(stelleMarke.range(i, i + text.length), stelleZeile.range(doc.lineAt(i).from));
      }
      programmatisch({ effects: stelle.reconfigure(deko.length ? CM.EditorView.decorations.of(CM.Decoration.set(deko, true)) : []) });
      if (deko.length) sanftZu(deko[0].from, true);
      return deko.length / 2;
    },
    // Erster Druck eines Einfüge-Schritts: der Code steht noch auf `alt`, die Zeilen, aus denen kopiert wird, sind
    // markiert -- gesucht wird je neuer Block eine Folge alter Zeilen mit demselben Text (Einrückung egal).
    async kopieMarkieren(neu, alt) {
      if (anim) { anim.abbrechen(); await anim.fertig; }
      const norm = x => x.replace(/\s+$/, "");
      programmatisch(norm(view.state.doc.toString()) !== norm(alt)
        ? { changes: { from: 0, to: view.state.doc.length, insert: alt }, effects: [marken.reconfigure([]), stand.reconfigure([])] }
        : { effects: [marken.reconfigure([]), stand.reconfigure([])] });
      const { art } = zeilenVergleich(alt, neu);
      const b = neu.split("\n"), a = alt.split("\n").map(z => z.trim());
      const bloecke = []; art.forEach((x, j) => { if (x === "gleich") return; const l = bloecke[bloecke.length - 1]; if (l && l[l.length - 1] === j - 1) l.push(j); else bloecke.push([j]); });
      const quelle = [];
      for (const bl of bloecke) {
        const t = bl.map(j => b[j].trim());
        for (let i = 0; i + t.length <= a.length; i++) if (t.every((x, k) => a[i + k] === x)) { for (let k = 0; k < t.length; k++) quelle.push(i + k); break; }
      }
      if (!quelle.length) return 0;
      const d = view.state.doc, zeilen = [...new Set(quelle)].sort((x, y) => x - y);
      sanftZu(d.line(zeilen[0] + 1).from, true);
      programmatisch({ effects: stand.reconfigure(CM.EditorView.decorations.of(CM.Decoration.set(zeilen.map(i => kopieMarke.range(d.line(i + 1).from)), true))) });
      return zeilen.length;
    },
    laeuftAnimation: () => !!anim,
    animationFertig() { if (anim) anim.abbrechen(); },
  };
}

// Eine Arbeitsdatei im Editor: speichert verzögert, kann ausführen, aufzeichnen, zurücksetzen.
// ─── Fenster im Browser (13.11.2026, Lehrer: Vortrag A, Übung B) ──────────────────────────────────────────────
// Ein Programm, das nur zeichnet, öffnet kein echtes Fenster mehr (laufzeit/kursserver/vorne/sitecustomize.py); der
// Bericht des Laufs bringt seine Zeichenflächen mit ({titel, flaechen, bilder}). Gezeichnet wird mit demselben
// Zeichner wie das Fenster im Debugger (zeichnungSvg, aufzeichnung.js). „als Fenster öffnen“ lässt das Programm noch
// einmal laufen, diesmal mit dem echten Fenster -- für alle, die es so sehen wollen, und für Thonny-Gewohnheiten.
//
// Klickbar (16.11.2026, Durchsicht iq1 schach W10/W12/W3: „Das Feld öffnet als GUI und nicht als Fenster im Browser“):
// Ein Programm, das nur zeichnet und auf den Klick hört, läuft unsichtbar weiter; f.klickbar sagt es. Dann schickt die
// Zeichnung jeden Klick an das Programm (klicken(x, y) in den Pixeln der Zeichenfläche) und zeigt, was es danach
// gezeichnet hat. Bedient wie ein Schachbrett im Netz: Klick auf das Startfeld, Klick auf das Zielfeld -- oder ziehen:
// Der Druck ist der erste Klick, das Loslassen an einer anderen Stelle der zweite; das Bild unter dem Zeiger zieht mit.
function fensterFigur(f, onEcht, onZu, klicken) {
  let daten = f;
  const titel = f.titel && f.titel !== "tk" ? f.titel : "";
  const laeuft = f.klickbar && klicken ? h("span", { class: "fs-lauf", title: "Das Programm läuft – die Zeichnung lässt sich anklicken" }, "läuft") : null;
  // „groß“ (16.11.2026): die Zeichnung über der Seite, so hoch wie der Schirm es hergibt -- zum Spielen am Beamer;
  // derselbe Knopf oder Esc stellt sie zurück
  const grossKnopf = h("button", { type: "button", class: "ruhig fs-gross", title: "Die Zeichnung groß zeigen – Esc: zurück", onclick: () => grossSetzen(!figurGross()) }, "⤢ groß");
  const kopf = h("figcaption", {}, h("span", { class: "fs-titel" }, "Fenster" + (titel ? " · " + titel : "")), laeuft, grossKnopf,
    onEcht ? h("button", { type: "button", class: "ruhig", title: "Das Programm noch einmal laufen lassen, diesmal mit einem echten Fenster", onclick: onEcht }, "als Fenster öffnen") : null,
    onZu ? h("button", { type: "button", class: "ruhig fs-zu", title: "Die Zeichnung schließen", "aria-label": "Die Zeichnung schließen", onclick: onZu }, "×") : null);
  const bild = h("div", { class: "fs-flaeche" });
  const malen = () => { bild.innerHTML = zeichnungSvg((daten.flaechen || [])[0] || { b: 1, h: 1, dinge: [] }, daten.bilder || {}, "Die Zeichenfläche des Programms"); };
  malen();
  const figur = h("figure", { class: "fenster-bild-seite" }, kopf, bild);
  const figurGross = () => figur.classList.contains("gross");
  const beiEsc = ev => { if (ev.key === "Escape" && figurGross()) { ev.stopPropagation(); grossSetzen(false); } };
  // Groß hängt die Figur an <body>: In der Spalte des Vortrags bliebe „fixed“ an der Spalte kleben (dort gilt ein
  // eigener Rahmen). An ihrem Platz wartet eine Marke; verschwindet die (der Schritt wechselt, der Film tippt weiter),
  // geht auch die große Zeichnung.
  const heim = h("span", { class: "fs-heim", hidden: true });
  let heimWache = null;
  function grossSetzen(an) {
    if (an === figurGross()) return;
    if (an) {
      if (!figur.isConnected) return;
      figur.before(heim); document.body.append(figur);
      heimWache = setInterval(() => { if (!heim.isConnected) { clearInterval(heimWache); heimWache = null; document.removeEventListener("keydown", beiEsc, true); figur.remove(); } }, 300);
    } else {
      clearInterval(heimWache); heimWache = null;
      if (heim.isConnected) heim.replaceWith(figur); else figur.remove();
    }
    figur.classList.toggle("gross", an);
    grossKnopf.textContent = an ? "⤡ klein" : "⤢ groß";
    if (an) document.addEventListener("keydown", beiEsc, true); else document.removeEventListener("keydown", beiEsc, true);
  }
  figur.amPlatz = () => figur.isConnected && (!figurGross() || heim.isConnected);   // steht sie noch dort, wo sie hingehört?
  figur.aktualisieren = neu => { daten = neu; malen(); };
  figur.beenden = () => {};
  // Der Film klickt (+ klick: x y): ein Ring zeigt der Klasse, wohin -- an <body>, weil malen() die Fläche neu setzt
  figur.zeigeKlick = (x, y) => {
    const svg = bild.querySelector("svg"); if (!svg) return;
    const r = svg.getBoundingClientRect(), vb = svg.viewBox.baseVal;
    if (!r.width || !r.height || !vb.width || !vb.height) return;
    const ring = h("span", { class: "fs-klickring", "aria-hidden": "true" });
    ring.style.left = (r.left + x / vb.width * r.width) + "px"; ring.style.top = (r.top + y / vb.height * r.height) + "px";
    ring.style.setProperty("--fs-ring", Math.max(18, r.width / 12) + "px");
    document.body.append(ring); setTimeout(() => ring.remove(), 1400);
  };
  // eine Zeile unter der Zeichnung: was das Programm zuletzt in die Shell geschrieben hat (Übung -- dort verdeckt der
  // Reiter „Fenster“ die Shell)
  let zeileEl = null;
  figur.shellZeile = text => {
    if (!zeileEl) { zeileEl = h("div", { class: "fs-shellzeile", title: "Die letzte Zeile der Shell" }); figur.append(zeileEl); }
    zeileEl.textContent = text; zeileEl.hidden = !text;
  };
  if (!laeuft) return figur;
  figur.classList.add("klickbar");
  let unten = null, geist = null, aus = false;
  // die Stelle in den Pixeln der Zeichenfläche (das SVG ist skaliert)
  const ort = ev => {
    const svg = bild.querySelector("svg"); if (!svg) return null;
    const r = svg.getBoundingClientRect(), vb = svg.viewBox.baseVal;
    if (!r.width || !r.height) return null;
    return { x: Math.round((ev.clientX - r.left) / r.width * vb.width), y: Math.round((ev.clientY - r.top) / r.height * vb.height),
      innen: ev.clientX >= r.left && ev.clientX <= r.right && ev.clientY >= r.top && ev.clientY <= r.bottom };
  };
  const geistWeg = () => { if (geist) { geist.remove(); geist = null; } };
  bild.addEventListener("pointerdown", ev => {
    if (aus || ev.button !== 0) return;
    const p = ort(ev); if (!p || !p.innen) return;
    ev.preventDefault();
    try { bild.setPointerCapture(ev.pointerId); } catch (e) {}
    const ding = ev.target && ev.target.tagName && ev.target.tagName.toLowerCase() === "image" ? ev.target : null;
    const maß = ding ? ding.getBoundingClientRect() : null;
    unten = { cx: ev.clientX, cy: ev.clientY, bild: ding ? { href: ding.getAttribute("href"), b: maß.width, h: maß.height } : null };
    klicken(p.x, p.y);
  });
  bild.addEventListener("pointermove", ev => {
    if (!unten || !unten.bild) return;
    if (!geist && Math.hypot(ev.clientX - unten.cx, ev.clientY - unten.cy) > 6) {
      geist = h("img", { class: "fs-geist", src: unten.bild.href, alt: "" });
      geist.style.width = unten.bild.b + "px"; geist.style.height = unten.bild.h + "px";
      document.body.append(geist);
    }
    if (geist) { geist.style.left = (ev.clientX - unten.bild.b / 2) + "px"; geist.style.top = (ev.clientY - unten.bild.h / 2) + "px"; }
  });
  bild.addEventListener("pointerup", ev => {
    if (!unten) return;
    const u = unten, p = ort(ev); unten = null; geistWeg();
    if (!aus && p && p.innen && Math.hypot(ev.clientX - u.cx, ev.clientY - u.cy) > 6) klicken(p.x, p.y);
  });
  bild.addEventListener("pointercancel", () => { unten = null; geistWeg(); });
  figur.beenden = () => { aus = true; unten = null; geistWeg(); figur.classList.remove("klickbar"); figur.classList.add("beendet"); laeuft.textContent = "beendet"; laeuft.title = "Das Programm ist beendet – ▶ Ausführen startet es neu"; };
  return figur;
}

function arbeitsEditor(opts) {
  // opts: pfad (relativ zur Wurzel), thema (reihe/thema), ort (fürs Fehlerbuch: uebung, vortrag/5 …), sprache, knoepfe: [..], onGespeichert, zusatzKnoepfe
  // Python-Ordner (11.11.2026, uebung.js pythonArbeitsplatz): vorLauf (vor Ausführen und Debugger: alle Dateien des Ordners
  // speichern), ohneLauf (eine Datei, die nicht selbst läuft -- ihre Knöpfe kommen als zusatzKnoepfe und starten das
  // Programm des Ordners), fehlerZeigen(f) (die Zeile in der Datei markieren, in der sie steht), mitEingabe()
  const box = h("div", { class: "editorbox" });
  const cmEl = h("div", { class: "cm-huelle" });
  const werkzeuge = h("div", { class: "werkzeuge" });
  const status = h("span", { class: "status" }, "");
  const konsole = h("div", { class: "konsole" });
  box.append(cmEl, werkzeuge);
  let ed = null, speicherTimer = null, gespeichert = true, lauf = null;
  let fensterFig = null, fensterStand = -1, klickKette = Promise.resolve();   // das lebende, klickbare Fenster dieses Laufs
  const ich = { box, konsole, ed: null, pfad: opts.pfad };
  // Fenster im Browser: ohne opts.fensterZeigen (Übung, Lösung, Erklärung) Reiter „Shell | Fenster“ an der Stelle der
  // Shell -- eigene Tags (nav, figure), damit sich die Anker der Nadeln nicht verschieben (LM7)
  const reiterShell = h("button", { type: "button", class: "aktiv", onclick: () => reiterWahl(false) }, "Shell");
  const reiterFenster = h("button", { type: "button", onclick: () => reiterWahl(true) }, "Fenster");
  const reiterEl = h("nav", { class: "fenster-reiter", "aria-label": "Shell oder Fenster" }, reiterShell, reiterFenster);
  // Die Zeichnung steht IN der Shell (ihr Platz, ihr Höhengriff -- „so groß, wie das Paar will“); die Ausgabe wartet
  // so lange in shellTeile und kommt mit dem Reiter „Shell“ zurück
  let fensterEl = null, shellTeile = null;
  function reiterWahl(fenster) {
    if (fenster && fensterEl && !shellTeile) { shellTeile = [...konsole.childNodes]; konsole.replaceChildren(fensterEl); konsole.classList.add("zeigt-fenster"); }
    if (!fenster && shellTeile) { konsole.replaceChildren(...shellTeile); shellTeile = null; konsole.classList.remove("zeigt-fenster"); }
    reiterShell.classList.toggle("aktiv", !fenster); reiterFenster.classList.toggle("aktiv", fenster);
  }
  function fensterWeg() {
    if (fensterFig) fensterFig.entfernt = true;      // ein lebendes Fenster, das weggeräumt wird: Sein Programm endet
    if (opts.fensterZeigen) { opts.fensterZeigen(null); return; }
    reiterWahl(false); reiterEl.remove(); fensterEl = null;
  }
  // in die Shell -- auch wenn gerade der Reiter „Fenster“ vorn ist (dann wartet die Ausgabe in shellTeile)
  function inShell(...teile) { teile = teile.filter(Boolean); if (shellTeile) shellTeile.push(...teile); else konsole.append(...teile); }
  // mitFehler: Das Programm ist abgebrochen -- dann bleibt die Shell mit dem Fehlersatz vorn, die Zeichnung (bis zum
  // Fehler) wartet im Reiter daneben (ordnerseite.mjs, „Fehler in figur.py“, 13.11.)
  function fensterZeigen(f, mitFehler, klicken) {
    const echt = () => ausfuehren(undefined, true);
    if (opts.fensterZeigen) return opts.fensterZeigen(f, echt, klicken) || null;
    if (!konsole.parentElement) return null;
    fensterWeg();
    fensterEl = fensterFigur(f, echt, null, klicken);
    konsole.before(reiterEl);
    reiterWahl(!mitFehler);
    return fensterEl;
  }
  // ein Klick auf die lebende Zeichnung: der Reihe nach an das Programm (Druck und Loslassen beim Ziehen sind zwei)
  function fensterKlick(x, y) {
    const mein = lauf; if (!mein) return;
    klickKette = klickKette.then(async () => {
      if (lauf !== mein || !fensterFig) return;
      let a;
      try { a = await api("lauf/klick", { id: mein.id, x, y }); } catch (e) { return; }
      if (lauf !== mein || !fensterFig) return;
      if (a.fenster) { fensterStand = a.fenster.stand; fensterFig.aktualisieren(a.fenster); if (a.fenster.taub) fensterTaub(); }
      else if (a.haengt) schreiben("\n— der Klick ist noch nicht fertig: Läuft dahinter eine Schleife ohne Ende? ■ Stopp beendet das Programm —\n", "satz");
    });
  }
  // Auf diesem Rechner kommt der Klick nicht beim unsichtbaren Fenster an: dann das echte (wie „als Fenster öffnen“)
  let taubGemeldet = false;
  function fensterTaub() {
    if (taubGemeldet) return; taubGemeldet = true;
    ausfuehren(undefined, true).then(() => { taubGemeldet = false; });
  }
  ich.fensterWeg = fensterWeg;
  // Der Film klickt (+ klick: x y, 16.11.2026): alle = die Klicks des Films seit dem letzten „ausführen“ bis zum
  // Schritt, der gerade dran ist; die letzten `neu` davon bringt dieser Schritt. Hat der laufende Lauf genau die davor
  // schon bekommen, gehen nur die neuen hinaus; sonst startet das Programm neu und bekommt alle (die früheren zügig,
  // die neuen mit Vorlauf für den Ring). Der Reihe nach (filmKette): Wer den Präsenter zweimal schnell drückt,
  // bekommt zwei Schritte, nicht zwei Starts.
  let filmGespielt = 0, filmKette = Promise.resolve();
  ich.filmKlick = (alle, neu, eingaben) => {
    filmKette = filmKette.then(async () => {
      let offen = alle.slice(-neu);
      if (!(lauf && fensterFig && !fensterFig.entfernt && filmGespielt === alle.length - neu)) {
        const alt = lauf;
        ausfuehren(eingaben);               // endet erst mit dem Programm -- nicht abwarten
        for (let i = 0; i < 100 && !(lauf && lauf !== alt && fensterFig); i++) await schlafen(100);
        if (!(lauf && lauf !== alt && fensterFig)) return;
        offen = alle;
      }
      const mein = lauf;
      for (let i = 0; i < offen.length; i++) {
        const ruhig = i >= offen.length - neu, letzter = i === offen.length - 1;
        if (lauf !== mein || !fensterFig) return;
        if (fensterFig.zeigeKlick) fensterFig.zeigeKlick(offen[i][0], offen[i][1]);
        await schlafen(ruhig ? 450 : 120);
        if (lauf !== mein || !fensterFig) return;
        fensterKlick(offen[i][0], offen[i][1]);
        await klickKette; filmGespielt++;
        if (!letzter) await schlafen(ruhig ? 450 : 120);
      }
    }).catch(() => {});
    return filmKette;
  };
  const nachLaden = [];   // was erst geht, wenn der Editor steht (Lesezeichen im Code-Film)

  async function laden() {
    const a = await api("datei/lesen", { pfad: opts.pfad });
    ed = ich.ed = editor(cmEl, a.text, opts.sprache || "python", geaendert, opts.schreibgeschuetzt);
    for (const f of nachLaden.splice(0)) f();
    if (opts.onGeladen) opts.onGeladen(a.text);
  }
  function geaendert() {
    if (opts.fensterBeiAenderungWeg) fensterWeg();
    gespeichert = false; status.textContent = "…";
    clearTimeout(speicherTimer); speicherTimer = setTimeout(speichern, 1200);
  }
  async function speichern() {
    if (!ed || gespeichert) return;
    try { await api("datei/schreiben", { pfad: opts.pfad, text: ed.text() }); gespeichert = true; status.textContent = "gespeichert"; if (opts.onGespeichert) opts.onGespeichert(ed.text()); }
    catch (e) { status.textContent = "nicht gespeichert: " + e.message; }
  }
  function konsoleLeeren() { konsole.textContent = ""; }
  function schreiben(text, cls) { const s = h("span", { class: cls || "" }, text); inShell(s); konsole.scrollTop = 1e9; }

  // vorgabe: Eingaben, die der Code-Film sichtbar in die Eingabezeile tippt und abschickt (21.10.)
  const fehlerZeigen = opts.fehlerZeigen || (f => { if (f.zeile && ed) ed.markieren(f.zeile, "fehler"); });
  // der Fehler steht in einem anderen Modul des Ordners (figur.py): dann nennt der Satz Datei und Zeile dort
  const fehlerOrt = f => f.modul ? f.modul.datei + ", Zeile " + f.modul.zeile : (f.zeile ? "Zeile " + f.zeile : "");
  async function ausfuehren(vorgabe, echtesFenster) {
    await (opts.vorLauf ? opts.vorLauf() : speichern()); if (ed) ed.entmarkieren();
    fensterWeg();
    konsoleLeeren(); konsole.hidden = false;
    if (lauf) { try { await api("lauf/stopp", { id: lauf.id }); } catch (e) {} }
    stoppKnopf.disabled = false; startKnopf.disabled = true;
    try { lauf = await api("lauf/start", Object.assign({ pfad: opts.pfad, thema: opts.thema, ort: opts.ort || "" }, echtesFenster ? { fenster: "echt" } : {})); }
    catch (e) { lauf = null; schreiben(e.message, "fehlertext"); startKnopf.disabled = false; stoppKnopf.disabled = true; return; }
    const mein = lauf;                     // dieser Lauf -- ein neues Ausführen löst ihn ab, dann endet diese Schleife still
    fensterFig = null; fensterStand = -1; klickKette = Promise.resolve(); filmGespielt = 0;
    const eingabe = h("input", { placeholder: "Eingabe für das Programm – Enter schickt sie", onkeydown: async ev => { if (ev.key === "Enter" && lauf) { const t = eingabe.value; eingabe.value = ""; await api("lauf/eingabe", { id: lauf.id, text: t }); } } });
    const zeile = h("div", { class: "eingabezeile" }, h("span", { class: "prompt" }, "›"), eingabe);
    const ausgabe = h("span", {});
    // Das Eingabefeld nur, wenn das Programm input() benutzt oder der Film Eingaben vorgibt (Durchsicht T16, W1,
    // 26.10.: „Warum erscheint in der Shell hier eine Eingabezeile?“ -- bei einem Fenster fragt niemand nach Text)
    const mitEingabe = (opts.mitEingabe ? opts.mitEingabe() : /\binput\s*\(/.test(ed ? ed.text() : "")) || (Array.isArray(vorgabe) && vorgabe.length > 0);
    konsole.append(ausgabe);
    if (mitEingabe) konsole.append(zeile);
    if (Array.isArray(vorgabe) && vorgabe.length) (async () => {
      const meinLauf = lauf;
      for (const text of vorgabe) {
        await schlafen(700);
        if (lauf !== meinLauf || !zeile.isConnected) return;
        for (const c of text) { eingabe.value += c; await schlafen(70); }
        await schlafen(250);
        if (lauf !== meinLauf) return;
        eingabe.value = "";
        try { await api("lauf/eingabe", { id: meinLauf.id, text }); } catch (e) { return; }
      }
    })();
    let ab = 0, klicks = 0;
    while (true) {
      let b;
      if (lauf !== mein) return;           // abgelöst: Der neue Lauf schreibt in die Shell, nicht mehr dieser
      // ein lebendes Fenster, dessen Editor nicht mehr zu sehen ist (Schritt gewechselt, Reiter zu): Das Programm endet
      if (fensterFig && (fensterFig.entfernt || !box.isConnected || (opts.fensterZeigen && !fensterFig.amPlatz()))) { try { await api("lauf/stopp", { id: mein.id }); } catch (e) {} }
      try { b = await api("lauf/lesen", { id: mein.id, ab, fenster_ab: fensterStand }); } catch (e) { if (lauf !== mein) return; schreiben("\n" + e.message, "fehlertext"); break; }
      if (lauf !== mein) return;
      if (b.text) {
        ausgabe.append(b.text);
        // Endlosschleife mit print: die Shell behält nur das Ende, sonst friert die Seite ein (Messlauf 22.10.)
        if (ausgabe.textContent.length > 60000) { const t = ausgabe.textContent; ausgabe.textContent = "… (so viel Ausgabe, dass nur das Ende zu sehen ist) …\n" + t.slice(t.indexOf("\n", t.length - 30000) + 1); }
        konsole.scrollTop = 1e9;
        if (fensterFig && !opts.fensterZeigen) { const z = ausgabe.textContent.trimEnd().split("\n"); fensterFig.shellZeile(z[z.length - 1].slice(0, 120)); }
      }
      // das Fenster lebt und lässt sich anklicken: sofort zeigen, nicht erst am Ende -- und ▶ Ausführen bleibt frei
      // (ein neuer Start löst das unsichtbare Programm ab; niemand muss erst ein Fenster schließen)
      if (b.fenster && !b.fertig) {
        fensterStand = b.fenster.stand;
        if (!fensterFig) { fensterFig = fensterZeigen(b.fenster, false, fensterKlick); startKnopf.disabled = false; }
        else fensterFig.aktualisieren(b.fenster);
        if (b.fenster.taub) fensterTaub();
      }
      // Fehler in einer Knopf-Funktion (Teil III, 25.10.): Das Fenster läuft weiter, das Programm endet nicht mit
      // Fehler -- der Satz kommt deshalb sofort, je Klick, mitten in die Ausgabe
      if (b.klickfehler && b.klickfehler_zahl > klicks) {
        const neu = b.klickfehler.slice(Math.max(0, b.klickfehler.length - (b.klickfehler_zahl - klicks)));
        for (const f of neu) {
          ausgabe.append(h("span", { class: "satz klickfehler" }, "Beim Klick" + (fehlerOrt(f) ? ", " + fehlerOrt(f) : "") + ": " + f.satz));
          fehlerZeigen(f);
        }
        if (klicks === 0) { const fb = fehlerbuchHinweis(b.fehlerbuch); if (fb) ausgabe.append(fb); }
        klicks = b.klickfehler_zahl; konsole.scrollTop = 1e9;
        if (fensterFig && !opts.fensterZeigen) reiterWahl(false);   // der Fehlersatz steht in der Shell: Sie kommt nach vorn
      }
      ab = b.bis;
      if (b.fertig) {
        zeile.remove();
        if (b.fehler) {
          const f = b.fehler;
          inShell(h("span", { class: "satz" }, (fehlerOrt(f) ? fehlerOrt(f) + ": " : "") + f.satz), fehlerbuchHinweis(b.fehlerbuch));
          fehlerZeigen(f);
        } else if (b.gestoppt) inShell(h("span", { class: "satz" }, "— angehalten (" + b.gestoppt + ") —"));
        else inShell(h("span", { class: "satz" }, "— Programm beendet —"));
        if (fensterFig) fensterFig.beenden();                    // das lebende Fenster bleibt stehen, klickt aber nicht mehr
        else if (b.fenster) fensterZeigen(b.fenster, !!b.fehler);   // erst jetzt: der Schlusssatz gehört in die Shell, nicht neben das Bild
        break;
      }
      await schlafen(200);
    }
    if (lauf !== mein) return;
    lauf = null; fensterFig = null; startKnopf.disabled = false; stoppKnopf.disabled = true;
    if (opts.nachLauf) opts.nachLauf();
  }
  async function stopp() { if (lauf) await api("lauf/stopp", { id: lauf.id }); }

  const startKnopf = h("button", { class: "primaer", onclick: () => ausfuehren() }, "▶ Ausführen");
  const stoppKnopf = h("button", { class: "gefahr", onclick: stopp, disabled: true }, "■ Stopp");
  // HTML laeuft nicht (29.10.): die Vorschau zeigt jeden gespeicherten Stand -- kein Ausfuehren, kein Debugger, keine Shell
  const html = opts.sprache === "html" || opts.sprache === "text" || !!opts.ohneLauf;
  if (!html) werkzeuge.append(startKnopf, stoppKnopf);
  // Debugger (bis 17.10. „⏺ Aufzeichnen“; Lehrer 14.10.: „Was macht Aufzeichnen?“ -- der Knopf sagt es
  // selbst; 17.10.: „ich würde den Debugger auch Debugger nennen“). Nach Eingaben fragt er nur, wenn das
  // Programm input() benutzt -- Vorschlag aus EINGABEN des Themas.
  if (!opts.ohneAufzeichnung && !html) werkzeuge.append(h("button", { class: "debugger-knopf", title: "Debugger: Das Programm läuft einmal durch, und ihr geht danach Schritt für Schritt hindurch – welche Zeile als Nächstes dran ist, was in den Variablen steht und was die Shell bis dahin zeigt.", onclick: async () => {
    await (opts.vorLauf ? opts.vorLauf() : speichern());
    // ohne Dialog (24.10.): Der Debugger haelt an jedem input() an, getippt wird in seiner Shell
    aufzeichnung(ich, Object.assign({}, opts, { eingaben: () => [] }));
  } }, zeichen(KAEFER_ZEICHEN, "z-kaefer"), "Debugger"));
  for (const k of opts.zusatzKnoepfe || []) werkzeuge.append(k(ich));
  const schriftKnoepfe = (art, name) => h("span", { class: "schrift", "data-art": art }, h("span", { class: "schrift-name" }, name),
    h("button", { class: "ruhig", title: name + ": Schrift kleiner", onclick: () => schriftAendern(-1, art) }, "A−"),
    h("button", { class: "ruhig", title: name + ": Schrift größer", onclick: () => schriftAendern(1, art) }, "A+"));
  werkzeuge.append(...[schriftKnoepfe("code", "Code"), html && !opts.ohneLauf ? null : schriftKnoepfe("shell", "Shell"), status].filter(Boolean));
  ich.laden = laden; ich.speichern = speichern; ich.ausfuehren = ausfuehren; ich.konsoleLeeren = konsoleLeeren;
  // Der Code-Film startet den Debugger selbst (+ debugger, 24.10.): ohne Dialog -- Eingaben aus dem Vorschlag des Themas
  ich.debuggerStarten = async (vorgabe) => {
    if (ich._dbg && ich._dbg.offen()) return ich._dbg;
    await speichern();
    const eingaben = vorgabe || (/\binput\s*\(/.test(ich.text()) ? (opts.eingabenVorschlag || []) : []);
    return aufzeichnung(ich, Object.assign({}, opts, { eingaben: () => eingaben }));
  };
  ich.debuggerZu = () => { if (ich._dbg && ich._dbg.offen()) ich._dbg.schliessen(); };
  ich.laeuft = () => !!lauf; ich.stopp = stopp;
  ich.setzen = t => { if (ed) { ed.setzen(t); } };
  ich.standZeigen = (neu, alt) => ed ? ed.standZeigen(neu, alt) : null;
  ich.standAnimieren = (neu, alt, opt) => ed ? ed.standAnimieren(neu, alt, opt || {}) : null;
  ich.laeuftAnimation = () => !!(ed && ed.laeuftAnimation());
  ich.hatWeg = (neu, alt) => !!(ed && ed.hatWeg(neu, alt));
  ich.wegMarkieren = (neu, alt) => ed ? ed.wegMarkieren(neu, alt) : null;
  ich.kopieMarkieren = (neu, alt) => ed ? ed.kopieMarkieren(neu, alt) : null;
  ich.stelleMarkieren = text => { if (ed) ed.stelleMarkieren(text); else if (text) nachLaden.push(() => ed.stelleMarkieren(text)); };
  ich.ladenDann = f => { if (ed) f(); else nachLaden.push(f); };
  ich.animationFertig = () => { if (ed) ed.animationFertig(); };
  ich.text = () => ed ? ed.text() : "";
  return ich;
}


// Die Vorschau als Browser (Attrappe ④ B, Lehrer 29.10.2026): dieselbe Leiste wie am Tisch web der Werkstatt Netz --
// ◂ zurück, ↻, die Adresse. basis ist der Ordner auf dem Server ("/themen/<thema>/gepaecksuche/"), adresse der Name
// davor ("www.gepaeck-suche.de"); ohne Adresse steht nur der Dateiname da. Ein Link in der Seite wechselt die Adresse,
// ◂ geht den Weg zurück, den man in der Vorschau gegangen ist (neu laden legt keinen Schritt an).
// mitBaum (Werkstatt Baum, 30.10.): {quelle, editor} -- oben ein Umschalter Seite | Baum, der Baum steht an der Stelle der Seite.
function browserVorschau(basis, adresse, mitBaum) {
  const rahmen = h("iframe", { class: "vorschau", title: "Vorschau" });
  const adr = h("span", { class: "br-adresse" });
  const weg = [];
  const zurueck = h("button", { type: "button", class: "ruhig", title: "Zurück", disabled: true, onclick: () => { if (weg.length > 1) { weg.pop(); laden(weg[weg.length - 1]); } } }, "◂");
  const neu = h("button", { type: "button", class: "ruhig", title: "Neu laden", onclick: () => { if (weg.length) laden(weg[weg.length - 1]); } }, "↻");
  // A− / A+ wie an Code und Werkstatt (router W2): die Seite in der Vorschau groesser, fuer den Beamer; gemerkt im Browser
  let baum = null, baumZeigen = false, baumUhr = null, ansicht = () => {};
  const SCHRIFT = "lernraum.vorschau.schrift";
  let zoom = 1; try { zoom = +localStorage.getItem(SCHRIFT) || 1; } catch (e) {}
  function zoomen() { try { rahmen.contentDocument.documentElement.style.zoom = String(zoom); } catch (e) {} if (baum) baum.zoomen(zoom); }
  const schrift = d => { zoom = Math.max(.6, Math.min(2.6, Math.round((zoom + d) * 10) / 10)); try { localStorage.setItem(SCHRIFT, String(zoom)); } catch (e) {} zoomen(); };
  // der title der Seite als Reiter ueber der Adresszeile (station, 29.10.: sonst bleibt <title> unsichtbar); fehlt er,
  // steht es da -- Lissabon ohne Grundgeruest zeigt es
  const reiter = h("span", { class: "br-tab" });
  const box = h("div", { class: "br-vorschau" }, h("div", { class: "br-reiter" }, reiter), h("div", { class: "br-leiste" }, zurueck, neu, adr,
    h("button", { type: "button", class: "ruhig", title: "Seite kleiner", onclick: () => schrift(-.2) }, "A−"),
    h("button", { type: "button", class: "ruhig", title: "Seite größer", onclick: () => schrift(.2) }, "A+")), rahmen);
  let erstes = true;
  if (mitBaum) {
    baum = baumFlaeche(mitBaum.quelle, liste => { const e = mitBaum.editor(); if (e) e.zeilenMarken(baumZeigen ? liste : []); });
    baum.box.hidden = true; box.append(baum.box);
    const kSeite = h("button", { type: "button", class: "an", onclick: () => ansicht("seite") }, "Seite"), kBaum = h("button", { type: "button", onclick: () => ansicht("baum") }, "Baum");
    box.querySelector(".br-reiter").append(h("span", { class: "br-schalter" }, kSeite, kBaum));
    ansicht = wert => {
      baumZeigen = wert === "baum"; kSeite.classList.toggle("an", !baumZeigen); kBaum.classList.toggle("an", baumZeigen);
      rahmen.hidden = baumZeigen; baum.box.hidden = !baumZeigen; box.querySelector(".br-leiste").classList.toggle("nur-schrift", baumZeigen);
      if (!baumZeigen) baum.keiner();
      baum.zeichnen();
    };
  }
  function zeigen(datei) {
    adr.textContent = "";
    // mit Eingaben (melden?name=…) bricht die Adresse um, statt abgeschnitten zu werden (seite.css: .br-adresse.lang)
    adr.classList.toggle("lang", datei.includes("?"));
    if (adresse) adr.append(h("i", {}, "http://"), adresse + "/" + datei); else adr.append(datei);
    zurueck.disabled = weg.length < 2;
  }
  function laden(datei) {
    zeigen(datei);
    // eine abgeschickte Meldung (melden?name=…, webseite/meldung) wird so geladen, wie sie ist -- ein ?t= hinge
    // sonst als Eingabe mit an
    const url = basis + datei + (datei.includes("?") ? "" : "?t=" + Date.now());
    // replace: neu laden legt keinen Eintrag im Verlauf an (das erste Mal geht nur ueber src)
    if (erstes || !rahmen.contentWindow) { erstes = false; rahmen.src = url; } else { try { rahmen.contentWindow.location.replace(url); } catch (e) { rahmen.src = url; } }
  }
  function oeffnen(datei) { if (weg[weg.length - 1] !== datei) weg.push(datei); laden(datei); }
  rahmen.addEventListener("load", () => {
    zoomen();
    let titel = ""; try { titel = rahmen.contentDocument.title.trim(); } catch (e) {}
    reiter.textContent = titel || "ohne Titel"; reiter.classList.toggle("leer", !titel);
    let p = "", q = ""; try { p = decodeURIComponent(rahmen.contentWindow.location.pathname); q = rahmen.contentWindow.location.search; } catch (e) { return; }
    if (!p.startsWith(basis)) return;
    // ein abgeschicktes Formular (GET) zeigt seine Eingaben in der Adresse wie ein echter Browser (webseite/meldung)
    q = q.replace(/^\?t=\d+$/, "").replace(/[?&]t=\d+$/, "");
    const datei = p.slice(basis.length) + q;
    if (datei && datei !== weg[weg.length - 1]) { weg.push(datei); zeigen(datei); }   // ein Link wurde geklickt
  });
  return { box, rahmen, oeffnen, jetzt: () => weg[weg.length - 1] || "",
    ansicht: x => ansicht(x), knoten: tag => { if (baum) baum.knoten(tag); }, zeile: z => { if (baum && baumZeigen) baum.zeile(z); },
    baumNeu: () => { if (!baum) return; clearTimeout(baumUhr); baumUhr = setTimeout(() => { if (baumZeigen) baum.zeichnen(); }, 250); } };
}

// Ein Trenner über einem Element (Shell, Regie): ziehen ändert seine Höhe, der Browser merkt sie sich,
// Doppelklick setzt zurück (Lehrer 14.10.: „per Ziehen einstellen, wie viel man vom Code bzw. von der Shell sieht").
function hoehenTrenner(ziel, schluessel, beschriftung) {
  const t = h("div", { class: "trenner-quer", title: "Ziehen: Höhe ändern · Doppelklick: zurücksetzen" }, beschriftung ? h("span", {}, beschriftung) : null);
  const name = "lernraum.hoehe." + schluessel;
  let gemerkt = null; try { gemerkt = localStorage.getItem(name); } catch (e) {}
  if (gemerkt) { ziel.style.height = gemerkt; ziel.style.flex = "0 0 auto"; ziel.style.maxHeight = "none"; }
  t.addEventListener("pointerdown", ev => {
    ev.preventDefault(); t.classList.add("aktiv"); t.setPointerCapture(ev.pointerId);
    const unten = ziel.getBoundingClientRect().bottom;
    const rahmen = (ziel.parentElement || document.body).getBoundingClientRect();
    const ziehen = e => { const px = Math.max(48, Math.min(rahmen.height - 120, unten - e.clientY)); ziel.style.height = px + "px"; ziel.style.flex = "0 0 auto"; ziel.style.maxHeight = "none"; };
    const ende = () => { t.classList.remove("aktiv"); t.removeEventListener("pointermove", ziehen); t.removeEventListener("pointerup", ende); try { localStorage.setItem(name, ziel.style.height); } catch (e) {} };
    t.addEventListener("pointermove", ziehen); t.addEventListener("pointerup", ende);
  });
  t.addEventListener("dblclick", () => { ziel.style.height = ""; ziel.style.flex = ""; ziel.style.maxHeight = ""; try { localStorage.removeItem(name); } catch (e) {} });
  return t;
}

// Ein senkrechter Trenner zwischen zwei Spalten eines Rasters (24.10.: Vortrag Editor | Text, Debugger Code | Variablen):
// ziehen setzt die Breite der linken Spalte als CSS-Variable am Raster, der Browser merkt sie sich; Doppelklick: zurueck.
function spaltenTrenner(raster, schluessel, variable) {
  const t = h("div", { class: "trenner spalte", title: "Ziehen: Breite ändern · Doppelklick: zurücksetzen" });
  const name = "lernraum.teilung." + schluessel;
  let gemerkt = null; try { gemerkt = localStorage.getItem(name); } catch (e) {}
  if (gemerkt) raster.style.setProperty(variable, gemerkt);
  t.addEventListener("pointerdown", ev => {
    ev.preventDefault(); t.classList.add("aktiv"); t.setPointerCapture(ev.pointerId);
    const links = raster.getBoundingClientRect().left;
    const ziehen = e => { const px = Math.max(200, Math.min(raster.clientWidth - 220, e.clientX - links)); raster.style.setProperty(variable, px + "px"); };
    const ende = () => { t.classList.remove("aktiv"); t.removeEventListener("pointermove", ziehen); t.removeEventListener("pointerup", ende); try { localStorage.setItem(name, raster.style.getPropertyValue(variable)); } catch (e) {} };
    t.addEventListener("pointermove", ziehen); t.addEventListener("pointerup", ende);
  });
  t.addEventListener("dblclick", () => { raster.style.removeProperty(variable); try { localStorage.removeItem(name); } catch (e) {} });
  return t;
}
// Ein Griff unter einem Bereich: ziehen setzt dessen Hoehe als CSS-Variable (Debugger in der Uebung, 24.10.)
function hoehenGriff(el, schluessel, variable, beschriftung) {
  const t = h("div", { class: "trenner-quer", title: "Ziehen: Höhe ändern · Doppelklick: zurücksetzen" }, beschriftung ? h("span", {}, beschriftung) : null);
  const name = "lernraum.hoehe." + schluessel;
  let gemerkt = null; try { gemerkt = localStorage.getItem(name); } catch (e) {}
  if (gemerkt) el.style.setProperty(variable, gemerkt);
  t.addEventListener("pointerdown", ev => {
    ev.preventDefault(); t.classList.add("aktiv"); t.setPointerCapture(ev.pointerId);
    const oben = el.getBoundingClientRect().top;
    const ziehen = e => { el.style.setProperty(variable, Math.max(120, e.clientY - oben - 40) + "px"); };
    const ende = () => { t.classList.remove("aktiv"); t.removeEventListener("pointermove", ziehen); t.removeEventListener("pointerup", ende); try { localStorage.setItem(name, el.style.getPropertyValue(variable)); } catch (e) {} };
    t.addEventListener("pointermove", ziehen); t.addEventListener("pointerup", ende);
  });
  t.addEventListener("dblclick", () => { el.style.removeProperty(variable); try { localStorage.removeItem(name); } catch (e) {} });
  return t;
}

// Kopieren-Knopf an jedem Codeblock (Lehrer 14.10.: per Copy-Paste einfügen statt abtippen).
function kopierKnoepfe(el) {
  el.querySelectorAll("pre.code").forEach(pre => {
    if (pre.parentElement.classList.contains("code-huelle") || pre.closest(".pruef, .stufen")) return;   // Frage und Stufen-Beispiel: nichts zu kopieren (Stufe 3 schreibt man selbst)
    const huelle = h("div", { class: "code-huelle" }); pre.replaceWith(huelle); huelle.append(pre);
    const knopf = h("button", { class: "kopieren ruhig", title: "Code kopieren – dann im Editor mit Strg+V (Mac: ⌘+V) einfügen", onclick: async ev => {
      ev.stopPropagation();
      const text = pre.textContent;
      try { await navigator.clipboard.writeText(text); }
      catch (e) { const ta = h("textarea", {}); ta.value = text; document.body.append(ta); ta.select(); try { document.execCommand("copy"); } catch (e2) {} ta.remove(); }
      knopf.textContent = "✓ kopiert"; setTimeout(() => { knopf.textContent = "Kopieren"; }, 1500);
    } }, "Kopieren");
    huelle.append(knopf);
  });
}
