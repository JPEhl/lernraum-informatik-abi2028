/* Lernraum · ichkann.js -- „Ich kann …“: das Kompetenzraster der Reihe zum Selbsteinschätzen
   (Seite, Karte in „Üben und Nachschlagen“, Zählung der Klasse in der Übersicht).
   Teil der Arbeitsseite; alle Teile teilen einen Namensraum und laden in der
   Reihenfolge von index.html (kein Bündler, CSP 'self'). */
"use strict";
// ─── „Ich kann …“ (Galerie 15.10., Rang 11 + 12; Lehrer 16.10.) ──────────────────────────
// Vier Smileys wie auf den Reihenblättern (noch nicht · ansatzweise · meistens · sicher), drei Runden
// wie die drei Spalten auf Papier (Mitte der Reihe · Ende der Reihe · vor der Klausur). Eingetragen
// werden kann jederzeit; den Anlass gibt der Lehrer im Unterricht. Die Klasse sieht einen Satz erst,
// wenn sie in einem seiner Themen etwas getan hat (Lehrer 16.10.: „würdest du Dinge, die erst später
// kommen, überhaupt einblenden? Das verwirrt irgendwie nur“ -- bis dahin standen sie grau da); sonst
// zählte die Übersicht auch lauter „noch nicht“, die nichts sagen. Das Pult zeigt alle Sätze.
// Die Übersicht zählt ohne Namen (Lehrer: „anonym“), nie in der Jahresübersicht.
const IK_STUFEN = ["noch nicht", "ansatzweise", "meistens", "sicher"];
const IK_RUNDEN = ["Mitte der Reihe", "Ende der Reihe", "vor der Klausur"];
const IK_MUND = ["M11.3 23.6 Q17 18.4 22.7 23.6", "M11.5 22 L22.5 22", "M11.3 20.4 Q17 25.6 22.7 20.4", "M10.4 19.2 Q17 28.6 23.6 19.2 Z"];
function smiley(stufe) {
  return zeichen('<svg viewBox="0 0 34 34" aria-hidden="true"><circle class="sg" cx="17" cy="17" r="14.6"/><circle class="sa" cx="12.6" cy="13.4" r="1.8"/><circle class="sa" cx="21.4" cy="13.4" r="1.8"/><path class="sm" d="' + IK_MUND[stufe - 1] + '"/></svg>', "smiley s" + stufe);
}
// ─── Wie lief das Kapitel? (P6, 24.11.2026) ─────────────────────────────────────────────────────────────────────
// Statt des Feedbackbogens auf Papier (Lehrer in der iq2-Sitzung: „Brauchen wir überhaupt Feedbackbögen? Es gibt ja die
// Möglichkeit, Nadeln zu setzen“ -> „ja, merk es so vor“): Was der Bogen fragt, hat „Ich kann …“ schon -- es fehlte nur
// das Urteil über den Ablauf. In der Runde „Ende der Reihe“, je Kapitel, ohne Namen gezählt.
const ABLAUF_SAETZE = [
  "Die Geschichte, die sich durch das Kapitel zieht, hat mir geholfen, den Überblick zu behalten.",
  "Die Fragen und Abstimmungen im Vortrag haben mir beim Verstehen geholfen.",
  "Die Hilfen und der Selbstcheck haben mir beim Üben geholfen.",
];
const ABLAUF_STUFEN = ["stimmt nicht", "eher nicht", "eher ja", "stimmt"];
const ABLAUF_FRAGE = "Was am Ablauf sollte bleiben – und was nicht?";
function ablaufBlock(r) {
  const e = () => ((Z.stand || {}).ablauf || {})[r.kennung] || {};
  const box = h("div", { class: "ik-ablauf" }, h("h3", {}, "Wie lief das Kapitel?"),
    h("p", { class: "leer" }, Z.lehrer ? "So fragt die Runde „Ende der Reihe“ nach dem Ablauf – gezählt wird ohne Namen in der Übersicht."
      : "Dein Lehrer sieht nur, wie viele was angekreuzt haben, und die Texte ohne Namen."),
    h("p", { class: "ik-legende" }, ABLAUF_STUFEN.map((w, i) => h("span", {}, smiley(i + 1), w))));
  ABLAUF_SAETZE.forEach((satz, i) => {
    const f = String(i + 1), jetzt = +(e()[f] || 0), wahl = h("div", { class: "ik-wahl", role: "radiogroup", "aria-label": satz });
    const zeile = h("div", { class: "ik-satz" + (jetzt ? " gewaehlt" : ""), "data-ablauf": f }, h("div", { class: "ik-text" }, satz),
      h("div", { class: "ik-rechts" }, wahl, h("div", { class: "ik-wort" }, jetzt ? ABLAUF_STUFEN[jetzt - 1] : "")));
    for (let s = 1; s <= 4; s++) {
      const knopf = h("button", { class: "ik-knopf" + (jetzt === s ? " an" : ""), role: "radio", "aria-checked": String(jetzt === s), title: ABLAUF_STUFEN[s - 1], "aria-label": ABLAUF_STUFEN[s - 1] }, smiley(s));
      if (Z.lehrer) knopf.disabled = true;
      else knopf.onclick = async () => {
        try { const a = await api("stand/ablauf", { reihe: r.kennung, frage: i + 1, wert: jetzt === s ? 0 : s }); ((Z.stand.ablauf = Z.stand.ablauf || {}))[r.kennung] = a.eintrag; box.replaceWith(ablaufBlock(r)); }
        catch (x) { meldung(x.message, "fehler"); }
      };
      wahl.append(knopf);
    }
    box.append(zeile);
  });
  const feld = h("textarea", { class: "ik-ablauf-text", rows: "3", maxlength: "600", placeholder: Z.lehrer ? "" : "in ein, zwei Sätzen", "aria-label": ABLAUF_FRAGE });
  feld.value = e().text || ""; if (Z.lehrer) feld.disabled = true;
  const status = h("span", { class: "leer" });
  let uhr = null;
  const sichern = async () => { try { const a = await api("stand/ablauf", { reihe: r.kennung, frage: "text", wert: feld.value }); ((Z.stand.ablauf = Z.stand.ablauf || {}))[r.kennung] = a.eintrag; status.textContent = "gespeichert"; } catch (x) { status.textContent = x.message; } };
  feld.addEventListener("input", () => { status.textContent = "…"; clearTimeout(uhr); uhr = setTimeout(sichern, 800); });
  feld.addEventListener("blur", () => { if (uhr) { clearTimeout(uhr); uhr = null; sichern(); } });
  box.append(h("label", { class: "ik-ablauf-frage" }, ABLAUF_FRAGE, feld), status);
  return box;
}

function rasterReihen() { return ((Z.inhalt && Z.inhalt.reihen) || []).filter(r => (r.raster || []).length); }
// Hat die Person in diesem Thema schon etwas getan? (irgendein Eintrag im Stand, der zum Thema gehört)
function themaBegonnen(pfad) {
  const s = Z.stand || {}, vor = pfad + "/";
  if (["aufgaben", "fragen", "stufen", "puzzles", "faelle", "vorhersagen", "plaene", "diagramme", "klausuren", "terme"].some(t => Object.keys(s[t] || {}).some(k => k.startsWith(vor)))) return true;
  const ts = (s.themen || {})[pfad];
  return !!(ts && ts.selbstcheck) || !!(s.kennwoerter || {})[pfad];
}
function satzOffen(r, satz) { return Z.lehrer || satz.themen.some(t => themaBegonnen(r.kennung + "/" + t)); }
function einschaetzung(r, satz) { return ((Z.stand || {}).einschaetzung || {})[r.kennung + "/" + satz.kennung] || {}; }
// Welche Runde die Seite aufschlägt: die späteste, in der schon etwas steht -- sonst die erste.
// Die nächste wählt die Person selbst, wenn der Lehrer sie ansagt (sonst stünde nach dem Ausfüllen
// der Mitte gleich „Ende der Reihe“ leer da und lüde zum Vorgreifen ein).
function rundeVorschlag(r) {
  let n = 1;
  for (const g of r.raster) for (const s of g.saetze) for (const [k, w] of Object.entries(einschaetzung(r, s))) if (w && w.stufe && +k > n) n = +k;
  return n;
}

async function ichKannSeite(haupt) {
  kopfZeichnen([["Ich kann …", adr("ichkann")]]);
  try { const a = await api("inhalt"); Z.stand = a.stand; } catch (e) {}
  const s = h("div", { class: "seite ichkann" }, h("h1", {}, "Ich kann …"),
    h("p", { class: "unter" }, Z.lehrer ? "So sieht die Klasse ihre Selbsteinschätzung. Einschätzen kann man nur in der Schülerfassung; die Zählung ohne Namen steht in der Übersicht."
      : "Schätz dich ehrlich ein. Dein Lehrer sieht nur, wie viele sich wo sehen – nicht, wer."),
    h("p", { class: "ik-legende" }, IK_STUFEN.map((w, i) => h("span", {}, smiley(i + 1), w))));
  const reihen = rasterReihen();
  if (!reihen.length) s.append(h("p", { class: "leer" }, "Für diesen Kurs gibt es noch kein Kompetenzraster."));
  for (const r of reihen) s.append(rasterKarte(r));
  haupt.append(s);
}

function rasterKarte(r) {
  let runde = rundeVorschlag(r);
  const reiter = h("div", { class: "ik-runden", role: "tablist" }), liste = h("div", { class: "ik-liste" });
  function zeigen() {
    reiter.textContent = "";
    IK_RUNDEN.forEach((n, i) => reiter.append(h("button", { class: "ik-runde" + (runde === i + 1 ? " aktiv" : ""), role: "tab", "aria-selected": String(runde === i + 1), onclick: () => { runde = i + 1; zeigen(); } }, n)));
    liste.textContent = "";
    let spaeter = 0;
    for (const g of r.raster) {
      const offen = g.saetze.filter(satz => satzOffen(r, satz));
      spaeter += g.saetze.length - offen.length;
      if (!offen.length) continue;
      if (g.titel) liste.append(h("h3", {}, g.titel));
      for (const satz of offen) liste.append(satzZeile(r, satz, runde));
    }
    if (spaeter) liste.append(h("p", { class: "leer ik-spaeter" }, spaeter + (spaeter === 1 ? " weiterer Satz kommt" : " weitere Sätze kommen") + " mit den nächsten Themen."));
    if (runde === 2) liste.append(ablaufBlock(r));          // Wie lief das Kapitel? -- nur in „Ende der Reihe“ (P6)
  }
  zeigen();
  return h("section", { class: "ik-karte" }, h("h2", {}, "Kapitel " + r.nr + " · " + r.titel), reiter,
    h("p", { class: "leer ik-runde-text" }, "Wann eine Runde dran ist, sagt dein Lehrer im Unterricht. Ändern kannst du sie jederzeit."), liste);
}

function satzZeile(r, satz, runde) {
  const k = r.kennung + "/" + satz.kennung, e = einschaetzung(r, satz);   // nur offene Sätze kommen hierher
  const jetzt = (e[runde] || {}).stufe || 0;
  const themen = satz.themen.map(t => thema(r.kennung, t)).filter(Boolean);
  const ueben = themen.length
    ? h("div", { class: "ik-ueben" }, "üben: ", themen.flatMap((T, i) => [i ? " · " : "", h("a", { href: adr("t/" + T.pfad + "/uebung") }, "Thema " + themaNr(T.pfad, T.thema.nr) + " " + T.thema.titel)]))
    : h("div", { class: "ik-ueben" }, "kommt in einem späteren Thema");      // nur im Pult zu sehen
  // die anderen Runden klein daneben: so sieht man, was sich bewegt hat
  const frueher = h("div", { class: "ik-frueher" });
  for (let i = 1; i <= 3; i++) { const w = (e[i] || {}).stufe; if (i !== runde && w) frueher.append(h("span", {}, IK_RUNDEN[i - 1] + ": ", smiley(w), IK_STUFEN[w - 1])); }
  const wahl = h("div", { class: "ik-wahl", role: "radiogroup", "aria-label": IK_RUNDEN[runde - 1] });
  const zeile = h("div", { class: "ik-satz" + (jetzt ? " gewaehlt" : ""), "data-satz": k },
    h("div", { class: "ik-text" }, h("div", { html: satz.html }), ueben, frueher.childNodes.length ? frueher : null),
    h("div", { class: "ik-rechts" }, wahl, h("div", { class: "ik-wort" }, jetzt ? IK_STUFEN[jetzt - 1] : "")));
  for (let i = 1; i <= 4; i++) {
    const knopf = h("button", { class: "ik-knopf" + (jetzt === i ? " an" : ""), role: "radio", "aria-checked": String(jetzt === i), title: IK_STUFEN[i - 1], "aria-label": IK_STUFEN[i - 1], "data-stufe": String(i) }, smiley(i));
    if (Z.lehrer) knopf.disabled = true;
    else knopf.onclick = async () => {
      const neu = jetzt === i ? 0 : i;      // noch einmal tippen nimmt sie zurück
      try {
        const a = await api("stand/einschaetzung", { kennung: k, runde, stufe: neu });
        (Z.stand.einschaetzung = Z.stand.einschaetzung || {})[k] = a.eintrag;
        zeile.replaceWith(satzZeile(r, satz, runde));
      } catch (x) { meldung(x.message, "fehler"); }
    };
    wahl.append(knopf);
  }
  return zeile;
}

// Die Karte im Bereich „Üben und Nachschlagen“ -- erst, wenn ein Satz einschätzbar ist (Regel 4).
function ichKannKarte() {
  const reihen = rasterReihen(); if (!reihen.length) return null;
  let offen = 0, eingeschaetzt = 0;
  for (const r of reihen) { const n = rundeVorschlag(r); for (const g of r.raster) for (const s of g.saetze) if (satzOffen(r, s)) { offen++; if ((einschaetzung(r, s)[n] || {}).stufe) eingeschaetzt++; } }
  if (!offen) return null;
  const n = rundeVorschlag(reihen[0]);
  return h("a", { class: "nachschlagkarte", href: adr("ichkann") }, h("div", { class: "nr" }, "Ich kann …"),
    h("div", { class: "titel" }, Z.lehrer ? "Selbsteinschätzung" : eingeschaetzt + " von " + offen + " Sätzen eingeschätzt"),
    h("div", {}, Z.lehrer ? "das Kompetenzraster der Reihe, vier Smileys, drei Runden" : IK_RUNDEN[n - 1] + " · noch nicht · ansatzweise · meistens · sicher"));
}

// ─── Übersicht: der Ablauf ohne Namen (P6) ───────────────────────────────────────────────────────────────────────
function ablaufKlasse(daten) {
  const box = h("div", { class: "ik-klasse ik-ablauf-klasse" }, h("h3", {}, "Wie lief das Kapitel? (ohne Namen)"),
    h("p", { class: "leer" }, "Aus den Abgaben – je Person ihre neueste. Statt des Feedbackbogens auf Papier."),
    h("p", { class: "ik-legende" }, ABLAUF_STUFEN.map((w, i) => h("span", {}, smiley(i + 1), w))));
  for (const r of daten) {
    box.append(h("h4", {}, r.titel + " · " + r.personen + (r.personen === 1 ? " Person" : " Personen")));
    ABLAUF_SAETZE.forEach((satz, i) => {
      const n = r.fragen[String(i + 1)] || [0, 0, 0, 0], summe = n.reduce((a, b) => a + b, 0);
      const leiste = h("span", { class: "ik-leiste", title: n.map((x, j) => x + " " + ABLAUF_STUFEN[j]).join(" · ") });
      n.forEach((x, j) => { if (x) { const t = h("span", { class: "s" + (j + 1) }); t.style.flexGrow = String(x); leiste.append(t); } });
      box.append(h("div", { class: "ik-zaehlung", "data-ablauf": String(i + 1) }, h("div", { class: "ik-text" }, satz),
        h("div", { class: "ik-balken" }, h("div", { class: "ik-balkenzeile" }, leiste, h("span", { class: "ik-zahlen", title: summe + " Personen" }, n.join(" · "))))));
    });
    if (r.texte.length) box.append(h("div", { class: "ik-ablauf-texte" }, h("div", { class: "ik-gruppe" }, ABLAUF_FRAGE), h("ul", {}, r.texte.map(t => h("li", {}, t)))));
  }
  return box;
}

// ─── Übersicht: die Klasse ohne Namen (Rang 12) ──────────────────────────────────────────
function einschaetzungKlasse(daten) {
  const box = h("div", { class: "ik-klasse" }, h("h3", {}, "Selbsteinschätzung der Klasse (ohne Namen)"),
    h("p", { class: "leer" }, "„Ich kann …“ aus den Abgaben – je Person ihre neueste. Wer sich wo sieht, steht hier nicht; in der Jahresübersicht steht es nie."),
    h("p", { class: "ik-legende" }, IK_STUFEN.map((w, i) => h("span", {}, smiley(i + 1), w))));
  for (const r of daten) {
    if (daten.length > 1) box.append(h("h4", {}, r.titel));
    let gruppe = null;
    for (const s of r.saetze) {
      if (s.gruppe !== gruppe) { gruppe = s.gruppe; if (gruppe) box.append(h("div", { class: "ik-gruppe" }, gruppe)); }
      const zeile = h("div", { class: "ik-zaehlung", "data-satz": s.kennung }, h("div", { class: "ik-text", html: s.html }));
      const balken = h("div", { class: "ik-balken" });
      for (const runde of ["1", "2", "3"]) {
        const n = s.runden[runde]; if (!n) continue;
        const summe = n.reduce((a, b) => a + b, 0);
        const b = h("div", { class: "ik-balkenzeile" }, h("span", { class: "ik-rn" }, IK_RUNDEN[+runde - 1]));
        const leiste = h("span", { class: "ik-leiste", title: n.map((x, i) => x + " " + IK_STUFEN[i]).join(" · ") });
        n.forEach((x, i) => { if (x) { const t = h("span", { class: "s" + (i + 1) }); t.style.flexGrow = String(x); leiste.append(t); } });
        b.append(leiste, h("span", { class: "ik-zahlen", title: summe + " Personen" }, n.join(" · ")));
        balken.append(b);
      }
      zeile.append(balken); box.append(zeile);
      // passt der Selbstcheck dazu? (Galerie: „grün eingeschätzt, aber Selbstcheck offen“)
      const sehen = n => n + (n === 1 ? " sieht sich" : " sehen sich") + " hier „meistens“ oder „sicher“, " + (n === 1 ? "hat" : "haben");
      for (const p of s.passt_nicht) {
        if (p.ohne_ziel) box.append(h("p", { class: "ik-passt-nicht" }, "⚑ " + sehen(p.ohne_ziel) + " in Thema " + p.nr + " das Ziel aber nicht erreicht."));
        if (p.ohne_abgabe) box.append(h("p", { class: "ik-passt-nicht" }, "⚑ " + sehen(p.ohne_abgabe) + " Thema " + p.nr + " aber nicht abgegeben."));
      }
    }
  }
  return box;
}
