// Werkstatt "Daten" -- die Fall-Datenbank des Kapitels iq2 `fall` im Lernraum (18.11.2026). Uebertragen aus der
// Datenwerkstatt des LaTeX-Bestands (werkstatt/_scripts/datenwerkstatt/: sql.js, kern.js, Fall-Generator); sie ist die
// Stelle, an der die Klasse SQL tippt (Lehrer 18.11.: „im Browser“). Lehrerwahl im Drehbuch `tabellen` aus drei
// Attrappen (fall/planung/drehbuch_tabellen/bilder/werkstatt_A|B|C): Fassung C „mit dem Plan daneben“ -- links die
// Tabellen als kleiner Plan, ein Pfeil von jedem ↑PersNr zu Einwohner; rechts der Tisch. Der Plan zeigt die Idee des
// ersten Themas, bevor sie gesagt wird: Alles verweist auf eine Stelle. Er waechst nicht.
// Tische (LT9: ein Tisch erscheint erst mit seinem Thema):
//   tabellen -- tabellen: blaettern. Je Tabelle der Steckbrief in Abiturnotation (Schluessel unterstrichen, ↑ fremd),
//               der Auszug (zehn Zeilen, wie auf Papier) oder die ganze Tabelle (je 100 Zeilen, Klick auf eine Spalte
//               sortiert). tabellen="Aussage|Einwohner" zeigt diese Auszuege untereinander, ohne Umschalten.
//   sql      -- tabellen: eine fertige Abfrage (```sql im Schritt, im Reiter abfrage=) ausfuehren und lesen; getippt
//               wird erst mit tippen="ja" (ab `select`). Ergebnis mit Zeilenzahl und Dauer, Meldungen des DBMS auf
//               Deutsch (aus kern.js), ein vergessenes ON wird bei 100 000 Zeilen abgebrochen.
//   relalg   -- streichen (19.11.2026, Lehrerwahl Fassung B „Streichen und abdecken“, Attrappen
//               fall/planung/attrappen_relalg/): ein Term (```relalg im Schritt, im Reiter term=) arbeitet sichtbar am
//               Auszug vom Papier -- Schritt ▶ von innen nach aussen, σ streicht Zeilen (rote Linie), π deckt Spalten ab
//               (Schraffur), was π doppelt macht, steht grau. „alle …“ rechnet auf der ganzen Tabelle und zeigt das
//               Zwischenergebnis. Wer erst abdeckt und dann streicht, sieht Schritt 1 und am Schritt 2 die Meldung.
//               Gerechnet wird mit relalg.js der Datenwerkstatt (bauen.py legt es ohne export bei): ein Term mit ⋈ oder
//               × steht als OPERATORBAUM da (aneinander, 19.11.2026, Lehrerwahl im Drehbuch, Form aus der Datenwerkstatt
//               vom 12.10.): Tabellen unten, Wurzel oben, Schritt ▶ von innen nach aussen, spaetere Knoten blass und ohne
//               Zahl, Antippen zeigt das Zwischenergebnis; σ/π auf einer Tabelle bekommt ihn mit baum="ja" als Schalter.
//               Getippt wird mit tippen="ja"; die Zeichenknoepfe ⋈ × erst mit verbund="ja" (ab `aneinander`, LT9).
//   schritte -- lesen (22.11.2026, Lehrerwahl B „Eine Tabelle, die schrumpft“, Attrappen fall/planung/drehbuch_lesen/):
//               eine SQL-Anweisung (```sql im Schritt, im Reiter abfrage=) Schritt fuer Schritt, wie das DBMS sie liest;
//               Einzelheiten am Tisch unten. Ohne Plan, er braucht die Breite.
// Geladen wird erst beim ersten Oeffnen: daten/sql-wasm.js, daten/sql-wasm.wasm (sql.js, MIT, daten/LICENSE),
// daten/fall.sqlite, daten/auszug.json -- bauen.py legt sie bei, nur in Kurse, die die Werkstatt benutzen. WebAssembly
// braucht in der CSP 'wasm-unsafe-eval' (Seite und Kursserver); JavaScript bleibt strikt 'self'.
// Einbinden: Werkstaetten.daten(element, {tisch: "sql", abfrage: "SELECT …"}) -> { film: {spielen, herstellen, laeuft}, zustand }
// Film (bauen.py, WERKSTATT_FILM): + ausführen · + abfrage: SELECT … · + tabelle: Einwohner · + auszug · + ganz · + markiere: 2215 · + neu · + halt
//   relalg: + term: π[…](…) (rechnet, zeigt Schritt 0) · + schritt · + zurück · + ausführen (alle Schritte) · + ganz · + auszug
//           · + baum (σ/π als Operatorbaum; bei ⋈ und × steht er ohnehin)
//   schritte: + schritt · + zurück · + ausführen (bis ans Ende) · + ganz · + auszug · + abfrage: SELECT … · + satz: … (der
//           Satz „Eine Zeile ist: …“; der naechste Schritt nimmt ihn weg) · + markiere: Reuter
window.Werkstaetten = window.Werkstaetten || {};
window.Werkstaetten.daten = function (wurzel, opt) {
  opt = opt || {};
  const W = window.Werkstaetten.daten;
  const GRENZE_ZEIGEN = 200, GRENZE_ZAEHLEN = 100000, JE_SEITE = 100;
  const h = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
  const zahl = n => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
  const esc = s => String(s).replace(/[&<>"]/g, z => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[z]));
  const liste = x => String(x || "").split("|").map(s => s.trim()).filter(Boolean);

  const TISCHE = { tabellen: "Tabellen", sql: "Abfrage", relalg: "Relationenalgebra", "term-sql": "Term ↔ SQL", schritte: "Schritte" };
  let tische = liste(opt.tische || opt.tisch).filter(t => TISCHE[t]);
  if (!tische.length) tische = ["tabellen"];
  const fest = liste(opt.tabellen);            // tabellen="Aussage|Einwohner": diese Auszuege untereinander
  // `basis: ganz` im Kopf der Uebung (zaehlen, 23.11.2026): die Tische beginnen mit allen Zeilen -- der Auszug Funkzelle laesst
  // die Verdaechtigen absichtlich weg (Akte, kein Verraten), eine Abfrage nach ihrem Handy liefe dort ins Leere
  const BASIS = opt.basis === "ganz" ? "ganz" : "auszug";
  const START = { tisch: tische[0], tabelle: opt.tabelle || fest[0] || "Einwohner", modus: BASIS, seite: 0, sort: [], ergebnis: null, fehler: null, markiert: null,
    raSchritt: 0, rabasis: BASIS, tsbasis: BASIS, schSchritt: 0, schbasis: BASIS, satz: "" };
  let z = Object.assign({}, START, { sort: [] });
  let db = null, auszug = null, steckbriefe = [], generation = 0, adb = null;
  const mitRa = ["relalg", "term-sql", "schritte"].some(t => tische.includes(t));   // sie rechnen am Auszug als zweiter Datenbank

  wurzel.textContent = "";
  wurzel.classList.add("daten-ws");
  const reiter = h("div", "tische");
  const raster = h("div", "raster");
  const planEl = h("figure", "plan");
  const tischEl = h("div", "tisch");
  raster.append(planEl, tischEl);
  // Lange Texte (die Aussagen) stehen gekuerzt -- sonst sprengt eine Zeile den Auszug; ein Klick zeigt den ganzen Text
  tischEl.addEventListener("click", ev => { const td = ev.target.closest("td.kurz"); if (td) { td.textContent = td.dataset.voll; td.classList.remove("kurz"); } });
  wurzel.append(reiter, raster);
  tische.forEach(t => {
    const b = h("button", "", TISCHE[t]); b.type = "button";
    b.addEventListener("click", () => { z.tisch = t; zeichne(); });
    b.dataset.tisch = t; reiter.append(b);
  });
  reiter.hidden = tische.length < 2;

  // ── Laden (einmal je Seite, alle Werkstaetten teilen die Datenbank; Abfragen lesen nur) ──────────────────────
  function laden() {
    if (W._laden) return W._laden;
    const basis = W.basis || "/_system/seite/werkstatt/daten/";
    W._laden = new Promise((ok, nein) => {
      const fertig = () => window.initSqlJs({ locateFile: f => basis + f })
        .then(SQL => Promise.all([fetch(basis + "fall.sqlite").then(r => { if (!r.ok) throw new Error("fall.sqlite: " + r.status); return r.arrayBuffer(); }),
          fetch(basis + "auszug.json").then(r => r.ok ? r.json() : {})])
          .then(([bytes, a]) => ok({ db: new SQL.Database(new Uint8Array(bytes)), auszug: a, SQL })))
        .catch(nein);
      if (window.initSqlJs) return fertig();
      const s = document.createElement("script"); s.src = basis + "sql-wasm.js";
      s.onload = fertig; s.onerror = () => nein(new Error("sql-wasm.js fehlt"));
      document.head.append(s);
    });
    return W._laden;
  }
  // relalg.js (Tisch relalg) -- einmal je Seite, nur wenn ein Tisch es braucht; ein gewoehnliches Skript (bauen.py
  // nimmt die export heraus), seine Namen beginnen mit ra/RA
  function raLaden() {
    if (W._raLaden) return W._raLaden;
    const basis = W.basis || "/_system/seite/werkstatt/daten/";
    W._raLaden = typeof raLesen === "function" ? Promise.resolve() : new Promise((ok, nein) => {
      const s = document.createElement("script"); s.src = basis + "relalg.js";
      s.onload = () => ok(); s.onerror = () => nein(new Error("relalg.js fehlt"));
      document.head.append(s);
    });
    return W._raLaden;
  }

  // ── Kern (aus werkstatt/_scripts/datenwerkstatt/kern.js) ─────────────────────────────────────────────────────
  const q = sql => { const r = db.exec(sql); return r.length ? r[0].values : []; };
  function steckbrief(name) {
    const t = '"' + name.replace(/"/g, '""') + '"';
    const fremd = {}; q("PRAGMA foreign_key_list(" + t + ")").forEach(f => { fremd[f[3]] = f[2]; });
    return { name, zeilen: q("SELECT COUNT(*) FROM " + t)[0][0],
      spalten: q("PRAGMA table_info(" + t + ")").map(s => ({ name: s[1], schluessel: s[5] > 0, fremd: fremd[s[1]] || null })) };
  }
  function ausfuehren(sql, basisDb) {
    let erg = null;
    for (const st of (basisDb || db).iterateStatements(sql)) {
      const spalten = st.getColumnNames();
      if (!spalten.length) { st.free(); throw new Error("Diese Werkstatt liest nur: Eine Abfrage beginnt mit SELECT."); }
      const zeilen = []; let anzahl = 0;
      while (st.step()) { if (zeilen.length < GRENZE_ZEIGEN) zeilen.push(st.get()); anzahl++; if (anzahl >= GRENZE_ZAEHLEN) break; }
      st.free();
      erg = { spalten, zeilen, anzahl, mehr: anzahl >= GRENZE_ZAEHLEN };
    }
    return erg || { spalten: [], zeilen: [], anzahl: 0, mehr: false };
  }
  function abstand(a, b) {
    a = a.toLowerCase(); b = b.toLowerCase();
    const d = Array.from({ length: a.length + 1 }, (_, i) => [i]);
    for (let j = 1; j <= b.length; j++) d[0][j] = j;
    for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    return d[a.length][b.length];
  }
  function aehnlich(wort, kandidaten) {
    let best = null, bestd = 99;
    for (const k of kandidaten) { const d = abstand(wort, k); if (d < bestd) { best = k; bestd = d; } }
    return bestd <= Math.max(2, Math.floor(wort.length / 3)) ? best : null;
  }
  const WOERTER = ["SELECT", "FROM", "WHERE", "AND", "OR", "NOT", "LIKE", "BETWEEN", "ORDER", "BY", "GROUP", "HAVING", "JOIN", "ON", "AS", "DISTINCT",
    "COUNT", "SUM", "AVG", "MIN", "MAX", "ASC", "DESC", "IN", "IS", "NULL", "INNER", "NATURAL"];
  // {titel, text} -- text mit <code>, aus der Meldung des DBMS; nennt die Stelle, nie die Loesung
  function fehlerDeuten(meldung, sql) {
    const tabs = steckbriefe.map(s => s.name);
    const spalten = [...new Set(steckbriefe.flatMap(s => s.spalten.map(x => x.name)))];
    const c = w => "<code>" + esc(w) + "</code>";
    let m;
    if ((m = /no such table: (?:main\.)?(\S+)/.exec(meldung))) {
      const v = aehnlich(m[1], tabs);
      return { titel: "Diese Tabelle gibt es nicht", text: "Eine Tabelle " + c(m[1]) + " kennt die Datenbank nicht." + (v ? " Meint ihr " + c(v) + "?" : "") + " Vorhanden: " + tabs.map(c).join(", ") + "." };
    }
    if ((m = /no such column: (\S+)/.exec(meldung))) {
      const w = m[1], kurz = w.includes(".") ? w.split(".").pop() : w, v = aehnlich(kurz, spalten);
      const wertstelle = !w.includes(".") && new RegExp("(=|<>|!=|<|>|\\bLIKE|\\bIN\\s*\\(|,)\\s*" + w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "\\b", "i").test(sql);
      if (v && v !== kurz && !wertstelle) return { titel: "Diese Spalte gibt es nicht", text: "Eine Spalte " + c(w) + " gibt es nicht. Meint ihr " + c(v) + "? Der Plan links zeigt alle Spalten." };
      if (w.includes(".")) return { titel: "Diese Spalte gibt es nicht", text: c(w) + " gibt es nicht. Steht die Tabelle vor dem Punkt auch im FROM, und hat sie diese Spalte?" };
      return { titel: "Spalte oder Text?", text: "Eine Spalte " + c(w) + " gibt es nicht. Ist " + c(w) + " ein <b>Wert</b>, also ein Text wie in der Tabelle? Dann gehört er in einfache Anführungszeichen: " + c("'" + w + "'") + "." };
    }
    if ((m = /ambiguous column name: (\S+)/.exec(meldung))) {
      const w = m[1];
      const da = steckbriefe.filter(s => s.spalten.some(x => x.name === w) && new RegExp("\\b" + s.name + "\\b", "i").test(sql)).map(s => s.name);
      return { titel: "Welche Spalte ist gemeint?", text: c(w) + " gibt es in mehreren Tabellen der Abfrage. Schreibt den Tabellennamen davor: " + (da.length ? da.map(t => c(t + "." + w)).join(" oder ") : c("Tabelle." + w)) + "." };
    }
    if (/unrecognized token: "'/.test(meldung)) return { titel: "Anführungszeichen nicht geschlossen", text: "Ein Text ist mit <code>'</code> geöffnet, aber nicht wieder geschlossen. Jeder Text braucht zwei Anführungszeichen: <code>'rot'</code>." };
    if (/incomplete input/.test(meldung)) return { titel: "Die Abfrage ist unvollständig", text: "Die Abfrage hört mitten drin auf. Fehlt am Ende noch etwas, zum Beispiel ein Wert nach <code>=</code> oder eine Klammer?" };
    if ((m = /near "([^"]*)": syntax error/.exec(meldung))) {
      const w = m[1], v = aehnlich(w.toUpperCase(), WOERTER);
      let tipp = "";
      if (v && v !== w.toUpperCase()) tipp = " Ist " + c(w) + " vielleicht ein vertipptes " + c(v) + "?";
      else if (/^FROM$/i.test(w) && /,\s*FROM/i.test(sql)) tipp = " Steht vor <code>FROM</code> ein Komma zu viel?";
      else if (/^WHERE$/i.test(w) && !/\bFROM\b/i.test(sql)) tipp = " Fehlt vor <code>WHERE</code> noch <code>FROM</code> und eine Tabelle?";
      return { titel: "Hier stimmt die Schreibweise nicht", text: "Die Datenbank versteht die Abfrage kurz vor " + c(w) + " nicht mehr." + tipp };
    }
    if (/misuse of aggregate/.test(meldung)) return { titel: "Zählen und Rechnen an der falschen Stelle", text: "Eine Funktion wie <code>COUNT</code> oder <code>SUM</code> darf nicht im <code>WHERE</code> stehen. Bedingungen an das Gezählte gehören hinter <code>GROUP BY</code> in <code>HAVING</code>." };
    if (/liest nur/.test(meldung)) return { titel: "Nur lesen", text: esc(meldung) };
    return { titel: "Das DBMS meldet einen Fehler", text: "Lest die Meldung unten und prüft die Abfrage Wort für Wort." };
  }

  // ── Der Plan (Fassung C): verwiesene Tabellen links, die anderen rechts; Pfeil von ↑Spalte zum Schluessel ──────
  // Breit: verwiesene Tabellen links, die anderen rechts untereinander. Schmal (Uebung rechts, unter 720 px): die
  // verwiesene oben, die anderen in einer Reihe darunter -- sonst schrumpft die Schrift auf ein Drittel.
  let planQuer = null;
  function planZeichnen() {
    const quer = wurzel.clientWidth > 0 && wurzel.clientWidth < 720;
    planQuer = quer;
    const ziele = new Set(), wer = {};
    steckbriefe.forEach(s => s.spalten.forEach(x => { if (x.fremd) ziele.add(x.fremd); }));
    const links = steckbriefe.filter(s => ziele.has(s.name)), rechts = steckbriefe.filter(s => !ziele.has(s.name));
    const B = 118, KOPF = 24, ZEILE = 18, LUFT = 12;
    const hoehe = s => KOPF + s.spalten.length * ZEILE + 8;
    const summe = arr => arr.reduce((a, s) => a + hoehe(s), 0) + Math.max(0, arr.length - 1) * LUFT;
    let BREIT, H;
    if (quer) {
      BREIT = Math.max(links.length, rechts.length) * (B + LUFT) + 12 - LUFT;
      const oben = Math.max(0, ...links.map(hoehe)), unten = Math.max(0, ...rechts.map(hoehe)), ABST = 46;
      H = 6 + oben + ABST + unten + 6;
      const reihe = (arr, y) => { let x = (BREIT - arr.length * (B + LUFT) + LUFT) / 2; arr.forEach(s => { wer[s.name] = { x, y, s }; x += B + LUFT; }); };
      reihe(links, 6); reihe(rechts, 6 + oben + ABST);
    } else {
      const XL = 4, XR = 166; BREIT = XR + B + 4;
      H = Math.max(summe(links), summe(rechts)) + 12;
      const setze = (arr, x) => { let y = (H - summe(arr)) / 2; arr.forEach(s => { wer[s.name] = { x, y, s }; y += hoehe(s) + LUFT; }); };
      setze(links, XL); setze(rechts, XR);
    }
    const id = "dpfeil" + (W._nr = (W._nr || 0) + 1);
    let svg = '<svg viewBox="0 0 ' + BREIT + " " + H + '" role="img" aria-label="Die Tabellen der Datenbank und ihre Verweise">' +
      '<defs><marker id="' + id + '" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" class="spitze"/></marker></defs>';
    const pfeile = [], anZiel = {};
    steckbriefe.forEach(s => s.spalten.forEach((x, i) => { if (x.fremd && wer[x.fremd] && wer[s.name]) anZiel[x.fremd] = (anZiel[x.fremd] || 0) + 1; }));
    const schon = {};
    steckbriefe.forEach(s => s.spalten.forEach((x, i) => {
      if (!x.fremd || !wer[x.fremd] || !wer[s.name]) return;
      const von = wer[s.name], nach = wer[x.fremd], ni = nach.s.spalten.findIndex(c => c.schluessel);
      const y1 = von.y + KOPF + i * ZEILE + ZEILE / 2 + 2, x1 = von.x;
      if (quer) {
        // von der Oberkante hinauf an den Boden der Zieltabelle, je Pfeil eine eigene Stelle (seitlich heraus kreuzten
        // die Pfeile die Nachbarkaesten); welche Zeile verweist, sagt das ↑
        const k = schon[x.fremd] = (schon[x.fremd] || 0) + 1, n = anZiel[x.fremd];
        const x2 = nach.x + B * k / (n + 1), y2 = nach.y + hoehe(nach.s), xa = von.x + B / 2, ya = von.y;
        pfeile.push('<path class="verweis" data-von="' + esc(s.name) + '" data-nach="' + esc(x.fremd) + '" d="M' + xa + "," + ya + " C" + xa + "," + (ya - 22) + " " + x2 + "," + (y2 + 22) + " " + x2 + "," + (y2 + 2) + '" marker-end="url(#' + id + ')"/>');
      } else {
        const y2 = nach.y + KOPF + Math.max(0, ni) * ZEILE + ZEILE / 2 + 2, x2 = nach.x + B;
        pfeile.push('<path class="verweis" data-von="' + esc(s.name) + '" data-nach="' + esc(x.fremd) + '" d="M' + x1 + "," + y1 + " C" + (x1 - 34) + "," + y1 + " " + (x2 + 30) + "," + y2 + " " + (x2 + 2) + "," + y2 + '" marker-end="url(#' + id + ')"/>');
      }
    }));
    svg += pfeile.join("");
    Object.values(wer).forEach(({ x, y, s }) => {
      svg += '<g class="tab" data-tabelle="' + esc(s.name) + '" tabindex="0"><rect x="' + x + '" y="' + y + '" width="' + B + '" height="' + hoehe(s) + '" rx="8"/>' +
        '<text class="name" x="' + (x + 8) + '" y="' + (y + 17) + '">' + esc(s.name) + "</text>";
      s.spalten.forEach((c, i) => {
        svg += '<text class="spalte' + (c.schluessel ? " schluessel" : "") + '" x="' + (x + 8) + '" y="' + (y + KOPF + (i + 1) * ZEILE - 3) + '">' + (c.fremd ? "↑" : "") + esc(c.name) + "</text>";
      });
      svg += "</g>";
    });
    svg += "</svg>";
    planEl.innerHTML = svg;
    planEl.append(h("figcaption", "", "↑ verweist auf die Spalte mit demselben Namen in der Tabelle, auf die der Pfeil zeigt."));
    planEl.querySelectorAll(".tab").forEach(g => {
      const wahl = () => { z.tabelle = g.dataset.tabelle; z.modus = "auszug"; z.seite = 0; z.sort = []; if (tische.includes("tabellen") && !fest.length) z.tisch = "tabellen"; zeichne(); };
      g.addEventListener("click", wahl);
      g.addEventListener("keydown", ev => { if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); wahl(); } });
    });
  }
  // Der Plan als Wegweiser (Lehrerwahl A, 20.11.2026, nach der Durchsicht `aneinander`: „Eigentlich gehe ich beim
  // Erstellen von Abfragen immer gerne vom ER-Diagramm her, um zu spotten, welche Tabellen ich brauche“): Steht im Tisch
  // relalg ein Term, leuchten seine Tabellen und bei ⋈ der Pfeil, über den verbunden wird; was er nicht braucht, wird
  // blass. × leuchtet keinen Pfeil -- es verbindet nicht über den Verweis.
  function raWeg(termText) {
    if (termText == null) { if (!R || R.fehler || !R.term) return null; termText = R.term; }
    let baum; try { baum = raLesen(termText); } catch (e) { return null; }
    const echt = n => (steckbriefe.find(s => s.name.toLowerCase() === String(n).toLowerCase()) || {}).name || n;
    const tabs = new Set(), kanten = new Set();
    const lauf = b => {
      if (b.art === "tab") { const n = echt(b.name); tabs.add(n); return [n]; }
      if (b.art === "sel" || b.art === "proj") return lauf(b.kind);
      const l = lauf(b.l), r = lauf(b.r);
      if (b.art === "join") l.forEach(a => r.forEach(c => { kanten.add(a + "|" + c); kanten.add(c + "|" + a); }));
      return l.concat(r);
    };
    lauf(baum);
    return { tabs, kanten };
  }
  // Im Tisch sql (select, 20.11.2026) leuchten nach dem Ausführen die Tabellen, die die Anweisung nennt; im Tisch
  // term-sql die des Terms und der Anweisung. Seit `join` (20.11.2026, Drehbuch, Nebenfrage 1) auch der Pfeil -- aber
  // nur, wenn die Anweisung ihn benutzt: eine Bedingung `A.X = B.X` über den Verweis (in WHERE oder ON) oder ein
  // NATURAL JOIN, in dem beide Tabellen stehen. `FROM A, B` ohne Bedingung lässt ihn blass -- die Datenbank weiß nicht,
  // was zusammengehört (das Kreuzprodukt). Texte in '…' werden vorher entfernt, damit kein Wert als Tabelle zählt.
  function sqlWeg(text) {
    const ohne = String(text || "").replace(/'(?:[^']|'')*'/g, "''");
    const tabs = new Set(steckbriefe.map(s => s.name).filter(n => new RegExp("\\b" + n + "\\b", "i").test(ohne)));
    if (!tabs.size) return null;
    const kanten = new Set(), klein = x => String(x).toLowerCase(), natural = /\bNATURAL\s+JOIN\b/i.test(ohne);
    const gleich = [...ohne.matchAll(/\b(\w+)\s*\.\s*(\w+)\s*=\s*(\w+)\s*\.\s*(\w+)/g)].map(m => [klein(m[1]), klein(m[2]), klein(m[3]), klein(m[4])]);
    steckbriefe.forEach(s => s.spalten.forEach(c => {
      if (!c.fremd || !tabs.has(s.name) || !tabs.has(c.fremd)) return;
      const ziel = steckbriefe.find(t => t.name === c.fremd), schl = ziel && (ziel.spalten.find(x => x.schluessel) || {}).name;
      const a = klein(s.name), b = klein(c.fremd), x = klein(c.name), y = klein(schl || c.name);
      const benutzt = natural || gleich.some(([t1, s1, t2, s2]) => (t1 === a && s1 === x && t2 === b && s2 === y) || (t1 === b && s1 === y && t2 === a && s2 === x));
      if (benutzt) { kanten.add(s.name + "|" + c.fremd); kanten.add(c.fremd + "|" + s.name); }
    }));
    return { tabs, kanten };
  }
  // Der Wegweiser in der Übung erst nach einem eigenen Lauf (Reihensichtung iq2 Teil I, 23.11.2026): Lädt `term:` einen Term
  // vor, leuchteten beim Öffnen sofort seine Tabellen (aneinander: Fahrzeug, Einwohner) -- neben der Frage „Welche Tabellen
  // haben einen Fremdschlüssel?“ lenkte das auf die falsche Antwort. In der Übung und im Reiter (ort: "uebung", uebung.js)
  // steht der Plan deshalb voll da, bis die Klasse selbst rechnet (Schritt ▶, Ergebnis, Strg+Enter, ein Knoten, Ausführen);
  // im Vortrag leuchtet er sofort, dort ist der Wegweiser gewollt.
  let wegFrei = opt.ort !== "uebung";
  function planMarkieren() {
    let weg = null;
    if (!wegFrei) weg = null;
    else if (z.tisch === "relalg") weg = raWeg();
    else if (z.tisch === "sql" && z.ergebnis) weg = sqlWeg(abfrageEl.value);
    else if (z.tisch === "term-sql" && TS) { weg = raWeg(TS.term) || { tabs: new Set(), kanten: new Set() }; const s = sqlWeg(tsFeld.value); if (s) { s.tabs.forEach(n => weg.tabs.add(n)); s.kanten.forEach(k => weg.kanten.add(k)); } }
    const an = weg ? [...weg.tabs] : z.tisch === "tabellen" ? (fest.length ? fest : [z.tabelle]) : [];
    planEl.querySelectorAll(".tab").forEach(g => { g.classList.toggle("an", an.includes(g.dataset.tabelle)); g.classList.toggle("blass", !!weg && !an.includes(g.dataset.tabelle)); });
    planEl.querySelectorAll(".verweis").forEach(v => {
      const lit = !!weg && weg.kanten.has(v.dataset.von + "|" + v.dataset.nach);
      v.classList.toggle("an", lit); v.classList.toggle("blass", !!weg && !lit);
    });
  }

  // ── Tabellen zeichnen ───────────────────────────────────────────────────────────────────────────────────────
  function steckbriefHtml(s) {
    return '<span class="tname">' + esc(s.name) + "</span>(" + s.spalten.map(c => (c.fremd ? "↑" : "") + (c.schluessel ? "<u>" + esc(c.name) + "</u>" : esc(c.name))).join(", ") + ")";
  }
  function tabelleHtml(spalten, zeilen, opts) {
    opts = opts || {};
    const sb = opts.steckbrief;
    // markiere: nach der ersten Spalte; steht der Wert dort nirgends, in irgendeiner (join, 22.11.: 1180 ist die zweite)
    const inErster = z.markiert != null && zeilen.some(r => String(r[0]) === String(z.markiert));
    let t = "<table><thead><tr>" + spalten.map((s, i) => {
      const c = sb ? sb.spalten[i] : null;
      const text = (c && c.fremd ? "↑" : "") + (c && c.schluessel ? "<u>" + esc(s) + "</u>" : esc(s));
      const so = opts.sortierbar ? z.sort.find(x => x.i === i) : null;
      return "<th" + (opts.sortierbar ? ' data-i="' + i + '" title="nach dieser Spalte sortieren"' : "") + ">" + text + (so ? (so.ab ? " ▼" : " ▲") : "") + "</th>";
    }).join("") + "</tr></thead><tbody>";
    zeilen.forEach(r => {
      const mark = z.markiert != null && (inErster ? String(r[0]) === String(z.markiert) : r.some(w => String(w) === String(z.markiert)));
      t += "<tr" + (mark ? ' class="markiert"' : "") + ">" + r.map(w => w === null ? '<td class="null" title="kein Wert"></td>' : (String(w).length > 56 ? '<td class="lang kurz" title="Klick: ganzer Text" data-voll="' + esc(w) + '">' + esc(String(w).slice(0, 52).replace(/\s+\S*$/, "")) + " …</td>" : "<td" + (String(w).length > 30 ? ' class="lang"' : "") + ">" + esc(w) + "</td>")).join("") + "</tr>";
    });
    return t + "</tbody></table>";
  }
  function auszugVon(name) { return (auszug && auszug[name]) || []; }
  function tischTabellen() {
    tischEl.textContent = "";
    if (fest.length) {
      fest.forEach(n => {
        const s = steckbriefe.find(x => x.name === n); if (!s) return;
        const k = h("section", "karte-tab");
        const kopf = h("div", "kopf"); kopf.innerHTML = '<span class="steckbrief">' + steckbriefHtml(s) + '</span><span class="zahl">Auszug · ' + auszugVon(n).length + " von " + zahl(s.zeilen) + " Zeilen</span>";
        const box = h("div", "rahmen"); box.innerHTML = tabelleHtml(s.spalten.map(c => c.name), auszugVon(n), { steckbrief: s });
        k.append(kopf, box); tischEl.append(k);
      });
      return;
    }
    const s = steckbriefe.find(x => x.name === z.tabelle) || steckbriefe[0];
    if (!s) return;
    z.tabelle = s.name;
    const kopf = h("div", "kopf");
    const sbEl = h("span", "steckbrief"); sbEl.innerHTML = steckbriefHtml(s);
    const wahl = h("div", "dw-modus");
    const kA = h("button", z.modus === "auszug" ? "an" : "", "Auszug · " + auszugVon(s.name).length + " Zeilen"); kA.type = "button";
    const kG = h("button", z.modus === "ganz" ? "an" : "", "ganze Tabelle · " + zahl(s.zeilen) + " Zeilen"); kG.type = "button";
    kA.addEventListener("click", () => { z.modus = "auszug"; zeichne(); });
    kG.addEventListener("click", () => { z.modus = "ganz"; z.seite = 0; zeichne(); });
    wahl.append(kA, kG);
    kopf.append(sbEl, wahl);
    const box = h("div", "rahmen");
    tischEl.append(kopf, box);
    if (z.modus === "auszug") {
      box.innerHTML = tabelleHtml(s.spalten.map(c => c.name), auszugVon(s.name), { steckbrief: s });
      return;
    }
    // ganze Tabelle: je 100 Zeilen; Klick auf eine Spalte sortiert (der vorige Klick bleibt die zweite Ordnung)
    const t = '"' + s.name.replace(/"/g, '""') + '"';
    const ord = z.sort.length ? z.sort.map(x => '"' + s.spalten[x.i].name + '"' + (x.ab ? " DESC" : "")).join(", ") : "rowid";
    const zeilen = q("SELECT * FROM " + t + " ORDER BY " + ord + " LIMIT " + JE_SEITE + " OFFSET " + z.seite * JE_SEITE);
    box.innerHTML = tabelleHtml(s.spalten.map(c => c.name), zeilen, { steckbrief: s, sortierbar: true });
    box.querySelectorAll("th[data-i]").forEach(th => th.addEventListener("click", () => {
      const i = +th.dataset.i, war = z.sort.find(x => x.i === i);
      z.sort = [{ i, ab: war && z.sort[0] === war ? !war.ab : false }].concat(z.sort.filter(x => x.i !== i)).slice(0, 2);
      z.seite = 0; zeichne();
    }));
    const seiten = Math.ceil(s.zeilen / JE_SEITE);
    const blaettern = h("div", "blaettern");
    const zur = h("button", "ruhig", "◀"); zur.type = "button"; zur.disabled = z.seite === 0;
    const vor = h("button", "ruhig", "▶"); vor.type = "button"; vor.disabled = z.seite >= seiten - 1;
    zur.addEventListener("click", () => { z.seite--; zeichne(); });
    vor.addEventListener("click", () => { z.seite++; zeichne(); });
    blaettern.append(zur, h("span", "", "Zeilen " + zahl(z.seite * JE_SEITE + 1) + "–" + zahl(Math.min(s.zeilen, (z.seite + 1) * JE_SEITE)) + " von " + zahl(s.zeilen)), vor);
    tischEl.append(blaettern);
  }

  const abfrageEl = h("textarea", "abfrage");
  abfrageEl.spellcheck = false; abfrageEl.rows = 3;
  abfrageEl.setAttribute("autocapitalize", "off"); abfrageEl.setAttribute("autocomplete", "off");
  // SQL schön gesetzt (Durchsicht select W1, 20.11.2026: „Ich fände es wichtig, wenn die SQL-Anweisungen schön formatiert
  // wären, d.h. z.B. dass ORDER BY in einer neuen Zeile steht“): jede Klausel auf eine eigene Zeile -- FROM, WHERE,
  // GROUP BY, HAVING, ORDER BY, JOIN. Eine Anweisung, die schon umbricht, bleibt, wie sie ist. Gilt für fertige
  // Anweisungen, Filmzeilen (+ abfrage: steht in der Quelle einzeilig) und das, was die Übung vorlädt.
  // Seit join (20.11.2026, die Regel sagt es seit select, getan hat es keiner): Ist eine Zeile mit WHERE, HAVING oder JOIN
  // länger als SQL_BREITE Zeichen, kommt jedes AND auf der obersten Ebene eingerückt auf eine neue Zeile -- nicht das AND
  // von BETWEEN … AND …, keins in '…' oder in Klammern. Zwilling: sql_schoen() in stand_wand.py (die Wand).
  // Eine zu lange JOIN-Zeile bricht vor ON um (ON eingerückt darunter, wie in den Erklärungen), danach gilt für die
  // ON-Zeile dieselbe AND-Regel.
  const SQL_BREITE = 48;
  function sqlOnZeile(zeile) {
    if (zeile.length <= SQL_BREITE || !/^(?:INNER\s+|NATURAL\s+|LEFT\s+|CROSS\s+)?JOIN\b/i.test(zeile)) return zeile;
    return zeile.replace(/\s+(?=ON\b)/i, "\n  ");
  }
  function sqlUndZeilen(zeile, breite = SQL_BREITE) {
    if (zeile.length <= breite || !/^\s*(?:WHERE|HAVING|ON|(?:INNER\s+|NATURAL\s+|LEFT\s+|CROSS\s+)?JOIN)\b/i.test(zeile)) return zeile;
    let aus = "", tiefe = 0, text = false, zwischen = false;
    for (let i = 0; i < zeile.length; i++) {
      const c = zeile[i];
      if (c === "'") text = !text;
      else if (!text && c === "(") tiefe++;
      else if (!text && c === ")") tiefe--;
      if (!text && tiefe === 0 && /\s/.test(c)) {
        const wort = ((/^(\w+)/.exec(zeile.slice(i + 1)) || [])[1] || "").toUpperCase();
        if (wort === "BETWEEN") zwischen = true;
        else if (wort === "AND") { if (zwischen) zwischen = false; else { aus = aus.replace(/\s+$/, "") + "\n  "; continue; } }
      }
      if (!(c === " " && aus.endsWith("\n  "))) aus += c;
    }
    return aus;
  }
  // Seit gruppieren (23.11.2026): eine zu lange SELECT-Zeile bricht nach jedem Komma der obersten Ebene um, die Teile
  // unter dem ersten (auf der Wand brach „AS zuletzt“ sonst mitten in der Zeile). Zwilling: _select_zeile() in stand_wand.py.
  function sqlSelectZeile(zeile) {
    if (zeile.length <= SQL_BREITE || !/^SELECT\b/i.test(zeile)) return zeile;
    let aus = "", tiefe = 0, text = false;
    for (let i = 0; i < zeile.length; i++) {
      const c = zeile[i];
      if (c === "'") text = !text;
      else if (!text && c === "(") tiefe++;
      else if (!text && c === ")") tiefe--;
      if (!text && !tiefe && c === ",") { aus += ",\n       "; while (zeile[i + 1] === " ") i++; continue; }
      aus += c;
    }
    return aus;
  }
  function sqlSchoen(s) {
    const x = String(s || "").trim();
    if (/\n/.test(x)) return x;
    return x.replace(/(?<!\b(?:INNER|NATURAL|LEFT|CROSS))\s+(?=(?:FROM|WHERE|GROUP\s+BY|HAVING|ORDER\s+BY|(?:INNER\s+|NATURAL\s+|LEFT\s+|CROSS\s+)?JOIN)\b)/gi, "\n")
      .split("\n").map(sqlSelectZeile).join("\n").split("\n").map(sqlOnZeile).join("\n").split("\n").map(sqlUndZeilen).join("\n");
  }
  // Was in die gemessene Breite nicht passt, bricht an einer Stelle, an der man liest (Reihensichtung iq2 fall Teil II,
  // 24.11.2026, Befund 8: im Vortrag stand „ON Fahrzeug.PersNr =“ / „Einwohner.PersNr“ ohne Einzug, im Tisch Term ↔ SQL
  // „WHERE Farbe =“ / „'rot' AND Typ =“): die SELECT-Liste nach einem Komma, eine WHERE-, HAVING- oder ON-Zeile vor
  // jedem AND, ein Vergleich nach dem = -- eingerückt unter den ersten Teil. Nur für fertige Anweisungen im Vortrag; was
  // die Klasse tippt, bleibt, wie sie es tippt.
  function sqlEinpassen(text, spalten) {
    const aus = [];
    const oben = (z, f) => { let tiefe = 0, txt = false; for (let i = 0; i < z.length; i++) { const c = z[i];
      if (c === "'") txt = !txt; else if (!txt && c === "(") tiefe++; else if (!txt && c === ")") tiefe--;
      else if (!txt && !tiefe && f(z, i)) return i; } return -1; };
    const passen = z => {
      if (z.length <= spalten) { aus.push(z); return; }
      const vorne = /^\s*/.exec(z)[0];
      if (/^\s*SELECT\b/i.test(z)) {
        const teile = []; let rest = z;
        for (let k = oben(rest, (x, i) => x[i] === ","); k >= 0; k = oben(rest, (x, i) => x[i] === ",")) { teile.push(rest.slice(0, k + 1)); rest = rest.slice(k + 1).trim(); }
        teile.push(rest);
        let zeile = teile[0];
        teile.slice(1).forEach(t => { if (zeile.length + 1 + t.length <= spalten) zeile += " " + t; else { aus.push(zeile); zeile = vorne + "       " + t; } });
        aus.push(zeile); return;
      }
      if (/^\s*(?:INNER\s+|NATURAL\s+|LEFT\s+|CROSS\s+)?JOIN\b.*\bON\b/i.test(z)) { z.trim().replace(/\s+(?=ON\b)/i, "\n  ").split("\n").forEach(t => passen(vorne + t)); return; }
      if (/^\s*(?:WHERE|HAVING|ON)\b/i.test(z) && oben(z, (x, i) => /\s/.test(x[i]) && /^AND\b/i.test(x.slice(i + 1))) >= 0) {
        const geteilt = sqlUndZeilen(z.trim(), 0).split("\n");
        if (geteilt.length > 1) { geteilt.forEach(t => passen(vorne + t)); return; }
      }
      const gl = oben(z, (x, i) => x[i] === "=" && x[i - 1] === " " && x[i + 1] === " ");
      const wort = /^\s*(?:ON|AND|WHERE|HAVING|OR)\s+/i.exec(z);
      if (gl > 0 && wort) { aus.push(z.slice(0, gl + 1)); aus.push(" ".repeat(wort[0].length) + z.slice(gl + 1).trim()); return; }
      aus.push(z);
    };
    String(text || "").split("\n").forEach(passen);
    return aus.join("\n");
  }
  // Zeichen je Zeile im Element (Monoschrift): Innenbreite durch die Breite eines Zeichens; 0, wenn es nicht im Bild ist
  let zeichenMass = null;
  function spaltenVon(el) {
    if (!el || !el.isConnected || !el.clientWidth) return 0;
    const st = getComputedStyle(el);
    zeichenMass = zeichenMass || document.createElement("canvas").getContext("2d");
    zeichenMass.font = st.fontStyle + " " + st.fontWeight + " " + st.fontSize + " " + st.fontFamily;
    const b = zeichenMass.measureText("MMMMMMMMMM").width / 10;
    const innen = el.clientWidth - parseFloat(st.paddingLeft || 0) - parseFloat(st.paddingRight || 0);
    return b > 0 ? Math.floor(innen / b) : 0;
  }
  abfrageEl.value = sqlSchoen(opt.abfrage);
  const getippt = String(opt.tippen || "") === "ja";
  abfrageEl.readOnly = !getippt;
  abfrageEl.addEventListener("keydown", ev => { if (ev.key === "Enter" && (ev.ctrlKey || ev.metaKey)) { ev.preventDefault(); abfrage(); } });
  // die fertige Anweisung in die Breite des Felds -- neu bei jeder Breite und Schriftgröße (A−/A+, groß, Trenner)
  function abfrageEinpassen() {
    const sp = spaltenVon(abfrageEl); if (!sp) return;
    if (abfrageEl.value !== abfrageEl._eingepasst) abfrageEl._roh = abfrageEl.value;
    const neu = sqlEinpassen(abfrageEl._roh, sp);
    abfrageEl._eingepasst = neu;
    if (abfrageEl.value !== neu) abfrageEl.value = neu;
    const n = Math.max(1, neu.split("\n").length); if (abfrageEl.rows !== n) abfrageEl.rows = n;
  }
  if (!getippt && window.ResizeObserver) new ResizeObserver(() => { if (abfrageEl.isConnected) abfrageEinpassen(); }).observe(abfrageEl);
  function tischSql() {
    tischEl.textContent = "";
    const feld = h("div", "abfrage-feld" + (getippt ? "" : " fest"));
    const los = h("button", "primaer", "▶ Ausführen"); los.type = "button";
    los.addEventListener("click", abfrage);
    abfrageEl.rows = Math.max(getippt ? 3 : 1, abfrageEl.value.split("\n").length);
    feld.append(abfrageEl, h("div", "leiste", null));
    feld.lastChild.append(los, h("small", "", getippt ? "Strg+Enter führt aus" : "eine fertige Abfrage – ausführen und lesen"));
    tischEl.append(feld);
    if (!getippt) abfrageEinpassen();
    const hoehe = () => { abfrageEl.style.height = "auto"; abfrageEl.style.height = abfrageEl.scrollHeight + "px"; };
    requestAnimationFrame(hoehe);
    if (!abfrageEl._hoehe) { abfrageEl._hoehe = true; abfrageEl.addEventListener("input", hoehe); }
    const erg = h("div", "ergebnis");
    if (z.fehler) {
      erg.classList.add("fehler");
      erg.innerHTML = "<b>" + esc(z.fehler.titel) + "</b><p>" + z.fehler.text + "</p><details><summary>Meldung des DBMS</summary><pre>" + esc(z.fehler.original) + "</pre></details>";
    } else if (z.ergebnis) {
      const e = z.ergebnis;
      const kopf = h("div", "kopf");
      kopf.append(h("span", "zahl", (e.mehr ? "über " : "") + zahl(e.anzahl) + (e.anzahl === 1 ? " Zeile" : " Zeilen")),
        h("span", "dauer", "in " + e.dauer.toFixed(3).replace(".", ",") + " Sekunden"));
      const box = h("div", "rahmen"); box.innerHTML = tabelleHtml(e.spalten, e.zeilen);
      erg.append(kopf, box);
      if (e.mehr) erg.append(h("p", "warnung", "Abgebrochen nach " + zahl(GRENZE_ZAEHLEN) + " Zeilen – so viele kann niemand lesen. Steht jede Tabelle mit einer Bedingung verbunden da?"));
      else if (e.anzahl > e.zeilen.length) erg.append(h("p", "hinweis", "Gezeigt sind die ersten " + zahl(e.zeilen.length) + "."));
      // eine Spalte neben einer Aggregatfunktion, die nicht in GROUP BY steht (gruppieren, 23.11.2026: „Susanne Rossi, 41“)
      if (e.lose && e.lose.length) { const p = h("p", "sch-lose"); p.innerHTML = loseSatz(e.lose, ""); erg.append(p); }
    } else {
      erg.classList.add("leer");
      erg.append(h("p", "", "Noch nicht ausgeführt."));
    }
    tischEl.append(erg);
  }
  function abfrage() {
    if (!db) return;
    wegFrei = true;
    const sql = abfrageEl.value.trim();
    z.markiert = null;
    if (!sql) { z.ergebnis = null; z.fehler = { titel: "Keine Abfrage", text: "Das Feld ist leer.", original: "" }; zeichne(); return; }
    const t0 = performance.now();
    try {
      const e = ausfuehren(sql);
      e.dauer = Math.max(0.001, (performance.now() - t0) / 1000);
      e.lose = loseSpalten(sql);
      z.ergebnis = e; z.fehler = null;
    } catch (err) {
      const m = String(err && err.message || err);
      z.ergebnis = null; z.fehler = Object.assign(fehlerDeuten(m, sql), { original: m });
    }
    zeichne();
  }

  // ── Tisch term-sql (select, 20.11.2026, Lehrerwahl A im Drehbuch: „nebeneinander, Farben verbunden“) ─────────────
  // Links der Term (fest, opt.term), rechts dieselbe Frage als SQL (opt.abfrage; tippbar mit tippen="ja"). „Ausführen“
  // rechnet beides auf derselben Basis (Auszug oder alle Zeilen) und vergleicht: „✓ gleiches Ergebnis“ oder ein
  // Gegenbeispiel. Erst nach dem Lauf bekommen die Teile ihre Farben -- π und SELECT blau, σ und WHERE Koralle, die
  // Tabelle und FROM Mint (die Schrittfarben aus relalg): Die Zuordnung zeigt sich, sie wird nicht vorgesagt.
  let TS = null;
  const tsFeld = h("textarea", "abfrage");
  tsFeld.spellcheck = false; tsFeld.rows = 3;
  tsFeld.setAttribute("autocapitalize", "off"); tsFeld.setAttribute("autocomplete", "off");
  tsFeld.value = sqlSchoen(opt.abfrage);
  tsFeld.readOnly = !getippt;
  tsFeld.addEventListener("input", () => { if (TS) { TS = null; zeichne(); tsFeld.focus(); } });
  tsFeld.addEventListener("keydown", ev => { if (ev.key === "Enter" && (ev.ctrlKey || ev.metaKey)) { ev.preventDefault(); tsRechnen(); } });
  function tsRechnen() {
    if (!db || !adb) return;
    wegFrei = true;
    const basisDb = z.tsbasis === "ganz" ? db : adb;
    TS = { term: (opt.term || "").trim(), sql: tsFeld.value.trim() };
    try { TS.term_e = raAusfuehren(basisDb, TS.term, { zeigen: GRENZE_ZEIGEN, zaehlen: GRENZE_ZAEHLEN }); } catch (e) { TS.term_fehler = raDeuten(e); }
    if (!TS.sql) TS.fehler = { titel: "Keine Abfrage", text: "Das Feld ist leer." };
    else {
      try { TS.sql_e = ausfuehren(TS.sql, basisDb); }
      catch (err) { const m = String(err && err.message || err); TS.fehler = Object.assign(fehlerDeuten(m, TS.sql), { original: m }); }
    }
    // abgebrochene Listen werden nicht verglichen (join, 22.11.2026): je die ersten 100 000 Zeilen sagen nichts über das Ganze
    if (TS.term_e && TS.sql_e && !TS.term_e.mehr && !TS.sql_e.mehr) {
      try {
        const alleT = raAusfuehren(basisDb, TS.term, { zeigen: GRENZE_ZAEHLEN, zaehlen: GRENZE_ZAEHLEN });
        const alleS = ausfuehrenAlle(TS.sql, basisDb);
        TS.vergleich = tsVergleichen(alleS, alleT);
      } catch (e) { TS.vergleich = null; }
    }
    zeichne();
  }
  // Fahrzeug × Einwohner nennt seine Spalten Fahrzeug.PersNr und Einwohner.PersNr, SELECT * liefert zweimal PersNr -- ohne
  // Zuordnung sagte der Tisch „Die Attribute stimmen noch nicht“ (join Schritt 5, 22.11.2026). Welche PersNr in SQL welche
  // ist, sagt der Name nicht: jede Zuordnung gleichnamiger Spalten wird probiert (höchstens 24), eine passende genügt.
  function tsVergleichen(alleS, alleT) {
    const kurz = x => x.toLowerCase().split(".").pop();
    const gruppen = {};
    alleS.spalten.forEach((s, i) => (gruppen[s.toLowerCase()] = gruppen[s.toLowerCase()] || []).push(i));
    let namen = [alleS.spalten.slice()];
    Object.keys(gruppen).forEach(g => {
      const stellen = gruppen[g], ziele = alleT.spalten.filter(s => kurz(s) === g);
      if (stellen.length < 2 || ziele.length !== stellen.length) return;
      const folgen = a => a.length < 2 ? [a] : a.flatMap((x, i) => folgen(a.filter((_, j) => j !== i)).map(r => [x].concat(r)));
      namen = namen.flatMap(n => folgen(ziele).map(f => { const m = n.slice(); stellen.forEach((st, k) => { m[st] = f[k]; }); return m; })).slice(0, 24);
    });
    let erstes = null;
    for (const n of namen) {
      const v = raVergleichen({ spalten: n, zeilen: alleS.zeilen }, alleT);
      if (v.ok) return v;
      erstes = erstes || v;
    }
    return erstes;
  }
  function ausfuehrenAlle(sql, basisDb) {
    const st = basisDb.prepare(sql), spalten = st.getColumnNames(), zeilen = [];
    try { while (st.step() && zeilen.length < GRENZE_ZAEHLEN) zeilen.push(st.get()); } finally { st.free(); }
    return { spalten, zeilen, anzahl: zeilen.length };
  }
  // Der Term in den Farben seiner Teile (nach Art, nicht nach Schritt): sel Koralle, proj Blau, Tabelle Mint
  function tsTermHtml(farbig) {
    let baum; try { baum = raLesen(TS && TS.term || opt.term || ""); } catch (e) { return esc(opt.term || ""); }
    const F = { sel: "st0", proj: "st1", tab: "st2", join: "st3", kreuz: "st3" };
    const sp = (art, x) => farbig ? '<span class="ts-teil ' + F[art] + '">' + x + "</span>" : x;
    const teil = b => {
      if (b.art === "tab") return sp("tab", esc(b.name));
      if (b.art === "sel") return sp("sel", esc("σ[" + b.bed + "]")) + "(" + teil(b.kind) + ")";
      if (b.art === "proj") return sp("proj", esc("π[" + b.attrs.join(", ") + "]")) + "(" + teil(b.kind) + ")";
      return teil(b.l) + " " + sp(b.art, b.art === "kreuz" ? "×" : "⋈") + " " + teil(b.r);
    };
    return teil(baum);
  }
  // Die Anweisung in Klauseln, je Klausel ihre Farbe; umbrochen wird vor jedem Schlüsselwort der Klausel
  function tsSqlHtml(sql, spalten) {
    const F = { SELECT: "st1", FROM: "st2", WHERE: "st0", "ORDER BY": "st4" };
    // nur Klauseln, kein eingerücktes AND (22.11.2026): in der halben Spaltenbreite des Vortrags brach es zusätzlich um und
    // machte aus der Anweisung in select zehn Zeilen; ein JOIN bleibt im FROM-Teil
    const teile = sql.replace(/\s+/g, " ").trim().split(/(?=\b(?:FROM|WHERE|ORDER\s+BY)\b)/i);
    // gestapelt (volle Breite, Reihensichtung iq2 fall Teil II, Befund 8): eine WHERE-Klausel, die auch dort nicht passt,
    // bekommt je AND eine eingerückte Zeile; was dann noch zu lang ist, bricht mit hängendem Einzug (.ts-klausel)
    return teile.map(s => { const k = (/^(SELECT|FROM|WHERE|ORDER\s+BY)/i.exec(s) || [""])[0].toUpperCase().replace(/\s+/, " ");
      const zeilen = spalten && k === "WHERE" && s.trim().length > spalten ? sqlUndZeilen(s.trim(), 0).split("\n") : [s.trim()];
      return zeilen.map((z, i) => '<div class="ts-klausel' + (i ? " und" : "") + '"><span class="ts-teil ' + (F[k] || "") + '">' + esc(z.trim()) + "</span></div>").join(""); }).join("");
  }
  function tsTabelle(e, titel) {
    const box = h("div", "ts-ergebnis");
    box.append(h("div", "ts-etk", titel + " · " + (e.mehr ? "über " : "") + zahl(e.anzahl) + (e.anzahl === 1 ? " Zeile" : " Zeilen")));
    const r = h("div", "rahmen"); r.innerHTML = tabelleHtml(e.spalten, e.zeilen); box.append(r);
    return box;
  }
  // Lange Texte im Vortrag (lesen, 22.11.2026: drei Tabellen, acht Bedingungen) -- ohne Plan und in kleinerer Schrift, sonst
  // liegen Urteil und Tabellen unter dem Rand. In der Übung (tippbar) bleibt der Plan.
  const tsLang = () => !getippt && (String(opt.term || "").length + tsFeld.value.length) > 320;
  function tischTermSql() {
    tischEl.textContent = "";
    const lauf = !!(TS && (TS.sql_e || TS.fehler));
    const raster = h("div", "ts-raster");
    const links = h("div", "ts-seite"), rechts = h("div", "ts-seite");
    links.append(h("div", "ts-etk", "Term"));
    const tf = h("div", "ts-term"); tf.innerHTML = tsTermHtml(lauf && !TS.term_fehler); links.append(tf);
    rechts.append(h("div", "ts-etk", "SQL"));
    if (getippt) {
      rechts.append(tsFeld);
      if (lauf && TS.sql_e) { const g = h("div", "ts-sql klein"); g.innerHTML = tsSqlHtml(TS.sql); rechts.append(g); }
    } else { const g = h("div", "ts-sql"); g.innerHTML = lauf && TS.sql_e ? tsSqlHtml(TS.sql) : tsSqlHtml(tsFeld.value).replace(/ts-teil st\d/g, "ts-teil"); rechts.append(g); }
    raster.append(links, rechts);
    const leiste = h("div", "leiste");
    const los = h("button", "primaer", "▶ Ausführen"); los.type = "button"; los.addEventListener("click", tsRechnen);
    const bA = h("button", z.tsbasis === "auszug" ? "an" : "", "Auszug"); bA.type = "button";
    const bG = h("button", z.tsbasis === "ganz" ? "an" : "", "alle Zeilen"); bG.type = "button";
    bA.addEventListener("click", () => { z.tsbasis = "auszug"; if (TS) tsRechnen(); else zeichne(); });
    bG.addEventListener("click", () => { z.tsbasis = "ganz"; if (TS) tsRechnen(); else zeichne(); });
    const wahl = h("span", "dw-modus"); wahl.append(bA, bG);
    leiste.append(los, h("small", "", getippt ? "Strg+Enter führt aus" : ""), h("span", "luft"), wahl);
    const feld = h("div", "abfrage-feld ts-feld" + (tsLang() ? " lang" : "")); feld.append(raster, leiste);
    tischEl.append(feld);
    // Term und SQL untereinander, sobald eine Seite nicht in ihre halbe Spalte passt (Reihensichtung iq2 fall Teil II,
    // 24.11.2026, Befund 8: in select brach „WHERE Farbe =“ / „'rot' AND Typ =“ / „'Kombi'“, der Term viermal) -- gemessen
    // an der gerenderten Breite, also auch nach A−/A+ und „groß“ richtig
    {
      const spT = spaltenVon(tf), termLang = spT && String(TS && TS.term || opt.term || "").length > spT;
      const sqlEl = getippt ? tsFeld : rechts.querySelector(".ts-sql"), spS = spaltenVon(sqlEl);
      const zeilenS = getippt ? tsFeld.value.split("\n") : Array.from(sqlEl ? sqlEl.querySelectorAll(".ts-klausel") : []).map(d => d.textContent);
      if (termLang || (spS && zeilenS.some(z => z.length > spS))) {
        raster.classList.add("gestapelt");
        if (!getippt && sqlEl) { const sp = spaltenVon(sqlEl); sqlEl.innerHTML = lauf && TS.sql_e ? tsSqlHtml(TS.sql, sp) : tsSqlHtml(tsFeld.value, sp).replace(/ts-teil st\d/g, "ts-teil"); }
      }
    }
    if (getippt) { const hoehe = () => { tsFeld.style.height = "auto"; tsFeld.style.height = tsFeld.scrollHeight + "px"; }; requestAnimationFrame(hoehe); if (!tsFeld._hoehe) { tsFeld._hoehe = true; tsFeld.addEventListener("input", hoehe); } }
    if (!lauf) { const e = h("div", "ergebnis leer"); e.append(h("p", "", "Noch nicht ausgeführt – ▶ rechnet Term und Anweisung auf demselben " + (z.tsbasis === "ganz" ? "Bestand (alle Zeilen)." : "Auszug."))); tischEl.append(e); return; }
    if (TS.fehler) { const e = h("div", "ergebnis fehler"); e.innerHTML = "<b>" + esc(TS.fehler.titel) + "</b><p>" + TS.fehler.text + "</p>"; tischEl.append(e); return; }
    const wo = z.tsbasis === "ganz" ? "alle Zeilen" : "Auszug";
    const zwei = h("div", "ts-zwei");
    if (TS.term_e) zwei.append(tsTabelle(TS.term_e, "Term · " + wo));
    else if (TS.term_fehler) { const f = h("div", "ergebnis fehler ts-ergebnis"); f.innerHTML = '<div class="ts-etk">Term · ' + wo + "</div><b>" + esc(TS.term_fehler.titel) + "</b><p>" + TS.term_fehler.text + "</p>"; zwei.append(f); }
    zwei.append(tsTabelle(TS.sql_e, "SQL · " + wo));
    // Urteil und Abbruch stehen ÜBER den Tabellen (22.11.2026): im Vortrag lagen sie unter dem Bildrand
    const v = TS.vergleich;
    if (TS.sql_e.mehr || (TS.term_e && TS.term_e.mehr))
      tischEl.append(h("p", "warnung ts-abbruch", "Abgebrochen nach " + zahl(GRENZE_ZAEHLEN) + " Zeilen – so viele kann niemand lesen. Steht jede Tabelle mit einer Bedingung verbunden da?"));
    if (v) {
      const box = h("div", "ts-vergleich " + (v.ok ? "ok" : "offen"));
      box.innerHTML = (v.ok ? "✓ gleiches Ergebnis" : "✗ verschieden — " + esc(v.text)) + (v.ok ? " — " + zahl(TS.sql_e.anzahl) + (TS.sql_e.anzahl === 1 ? " Zeile" : " Zeilen") + (z.tsbasis === "ganz" ? " unter allen" : " im Auszug") : "");
      if (!v.ok && v.zeile) box.innerHTML += ' <span class="ts-zeile">' + v.zeile.map(w => esc(w === null ? "" : String(w))).join(" · ") + "</span>";
      tischEl.append(box);
    }
    tischEl.append(zwei);
  }

  // ── Tisch schritte (lesen, 22.11.2026, Lehrerwahl B im Drehbuch: „Eine Tabelle, die schrumpft“) ────────────────────
  // Eine Anweisung arbeitet Schritt für Schritt, wie das DBMS sie liest: FROM und die Bedingungen, die verbinden · WHERE
  // streicht Zeilen (rot) · SELECT deckt Spalten ab (Schraffur) · DISTINCT streicht, was doppelt ist (gelb) · ORDER BY
  // sortiert. Oben die Zählleiste, auch für alle Zeilen; spätere Schritte tragen ein „?“. Die Tabelle zeigt die Spalten,
  // die in der Anweisung vorkommen. Der Tisch braucht die Breite und zeigt keinen Plan. Gerechnet wird mit EINER
  // Grundabfrage (die wählenden Bedingungen als Spalte), die letzte Zahl ist die der Anweisung selbst (test/daten.mjs).
  // Er liest SELECT · FROM · WHERE · ORDER BY; GROUP BY und HAVING kommen mit `gruppieren` (LT9).
  // Seit `zaehlen` (23.11.2026, Lehrerwahl A im Drehbuch: „Die Zeilen fallen in eine“): Steht hinter SELECT nur
  // Aggregatfunktionen (COUNT · SUM · AVG · MIN · MAX, mit AS), heißt der Schritt nach WHERE „zusammengefasst“ -- die
  // behaltenen Zeilen werden grau, darunter die EINE Ergebniszeile; auch aus null Zeilen wird eine (die Zeile mit 0).
  let SCH = null;
  const schFeld = h("textarea", "abfrage");
  schFeld.spellcheck = false; schFeld.rows = 3;
  schFeld.setAttribute("autocapitalize", "off"); schFeld.setAttribute("autocomplete", "off");
  schFeld.value = sqlSchoen(opt.abfrage);
  schFeld.readOnly = !getippt;
  schFeld.addEventListener("input", () => { if (SCH) { SCH = null; z.schSchritt = 0; zeichne(); schFeld.focus(); } });
  schFeld.addEventListener("keydown", ev => { if (ev.key === "Enter" && (ev.ctrlKey || ev.metaKey)) { ev.preventDefault(); schGehe("vor"); } });
  // Text an einem Muster der obersten Ebene teilen -- nicht in '…', nicht in Klammern, nicht das AND von BETWEEN
  function schTeilen(text, wort) {
    const teile = []; let tiefe = 0, txt = false, zwischen = false, anfang = 0;
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (c === "'") txt = !txt;
      if (txt) continue;
      if (c === "(") tiefe++; else if (c === ")") tiefe--;
      if (tiefe) continue;
      if (wort === ",") { if (c === ",") { teile.push(text.slice(anfang, i)); anfang = i + 1; } continue; }
      const w = i && /\w/.test(text[i - 1]) ? "" : (/^(\w+)/.exec(text.slice(i)) || [])[1];
      if (!w) continue;
      if (/^BETWEEN$/i.test(w)) zwischen = true;
      else if (w.toUpperCase() === wort) { if (wort === "AND" && zwischen) zwischen = false; else { teile.push(text.slice(anfang, i)); anfang = i + w.length; } }
      i += w.length - 1;
    }
    teile.push(text.slice(anfang));
    return teile.map(s => s.trim());
  }
  function schLesen(sql) {
    const nein = (titel, text) => { throw { titel, text }; };
    const x = String(sql || "").replace(/;\s*$/, "").replace(/\s+/g, " ").trim();
    if (!x) nein("Keine Anweisung", "Das Feld ist leer.");
    if (/\b(UNION|LIMIT)\b/i.test(x.replace(/'(?:[^']|'')*'/g, "''"))) nein("Das zeigt dieser Tisch nicht", "Er geht SELECT, FROM, WHERE, GROUP BY, HAVING und ORDER BY Schritt für Schritt. Führt die Anweisung im Tisch <i>Abfrage</i> aus.");
    const m = /^SELECT\s+(DISTINCT\s+)?(.+?)\s+FROM\s+(.+?)(?:\s+WHERE\s+(.+?))?(?:\s+GROUP\s+BY\s+(.+?))?(?:\s+HAVING\s+(.+?))?(?:\s+ORDER\s+BY\s+(.+))?$/i.exec(x);
    if (!m) nein("Keine ganze Anweisung", "Eine Anweisung braucht mindestens <code>SELECT … FROM …</code>.");
    const P = { distinct: !!m[1], select: m[2].trim(), from: m[3].trim(), where: (m[4] || "").trim(), group: (m[5] || "").trim(), having: (m[6] || "").trim(), order: (m[7] || "").trim() };
    if (P.having && !P.group) nein("Das zeigt dieser Tisch nicht", "<code>HAVING</code> prüft Gruppen -- hier steht es ohne <code>GROUP BY</code> davor.");
    // die Tabellen hinter FROM, mit ihrem Namen in der Anweisung (Alias)
    const STOPP = /^(INNER|NATURAL|LEFT|RIGHT|CROSS|JOIN|ON|USING|WHERE|OUTER)$/i;
    P.tabs = [...P.from.replace(/'(?:[^']|'')*'/g, "''").matchAll(/(?:^|,|\bJOIN\b)\s*([^\s,()]+)(?:\s+(?:AS\s+)?([^\s,()]+))?/gi)].map(t => {
      const s = steckbriefe.find(k => k.name.toLowerCase() === t[1].toLowerCase());
      if (!s) nein("Diese Tabelle gibt es nicht", "<code>" + esc(t[1]) + "</code> steht nicht in der Datenbank.");
      return { s, alias: t[2] && !STOPP.test(t[2]) ? t[2] : t[1] };
    });
    if (/\b(LEFT|RIGHT)\b/i.test(P.from)) nein("Das zeigt dieser Tisch nicht", "Er kennt <code>FROM A, B</code>, <code>INNER JOIN … ON</code> und <code>NATURAL JOIN</code>.");
    P.natural = /\bNATURAL\s+JOIN\b/i.test(P.from);
    // verbindet oder wählt aus? Eine Bedingung A.x = B.y zwischen zwei Tabellen der Anweisung verbindet
    const bed = P.where ? (schTeilen(P.where, "OR").length > 1 ? [P.where] : schTeilen(P.where, "AND")) : [];
    const al = n => P.tabs.findIndex(t => t.alias.toLowerCase() === String(n).toLowerCase());
    P.verb = []; P.wahl = [];
    bed.forEach(b => { const g = /^([^\s.=]+)\.([^\s.=]+)\s*=\s*([^\s.=]+)\.([^\s.=]+)$/.exec(b); (g && al(g[1]) >= 0 && al(g[3]) >= 0 && al(g[1]) !== al(g[3]) ? P.verb : P.wahl).push(b); });
    // ohne '…' -- was in der Anweisung an Spalten vorkommt
    const worte = [P.select, P.wahl.join(" "), P.group, P.having, P.order].join(" ").replace(/'(?:[^']|'')*'/g, "''");
    const nennt = (t, c) => new RegExp("(?<![\\wäöüßÄÖÜ.])" + c + "(?![\\wäöüßÄÖÜ])", "i").test(worte) || new RegExp("(?<![\\wäöüßÄÖÜ])" + t + "\\." + c + "(?![\\wäöüßÄÖÜ])", "i").test(worte);
    // Aggregatfunktionen hinter SELECT (zaehlen): alle oder keine -- eine einfache Spalte daneben hat keinen Wert
    const AGG = /^(COUNT|SUM|AVG|MIN|MAX)\s*\(\s*(?:DISTINCT\s+)?(\*|[^\s()]+)\s*\)(?:\s+(?:AS\s+)?[^\s,()]+)?$/i;
    const teileSel = schTeilen(P.select, ",");
    const agg = teileSel.filter(a => AGG.test(a));
    // Seit `gruppieren` (23.11.2026): eine einfache Spalte neben einer Aggregatfunktion, die nicht in GROUP BY steht, ist
    // „lose“ -- SQLite nimmt irgendeinen ihrer Werte (Rossi, 41), andere DBMS melden einen Fehler. Der Tisch zeigt dort „?“.
    P.gruppen = P.group ? schTeilen(P.group, ",") : [];
    P.lose = agg.length ? loseTeile(teileSel, P.gruppen) : [];
    if (agg.length && P.distinct && !P.group) nein("Das zeigt dieser Tisch nicht", "Nach dem Zusammenfassen gibt es nur eine Zeile -- DISTINCT gehört hier in die Klammer, <code>COUNT(DISTINCT …)</code>.");
    P.aggregat = agg.length > 0 && !P.group;
    const stern = /(^|,)\s*\*\s*(,|$)/.test(P.select) || agg.some(a => AGG.exec(a)[2] === "*");
    P.spalten = []; const schon = new Map();
    P.tabs.forEach(t => t.s.spalten.forEach(c => {
      if (!stern && !nennt(t.alias, c.name) && !new RegExp("(^|,)\\s*" + t.alias + "\\.\\*", "i").test(P.select)) return;
      if (schon.has(c.name) && P.natural) return;
      if (schon.has(c.name)) schon.get(c.name).name = schon.get(c.name).alias + "." + c.name;
      const sp = { name: schon.has(c.name) ? t.alias + "." + c.name : c.name, feld: c.name, alias: t.alias, voll: (P.natural ? "" : '"' + t.alias + '".') + '"' + c.name + '"' };
      if (!schon.has(c.name)) schon.set(c.name, sp);
      P.spalten.push(sp);
    }));
    // welche der gezeigten Spalten SELECT ausgibt
    // mit GROUP BY: die Spalten, nach denen gruppiert wird, unter den gezeigten -- ihr Wert ist der Schlüssel der Gruppe
    P.schluessel = P.gruppen.map(a => {
      const g = /^(?:([^\s.]+)\.)?([^\s.]+)$/.exec(a);
      if (!g) nein("Das zeigt dieser Tisch nicht", "Hinter GROUP BY stehen hier nur Spaltennamen, kein <code>" + esc(a) + "</code>.");
      const i = P.spalten.findIndex(s => s.feld.toLowerCase() === g[2].toLowerCase() && (!g[1] || P.natural || s.alias.toLowerCase() === g[1].toLowerCase()));
      if (i < 0) nein("Diese Spalte gibt es nicht", "<code>" + esc(a) + "</code> steht in keiner der Tabellen hinter FROM.");
      return i;
    });
    P.sicht = P.aggregat || P.group ? P.spalten.map((_, i) => i) : schTeilen(P.select, ",").map(a => {
      if (a === "*") return P.spalten.map((_, i) => i);
      const g = /^(?:([^\s.]+)\.)?([^\s.]+)$/.exec(a);
      if (!g) nein("Das zeigt dieser Tisch nicht", "Hinter SELECT stehen hier nur Spaltennamen, kein <code>" + esc(a) + "</code>.");
      if (g[2] === "*") return P.spalten.map((s, i) => s.alias.toLowerCase() === g[1].toLowerCase() ? i : -1).filter(i => i >= 0);
      const i = P.spalten.findIndex(s => s.feld.toLowerCase() === g[2].toLowerCase() && (!g[1] || P.natural || s.alias.toLowerCase() === g[1].toLowerCase()));
      if (i < 0) nein("Diese Spalte gibt es nicht", "<code>" + esc(a) + "</code> steht in keiner der Tabellen hinter FROM.");
      return [i];
    }).flat();
    P.schritte = ["verbunden"].concat(P.wahl.length ? ["where"] : [], P.group ? ["gruppiert"].concat(P.having ? ["having"] : [], ["select"]) : P.aggregat ? ["zusammen"] : ["select"],
      P.distinct ? ["distinct"] : [], P.order ? ["order"] : []);
    return P;
  }
  // Die losen Teile hinter SELECT: einfache Spalten neben einer Aggregatfunktion, die nicht in GROUP BY stehen (Abitur:
  // jede steht dort, LA25 B1 6.1). Gibt die Teile zurück, wie sie dastehen; leer ohne Aggregatfunktion.
  function loseTeile(teile, gruppen) {
    if (!teile.some(a => /^(COUNT|SUM|AVG|MIN|MAX)\s*\(/i.test(a))) return [];
    const name = a => { const g = /^(?:[^\s.()]+\.)?([^\s.()]+)(?:\s+(?:AS\s+)?[^\s,()]+)?$/i.exec(a); return g ? g[1].toLowerCase() : null; };
    const gr = new Set(gruppen.map(name));
    return teile.filter(a => !/^(COUNT|SUM|AVG|MIN|MAX)\s*\(/i.test(a) && a !== "*" && name(a) && !gr.has(name(a)));
  }
  function loseSpalten(sql) {
    const x = String(sql || "").replace(/;\s*$/, "").replace(/\s+/g, " ").trim();
    const m = /^SELECT\s+(?:DISTINCT\s+)?(.+?)\s+FROM\s+.+?(?:\s+WHERE\s+.+?)?(?:\s+GROUP\s+BY\s+(.+?))?(?:\s+HAVING\s+.+?)?(?:\s+ORDER\s+BY\s+.+)?$/i.exec(x);
    return m ? loseTeile(schTeilen(m[1], ","), m[2] ? schTeilen(m[2], ",") : []) : [];
  }
  const loseSatz = (lose, wert) => lose.map(a => "<code>" + esc(a) + "</code>").join(" und ") + (lose.length > 1 ? " stehen" : " steht") +
    " weder in GROUP BY noch in einer Aggregatfunktion. SQLite nimmt irgendeine der Zeilen" + (wert ? " — hier " + esc(wert) : "") + ". Andere Datenbanksysteme melden einen Fehler.";
  const teileSelIndex = (select, teil) => schTeilen(select, ",").indexOf(teil);
  const schName = { verbunden: "verbunden", where: "WHERE", select: "SELECT", zusammen: "zusammengefasst", gruppiert: "gruppiert", having: "HAVING", distinct: "DISTINCT", order: "ORDER BY" };
  function schRechnen() {
    const sql = schFeld.value.trim();
    SCH = { sql, basis: z.schbasis, fehler: null };
    const d = z.schbasis === "ganz" ? db : adb;
    try {
      ausfuehren(sql.replace(/;\s*$/, "") + (/\bLIMIT\b/i.test(sql) ? "" : " LIMIT 1"), d);   // die Meldungen des DBMS zuerst -- in ihrer Sprache (ohne LIMIT liefe ein Kreuzprodukt los)
      const P = SCH.P = schLesen(sql);
      const eins = q => { const r = d.exec(q); return r[0].values[0][0]; };
      SCH.kreuz = P.tabs.length > 1 ? P.tabs.reduce((a, t) => a * eins('SELECT COUNT(*) FROM "' + t.s.name + '"'), 1) : null;
      const wo = P.verb.length ? " WHERE " + P.verb.join(" AND ") : "";
      SCH.verbunden = eins("SELECT COUNT(*) FROM (SELECT 1 FROM " + P.from + wo + " LIMIT " + (GRENZE_ZAEHLEN + 1) + ")");
      SCH.mehr = SCH.verbunden > GRENZE_ZAEHLEN;
      if (SCH.mehr) return;
      const wahl = P.wahl.length ? "(" + P.wahl.join(") AND (") + ")" : "1";
      const alle = ausfuehrenAlle("SELECT " + P.spalten.map(s => s.voll).join(", ") + ", (" + wahl + ") FROM " + P.from + wo, d).zeilen;
      SCH.zeilen = alle.map(r => ({ w: r.slice(0, -1), bleibt: !!r[r.length - 1] }));
      const gesehen = new Set();
      SCH.zeilen.forEach(r => { if (!r.bleibt) return; const k = JSON.stringify(P.sicht.map(i => r.w[i])); r.doppelt = gesehen.has(k); gesehen.add(k); });
      SCH.zahl = { verbunden: SCH.verbunden, where: SCH.zeilen.filter(r => r.bleibt).length };
      SCH.zahl.select = SCH.zahl.where; SCH.zahl.distinct = gesehen.size; SCH.zahl.order = P.distinct ? gesehen.size : SCH.zahl.where;
      if (P.aggregat) SCH.zahl.zusammen = SCH.zahl.order = 1;
      SCH.ergebnis = ausfuehrenAlle(sql.replace(/;\s*$/, ""), d);
      if (P.group) {
        // je Gruppe: der Schlüssel, die Ausgabe von SELECT und ob HAVING sie behält -- gerechnet vom DBMS, nicht hier
        const k = P.gruppen.length, ohneOrder = "SELECT " + (P.distinct ? "DISTINCT " : "") + P.select + " FROM " + P.from + (P.where ? " WHERE " + P.where : "") + " GROUP BY " + P.group;
        const g = ausfuehrenAlle("SELECT " + P.gruppen.join(", ") + ", " + P.select + ", (" + (P.having || "1") + ") FROM " + P.from + (P.where ? " WHERE " + P.where : "") + " GROUP BY " + P.group, d);
        SCH.gspalten = g.spalten.slice(k, -1);
        SCH.gruppen = g.zeilen.map((r, n) => ({ schluessel: JSON.stringify(r.slice(0, k).map(String)), aus: r.slice(k, -1), bleibt: !!r[r.length - 1], nr: n }));
        const nach = new Map(SCH.gruppen.map(x => [x.schluessel, x]));
        SCH.zeilen.forEach(r => { if (r.bleibt) r.gruppe = nach.get(JSON.stringify(P.schluessel.map(i => String(r.w[i])))); });
        SCH.zahl.gruppiert = SCH.gruppen.length; SCH.zahl.having = SCH.gruppen.filter(x => x.bleibt).length;
        SCH.ohneOrder = ausfuehrenAlle(ohneOrder + (P.having ? " HAVING " + P.having : ""), d);
        SCH.zahl.select = SCH.ohneOrder.anzahl; SCH.zahl.distinct = SCH.ohneOrder.anzahl; SCH.zahl.order = SCH.ergebnis.anzahl;
      }
      // lose Spalten (neben einer Aggregatfunktion, nicht in GROUP BY): welche Spalten des Ergebnisses, und was SQLite nahm
      SCH.loseIdx = P.lose.map(a => teileSelIndex(P.select, a)).filter(i => i >= 0);
    } catch (e) {
      SCH.fehler = e && e.titel ? e : Object.assign(fehlerDeuten(String(e && e.message || e), sql), { original: String(e && e.message || e) });
    }
  }
  function schGehe(wohin) {
    if (!db || !adb) return;
    if (!SCH || SCH.basis !== z.schbasis) { const s = z.schSchritt; schRechnen(); z.schSchritt = SCH.P && !SCH.fehler ? Math.min(s, SCH.P.schritte.length) : 0; }
    const n = SCH.P && !SCH.fehler && !SCH.mehr ? SCH.P.schritte.length : SCH.mehr ? 1 : 0;
    if (wohin === "vor") z.schSchritt = Math.min(n, z.schSchritt + 1);
    else if (wohin === "zurueck") z.schSchritt = Math.max(0, z.schSchritt - 1);
    else if (wohin === "ende") z.schSchritt = n;
    else if (wohin === "anfang") z.schSchritt = 0;
    zeichne();
  }
  // Die Anweisung mit einer Zeile je Schritt; die Zeile des Schritts leuchtet, was noch kommt, ist blass
  function schSqlHtml() {
    const P = SCH && SCH.P, jetzt = P && z.schSchritt ? P.schritte[z.schSchritt - 1] : "", nr = s => P.schritte.indexOf(s) + 1;
    if (!P) return sqlSchoen(schFeld.value).split("\n").map(t => "<div>" + esc(t).replace(/^ +/, "&nbsp;&nbsp;") + "</div>").join("");
    const cls = s => (s === jetzt ? "jetzt" : z.schSchritt && nr(s) > z.schSchritt ? "kommt" : "");
    const zeile = (s, t) => '<div class="' + cls(s) + '">' + t + "</div>";
    const sel = P.aggregat ? "zusammen" : "select";
    let aus = '<div class="' + (jetzt === sel ? "jetzt" : cls(sel)) + '">SELECT ' + (P.distinct ? '<span class="' + (jetzt === "distinct" ? "jetzt" : cls("distinct")) + '">DISTINCT</span> ' : "") + esc(P.select) + "</div>";
    if (jetzt === "distinct") aus = aus.replace('<div class="">', "<div>");
    const von = P.from.replace(/(?<!\b(?:INNER|NATURAL|CROSS))\s+(?=(?:INNER\s+|NATURAL\s+|CROSS\s+)?JOIN\b)/gi, "\n").split("\n");
    aus += von.map((t, i) => zeile("verbunden", (i ? "" : "FROM ") + esc(t))).join("");
    let erste = true;
    const bed = (s, liste) => { if (!liste.length) return; const w = erste ? "WHERE " : "&nbsp;&nbsp;AND "; erste = false; aus += zeile(s, liste.map((b, i) => '<span class="sch-bed">' + (i ? "AND " : w) + esc(b) + "</span>").join(" ")); };
    bed("verbunden", P.verb); bed("where", P.wahl);
    if (P.group) aus += zeile("gruppiert", "GROUP BY " + esc(P.group));
    if (P.having) aus += zeile("having", "HAVING " + esc(P.having));
    if (P.order) aus += zeile("order", "ORDER BY " + esc(P.order));
    return aus;
  }
  function schTafel(schritt) {
    const P = SCH.P, ab = P.schritte.indexOf(schritt), hat = s => { const i = P.schritte.indexOf(s); return i >= 0 && i <= ab; };
    // lose Spalten zeigen „?“ -- und der Hinweis sagt, was SQLite genommen hat
    const lose = (zeilen) => SCH.loseIdx.length ? zeilen.map(r => r.map((w, i) => SCH.loseIdx.includes(i) ? "?" : w)) : zeilen;
    const loseHinweis = e => SCH.loseIdx.length ? loseSatz(P.lose, e && e.zeilen.length === 1 ? SCH.loseIdx.map(i => e.zeilen[0][i]).join(" · ") : "") : "";
    const mark = r => z.markiert != null && r.w.some(w => String(w) === String(z.markiert));
    if (schritt === "order" || (schritt === "select" && P.group)) {
      const e = schritt === "order" ? SCH.ergebnis : SCH.ohneOrder;
      return { html: tabelleHtml(e.spalten, lose(e.zeilen.slice(0, GRENZE_ZEIGEN))), gezeigt: Math.min(e.anzahl, GRENZE_ZEIGEN), von: e.anzahl, hinweis: loseHinweis(null) };
    }
    if (schritt === "zusammen") {
      // Lehrerwahl A (zaehlen, 23.11.): die behaltenen Zeilen grau, darunter die eine Ergebniszeile -- auch bei null Zeilen
      const bleibt = SCH.zeilen.filter(r => r.bleibt), e = SCH.ergebnis, n = bleibt.length;
      let t = '<table class="ra-tafel sch-tafel sch-grau"><thead><tr>' + P.spalten.map(s => "<th>" + esc(s.name) + "</th>").join("") + "</tr></thead><tbody>";
      bleibt.slice(0, GRENZE_ZEIGEN).forEach(r => { t += "<tr" + (mark(r) ? ' class="markiert"' : "") + ">" + r.w.map(w => "<td>" + esc(w === null ? "" : w) + "</td>").join("") + "</tr>"; });
      t += "</tbody></table>" + (n ? "" : '<p class="sch-keine">keine Zeile übrig</p>');
      // Pfeil und Ergebnis UNTER dem Kasten (gruppieren, 23.11.: bei 41 Zeilen lag die Ergebniszeile sonst unsichtbar unten im Rollkasten)
      const nach = '<p class="sch-pfeil">⟱ <span>' + (n === 1 ? "1 Zeile wird eine" : zahl(n) + " Zeilen werden eine") + "</span></p>" +
        tabelleHtml(e.spalten, lose(e.zeilen)).replace("<table", '<table class="sch-erg"');
      return { html: t, nach, gezeigt: Math.min(n, GRENZE_ZEIGEN), von: n, hinweis: loseHinweis(e) };
    }
    if (schritt === "gruppiert" || schritt === "having") {
      // Lehrerwahl A (gruppieren, 23.11.: „Farbige Häufchen“): die Zeilen nach WHERE, je Gruppe zusammen und in einer
      // Farbe; rechts daneben ⟹ die EINE Zeile der Gruppe. HAVING streicht ganze Häufchen (grau, Ergebnis gestrichen).
      const bleibt = SCH.zeilen.filter(r => r.bleibt && r.gruppe).sort((a, b) => a.gruppe.nr - b.gruppe.nr);
      const groesse = new Map(); bleibt.forEach(r => groesse.set(r.gruppe, (groesse.get(r.gruppe) || 0) + 1));
      const farbe = new Map(); let f = 0; SCH.gruppen.forEach(g => farbe.set(g, (groesse.get(g) || 0) > 1 ? "sch-g" + (1 + (f++ % 5)) : "sch-g0"));
      const zeigen = bleibt.slice(0, GRENZE_ZEIGEN), ausLose = r => lose([r])[0];
      let t = '<table class="ra-tafel sch-tafel sch-haufen"><thead><tr>' + P.spalten.map(s => "<th>" + esc(s.name) + "</th>").join("") + '<th class="sch-pf"></th>' +
        SCH.gspalten.map(s => '<th class="sch-gerg">' + esc(s) + "</th>").join("") + "</tr></thead><tbody>";
      zeigen.forEach((r, i) => {
        const g = r.gruppe, erste = !i || zeigen[i - 1].gruppe !== g, n = zeigen.filter(x => x.gruppe === g).length;
        const c = [farbe.get(g), erste ? "sch-anfang" : "", schritt === "having" && !g.bleibt ? "sch-hweg" : "", mark(r) ? "markiert" : ""].filter(Boolean).join(" ");
        t += '<tr class="' + c + '">' + r.w.map(w => "<td>" + esc(w === null ? "" : w) + "</td>").join("");
        if (erste) t += '<td class="sch-pf" rowspan="' + n + '">⟹</td>' + ausLose(g.aus).map(w => '<td class="sch-gerg" rowspan="' + n + '">' + esc(w === null ? "" : w) + "</td>").join("");
        t += "</tr>";
      });
      const gz = schritt === "having" ? SCH.zahl.having : SCH.zahl.gruppiert;
      return { html: t + "</tbody></table>", gezeigt: zeigen.length, von: bleibt.length, hinweis: loseHinweis(null),
        unter: schritt === "having" ? zahl(SCH.zahl.gruppiert) + " Gruppen · HAVING behält " + zahl(gz) : zahl(bleibt.length) + (bleibt.length === 1 ? " Zeile · " : " Zeilen · ") + zahl(gz) + (gz === 1 ? " Gruppe" : " Gruppen") + " · je Gruppe eine Zeile" };
    }
    let zeilen = SCH.zeilen;
    if (hat("select")) zeilen = zeilen.filter(r => r.bleibt);
    const zuViele = schritt === "where" && zeilen.length > GRENZE_ZEIGEN;
    if (zuViele) zeilen = zeilen.filter(r => r.bleibt);
    const von = zeilen.length; zeilen = zeilen.slice(0, GRENZE_ZEIGEN);
    const deck = i => hat("select") && !P.sicht.includes(i);
    let t = '<table class="ra-tafel sch-tafel"><thead><tr>' + P.spalten.map((s, i) => "<th" + (deck(i) ? ' class="deck"' : "") + ">" + esc(s.name) + "</th>").join("") + "</tr></thead><tbody>";
    zeilen.forEach(r => {
      const mark = z.markiert != null && r.w.some(w => String(w) === String(z.markiert));
      const c = [schritt === "where" && !r.bleibt ? "weg" : "", schritt === "distinct" && r.doppelt ? "dopp" : "", mark ? "markiert" : ""].filter(Boolean).join(" ");
      t += "<tr" + (c ? ' class="' + c + '"' : "") + ">" + r.w.map((w, i) => "<td" + (deck(i) ? ' class="deck"' : "") + ">" + esc(w === null ? "" : w) + "</td>").join("") + "</tr>";
    });
    return { html: t + "</tbody></table>", gezeigt: zeilen.length, von, zuViele };
  }
  function tischSchritte() {
    tischEl.textContent = "";
    if (!SCH && !getippt && schFeld.value.trim()) schRechnen();
    if (SCH && SCH.basis !== z.schbasis) { const s = z.schSchritt; schRechnen(); z.schSchritt = s; }
    const P = SCH && SCH.P && !SCH.fehler ? SCH.P : null;
    if (P && z.schSchritt > P.schritte.length) z.schSchritt = P.schritte.length;
    const kopf = h("div", "sch-kopf"); tischEl.append(kopf);      // Zählleiste und Knöpfe in einer Zeile -- im Vortrag zählt jede
    if (P) {
      const l = h("div", "sch-zaehl");
      const kasten = (n, text, an, kommt) => { const k = h("div", (an ? "an" : "") + (kommt ? " kommt" : "")); k.append(h("b", n && String(n).length > 9 ? "lang" : "", kommt || n == null ? "?" : zahl(n)), h("span", "", text)); l.append(k); };
      if (SCH.kreuz != null) kasten(SCH.kreuz, "jede mit jeder", false, false);
      P.schritte.forEach((s, i) => kasten(SCH.mehr ? null : SCH.zahl[s], s === "verbunden" ? (SCH.kreuz != null ? "FROM, verbunden" : "FROM") : schName[s], i + 1 === z.schSchritt, i + 1 > z.schSchritt));
      kopf.append(l);
    }
    const feld = h("div", "abfrage-feld sch-feld");
    if (getippt) { schFeld.rows = Math.max(3, schFeld.value.split("\n").length); feld.append(schFeld); const hoehe = () => { schFeld.style.height = "auto"; schFeld.style.height = schFeld.scrollHeight + "px"; }; requestAnimationFrame(hoehe); if (!schFeld._hoehe) { schFeld._hoehe = true; schFeld.addEventListener("input", hoehe); } }
    if (!getippt || P) { const g = h("div", "sch-sql"); g.innerHTML = schSqlHtml(); feld.append(g); }
    const leiste = h("div", "leiste");
    const knopf = (text, cls, f, aus) => { const b = h("button", cls, text); b.type = "button"; b.disabled = !!aus; b.addEventListener("click", f); return b; };
    const n = P && !SCH.mehr ? P.schritte.length : 1;
    const vor = knopf("Schritt ▶", "primaer", () => schGehe("vor"), P && z.schSchritt >= n), zur = knopf("◀", "", () => schGehe("zurueck"), !z.schSchritt);
    zur.title = "einen Schritt zurück";
    leiste.append(zur, vor);
    if (getippt) leiste.append(h("small", "", "Strg+Enter: nächster Schritt"));
    leiste.append(h("span", "luft"));
    const bA = knopf("Auszug", z.schbasis === "auszug" ? "an" : "", () => { z.schbasis = "auszug"; zeichne(); }), bG = knopf("alle Zeilen", z.schbasis === "ganz" ? "an" : "", () => { z.schbasis = "ganz"; zeichne(); });
    const wahl = h("span", "dw-modus"); wahl.append(bA, bG); leiste.append(wahl);
    kopf.append(leiste); tischEl.append(feld);
    if (z.satz) { const s = h("div", "sch-satz"); s.append("Eine Zeile ist: ", h("i", "", z.satz)); tischEl.append(s); }
    if (SCH && SCH.fehler) { const e = h("div", "ergebnis fehler"); e.innerHTML = "<b>" + esc(SCH.fehler.titel) + "</b><p>" + SCH.fehler.text + "</p>" + (SCH.fehler.original ? "<details><summary>Meldung des DBMS</summary><pre>" + esc(SCH.fehler.original) + "</pre></details>" : ""); tischEl.append(e); return; }
    if (!P || !z.schSchritt) { const e = h("div", "ergebnis leer"); e.append(h("p", "", "Schritt ▶ geht die Anweisung durch, wie das DBMS sie liest: erst FROM.")); tischEl.append(e); return; }
    if (SCH.mehr) { tischEl.append(h("p", "warnung ts-abbruch", "Abgebrochen nach " + zahl(GRENZE_ZAEHLEN) + " Zeilen – so viele kann niemand lesen. Steht jede Tabelle mit einer Bedingung verbunden da?")); return; }
    const t = schTafel(P.schritte[z.schSchritt - 1]);
    const erg = h("div", "ergebnis"), box = h("div", "rahmen" + (t.nach ? " sch-kurz" : "")); box.innerHTML = t.html; erg.append(box);
    if (t.unter) erg.append(h("p", "sch-unter", t.unter));
    if (t.zuViele) erg.append(h("p", "hinweis", "Gezeigt sind nur die Zeilen, die bleiben."));
    else if (t.von > t.gezeigt) erg.append(h("p", "hinweis", "Gezeigt sind die ersten " + zahl(t.gezeigt) + "."));
    if (t.nach) { const d = h("div", "sch-nach"); d.innerHTML = t.nach; erg.append(d); }
    if (t.hinweis) { const p = h("p", "sch-lose"); p.innerHTML = t.hinweis; erg.append(p); }
    tischEl.append(erg);
  }

  // ── Tisch relalg: der Term arbeitet am Auszug (Fassung B, 19.11.2026) ──────────────────────────────────────────
  // R: das Gerechnete zum Term im Feld. schritte[i] = {art, zeichen, was, teilterm, auszug:{spalten,zeilen}, ganz:Zahl,
  // fehler}; basis = die Tabelle im Auszug. Schritt 0 = der Auszug, wie er auf dem Papier liegt.
  let R = null;
  const raFeld = h("textarea", "abfrage");
  raFeld.spellcheck = false; raFeld.rows = 1;
  raFeld.setAttribute("autocapitalize", "off"); raFeld.setAttribute("autocomplete", "off");
  raFeld.value = (opt.term || "").trim();
  raFeld.readOnly = !getippt;
  raFeld.addEventListener("input", () => { if (R) { R = null; z.raSchritt = 0; zeichne(); raFeld.focus(); } });
  raFeld.addEventListener("keydown", ev => { if (ev.key === "Enter" && (ev.ctrlKey || ev.metaKey)) { ev.preventDefault(); raGehe("ende"); } });
  const raDeuten = e => (e && e.titel) ? { titel: e.titel, text: e.text } : { titel: "Das DBMS meldet einen Fehler", text: esc(String(e && e.message || e)) };
  const raZahl = (d, term) => d.exec("SELECT COUNT(*) FROM (" + raSql(d, term).sql + ")")[0].values[0][0];
  function raRechnen() {
    const term = raFeld.value.trim();
    R = { term, schritte: [], linear: true, fehler: null, tabelle: null, basis: null, gesetzt: "" };
    z.raSchritt = 0;
    if (!term) { R.fehler = { titel: "Noch kein Term", text: "Gebt einen Term ein, zum Beispiel <code>σ[Farbe = 'rot'](Fahrzeug)</code>." }; return; }
    let baum;
    try { baum = raLesen(term); R.gesetzt = raSetzen(term); } catch (e) { R.fehler = raDeuten(e); return; }
    const kette = []; let b = baum;
    while (b.art === "sel" || b.art === "proj") { kette.unshift(b); b = b.kind; }
    if (b.art !== "tab") {
      // mit ⋈ oder ×: der Operatorbaum (aneinander, 19.11.2026) -- Schritt für Schritt von den Tabellen zur Wurzel
      R.linear = false;
      try { R.auszugErg = raAusfuehren(adb, term); R.ganzErg = raAusfuehren(db, term, { zeigen: GRENZE_ZEIGEN, zaehlen: GRENZE_ZAEHLEN }); }
      catch (e) { R.fehler = raDeuten(e); return; }
      raBaumDaten();
      return;
    }
    try { R.basis = raAlle(adb, b.name); } catch (e) { R.fehler = raDeuten(e); return; }
    const echt = steckbriefe.find(s => s.name.toLowerCase() === b.name.toLowerCase());
    R.tabelle = echt.name; R.gesamt = echt.zeilen;
    const text = k => k.art === "tab" ? k.name : (k.art === "sel" ? "σ[" + k.bed + "](" : "π[" + k.attrs.join(", ") + "](") + text(k.kind) + ")";
    R.tabelleGetippt = b.name;
    R.schritte = kette.map(k => ({ art: k.art, zeichen: k.art === "sel" ? "σ" : "π", was: k.art === "sel" ? k.bed : k.attrs.join(", "), teilterm: text(k) }));
    for (const s of R.schritte) {
      try { s.auszug = raAlle(adb, s.teilterm); s.ganz = raZahl(db, s.teilterm); }
      catch (e) { s.fehler = raDeuten(e); break; }
    }
  }
  // der Auszug nach `bis` Schritten: welche Zeilen gestrichen, welche Spalten abgedeckt, welche doppelt
  function raBild(bis) {
    const sp = R.basis.spalten, n = x => String(x).toLowerCase();
    let sicht = sp.map(() => true); const weg = new Set(); const je = [];
    for (let i = 0; i < bis; i++) {
      const s = R.schritte[i];
      if (!s || s.fehler) break;
      const kopf = s.auszug.spalten, pos = kopf.map(k => sp.findIndex(x => n(x) === n(k.split(".").pop())));
      if (s.art === "proj") {
        const neu = sp.map((x, j) => pos.includes(j));
        je.push(sicht.filter((v, j) => v && !neu[j]).length); sicht = neu;
      } else {
        const bleibt = new Set(s.auszug.zeilen.map(r => JSON.stringify(r.map(String))));
        let k = 0;
        R.basis.zeilen.forEach((r, j) => { if (!weg.has(j) && !bleibt.has(JSON.stringify(pos.map(p => String(r[p]))))) { weg.add(j); k++; } });
        je.push(k);
      }
    }
    const doppelt = new Set(), gesehen = new Set();
    if (sicht.some(v => !v)) R.basis.zeilen.forEach((r, j) => {
      if (weg.has(j)) return;
      const key = JSON.stringify(r.filter((v, i) => sicht[i]).map(String));
      if (gesehen.has(key)) doppelt.add(j); else gesehen.add(key);
    });
    return { sicht, weg, doppelt, je };
  }
  // ── Operatorbaum (aneinander, 19.11.2026; Form aus der Datenwerkstatt, gebaut 12.10.: raBaum in relalg.js) ──
  // Der Term als Baum: Tabellen unten, Wurzel oben, jeder Operator mit Schrittnummer (linker Ast, rechter Ast, dann der
  // Knoten) und Zeilenzahl. Stufe 0 = nur die Tabellen, Stufe k = Schritte 1..k gerechnet; spätere Knoten sind blass
  // und ohne Zahl (die Klasse soll vorhersagen). Antippen zeigt das Zwischenergebnis. Keine Sätze: Erläutern bleibt
  // Aufgabe der Klasse. Bei ⋈ und × steht immer der Baum; bei σ/π auf einer Tabelle schaltet baum="ja" ihn zu.
  const baumAn = () => !!(R && !R.fehler && (!R.linear || z.raBaum));
  function raBaumDaten() {
    const basis = z.rabasis === "ganz" ? "ganz" : "auszug";
    R.baum = R.baum || {};
    R.baumFehler = R.baumFehler || {};
    if (!R.baum[basis] && !R.baumFehler[basis]) {
      try { R.baum[basis] = raBaum(basis === "ganz" ? db : adb, R.term, { zaehlen: GRENZE_ZAEHLEN }); }
      catch (e) { R.baumFehler[basis] = raDeuten(e); }
    }
    return R.baum[basis] || null;
  }
  const raLetzter = () => {
    if (baumAn()) { const d = raBaumDaten(); return d ? d.schritte : 0; }
    const f = R.schritte.findIndex(s => s.fehler); return f >= 0 ? f + 1 : R.schritte.length;
  };
  function raGehe(wohin) {
    if (!db || !adb) return;
    wegFrei = true;
    if (!R) { raRechnen(); if (wohin === "zurueck") wohin = 0; }
    if (R) R.wahl = null;
    if (wohin === "ende") z.raSchritt = raLetzter();
    else if (wohin === "vor") z.raSchritt = Math.min(raLetzter(), (z.raSchritt || 0) + 1);
    else if (wohin === "zurueck") z.raSchritt = Math.max(0, (z.raSchritt || 0) - 1);
    else z.raSchritt = wohin;
    zeichne();
  }
  // Der Term als Zeile in den Farben seiner Schritte (Durchsicht streichen W3/W4, 19.11.2026: „unschön, dass die Zeile so
  // umbricht und die Schriftart ist nicht schön“ · „Kann man die Schritte auch farblich im Ausdruck markieren?“): jeder
  // Handgriff in der Farbe seiner Karte, der von jetzt hinterlegt; umbrochen wird nur zwischen den Teilen.
  function raTermZeile() {
    const n = R.schritte.length;
    const teil = k => {
      if (k < 0) return '<span class="ra-tab">' + esc(R.tabelleGetippt) + "</span>";
      const s = R.schritte[k], jetzt = k === z.raSchritt - 1 ? " jetzt" : "";
      // Umbruch nur zwischen den Teilen und zwischen den Vergleichen einer Bedingung -- „Farbe = 'rot'“ bleibt zusammen
      const stuecke = s.art === "sel" ? s.was.split(/\s+(?=(?:AND|OR|∧|∨)\s)/i) : s.was.split(/,\s*/).map((x, i, a) => i < a.length - 1 ? x + "," : x);
      stuecke[0] = s.zeichen + "[" + stuecke[0]; stuecke[stuecke.length - 1] += "](";
      const auf = stuecke.map(x => '<span class="ra-w">' + esc(x) + "</span>").join(" ");
      return '<span class="ra-teil st' + (k % 5) + jetzt + '"><span class="ra-op">' + auf + "</span><wbr>" + teil(k - 1) + '<wbr><span class="ra-op">)</span></span>';
    };
    const d = h("div", "ra-term"); d.innerHTML = teil(n - 1);
    return d;
  }
  // Derselbe Term als Zeile in den Farben der Baumschritte (Durchsicht aneinander W2, 20.11.2026: „Der Ausdruck sollte
  // auch nochmal da stehen und auch schrittweise farblich markiert werden“). Nummeriert wie raBaum: linker Ast, rechter
  // Ast, dann der Knoten; jeder Handgriff in der Farbe seines Schritts, der von jetzt hinterlegt, die späteren blass.
  function raBaumZeile(stufe) {
    let n = 0;
    const op = (x, k) => '<span class="ra-op">' + x + "</span>";
    const teil = b => {
      if (b.art === "tab") return '<span class="ra-tab">' + esc(b.name) + "</span>";
      if (b.art === "sel" || b.art === "proj") {
        const innen = teil(b.kind), nr = ++n;
        const stuecke = b.art === "sel" ? b.bed.split(/\s+(?=(?:AND|OR|∧|∨)\s)/i) : b.attrs.map((x, i, a) => i < a.length - 1 ? x + "," : x);
        stuecke[0] = (b.art === "sel" ? "σ[" : "π[") + stuecke[0]; stuecke[stuecke.length - 1] += "](";
        const auf = stuecke.map(x => '<span class="ra-w">' + esc(x) + "</span>").join(" ");
        return '<span class="ra-teil st' + ((nr - 1) % 5) + (nr === stufe ? " jetzt" : nr > stufe ? " kommt" : "") + '">' + op(auf) + "<wbr>" + innen + "<wbr>" + op(")") + "</span>";
      }
      const l = teil(b.l), r = teil(b.r), nr = ++n;
      const rechts = (b.r.art === "join" || b.r.art === "kreuz") ? op("(") + r + op(")") : r;
      return '<span class="ra-teil st' + ((nr - 1) % 5) + (nr === stufe ? " jetzt" : nr > stufe ? " kommt" : "") + '">' + l + " <wbr>" + op(b.art === "kreuz" ? "×" : "⋈") + " " + rechts + "</span>";
    };
    let baum; try { baum = raLesen(R.term); } catch (e) { return null; }
    const d = h("div", "ra-term ra-baumterm"); d.innerHTML = teil(baum);
    return d;
  }
  function raEinfuegen(text) {
    const a = raFeld.selectionStart, e = raFeld.selectionEnd;
    raFeld.value = raFeld.value.slice(0, a) + text + raFeld.value.slice(e);
    raFeld.selectionStart = raFeld.selectionEnd = a + text.length;
    raFeld.dispatchEvent(new Event("input")); raFeld.focus();
  }
  function tischRelalg() {
    tischEl.textContent = "";
    const feld = h("div", "abfrage-feld ra-feld" + (getippt ? "" : " fest"));
    const leiste = h("div", "leiste");
    if (getippt) {
      // AND, OR, NOT statt ∧ ∨ ¬ (Reihensichtung iq2 Teil I, 23.11.2026, LT14): eingeführt sind die Wörter, und das Abitur
      // schreibt σ[Vorname = 'Jan' AND Nachname = 'Meier'] (LA25). Gelesen werden ∧ ∨ ¬ weiter (relalg.js).
      const zeichen = [["σ", "σ["], ["π", "π["], ["AND", " AND "], ["OR", " OR "], ["NOT", "NOT "]].concat(String(opt.verbund) === "ja" ? [["⋈", " ⋈ "], ["×", " × "]] : []);
      zeichen.forEach(([z_, ein]) => { const b = h("button", "ra-zeichen" + (/^[A-Z]/.test(z_) ? " wort" : ""), z_); b.type = "button"; b.title = z_ + " einfügen"; b.addEventListener("click", () => raEinfuegen(ein)); leiste.append(b); });
    }
    leiste.append(h("span", "luft"));
    const zur = h("button", "ruhig", "◀"); zur.type = "button"; zur.title = "einen Schritt zurück";
    const vor = h("button", "primaer", "Schritt ▶"); vor.type = "button";
    const ende = h("button", "", "Ergebnis"); ende.type = "button"; ende.title = "alle Schritte (Strg+Enter)";
    zur.addEventListener("click", () => raGehe("zurueck")); vor.addEventListener("click", () => raGehe("vor")); ende.addEventListener("click", () => raGehe("ende"));
    const gesamt = R && R.gesamt != null ? R.gesamt : null;
    const bA = h("button", z.rabasis === "auszug" ? "an" : "", "Auszug"); bA.type = "button";
    const bG = h("button", z.rabasis === "ganz" ? "an" : "", "alle" + (gesamt != null ? " " + zahl(gesamt) : "") + " Zeilen"); bG.type = "button";
    bA.addEventListener("click", () => { z.rabasis = "auszug"; zeichne(); }); bG.addEventListener("click", () => { z.rabasis = "ganz"; zeichne(); });
    const basisWahl = h("span", "dw-modus"); basisWahl.append(bA, bG);
    leiste.append(zur, vor, ende);
    // der Schalter „Baum“ nur, wo es auch ohne Baum geht (σ/π auf einer Tabelle) und das Thema ihn freigibt
    if (String(opt.baum) === "ja" && (!R || R.linear)) {
      const bb = h("button", "ra-baumknopf" + (z.raBaum ? " an" : ""), "Baum"); bb.type = "button"; bb.title = "den Term als Operatorbaum zeigen";
      bb.setAttribute("aria-pressed", z.raBaum ? "true" : "false");
      bb.addEventListener("click", () => { z.raBaum = !z.raBaum; if (R) R.wahl = null; zeichne(); });
      leiste.append(bb);
    }
    leiste.append(basisWahl);
    if (R && !R.fehler && (R.linear || baumAn())) { zur.disabled = !z.raSchritt; vor.disabled = z.raSchritt >= raLetzter(); }
    const zeile = R && R.linear && !R.fehler && R.schritte.length && !baumAn() ? raTermZeile() : null;
    if (zeile && !getippt) feld.append(zeile, leiste);       // im Vortrag: die Zeile statt des Feldes
    else if (baumAn() && !getippt) { const bz = raBaumZeile(Math.min(z.raSchritt || 0, (raBaumDaten() || {}).schritte || 0)); if (bz) feld.append(bz); feld.append(leiste); }   // im Vortrag mit Baum: die farbige Zeile statt des Feldes (W2, 20.11.)
    else { feld.append(raFeld, leiste); if (zeile) feld.append(zeile); else if (baumAn()) { const bz = raBaumZeile(Math.min(z.raSchritt || 0, (raBaumDaten() || {}).schritte || 0)); if (bz) feld.append(bz); } }
    // die Abiturform nur beim Tippen -- im Vortrag zeigt sie die Folie davor, und doppelt umbrochen stört sie (W3, 19.11.)
    if (R && R.gesetzt && getippt) { const g = h("div", "ra-gesetzt"); g.innerHTML = "<span>im Abitur:</span> " + R.gesetzt; feld.append(g); }
    else if (getippt) feld.append(h("small", "", "Strg+Enter rechnet alles, Schritt ▶ einen Handgriff nach dem anderen – von innen nach außen."));
    tischEl.append(feld);
    const hoehe = () => { raFeld.style.height = "auto"; raFeld.style.height = raFeld.scrollHeight + "px"; };
    requestAnimationFrame(hoehe);
    if (!raFeld._hoehe) { raFeld._hoehe = true; raFeld.addEventListener("input", hoehe); }
    if (!R) { tischEl.append(h("div", "ergebnis leer", null)); tischEl.lastChild.append(h("p", "", "Schritt ▶ rechnet den Term – erst den innersten Handgriff.")); return; }
    if (R.fehler) { raFehlerKasten(R.fehler); return; }
    if (baumAn()) { raBaumZeigen(); return; }
    const bild = raBild(z.raSchritt);
    const leiste2 = h("div", "ra-schritte");
    R.schritte.forEach((s, i) => {
      const k = h("div", "ra-schritt st" + (i % 5) + (i < z.raSchritt ? " getan" : "") + (i === z.raSchritt - 1 ? " an" : "") + (i >= z.raSchritt ? " kommt" : "") + (s.fehler && i < z.raSchritt ? " falsch" : ""));
      k.innerHTML = '<b class="nr">' + (i + 1) + '</b><span class="op">' + s.zeichen + "</span> " + (s.art === "sel" ? "streicht Zeilen: " : "deckt Spalten ab, es bleiben: ") + esc(s.was) +
        (i < z.raSchritt ? (s.fehler ? " — <b>geht nicht</b>" : z.rabasis === "ganz" ? " — <b>" + zahl(s.ganz) + " Zeilen bleiben</b>"
          : " — <b>" + bild.je[i] + (s.art === "sel" ? " gestrichen" : " abgedeckt") + "</b>") : "");
      k.addEventListener("click", () => raGehe(i + 1));
      leiste2.append(k);
    });
    tischEl.append(leiste2);
    const s = R.schritte[z.raSchritt - 1];
    if (s && s.fehler) { raFehlerKasten(s.fehler); }
    if (z.rabasis === "ganz") {
      const term = z.raSchritt ? (s && s.fehler ? R.schritte[z.raSchritt - 2] : s) : null;
      const t = term ? term.teilterm : R.tabelle;
      raErgebnis(raAusfuehren(db, t, { zeigen: GRENZE_ZEIGEN, zaehlen: GRENZE_ZAEHLEN }), z.raSchritt ? "von " + zahl(R.gesamt) + " in " + R.tabelle : "die ganze Tabelle " + R.tabelle);
      return;
    }
    const erg = h("div", "ergebnis");
    const bleiben = R.basis.zeilen.length - bild.weg.size - bild.doppelt.size;
    const kopf = h("div", "kopf");
    kopf.append(h("span", "zahl", z.raSchritt ? bleiben + (bleiben === 1 ? " Zeile bleibt" : " Zeilen bleiben") : "Der Auszug"),
      h("span", "dauer", "Auszug " + R.tabelle + " · " + R.basis.zeilen.length + " von " + zahl(R.gesamt) + " Zeilen"));
    const sb = steckbriefe.find(x => x.name === R.tabelle);
    let t = "<table class=\"ra-tafel\"><thead><tr>" + R.basis.spalten.map((n, i) => {
      const c = sb && sb.spalten[i];
      return "<th" + (bild.sicht[i] ? "" : ' class="deck"') + ">" + (c && c.fremd ? "↑" : "") + (c && c.schluessel ? "<u>" + esc(n) + "</u>" : esc(n)) + "</th>";
    }).join("") + "</tr></thead><tbody>";
    R.basis.zeilen.forEach((r, j) => {
      t += "<tr" + (bild.weg.has(j) ? ' class="weg"' : bild.doppelt.has(j) ? ' class="doppelt"' : "") + ">" +
        r.map((w, i) => "<td" + (bild.sicht[i] ? "" : ' class="deck"') + ">" + (w === null ? "" : esc(w)) + "</td>").join("") + "</tr>";
    });
    const box = h("div", "rahmen"); box.innerHTML = t + "</tbody></table>";
    erg.append(kopf, box);
    const legende = [];
    if (bild.weg.size) legende.push('<span class="l-weg">gestrichen</span>');
    if (bild.sicht.some(v => !v)) legende.push('<span class="l-deck">abgedeckt</span>');
    if (bild.doppelt.size) legende.push('<span class="l-doppelt">doppelt – zählt einmal</span>');
    if (!z.raSchritt) legende.push("Schritt ▶ zeigt, was der Term tut – von innen nach außen.");
    if (legende.length) { const l = h("p", "ra-legende"); l.innerHTML = legende.join(" · "); erg.append(l); }
    tischEl.append(erg);
  }
  function raBaumZeigen() {
    const d = raBaumDaten();
    if (!d) { raFehlerKasten((R.baumFehler || {})[z.rabasis === "ganz" ? "ganz" : "auszug"] || { titel: "Der Baum lässt sich nicht rechnen", text: "" }); return; }
    const stufe = Math.min(z.raSchritt || 0, d.schritte);
    const stufenKnoten = stufe ? d.knoten.find(k => k.schritt === stufe) : null;
    const wahl = R.wahl != null ? d.knoten[R.wahl] : stufenKnoten;
    const zz = k => (k.mehr ? "über " : "") + zahl(k.anzahl) + (k.anzahl === 1 ? " Zeile" : " Zeilen");
    const knotenHtml = k => {
      const op = k.art !== "tab", spaeter = op && k.schritt > stufe;
      const cls = "bk" + (op ? " st" + ((k.schritt - 1) % 5) : " blatt") + (wahl && wahl.nr === k.nr ? " gewaehlt" : "") + (spaeter ? " spaeter" : "");
      const knopf = '<button type="button" class="' + cls + '" data-nr="' + k.nr + '">' +
        (op ? '<span class="nr">' + k.schritt + "</span>" : "") + '<span class="sym">' + k.zeichen + "</span>" +
        (k.handgriff ? '<span class="hg">' + esc(k.handgriff) + "</span>" : "") +
        '<span class="zz">' + (spaeter ? "?" : zz(k)) + "</span></button>";
      return knopf + (k.kinder.length ? "<ul>" + k.kinder.map(c => "<li>" + knotenHtml(c) + "</li>").join("") + "</ul>" : "");
    };
    const flaeche = h("div", "ra-baum" + (getippt ? "" : " vortrag"));   // im Vortrag ohne Handgriff-Wörter: die Zeile darüber trägt die Schritte (W2, 20.11.)
    flaeche.innerHTML = '<ul class="bt"><li>' + knotenHtml(d.wurzel) + "</li></ul>";
    flaeche.addEventListener("click", ev => {
      const b = ev.target.closest(".bk"); if (!b) return;
      const k = d.knoten[+b.dataset.nr];
      if (k.schritt > stufe) z.raSchritt = k.schritt;      // ein späterer Knoten rechnet bis dorthin
      R.wahl = k.nr; wegFrei = true; zeichne();
    });
    const stand = h("p", "ra-baumstand", stufe ? "Schritt " + stufe + " von " + d.schritte : "Nur die Tabellen – Schritt ▶ rechnet den ersten Handgriff, von innen nach außen.");
    tischEl.append(flaeche, stand);
    if (!wahl) return;
    const e = raKnotenZeilen(z.rabasis === "ganz" ? db : adb, wahl, { zeigen: GRENZE_ZEIGEN });
    const erg = h("div", "ergebnis");
    const kopf = h("div", "kopf");
    const titel = h("span", "zahl ra-baumtitel");
    titel.innerHTML = (wahl.schritt ? "Schritt " + wahl.schritt + ": " : "Tabelle ") + '<span class="term">' + wahl.teilterm + "</span>";
    kopf.append(titel, h("span", "dauer", zz(wahl) + " · " + wahl.kopf.length + (wahl.kopf.length === 1 ? " Attribut" : " Attribute") + (z.rabasis === "ganz" ? " · alle Zeilen" : " · aus dem Auszug")));
    const box = h("div", "rahmen"); box.innerHTML = e.anzahl ? tabelleHtml(e.spalten, e.zeilen) : '<p class="leer">Hier ist die Menge leer: keine Zeile.</p>';
    erg.append(kopf, box);
    if (stufe === d.schritte) (d.hinweise || []).forEach(x => { const p = h("p", "hinweis"); p.innerHTML = x; erg.append(p); });
    if (wahl.mehr) erg.append(h("p", "warnung", "Abgebrochen nach " + zahl(GRENZE_ZAEHLEN) + " Zeilen – so viele kann niemand lesen."));
    else if (e.anzahl > e.zeilen.length) erg.append(h("p", "hinweis", "Gezeigt sind die ersten " + zahl(e.zeilen.length) + "."));
    tischEl.append(erg);
  }
  function raFehlerKasten(f) {
    const e = h("div", "ergebnis fehler");
    e.innerHTML = "<b>" + esc(f.titel) + "</b><p>" + f.text + "</p>";
    tischEl.append(e);
  }
  function raErgebnis(e, wo) {
    const erg = h("div", "ergebnis");
    const kopf = h("div", "kopf");
    kopf.append(h("span", "zahl", (e.mehr ? "über " : "") + zahl(e.anzahl) + (e.anzahl === 1 ? " Zeile" : " Zeilen")), h("span", "dauer", wo));
    const box = h("div", "rahmen"); box.innerHTML = tabelleHtml(e.spalten, e.zeilen);
    erg.append(kopf, box);
    (e.hinweise || []).forEach(x => { const p = h("p", "hinweis"); p.innerHTML = x; erg.append(p); });
    if (e.mehr) erg.append(h("p", "warnung", "Abgebrochen nach " + zahl(GRENZE_ZAEHLEN) + " Zeilen – so viele kann niemand lesen."));
    else if (e.anzahl > e.zeilen.length) erg.append(h("p", "hinweis", "Gezeigt sind die ersten " + zahl(e.zeilen.length) + "."));
    tischEl.append(erg);
  }

  function zeichne() {
    reiter.querySelectorAll("button").forEach(b => b.classList.toggle("an", b.dataset.tisch === z.tisch));
    if (!db || (mitRa && !adb)) return;
    if (z.tisch === "sql") tischSql(); else if (z.tisch === "relalg") tischRelalg(); else if (z.tisch === "term-sql") tischTermSql(); else if (z.tisch === "schritte") tischSchritte(); else tischTabellen();
    raster.classList.toggle("ohne-plan", z.tisch === "schritte" || (z.tisch === "term-sql" && tsLang()));
    planMarkieren();
    if (z.markiert != null) wurzel.dataset.markiere = z.markiert; else delete wurzel.dataset.markiere;   // datenfilm.mjs prüft, dass die Zeile auch da ist
    // die markierte Zeile (Gruppe: alle ihre Zeilen) knapp unter den Kopf des Rahmens, nicht in seine Mitte -- ein hoher
    // Rahmen reicht unter den Bildrand, dort lag die Gruppe 4127 halb verdeckt (iq2 gruppieren, 23.11.2026)
    const mark = tischEl.querySelector("tr.markiert");
    if (mark) { const box = mark.closest(".rahmen"); if (box) box.scrollTop = Math.max(0, mark.offsetTop - 2.5 * mark.offsetHeight); }
  }

  // Der Film rollt zum Ergebnis (Lehrer 22.11.2026, Durchsicht join: „ja, beides“): Im Vortrag lag das Ergebnis unter einer
  // langen Anweisung unter dem Rand -- von den zehn Namen sah man den Tabellenkopf. Der Plan bleibt stehen, wenn er passt.
  // Seit der Reihensichtung iq2 Teil I (23.11.2026, LV10: „Die markierte Zeile steht im Bild“): für JEDEN Tisch, auch relalg
  // (mit und ohne Baum) und term-sql -- in aneinander Schritt 13 fragte der Impuls nach der Bedeutung des Ergebnisses, und
  // das Ergebnis lag unter dem Baum unter dem Rand. Ins Bild kommt, was der Film zeigt: Ergebnis samt Kopf, Urteil,
  // Abbruch, Meldung, die markierte Zeile, was unter dem Kasten steht (Pfeil, die eine Zeile, der Satz zur losen Spalte).
  // So weit wie nötig, höchstens bis das Erste davon oben anliegt; im Tisch schritte nie über die Zeile des Schritts hinaus.
  // Passt es auch dann nicht, wird der Tabellenrahmen kürzer (höchstens bis auf drei Zeilen) und rollt in sich, eine
  // markierte Zeile darin bleibt zu sehen. Ohne Ergebnis (Schritt 0, nur der Baum) steht der Rahmen oben.
  // datenfilm.mjs zählt jedes „UNTER DEM RAND“ als Fehler.
  function rollen() {
    if (getComputedStyle(wurzel).overflowY !== "auto") return;
    requestAnimationFrame(() => requestAnimationFrame(() => {
      const hoch = wurzel.clientHeight;
      const zweispaltig = getComputedStyle(raster).gridTemplateColumns.split(" ").length > 1;
      const svg = planEl.querySelector("svg");
      if (svg) svg.style.maxHeight = zweispaltig ? Math.max(160, hoch - (planEl.offsetHeight - svg.clientHeight) - 2) + "px" : "";   // passt er nicht (groß, kleiner Schirm), wird er kleiner
      planEl.classList.toggle("haftet", zweispaltig && planEl.offsetHeight <= hoch);
      const y = (e, seite) => e.getBoundingClientRect()[seite] - (wurzel.getBoundingClientRect().top - wurzel.scrollTop);
      const sicht = e => !!(e && e.offsetParent);
      const SACHE = ".ts-vergleich, .ts-abbruch, .warnung, .ergebnis.fehler, .ergebnis:not(.leer) .rahmen, .ts-zwei .rahmen, tr.markiert, .ergebnis .sch-nach, .ergebnis .sch-lose, .sch-lose";
      const teile = () => [...tischEl.querySelectorAll(SACHE)].filter(sicht);
      // der Kopf gehört zum Rahmen: „3 Zeilen bleiben“, „Term · Auszug · 2 Zeilen“
      const anker = e => e.matches(".rahmen, tr") ? (e.closest(".ergebnis, .ts-ergebnis") || e.closest(".rahmen") || e) : e;
      const jetzt = z.tisch === "schritte" ? wurzel.querySelector(".sch-sql > div.jetzt, .sch-sql > div:has(> .jetzt)") : null;
      const masse = () => {
        const t = teile(); if (!t.length) return null;
        let A = Math.min(...t.map(e => y(anker(e), "top"))), B = Math.max(...t.map(e => y(e, "bottom")));
        if (jetzt) A = Math.min(A, y(jetzt, "top") - 6);
        return { A, B };
      };
      const markZeigen = box => {
        const mark = [...box.querySelectorAll("tr.markiert")].pop(); if (!mark) return;
        box.scrollTop = Math.max(0, mark.offsetTop - 2.5 * mark.offsetHeight);
        const kopfH = (box.querySelector("thead") || {}).offsetHeight || 0;
        if (mark.offsetTop + mark.offsetHeight > box.scrollTop + box.clientHeight) box.scrollTop = mark.offsetTop + mark.offsetHeight - box.clientHeight + 4;
        if (mark.offsetTop < box.scrollTop + kopfH) box.scrollTop = Math.max(0, mark.offsetTop - kopfH - 2);
      };
      let m = masse();
      if (m && m.B - m.A > hoch - 12) {
        const rahmen = [...new Set(teile().map(e => e.matches(".rahmen") ? e : e.matches("tr") ? e.closest(".rahmen") : null).filter(Boolean))];
        const reihen = new Set(rahmen.map(r => Math.round(y(r, "top") / 24))).size || 1;   // nebeneinander zählen einmal
        const zuviel = m.B - m.A - (hoch - 12);
        rahmen.forEach(r => {
          const kopfH = (r.querySelector("thead") || {}).offsetHeight || 0, zeile = (r.querySelector("tbody tr") || {}).offsetHeight || 24;
          r.style.maxHeight = Math.max(kopfH + 3 * zeile + 6, r.getBoundingClientRect().height - Math.ceil(zuviel / reihen)) + "px";
          markZeigen(r);
        });
        m = masse();
      }
      const nach = m ? Math.max(0, Math.min(m.B + 8 - hoch, m.A)) : 0;
      wurzel.scrollTo({ top: nach, behavior: "smooth" });
    }));
  }

  // ── Film ────────────────────────────────────────────────────────────────────────────────────────────────────
  function schritt(x) {
    const a = x.aktion;
    if (a === "neu") { z = Object.assign({}, START, { sort: [] }); abfrageEl.value = sqlSchoen(opt.abfrage); tsFeld.value = schFeld.value = sqlSchoen(opt.abfrage); TS = null; SCH = null; if (mitRa) { raFeld.value = (opt.term || "").trim(); R = null; if (raFeld.value) raRechnen(); } }
    else if (z.tisch === "term-sql" && a === "abfrage") { tsFeld.value = sqlSchoen(x.befehl); TS = null; }
    else if (z.tisch === "term-sql" && a === "ausführen") { tsRechnen(); }
    else if (z.tisch === "term-sql" && (a === "ganz" || a === "auszug")) { z.tsbasis = a; if (TS) tsRechnen(); }
    else if (z.tisch === "schritte" && a === "abfrage") { schFeld.value = sqlSchoen(x.befehl); SCH = null; z.schSchritt = 0; z.satz = ""; z.markiert = null; }
    else if (z.tisch === "schritte" && (a === "schritt" || a === "zurück")) { z.markiert = null; z.satz = ""; schGehe(a === "schritt" ? "vor" : "zurueck"); return; }
    else if (z.tisch === "schritte" && a === "ausführen") { schGehe("ende"); return; }
    else if (z.tisch === "schritte" && (a === "ganz" || a === "auszug")) { z.schbasis = a; z.satz = ""; }
    else if (a === "satz") z.satz = x.befehl;
    else if (a === "term") { raFeld.value = x.befehl; if (mitRa) z.tisch = "relalg"; raRechnen(); }
    else if (a === "schritt") { if (mitRa) z.tisch = "relalg"; raGehe("vor"); return; }
    else if (a === "zurück") { if (mitRa) z.tisch = "relalg"; raGehe("zurueck"); return; }
    else if (a === "baum") { if (mitRa) { z.tisch = "relalg"; z.raBaum = true; if (R) R.wahl = null; } }
    else if (a === "ausführen" && z.tisch === "relalg") { raGehe("ende"); return; }
    else if ((a === "ganz" || a === "auszug") && z.tisch === "relalg") z.rabasis = a;
    // eine zweite Abfrage im selben Schritt (tabellen, 18.11.: „Und die Autos?“) -- steht da, laeuft erst mit + ausführen
    else if (a === "abfrage") { abfrageEl.value = sqlSchoen(x.befehl); z.ergebnis = null; z.fehler = null; z.markiert = null; if (tische.includes("sql")) z.tisch = "sql"; }
    else if (a === "ausführen") { if (tische.includes("sql")) z.tisch = "sql"; abfrage(); return; }
    else if (a === "tabelle") { z.tabelle = x.wert; z.modus = "auszug"; z.seite = 0; z.sort = []; if (tische.includes("tabellen")) z.tisch = "tabellen"; }
    else if (a === "auszug") z.modus = "auszug";
    else if (a === "ganz") { z.modus = "ganz"; z.seite = 0; }
    else if (a === "markiere") z.markiert = x.wert;
    zeichne();
  }
  // Vor dem Laden gilt nur der letzte Auftrag (herstellen ersetzt alles davor); danach laeuft jeder sofort
  const bereit = () => db && (!mitRa || adb);
  function wennBereit(f) { const g = ++generation; if (bereit()) { f(); return; } fertig.then(() => { if (g === generation && bereit()) f(); }); }
  const film = {
    spielen: x => wennBereit(() => { schritt(x); rollen(); }),
    herstellen: liste => wennBereit(() => { schritt({ aktion: "neu" }); (liste || []).forEach(schritt); rollen(); }),
    laeuft: () => false,
  };

  tischEl.append(h("p", "laedt", "Die Datenbank lädt …"));
  const fertig = laden().then(r => (mitRa ? raLaden() : null)).then(() => W._laden).then(r => {
    db = r.db; auszug = r.auszug;
    if (!W._steckbriefe) W._steckbriefe = q("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY rowid").map(x => steckbrief(x[0]));
    steckbriefe = W._steckbriefe;
    // der Auszug vom Papier als zweite Datenbank (Tisch relalg) -- dieselben Tabellen, je zehn Zeilen
    if (mitRa) { if (!W._adb) W._adb = raAusdruckBauen(r.SQL, db, auszug); adb = W._adb; if (raFeld.value) raRechnen(); }
    planZeichnen(); zeichne();
    if (window.ResizeObserver) new ResizeObserver(() => { const q = wurzel.clientWidth > 0 && wurzel.clientWidth < 720; if (q !== planQuer) { planZeichnen(); planMarkieren(); } }).observe(wurzel);
  }).catch(e => { tischEl.textContent = ""; tischEl.append(h("p", "fehler", "Die Datenbank lädt nicht: " + (e && e.message || e))); });

  const raZustand = () => {
    if (!R) return { gerechnet: false };
    const s = R.schritte[z.raSchritt - 1], bild = R.linear && R.basis ? raBild(z.raSchritt) : null;
    return { gerechnet: true, schritt: z.raSchritt, schritte: R.schritte.length, basis: z.rabasis, linear: R.linear, tabelle: R.tabelle,
      fehler: R.fehler ? R.fehler.titel : s && s.fehler ? s.fehler.titel : null,
      gestrichen: bild ? bild.weg.size : null, abgedeckt: bild ? bild.sicht.filter(v => !v).length : null, doppelt: bild ? bild.doppelt.size : null,
      bleiben: bild && R.basis ? R.basis.zeilen.length - bild.weg.size - bild.doppelt.size : null,
      ganz: s && !s.fehler ? s.ganz : null,
      baum: baumAn() ? (d => d ? { schritte: d.schritte, wahl: R.wahl, anzahl: (R.wahl != null ? d.knoten[R.wahl] : d.knoten.find(k => k.schritt === z.raSchritt) || {}).anzahl } : null)(raBaumDaten()) : null };
  };
  return { film, zustand: () => ({ tisch: z.tisch, tabelle: z.tabelle, modus: z.modus, seite: z.seite, markiert: z.markiert, bereit: !!bereit(),
    zeilen: z.ergebnis ? z.ergebnis.anzahl : null, fehler: z.fehler ? z.fehler.titel : null, ra: mitRa ? raZustand() : null,
    ts: TS ? { basis: z.tsbasis, gleich: TS.vergleich ? !!TS.vergleich.ok : null, text: TS.vergleich ? TS.vergleich.text : null,
      termZeilen: TS.term_e ? TS.term_e.anzahl : null, sqlZeilen: TS.sql_e ? TS.sql_e.anzahl : null, fehler: TS.fehler ? TS.fehler.titel : null,
      termFehler: TS.term_fehler ? TS.term_fehler.titel : null } : null,
    sch: SCH ? { schritt: z.schSchritt, schritte: SCH.P ? SCH.P.schritte : [], basis: z.schbasis, kreuz: SCH.kreuz == null ? null : SCH.kreuz, zahl: SCH.zahl || null, mehr: !!SCH.mehr,
      ergebnis: SCH.ergebnis ? SCH.ergebnis.anzahl : null, verb: SCH.P ? SCH.P.verb.length : null, wahl: SCH.P ? SCH.P.wahl.length : null, spalten: SCH.P ? SCH.P.spalten.map(s => s.name) : null,
      fehler: SCH.fehler ? SCH.fehler.titel : null, satz: z.satz, lose: SCH.P ? SCH.P.lose : null,
      gruppen: SCH.gruppen ? SCH.gruppen.map(g => [JSON.parse(g.schluessel).join("|"), g.aus, g.bleibt]) : null } : null,
    lose: z.ergebnis && z.ergebnis.lose ? z.ergebnis.lose : null }) };
};
window.Werkstaetten.daten.basis = (document.currentScript && document.currentScript.src ? document.currentScript.src.replace(/[^/]*$/, "") : "/_system/seite/werkstatt/") + "daten/";
window.Werkstaetten.daten.kurz = "die Tabellen des Falls: links der Plan, rechts blättern oder eine Abfrage ausführen.";
window.Werkstaetten.daten.einleitung = "Links der Plan: fünf Tabellen, die Pfeile zeigen, welche Spalte auf welche Tabelle verweist. Klickt eine Tabelle an, um sie zu lesen – erst den Auszug, dann die ganze.";
