//  Datenwerkstatt -- Relationenalgebra (Reiter "Relationenalgebra", ab t02).
//  Wie kern.js ohne Oberflaeche und in node getestet (pruefe.mjs); bauen.mjs
//  entfernt die exports. Alle globalen Namen beginnen mit ra/RA, damit sie im
//  Bundle nicht mit kern.js oder bedienung.js kollidieren.
//
//  WAS EINGEGEBEN WIRD (Abiturnotation, LA25 GK B1/B2, LK):
//    σ[Farbe = 'rot' AND Typ = 'Kombi'](Fahrzeug)
//    π[Kennzeichen, PersNr](σ[...](Fahrzeug))
//    Fahrzeug ⋈ Einwohner              Verbund ueber GLEICHNAMIGE Attribute
//    Fahrzeug × Einwohner               jede Zeile mit jeder
//  ⋈ gibt es NUR als natuerlichen Verbund, wie im Abitur (GK 2014-2025: nie
//  mit Bedingung; Lehrerentscheidung 2026-10-12, die Fall-DB ist danach
//  gebaut: Fremdschluessel heissen wie ihr Schluessel). Wer ⋈[...] tippt,
//  bekommt den Abiturweg genannt: σ[Bedingung](A × B).
//  Die Bedingung bzw. Attributliste steht in [ ] -- so tippt man sie. Auch
//  angenommen: _{ ... } und die Form, in der das Abitur sie druckt
//  (σFarbe = 'rot' (Fahrzeug): alles bis zur ersten Klammer). Statt der
//  Zeichen gehen die Woerter sigma, pi, join, kreuz.
//  Bedingungen: = <> != < > <= >= (auch ≠ ≤ ≥), AND OR NOT (auch ∧ ∨ ¬),
//  Texte in einfachen Anfuehrungszeichen, Zahlen. Mehr kennt das Abitur
//  nicht -- insbesondere kein LIKE (das kommt mit SQL, t04).
//
//  WIE GERECHNET WIRD: Der Term wird in SQL uebersetzt und von SQLite
//  ausgefuehrt. Relationen sind Mengen -- doppelte Zeilen entstehen nur durch
//  π, deshalb steht nur dort DISTINCT. Spalten heissen intern c0, c1, ...;
//  jede traegt ihre Herkunft (Tabelle, Attribut), damit Zahlung.Zeit und
//  Funkzelle.Zeit auseinanderzuhalten sind.
//
//  OPERATORBAUM (ab t03, raBaum): derselbe Term als Baum, jeder Operator mit
//  Schrittnummer (von innen nach aussen) und Zwischenergebnis.
//
//  FEHLER sind Objekte {titel, text} (text darf <code> enthalten) und werden
//  als RAFehler geworfen. Der wichtigste ist der aus dem Vorlauf von t02:
//  Wer zuerst Spalten abdeckt, kann danach nicht mehr nach ihnen streichen --
//  die Meldung sagt das ausdruecklich.

class RAFehler extends Error {
  constructor(titel, text) { super(titel); this.titel = titel; this.text = text; }
}

const RA_ID = /[A-Za-zÄÖÜäöüß_][A-Za-z0-9ÄÖÜäöüß_]*/y;
const raCode = w => "<code>" + raEsc(w) + "</code>";
function raEsc(s) {
  return String(s).replace(/[&<>"]/g, z => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[z]));
}
const raQ = n => '"' + String(n).replace(/"/g, '""') + '"';

//  iPad und Mac setzen gern typografische Anfuehrungszeichen -- die meinen
//  dasselbe wie '. Doppelte bleiben, damit die Meldung sie ansprechen kann.
function raNormalisieren(s) {
  return String(s).replace(/[‘’‚‛′`´]/g, "'").replace(/[„“”]/g, '"');
}

// ── Lesen ────────────────────────────────────────────────────────────────

const RA_WOERTER = { sigma: "σ", pi: "π", join: "⋈", kreuz: "×", cross: "×" };

//  Liefert den Baum: {art:"tab", name} · {art:"sel", bed, kind} ·
//  {art:"proj", attrs:[...], kind} · {art:"join", l, r} (natuerlich) · {art:"kreuz", l, r}
function raLesen(eingabe) {
  const s = raNormalisieren(eingabe);
  let i = 0;
  const leer = () => { while (i < s.length && /\s/.test(s[i])) i++; };
  const rest = () => s.slice(i, i + 25).trim();
  const kurzVor = () => rest() ? ` (kurz vor ${raCode(rest())})` : " (am Ende)";

  //  Operatorzeichen an der Stelle i -- als Zeichen oder als Wort
  function zeichen() {
    leer();
    const c = s[i];
    if ("σπ⋈×".includes(c)) return c;
    RA_ID.lastIndex = i;
    const m = RA_ID.exec(s);
    if (m && RA_WOERTER[m[0].toLowerCase()]) return RA_WOERTER[m[0].toLowerCase()];
    return null;
  }
  function zeichenNehmen() {
    leer();
    if ("σπ⋈×".includes(s[i])) { i++; return; }
    RA_ID.lastIndex = i; i += RA_ID.exec(s)[0].length;
  }
  //  Index nach σ/π/⋈: [ ... ], _{ ... } oder (nur σ/π) alles bis zur ersten
  //  Klammer ausserhalb eines Textes. Gibt null, wenn keiner da ist.
  function index(mussKlammerform) {
    leer();
    let auf = null, zu = null;
    if (s[i] === "[") { auf = "["; zu = "]"; i++; }
    else if (s[i] === "_" && s[i + 1] === "{") { auf = "{"; zu = "}"; i += 2; }
    else if (s[i] === "_") { i++; }
    if (zu) {
      const start = i; let tiefe = 0, inText = false;
      for (; i < s.length; i++) {
        const c = s[i];
        if (c === "'") inText = !inText;
        else if (!inText && c === auf) tiefe++;
        else if (!inText && c === zu) { if (tiefe === 0) break; tiefe--; }
      }
      if (i >= s.length) throw new RAFehler("Klammer nicht geschlossen",
        `Die ${raCode(auf === "[" ? "[" : "_{")} nach dem Zeichen wird nicht wieder geschlossen. ` +
        `Bedingung bzw. Attribute stehen zwischen ${raCode(auf === "[" ? "[ ]" : "_{ }")}.`);
      const inhalt = s.slice(start, i); i++;
      return inhalt;
    }
    if (mussKlammerform) return null;
    //  Abitur-Druckform: bis zur ersten "(" ausserhalb eines Textes
    const start = i; let inText = false;
    for (; i < s.length; i++) {
      if (s[i] === "'") inText = !inText;
      else if (!inText && s[i] === "(") break;
    }
    const inhalt = s.slice(start, i);
    return inhalt.trim() ? inhalt : null;
  }

  function primaer() {
    leer();
    const z = zeichen();
    if (z === "σ" || z === "π") {
      zeichenNehmen();
      const idx = index(false);
      if (idx === null || !idx.trim())
        throw new RAFehler(z === "σ" ? "Hinter σ fehlt die Bedingung" : "Hinter π fehlen die Attribute",
          z === "σ" ? "σ braucht eine Bedingung, zum Beispiel " + raCode("σ[Farbe = 'rot'](Fahrzeug)") + "."
                    : "π braucht die Attribute, die stehen bleiben, zum Beispiel " +
                      raCode("π[Kennzeichen, PersNr](Fahrzeug)") + ".");
      leer();
      if (i >= s.length) throw new RAFehler("Es fehlt, worauf " + z + " wirkt",
        `Hinter ${raCode(z + "[" + idx.trim() + "]")} muss in Klammern stehen, worauf es angewendet wird, ` +
        `zum Beispiel ${raCode("(Fahrzeug)")}.`);
      const kind = primaer();
      if (z === "σ") return { art: "sel", bed: idx.trim(), kind };
      const attrs = idx.split(",").map(a => a.trim());
      if (attrs.some(a => !a)) throw new RAFehler("Ein Attribut fehlt",
        `In ${raCode("π[" + idx.trim() + "]")} steht ein Komma zu viel oder eins fehlt.`);
      return { art: "proj", attrs, kind };
    }
    if (z === "⋈" || z === "×") throw new RAFehler("Links fehlt etwas",
      `Vor ${raCode(z)} muss eine Tabelle oder ein Term stehen${kurzVor()}.`);
    if (s[i] === "(") {
      i++;
      const t = term();
      leer();
      if (s[i] !== ")") throw new RAFehler("Klammer nicht geschlossen",
        `Eine ${raCode("(")} wird nicht wieder geschlossen${kurzVor()}.`);
      i++;
      return t;
    }
    RA_ID.lastIndex = i;
    const m = RA_ID.exec(s);
    if (m) { i += m[0].length; return { art: "tab", name: m[0] }; }
    if (i >= s.length) throw new RAFehler("Der Term hört zu früh auf",
      "Am Ende fehlt noch eine Tabelle oder ein Term in Klammern.");
    throw new RAFehler("Das Zeichen passt hier nicht",
      `Mit ${raCode(s[i])} kann die Werkstatt hier nichts anfangen${kurzVor()}.`);
  }

  function term() {
    let links = primaer();
    for (;;) {
      leer();
      const z = zeichen();
      if (z !== "⋈" && z !== "×") break;
      zeichenNehmen();
      if (z === "⋈") {
        leer();
        if (s[i] === "[" || (s[i] === "_" && s[i + 1] === "{")) throw new RAFehler("⋈ steht ohne Bedingung",
          `${raCode("⋈")} verbindet die Zeilen, die in den Attributen mit <b>gleichem Namen</b> übereinstimmen — ` +
          `so steht es im Abitur, ohne Bedingung daran. Soll nach einer anderen Bedingung verbunden werden: ` +
          raCode("σ[Bedingung](A × B)") + ".");
      }
      leer();
      if (i >= s.length) throw new RAFehler("Rechts fehlt etwas",
        `Hinter ${raCode(z)} muss eine zweite Tabelle oder ein Term stehen.`);
      const rechts = primaer();
      links = z === "×" ? { art: "kreuz", l: links, r: rechts }
                        : { art: "join", l: links, r: rechts };
    }
    return links;
  }

  leer();
  if (i >= s.length) throw new RAFehler("Noch kein Term", "Gebt einen Term ein, zum Beispiel " +
    raCode("σ[Farbe = 'rot'](Fahrzeug)") + ".");
  const baum = term();
  leer();
  if (i < s.length) {
    const c = s[i];
    if (c === ")") throw new RAFehler("Eine Klammer zu viel",
      `Hier wird eine ${raCode(")")} geschlossen, die nie geöffnet wurde${kurzVor()}.`);
    throw new RAFehler("Hier geht es nicht weiter",
      `Nach dem Term steht noch etwas${kurzVor()}. Fehlt ein ${raCode("⋈")} oder ein ${raCode("×")} dazwischen?`);
  }
  return baum;
}

// ── Bedingungen ──────────────────────────────────────────────────────────

const RA_VERGL = { "=": "=", "<>": "<>", "!=": "<>", "≠": "<>", "<": "<", ">": ">",
                   "<=": "<=", ">=": ">=", "≤": "<=", "≥": ">=" };

function raBedTokens(bed) {
  const t = []; let i = 0;
  const s = bed;
  while (i < s.length) {
    const c = s[i];
    if (/\s/.test(c)) { i++; continue; }
    if (c === "'") {
      let j = i + 1, w = "";
      for (;;) {
        if (j >= s.length) throw new RAFehler("Anführungszeichen nicht geschlossen",
          `Ein Text ist mit ${raCode("'")} geöffnet, aber nicht wieder geschlossen: ${raCode(s.slice(i))}.`);
        if (s[j] === "'" && s[j + 1] === "'") { w += "'"; j += 2; continue; }
        if (s[j] === "'") break;
        w += s[j++];
      }
      t.push({ a: "text", w }); i = j + 1; continue;
    }
    if (c === '"') throw new RAFehler("Doppelte Anführungszeichen",
      `Texte stehen in <b>einfachen</b> Anführungszeichen: ${raCode("'rot'")}, nicht ${raCode('"rot"')}.`);
    const zwei = s.slice(i, i + 2);
    if (["<>", "!=", "<=", ">="].includes(zwei)) { t.push({ a: "op", w: zwei }); i += 2; continue; }
    if ("=<>≠≤≥".includes(c)) { t.push({ a: "op", w: c }); i++; continue; }
    if (c === "∧") { t.push({ a: "und" }); i++; continue; }
    if (c === "∨") { t.push({ a: "oder" }); i++; continue; }
    if (c === "¬") { t.push({ a: "nicht" }); i++; continue; }
    if (c === "(" || c === ")") { t.push({ a: c }); i++; continue; }
    const z = /^-?\d+(?:[.,]\d+)?/.exec(s.slice(i));
    if (z && !/[A-Za-zÄÖÜäöüß_]/.test(s[i + z[0].length] || "")) {
      t.push({ a: "zahl", w: Number(z[0].replace(",", ".")) }); i += z[0].length; continue;
    }
    RA_ID.lastIndex = i;
    const m = RA_ID.exec(s);
    if (m) {
      let w = m[0]; i += w.length;
      if (s[i] === "." ) {
        RA_ID.lastIndex = i + 1;
        const m2 = RA_ID.exec(s);
        if (m2) { w += "." + m2[0]; i += 1 + m2[0].length; }
      }
      const g = w.toUpperCase();
      if (g === "AND" || g === "UND") t.push({ a: "und" });
      else if (g === "OR" || g === "ODER") t.push({ a: "oder" });
      else if (g === "NOT" || g === "NICHT") t.push({ a: "nicht" });
      else if (g === "LIKE") throw new RAFehler("LIKE gibt es in der Relationenalgebra nicht",
        "In einer Bedingung der Relationenalgebra wird nur verglichen: " +
        raCode("=") + ", " + raCode("<") + ", " + raCode(">") + " … Textmuster wie „fängt mit WI an“ kommen mit SQL.");
      else t.push({ a: "name", w });
      continue;
    }
    throw new RAFehler("Das Zeichen passt nicht in die Bedingung",
      `Mit ${raCode(c)} in ${raCode(bed)} kann die Werkstatt nichts anfangen.`);
  }
  return t;
}

//  Uebersetzt eine Bedingung; aufloesen(name) gibt den SQL-Spaltennamen
//  oder wirft. Prueft den Aufbau selbst, damit die Meldung deutsch ist.
function raBedSql(bed, aufloesen) {
  const t = raBedTokens(bed);
  let k = 0;
  const wo = () => k < t.length ? "" : " am Ende";
  const ganz = raCode(bed);
  function operand() {
    const x = t[k];
    if (!x) throw new RAFehler("Die Bedingung hört zu früh auf",
      `In ${ganz} fehlt hinter dem Vergleich noch ein Wert.`);
    if (x.a === "text") { k++; return { sql: "'" + x.w.replace(/'/g, "''") + "'", art: "wert" }; }
    if (x.a === "zahl") { k++; return { sql: String(x.w), art: "wert" }; }
    if (x.a === "name") { k++; return { sql: aufloesen(x.w, true), art: "attr" }; }
    throw new RAFehler("Hier fehlt ein Attribut oder ein Wert",
      `In ${ganz} steht an einer Stelle kein Attribut und kein Wert${wo()}.`);
  }
  function vergleich() {
    if (t[k] && t[k].a === "(") {
      k++; const e = oder();
      if (!t[k] || t[k].a !== ")") throw new RAFehler("Klammer nicht geschlossen",
        `In ${ganz} wird eine ${raCode("(")} nicht wieder geschlossen.`);
      k++; return "(" + e + ")";
    }
    const a = operand();
    const op = t[k];
    if (!op || op.a !== "op") throw new RAFehler("Hier fehlt der Vergleich",
      `In ${ganz} steht ein Attribut ohne Vergleich. Eine Bedingung vergleicht, zum Beispiel ` +
      raCode("Farbe = 'rot'") + ".");
    k++;
    const b = operand();
    return a.sql + " " + RA_VERGL[op.w] + " " + b.sql;
  }
  function nicht() {
    if (t[k] && t[k].a === "nicht") { k++; return "NOT " + nicht(); }
    return vergleich();
  }
  function und() {
    let e = nicht();
    while (t[k] && t[k].a === "und") { k++; e += " AND " + nicht(); }
    return e;
  }
  function oder() {
    let e = und();
    while (t[k] && t[k].a === "oder") { k++; e += " OR " + und(); }
    return e;
  }
  if (!t.length) throw new RAFehler("Die Bedingung ist leer", "Zwischen den Klammern steht keine Bedingung.");
  const e = oder();
  if (k < t.length) {
    const x = t[k];
    throw new RAFehler("Zwei Vergleiche ohne AND oder OR",
      `In ${ganz} stehen Vergleiche nebeneinander. Verbindet sie mit ${raCode("AND")} oder ${raCode("OR")}` +
      (x.a === "name" ? ` (vor ${raCode(x.w)}).` : "."));
  }
  return e;
}

// ── Uebersetzen ──────────────────────────────────────────────────────────

const raZeilenzahl = (db, tab) => {
  const r = db.exec(`SELECT COUNT(*) FROM ${raQ(tab)}`);
  return r[0].values[0][0];
};
const raSpalten = (db, tab) => {
  const r = db.exec(`PRAGMA table_info(${raQ(tab)})`);
  return r.length ? r[0].values.map(z => z[1]) : [];
};
const raTabellen = db => {
  const r = db.exec("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY rowid");
  return r.length ? r[0].values.map(z => z[0]) : [];
};

function raAehnlich(wort, kandidaten) {
  let best = null, bestd = 99;
  for (const k of kandidaten) {
    const a = wort.toLowerCase(), b = k.toLowerCase();
    const d = Array.from({ length: a.length + 1 }, (_, i) => [i]);
    for (let j = 1; j <= b.length; j++) d[0][j] = j;
    for (let i = 1; i <= a.length; i++)
      for (let j = 1; j <= b.length; j++)
        d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    if (d[a.length][b.length] < bestd) { best = k; bestd = d[a.length][b.length]; }
  }
  return bestd <= Math.max(2, Math.floor(wort.length / 3)) ? best : null;
}

const RA_GRENZE_DISTINCT = 2e7;    // π ueber mehr Zeilen: abgelehnt (Browser haengt sonst)

//  Ergebnis je Knoten: {sql, schema:[{tab,name}], basis:[{tab,name}], schaetz, hinweise}
//  protokoll (Map, optional): haelt das Ergebnis JEDES Knotens fest -- daraus
//  baut raBaum die Zwischenergebnisse des Operatorbaums.
function raUebersetzen(db, baum, protokoll = null) {
  const tabs = raTabellen(db);
  let n = 0;
  const neu = () => "q" + (n++);

  function aufloeserFuer(schema, basis, wo) {
    return (ref, inBed) => {
      const [t, a] = ref.includes(".") ? ref.split(".") : [null, ref];
      const treffer = schema.map((s, k) => ({ s, k })).filter(({ s }) =>
        s.name.toLowerCase() === a.toLowerCase() && (!t || s.tab.toLowerCase() === t.toLowerCase()));
      if (treffer.length === 1) return "c" + treffer[0].k;
      if (treffer.length > 1) throw new RAFehler("Welches Attribut ist gemeint?",
        `${raCode(a)} gibt es hier mehrmals. Schreibt die Tabelle davor: ` +
        treffer.map(({ s }) => raCode(s.tab + "." + s.name)).join(" oder ") + ".");
      const vorhanden = schema.map(s => s.name);
      const frueher = basis.find(b => b.name.toLowerCase() === a.toLowerCase());
      if (frueher) throw new RAFehler(`${a} gibt es hier nicht mehr`,
        `${raCode(a)} steht in ${raCode(frueher.tab)}, aber ein ${raCode("π")} weiter innen hat es ` +
        `nicht übernommen. ${wo} kann nur mit dem arbeiten, was noch da ist: ` +
        vorhanden.map(raCode).join(", ") + ".");
      if (inBed && !t) throw new RAFehler("Attribut oder Text?",
        `Ein Attribut ${raCode(a)} gibt es hier nicht. Ist ${raCode(a)} ein <b>Wert</b>? ` +
        `Dann gehört er in einfache Anführungszeichen: ${raCode("'" + a + "'")}. ` +
        `Vorhanden: ${vorhanden.map(raCode).join(", ")}.`);
      const v = raAehnlich(a, vorhanden);
      throw new RAFehler("Dieses Attribut gibt es hier nicht",
        `Ein Attribut ${raCode(ref)} gibt es hier nicht.` + (v ? ` Meint ihr ${raCode(v)}?` : "") +
        ` Vorhanden: ${vorhanden.map(raCode).join(", ")}.`);
    };
  }

  function knoten(b) {
    const e = knotenRoh(b);
    if (protokoll) protokoll.set(b, e);
    return e;
  }
  function knotenRoh(b) {
    if (b.art === "tab") {
      const echt = tabs.find(t => t.toLowerCase() === b.name.toLowerCase());
      if (!echt) {
        const v = raAehnlich(b.name, tabs);
        throw new RAFehler("Diese Tabelle gibt es nicht",
          `Eine Tabelle ${raCode(b.name)} kennt die Datenbank nicht.` + (v ? ` Meint ihr ${raCode(v)}?` : "") +
          ` Vorhanden: ${tabs.map(raCode).join(", ")}.`);
      }
      const sp = raSpalten(db, echt);
      const schema = sp.map(name => ({ tab: echt, name }));
      return { sql: `SELECT ${sp.map((x, k) => raQ(x) + " AS c" + k).join(", ")} FROM ${raQ(echt)}`,
               schema, basis: schema.slice(), schaetz: raZeilenzahl(db, echt), hinweise: [] };
    }
    if (b.art === "sel") {
      const k = knoten(b.kind), a = neu();
      const bed = raBedSql(b.bed, aufloeserFuer(k.schema, k.basis, raCode("σ")));
      const verbindet = /c\d+ = c\d+/.test(bed);
      const sel = bed.replace(/\bc(\d+)\b/g, (_, d) => `${a}.c${d}`);
      return { ...k, sql: `SELECT * FROM (${k.sql}) AS ${a} WHERE ${sel}`,
               schaetz: verbindet && k.produkt ? k.produkt : k.schaetz, produkt: null };
    }
    if (b.art === "proj") {
      const k = knoten(b.kind), a = neu();
      const auf = aufloeserFuer(k.schema, k.basis, raCode("π"));
      const idx = b.attrs.map(x => Number(auf(x, false).slice(1)));
      const doppelt = idx.find((x, j) => idx.indexOf(x) !== j);
      if (doppelt !== undefined) throw new RAFehler("Ein Attribut steht zweimal",
        `${raCode(k.schema[doppelt].name)} steht in ${raCode("π")} doppelt.`);
      if (k.schaetz > RA_GRENZE_DISTINCT) throw new RAFehler("Das wird zu groß",
        `Unter diesem ${raCode("π")} stünden rund ${raTausend(k.schaetz)} Zeilen — jede mit jeder. ` +
        `Das rechnet auch ein Computer nicht in Ruhe durch. Fehlt ein ${raCode("⋈")} mit Bedingung statt ${raCode("×")}?`);
      return { ...k, sql: `SELECT DISTINCT ${idx.map((x, j) => `${a}.c${x} AS c${j}`).join(", ")} FROM (${k.sql}) AS ${a}`,
               schema: idx.map(x => k.schema[x]), produkt: null };
    }
    const l = knoten(b.l), r = knoten(b.r), al = neu(), ar = neu();
    const versatz = l.schema.length;
    const alle = [...l.schema, ...r.schema];
    const basis = [...l.basis, ...r.basis];
    const hinweise = [...l.hinweise, ...r.hinweise];
    const spaltenSql = (schema, links) => schema.map((s, k) =>
      `${links ? al : ar}.c${k} AS c${links ? k : k + versatz}`);
    if (b.art === "kreuz") {
      return { sql: `SELECT ${[...spaltenSql(l.schema, true), ...spaltenSql(r.schema, false)].join(", ")} ` +
                    `FROM (${l.sql}) AS ${al}, (${r.sql}) AS ${ar}`,
               schema: alle, basis, hinweise,
               schaetz: l.schaetz * r.schaetz, produkt: Math.max(l.schaetz, r.schaetz) };
    }
    //  natuerlicher Verbund: gleichnamige Attribute
    const paare = [];
    r.schema.forEach((s, kr) => {
      const kl = l.schema.map((x, k) => ({ x, k })).filter(({ x }) => x.name.toLowerCase() === s.name.toLowerCase());
      if (kl.length > 1) throw new RAFehler("Welches Attribut verbindet?",
        `${raCode(s.name)} steht links mehrmals (aus einem ${raCode("×")}). ${raCode("⋈")} weiß nicht, über welches ` +
        `verbunden werden soll. Deckt vorher mit ${raCode("π")} ab, was nicht gebraucht wird.`);
      if (kl.length === 1) paare.push([kl[0].k, kr]);
    });
    if (!paare.length) {
      //  Kein gemeinsamer Name: ⋈ ist dann × -- gerechnet wird es, gesagt auch.
      hinweise.push(`Die beiden Seiten von ${raCode("⋈")} haben kein Attribut mit demselben Namen. ` +
        `Dann verbindet ${raCode("⋈")} jede Zeile mit jeder, wie ${raCode("×")}.`);
      return { sql: `SELECT ${[...spaltenSql(l.schema, true), ...spaltenSql(r.schema, false)].join(", ")} ` +
                    `FROM (${l.sql}) AS ${al}, (${r.sql}) AS ${ar}`,
               schema: alle, basis, hinweise, schaetz: l.schaetz * r.schaetz,
               produkt: Math.max(l.schaetz, r.schaetz) };
    }
    //  Mehr als ein gleichnamiges Attribut: ALLE muessen uebereinstimmen --
    //  die Falle aus LA21 GK B2 7.1 (Zahlung ⋈ Funkzelle: PersNr UND Zeit).
    if (paare.length > 1)
      hinweise.push(`${raCode("⋈")} verbindet hier über ${paare.length} Attribute mit gleichem Namen: ` +
        paare.map(([, kr]) => raCode(r.schema[kr].name)).join(" und ") + ". Eine Zeile findet nur einen Partner, " +
        "wenn <b>alle</b> übereinstimmen.");
    const weg = new Set(paare.map(p => p[1]));
    const rechts = r.schema.map((s, k) => ({ s, k })).filter(({ k }) => !weg.has(k));
    const schema = [...l.schema, ...rechts.map(x => x.s)];
    const sel = [...l.schema.map((s, k) => `${al}.c${k} AS c${k}`),
                 ...rechts.map((x, j) => `${ar}.c${x.k} AS c${versatz + j}`)];
    return { sql: `SELECT ${sel.join(", ")} FROM (${l.sql}) AS ${al}, (${r.sql}) AS ${ar} WHERE ` +
                  paare.map(([a, c]) => `${al}.c${a} = ${ar}.c${c}`).join(" AND "),
             schema, basis, hinweise, schaetz: Math.max(l.schaetz, r.schaetz), produkt: null };
  }
  return knoten(baum);
}

function raTausend(n) {
  const r = n >= 1e9 ? Math.round(n / 1e9) + " Milliarden" : n >= 1e6 ? Math.round(n / 1e6) + " Millionen" : String(n);
  return r.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
}

//  Spaltennamen fuer die Anzeige: das Attribut, bei Doppelten Tabelle.Attribut
function raKopf(schema) {
  return schema.map(s => schema.filter(x => x.name.toLowerCase() === s.name.toLowerCase()).length > 1
    ? s.tab + "." + s.name : s.name);
}

//  Uebersetzt und prueft einen Term (ohne Ausfuehren): {sql, kopf, hinweise}
function raSql(db, eingabe) {
  const k = raUebersetzen(db, raLesen(eingabe));
  return { sql: `SELECT * FROM (${k.sql})`, kopf: raKopf(k.schema), hinweise: k.hinweise };
}

//  Ausfuehren mit Deckel wie in kern.js: {spalten, zeilen, anzahl, mehr, hinweise}
function raAusfuehren(db, eingabe, { zeigen = 200, zaehlen = 100000 } = {}) {
  const u = raSql(db, eingabe);
  const st = db.prepare(u.sql);
  const zeilen = []; let anzahl = 0;
  try {
    while (st.step()) {
      if (zeilen.length < zeigen) zeilen.push(st.get());
      if (++anzahl >= zaehlen) break;
    }
  } finally { st.free(); }
  return { spalten: u.kopf, zeilen, anzahl, mehr: anzahl >= zaehlen, hinweise: u.hinweise };
}

//  Alle Zeilen (fuer die Pruefung)
function raAlle(db, eingabe) {
  return raAusfuehren(db, eingabe, { zeigen: 100001, zaehlen: 100001 });
}

// ── Setzen: der Term so, wie er im Abitur gedruckt steht ─────────────────

//  HTML mit <sub>; ohne Klammern um eine einzelne Tabelle hinter σ/π nur,
//  wenn auch die Eingabe keine hatte -- wir setzen sie immer (Abiturform).
const raBedSetzen = bed => raEsc(raNormalisieren(bed)).replace(/\s+/g, " ");
//  Nur das Zeichen eines Knotens mit seinem Index (fuer den Operatorbaum)
function raZeichenSetzen(b) {
  if (b.art === "tab") return raEsc(b.name);
  if (b.art === "sel") return `σ<sub>${raBedSetzen(b.bed)}</sub>`;
  if (b.art === "proj") return `π<sub>${raEsc(b.attrs.join(", "))}</sub>`;
  if (b.art === "kreuz") return "×";
  return "⋈";
}
function raBaumSetzen(b, aussen = true) {
  if (b.art === "tab") return raEsc(b.name);
  if (b.art === "sel" || b.art === "proj") return `${raZeichenSetzen(b)}(${raBaumSetzen(b.kind, true)})`;
  //  ⋈ und × sind linksassoziativ: A ⋈ B ⋈ C wie im Abitur, ohne Klammer links
  const t = `${raBaumSetzen(b.l, b.l.art === "join" || b.l.art === "kreuz")} ${raZeichenSetzen(b)} ${raBaumSetzen(b.r, false)}`;
  return aussen ? t : `(${t})`;
}
function raSetzen(eingabe) {
  return raBaumSetzen(raLesen(eingabe), true);
}

// ── Operatorbaum (ab t03): der Term als Baum, von innen nach aussen ───────
//  Fuer die Abiturform "Term erlaeutern": Man liest einen Term von innen nach
//  aussen -- im Baum von den Tabellen unten zur Wurzel oben. Jeder Operator
//  bekommt eine Schrittnummer in genau dieser Reihenfolge (erst der linke Ast,
//  dann der rechte, dann der Knoten selbst) und sein Zwischenergebnis.
//  Die Werkstatt formuliert KEINE Saetze zum Term: das Erlaeutern ist die
//  Aufgabe der Klasse. Sie zeigt nur, was an jeder Stelle herauskommt.

const RA_HANDGRIFF = { sel: "Zeilen streichen", proj: "Spalten abdecken",
                       join: "aneinanderlegen", kreuz: "jede mit jeder" };

//  {wurzel, knoten:[...], schritte, hinweise}. Ein Knoten:
//  {nr, art, zeichen (HTML), handgriff, teilterm (HTML, Abiturform),
//   schritt (0 bei Tabellen), kinder:[...], sql, kopf:[...], anzahl, mehr}
//  anzahl wird je Knoten mit Deckel gezaehlt (wie raAusfuehren).
function raBaum(db, eingabe, { zaehlen = 100000 } = {}) {
  const baum = raLesen(eingabe);
  const protokoll = new Map();
  const ganz = raUebersetzen(db, baum, protokoll);
  const knoten = [];
  let schritt = 0;
  function bau(b) {
    const kinder = b.art === "tab" ? [] : (b.art === "sel" || b.art === "proj") ? [bau(b.kind)] : [bau(b.l), bau(b.r)];
    const e = protokoll.get(b);
    const sql = `SELECT * FROM (${e.sql})`;
    const n = db.exec(`SELECT COUNT(*) FROM (SELECT 1 FROM (${e.sql}) LIMIT ${zaehlen})`)[0].values[0][0];
    const k = { nr: knoten.length, art: b.art, zeichen: raZeichenSetzen(b), handgriff: RA_HANDGRIFF[b.art] || "",
                teilterm: raBaumSetzen(b, true), schritt: b.art === "tab" ? 0 : ++schritt, kinder, sql,
                kopf: raKopf(e.schema), anzahl: n, mehr: n >= zaehlen };
    knoten.push(k);
    return k;
  }
  const wurzel = bau(baum);
  return { wurzel, knoten, schritte: schritt, hinweise: ganz.hinweise };
}

//  Die Zeilen eines Knotens zum Zeigen: {spalten, zeilen, anzahl, mehr}
function raKnotenZeilen(db, k, { zeigen = 200 } = {}) {
  const st = db.prepare(k.sql);
  const zeilen = [];
  try { while (zeilen.length < zeigen && st.step()) zeilen.push(st.get()); }
  finally { st.free(); }
  return { spalten: k.kopf, zeilen, anzahl: k.anzahl, mehr: k.mehr };
}

// ── Pruefen ──────────────────────────────────────────────────────────────

const raNorm = w => w === null ? "NULL" : typeof w === "number" ? String(+w.toFixed(6))
  : String(w).trim().replace(/\s+/g, " ").toLowerCase();
const raZeile = z => JSON.stringify(z.map(raNorm));

//  Ordnet die Spalten von ist nach den Namen von soll (die Reihenfolge der
//  Attribute ist in der Relationenalgebra gleichgueltig). null, wenn die
//  Namen nicht passen.
function raNachNamen(ist, soll) {
  const n = x => x.toLowerCase().split(".").pop();
  if (ist.spalten.length !== soll.spalten.length) return null;
  const pos = soll.spalten.map(s => {
    const exakt = ist.spalten.findIndex(x => x.toLowerCase() === s.toLowerCase());
    return exakt >= 0 ? exakt : ist.spalten.findIndex(x => n(x) === n(s));
  });
  if (pos.some(p => p < 0) || new Set(pos).size !== pos.length) return null;
  return { spalten: soll.spalten, zeilen: ist.zeilen.map(z => pos.map(p => z[p])) };
}

//  {ok, text, zeile?, fehlt?} -- wie vergleichen() in kern.js, aber nach
//  Attributnamen und als Menge. zeigeFehlende: false verraet keine Zeile
//  der Loesung (Ergebnismenge von Hand: dort waere das die Antwort).
function raVergleichen(ist, soll, { zeigeFehlende = true } = {}) {
  if (ist.spalten.length !== soll.spalten.length)
    return { ok: false, text: `Euer Ergebnis hat ${ist.spalten.length} Attribut${ist.spalten.length === 1 ? "" : "e"}, ` +
      `gesucht ${soll.spalten.length === 1 ? "ist eins" : "sind " + soll.spalten.length}.` };
  const geordnet = raNachNamen(ist, soll);
  if (!geordnet) {
    const fehlt = soll.spalten.filter(s => !ist.spalten.some(x =>
      x.toLowerCase().split(".").pop() === s.toLowerCase().split(".").pop()));
    return { ok: false, text: "Die Attribute stimmen noch nicht" +
      (fehlt.length && zeigeFehlende ? ": es fehlt " + fehlt.join(", ") + "." : ".") };
  }
  const b = new Set(soll.zeilen.map(raZeile)), a = new Set(geordnet.zeilen.map(raZeile));
  for (const z of geordnet.zeilen)
    if (!b.has(raZeile(z))) return { ok: false, zeile: z, spalten: soll.spalten, text: "Diese Zeile gehört nicht ins Ergebnis:" };
  for (const z of soll.zeilen)
    if (!a.has(raZeile(z))) return zeigeFehlende
      ? { ok: false, zeile: z, spalten: soll.spalten, text: "Es fehlt mindestens eine Zeile, zum Beispiel:" }
      : { ok: false, text: `Es fehlt noch mindestens eine Zeile.` };
  if (geordnet.zeilen.length !== a.size)
    return { ok: false, text: "Eine Zeile steht doppelt da. Ein Ergebnis der Relationenalgebra ist eine Menge: jede Zeile einmal." };
  return { ok: true, text: `Stimmt: ${b.size === 0 ? "keine Zeile — die Menge ist leer" :
    b.size + " Zeile" + (b.size === 1 ? "" : "n")}, genau die gesuchten.` };
}

//  Prueft einen Term gegen das Muster -- auf jeder Datenbasis, die genannt
//  ist. Was im Auszug stimmt, kann in der ganzen Datenbank falsch sein.
function raPruefen(basen, eingabe, muster) {
  for (const { name, db } of basen) {
    const v = raVergleichen(raAlle(db, eingabe), raAlle(db, muster));
    if (!v.ok) return { ...v, basis: name };
  }
  const n = raAlle(basen[0].db, muster).zeilen.length;
  return { ok: true, text: `Stimmt: ${n === 0 ? "die Menge ist leer" : n + " Zeile" + (n === 1 ? "" : "n")}, genau die gesuchten` +
    (basen.length > 1 ? " — im Auszug und in der ganzen Datenbank." : ".") };
}

//  Ergebnismenge von Hand: kopf [..], zeilen [[..]] (Texte, wie getippt)
function raMengePruefen(db, kopf, zeilen, muster) {
  const k = kopf.map(x => String(x || "").trim());
  if (k.some(x => !x)) return { ok: false, text: "Jede Spalte braucht oben den Namen ihres Attributs." };
  const voll = zeilen.filter(z => z.some(w => String(w || "").trim()));
  if (voll.some(z => z.some(w => !String(w || "").trim())))
    return { ok: false, text: "In einer Zeile ist ein Feld leer. Jede Zeile hat in jeder Spalte einen Wert." };
  const soll = raAlle(db, muster);
  const ist = { spalten: k, zeilen: voll.map(z => z.map(w => {
    const s = String(w).trim();
    return /^-?\d+(?:[.,]\d+)?$/.test(s) ? Number(s.replace(",", ".")) : s;
  })) };
  return raVergleichen(ist, soll, { zeigeFehlende: false });
}

// ── Der Auszug: die zehn Zeilen je Tabelle vom Papier ────────────────────
//  Hiess bis 12.10. "Ausdruck" (Kaczmareks Ausdruck) -- in einer Stunde ueber
//  Terme las der Lehrer das als "Ausdruck = Term" (Drehbuch t02). Der Name der
//  Funktion bleibt, damit nichts bricht.

//  Legt eine zweite Datenbank mit demselben Schema und den Zeilen aus
//  auszug.json an. Damit stimmt, was die Werkstatt rechnet, mit dem Blatt.
function raAusdruckBauen(SQLMOD, voll, auszug) {
  const db = new SQLMOD.Database();
  const r = voll.exec("SELECT name, sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY rowid");
  for (const [name, sql] of r[0].values) {
    db.run(sql);
    const zeilen = auszug[name] || [];
    if (!zeilen.length) continue;
    const st = db.prepare(`INSERT INTO ${raQ(name)} VALUES (${zeilen[0].map(() => "?").join(",")})`);
    for (const z of zeilen) st.run(z);
    st.free();
  }
  return db;
}
