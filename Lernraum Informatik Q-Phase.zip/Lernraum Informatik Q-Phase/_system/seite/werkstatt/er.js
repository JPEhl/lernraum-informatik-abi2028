// Werkstatt „ER“ (25.11.2026) -- ER-Diagramme in Chen-Notation wie im Abitur, aus einem Text gelesen. Fuer iq2 `wache`,
// ab dem Thema `text` (danach kardinal, sonderfall, schema). Lehrerwahl aus drei Attrappen
// (werkstatt/informatik/q2/gk/lernraum/wache/planung/attrappen_er/, 25.11.): Fassung A „Text führt“ („A, bau den
// Baustein“), dazu aus B die gelesenen Saetze unter der Flaeche (Vorschlag beim Vorlegen).
//   * Links der Auftrag (```er text): die Klasse markiert in drei Farben -- Ding · Eigenschaft · Beziehung. Jede
//     Markierung ist sofort ein Zeichen auf der Flaeche (seit 25.11. abends, Lehrer: „könnte doch auch automatisch beim
//     Markieren passieren“; vorher als Pille gezogen): Rechteck und Raute in einer Reihe in der Folge des Texts, die
//     Ellipse LOSE oben -- woran sie haengt, entscheidet die Klasse und zieht sie auf ihr Rechteck oder ihre Raute.
//     Markierung und Zeichen sind ein Paar: entmarkieren loescht das Zeichen, loeschen entmarkiert, umfaerben aendert
//     die Form. Wer auf das eine zeigt, sieht das andere.
//   * Rechts die Flaeche, bedient wie eine Zeichenflaeche (LR6): Zeichen ziehen = verschieben · am Punkt ● ziehen =
//     Linie (auf ein anderes Zeichen) oder neue Eigenschaft (ins Leere) · zwei Rechtecke verbunden = Raute dazwischen ·
//     Doppelklick ins Leere = neues Rechteck, auf ein Zeichen = umbenennen · Klick waehlt · S = Schluessel ·
//     Entf loescht · Strg/⌘+Z, mit Umschalt wiederholen · Esc bricht ab · „Ordnen“ legt alles neu hin.
//   * Pruefen (nur an Tischen mit ```er soll) vergleicht mit der Aufgabe und nennt ein GEGENBEISPIEL, nie die Loesung:
//     „Zwei Personen heissen Emre Yildiz … dein Schluessel haelt sie nicht auseinander.“ Die Saetze dafuer stehen in der
//     Aufgabe (`# gegen Person.schluessel: …`), sonst ein allgemeiner. Die Form (Raute zwischen zwei Rechtecken,
//     Ellipse an genau einem Zeichen, ein Schluessel je Rechteck) prueft sie immer, auch am Tisch „Eigenes“.
//   * Stufen (LT9): text -- Rechteck, Ellipse, Raute, Schluessel unterstrichen. Zahlen 1/n/m und muss/kann an den
//     Linien kommen mit `kardinal`, Doppelellipse, schwacher Entitaetstyp und is-a mit `sonderfall` -- je mit ihrem Thema.
// Die Aufgabe (```er soll, auch ```er fuer den Anfang des Tischs):
//     Fall|Fälle: Aktenzeichen*, Titel, Beginn|Datum      Rechteck: Name|andere Namen, dann die Eigenschaften;
//     Person|Personen: *neu, Name, Adresse                 * = Schluessel; *neu = ein Schluessel, den der Text nicht
//     ◇ kommt vor in|beteiligt (Fall, Person): Rolle       nennt (Name frei); ◇ (oder <>) Name (A, B): Eigenschaften
//     # gegen Person.Rolle: Grace Okafor ist …             Gegenbeispiel fuer eine Stelle (Ding, Ding.Eigenschaft,
//                                                          Ding.schluessel, Beziehung)
// Optionen: text= · soll= · quelle= (der Tisch des Vortragsschritts) · tische=[{name, text, soll, quelle}] · stufe= ·
//   ort=vortrag (nichts gemerkt). Einbinden: Werkstaetten.er(element, opt) -> { zustand, pruefen, film }
// Film (bauen.py, WERKSTATT_FILM["er"]): + markiere: Fälle | ding · + ziehe: Datum, an dem er begonnen hat = Beginn → Fall ·
//   + ding: Fall · + eigenschaft: Titel → Fall · + beziehung: leitet → Ermittlerin, Fall · + verbinde: A → B ·
//   + haenge: Rolle → kommt vor in · + schluessel: Fall.Aktenzeichen · + umbenennen: Fälle = Fall · + loesche: X ·
//   + pruefen · + ordnen · + tisch: <name> · + neu · + halt
window.Werkstaetten = window.Werkstaetten || {};
(function () {
  // ─── Der Kern (ohne Seite; test/er_kern.mjs prueft ihn in node) ───────────────────────────────────────────────
  const K = {};
  K.STUFEN = ["text", "kardinal", "sonderfall", "schema"];
  K.norm = s => String(s || "").toLowerCase().replace(/ä/g, "ae").replace(/ö/g, "oe").replace(/ü/g, "ue").replace(/ß/g, "ss")
    .normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]/g, "");
  K.ART = { d: "Rechteck", e: "Ellipse", b: "Raute" };
  K.FARBE = { d: "Ding", e: "Eigenschaft", b: "Beziehung" };
  const kopie = x => JSON.parse(JSON.stringify(x));

  // Die Aufgabe lesen. Wirft {fehler, zeile} bei einer Zeile, die keine Form hat (bauen.py liest dieselbe Form, K1).
  K.lesen = function (quelle) {
    const m = { dinge: [], bez: [], gegen: {} };
    const namen = s => s.split("|").map(x => x.trim()).filter(Boolean);
    const attrs = s => (s || "").split(",").map(x => x.trim()).filter(Boolean).map(a => {
      const key = /\*/.test(a), roh = a.replace(/\*/g, "").trim();   // Stern vorn, hinten oder vor dem | (Dienstnummer*|Nummer)
      if (key && K.norm(roh) === "neu") return { namen: [], key: true, neu: true };
      return { namen: namen(roh), key, neu: false };
    });
    String(quelle || "").split("\n").forEach((z, i) => {
      const t = z.trim();
      if (!t) return;
      if (t.startsWith("#")) {
        const g = /^#\s*gegen\s+([^:]+):\s*(.+)$/.exec(t);
        if (g) m.gegen[K.schluesselStelle(g[1])] = g[2].trim();
        return;
      }
      let r = /^(?:◇|<>)\s*(.+?)\s*\(\s*([^,()]+?)\s*,\s*([^,()]+?)\s*\)\s*(?::\s*(.*))?$/.exec(t);
      if (r) { m.bez.push({ namen: namen(r[1]), a: r[2], b: r[3], attrs: attrs(r[4]) }); return; }
      if (/^(?:◇|<>)/.test(t)) throw { fehler: "Zeile " + (i + 1) + ": eine Beziehung steht als ◇ Name (A, B): Eigenschaften", zeile: i + 1 };
      r = /^([^:()]+?)\s*(?::\s*(.*))?$/.exec(t);
      if (!r) throw { fehler: "Zeile " + (i + 1) + ": „" + t + "“ hat keine Form -- Name: Eigenschaften oder ◇ Name (A, B)", zeile: i + 1 };
      m.dinge.push({ namen: namen(r[1]), attrs: attrs(r[2]) });
    });
    m.bez.forEach(b => ["a", "b"].forEach(s => {
      if (!m.dinge.some(d => d.namen.some(n => K.norm(n) === K.norm(b[s]))))
        throw { fehler: "◇ " + b.namen[0] + ": „" + b[s] + "“ ist kein Rechteck der Aufgabe", zeile: 0 };
    }));
    return m;
  };
  K.schluesselStelle = s => String(s).split(".").map(x => K.norm(x)).join(".");

  // Aus der Aufgabe (oder dem Anfang eines Tischs) ein Diagramm: der erste Name gilt, *neu wird „Nr“.
  K.diagrammAus = function (m) {
    const d = K.leer(); const id = {};
    m.dinge.forEach(x => {
      const r = K.neuesEl(d, "d", x.namen[0]); id[K.norm(x.namen[0])] = r.id;
      x.attrs.forEach(a => { const e = K.neuesEl(d, "e", a.neu ? "Nr" : a.namen[0]); e.key = a.key; K.verbinden(d, e.id, r.id); });
    });
    m.bez.forEach(x => {
      const r = K.neuesEl(d, "b", x.namen[0]);
      const finde = n => { const dd = m.dinge.find(y => y.namen.some(z => K.norm(z) === K.norm(n))); return dd ? id[K.norm(dd.namen[0])] : null; };
      [finde(x.a), finde(x.b)].forEach(z => { if (z) K.verbinden(d, r.id, z); });
      x.attrs.forEach(a => { const e = K.neuesEl(d, "e", a.namen[0] || "Nr"); K.verbinden(d, e.id, r.id); });
    });
    K.ordnen(d);
    return d;
  };

  K.leer = () => ({ el: [], li: [], marken: [], n: 1 });
  K.neuesEl = function (d, art, name, x, y) {
    const e = { id: "z" + (d.n++), art, name: name || "", x: x || 0, y: y || 0, key: false, anker: null };
    d.el.push(e); return e;
  };
  K.el = (d, id) => d.el.find(e => e.id === id);
  K.linienVon = (d, id) => d.li.filter(l => l.a === id || l.b === id);
  K.nachbarn = (d, id) => K.linienVon(d, id).map(l => K.el(d, l.a === id ? l.b : l.a)).filter(Boolean);
  // verbinden: nur erlaubte Paare (Rechteck–Ellipse, Raute–Ellipse, Raute–Rechteck), keine doppelte Linie
  K.verbinden = function (d, a, b) {
    if (a === b) return null;
    if (d.li.some(l => (l.a === a && l.b === b) || (l.a === b && l.b === a))) return null;
    const l = { id: "l" + (d.n++), a, b }; d.li.push(l); return l;
  };
  K.loeschen = function (d, id) {
    d.el = d.el.filter(e => e.id !== id);
    d.li = d.li.filter(l => l.id !== id && l.a !== id && l.b !== id);
  };

  // ─── Groessen ───
  let messer = null;
  K.breite = function (t, fett) {
    try {
      if (!messer && typeof document !== "undefined") messer = document.createElement("canvas").getContext("2d");
      if (messer) { messer.font = (fett ? "700 " : "500 ") + "15.5px 'Exo 2', system-ui, sans-serif"; return messer.measureText(t || "").width; }
    } catch (e) {}
    return (t || "").length * 8.6;
  };
  K.mass = function (e) {
    const tw = Math.max(K.breite(e.name || "  ", e.art === "d"), 24);
    if (e.art === "d") return { w: Math.max(120, tw + 38), h: 46 };
    if (e.art === "e") return { rx: tw / 2 + 19, ry: 21 };
    return { hw: tw / 2 + 36, hh: 31 };
  };
  K.trifft = function (e, x, y) {
    const m = K.mass(e), dx = x - e.x, dy = y - e.y;
    if (e.art === "d") return Math.abs(dx) <= m.w / 2 && Math.abs(dy) <= m.h / 2;
    if (e.art === "e") return (dx * dx) / (m.rx * m.rx) + (dy * dy) / (m.ry * m.ry) <= 1;
    return Math.abs(dx) / m.hw + Math.abs(dy) / m.hh <= 1;
  };
  K.griffPunkt = function (e) {
    const m = K.mass(e);
    if (e.art === "d") return { x: e.x + m.w / 2, y: e.y + m.h / 2 };
    if (e.art === "e") return { x: e.x + m.rx * .78, y: e.y + m.ry * .78 };
    return { x: e.x + m.hw, y: e.y };
  };

  // ─── Ordnen: Rechtecke in einer Reihe, Rauten dazwischen, Ellipsen um ihr Zeichen ───
  K.ordnen = function (d) {
    const Y = 250, LUECKE = 14, OBEN = 118, UNTEN = 112;
    const dinge = d.el.filter(e => e.art === "d"), rauten = d.el.filter(e => e.art === "b");
    const rautenDinge = r => K.nachbarn(d, r.id).filter(x => x.art === "d");
    const nb = new Map(dinge.map(x => [x.id, new Set()]));
    rauten.forEach(r => { const ds = rautenDinge(r); for (let i = 0; i < ds.length; i++) for (let j = 0; j < ds.length; j++) if (i !== j) nb.get(ds[i].id).add(ds[j].id); });
    // eine Kette: vom Rechteck mit den wenigsten Nachbarn (aber mindestens einem) aus, immer zum naechsten freien Nachbarn
    const folge = [], frei = new Set(dinge.map(x => x.id));
    while (frei.size) {
      const kand = [...frei].sort((a, b) => (nb.get(a).size || 99) - (nb.get(b).size || 99) || dinge.findIndex(x => x.id === a) - dinge.findIndex(x => x.id === b));
      let akt = kand[0];
      while (akt) {
        folge.push(akt); frei.delete(akt);
        akt = [...nb.get(akt)].find(n => frei.has(n)) || null;
      }
    }
    // die Ellipsen je Zeichen
    const ell = new Map(), lose = [];
    d.el.filter(e => e.art === "e").forEach(e => {
      const o = K.nachbarn(d, e.id).find(x => x.art !== "e");
      if (!o) { lose.push(e); return; }
      if (!ell.has(o.id)) ell.set(o.id, []);
      ell.get(o.id).push(e);
    });
    const breiteE = e => 2 * K.mass(e).rx;
    const reiheBreite = l => l.reduce((s, e) => s + breiteE(e), 0) + LUECKE * Math.max(0, l.length - 1);
    // an einem Rechteck: oben, solange die Reihe nicht breiter als 380 wird, der Rest unten
    const teil = new Map();
    folge.forEach(id => {
      const l = ell.get(id) || [], oben = [], unten = [];
      l.forEach(e => (reiheBreite(oben.concat(e)) <= 380 || !oben.length ? oben : unten).push(e));
      teil.set(id, { oben, unten });
    });
    // Abstand zweier Nachbarn in der Kette: Rechtecke, Raute dazwischen, die Reihen oben und unten
    const halb = id => K.mass(K.el(d, id)).w / 2;
    let x = 0;
    folge.forEach((id, i) => {
      const e = K.el(d, id);
      if (i > 0) {
        const vor = folge[i - 1], r = rauten.find(q => { const ds = rautenDinge(q); return ds.some(y => y.id === vor) && ds.some(y => y.id === id); });
        const mitte = r ? 2 * K.mass(r).hw + 56 : 90;
        const t0 = teil.get(vor), t1 = teil.get(id);
        x += Math.max(halb(vor) + mitte + halb(id), reiheBreite(t0.oben) / 2 + reiheBreite(t1.oben) / 2 + 40,
          reiheBreite(t0.unten) / 2 + reiheBreite(t1.unten) / 2 + 40);
      }
      e.x = x; e.y = Y;
    });
    const platz = new Map(folge.map((id, i) => [id, i]));
    const belegt = {};
    rauten.forEach(r => {
      const ds = rautenDinge(r).sort((a, b) => platz.get(a.id) - platz.get(b.id));
      if (ds.length >= 2) {
        const i = platz.get(ds[0].id), j = platz.get(ds[ds.length - 1].id), k = i + "-" + j;
        const n = belegt[k] = (belegt[k] || 0) + 1;
        r.x = (ds[0].x + ds[ds.length - 1].x) / 2;
        r.y = Y + (j === i + 1 && n === 1 ? 0 : 190 * (n - (j === i + 1 ? 1 : 0)));
      } else if (ds.length === 1) { r.x = ds[0].x + 170; r.y = Y + 190; }
      else { r.x = x + 260; r.y = Y; x += 260; }
    });
    // eine Reihe Ellipsen mittig ueber (oder unter) ihr Zeichen legen, leicht gewoelbt
    const legen = (l, o, dy) => {
      let xx = o.x - reiheBreite(l) / 2;
      l.forEach((e, i) => {
        const w = breiteE(e); e.x = xx + w / 2; xx += w + LUECKE;
        const rand = l.length > 2 && (i === 0 || i === l.length - 1) ? 22 : 0;
        e.y = o.y + dy - Math.sign(dy) * rand;
      });
    };
    folge.forEach(id => { const o = K.el(d, id), t = teil.get(id); legen(t.oben, o, -OBEN); legen(t.unten, o, UNTEN); });
    rauten.forEach(r => { const l = ell.get(r.id); if (l) legen(l, r, UNTEN); });
    let lx = 0; lose.forEach(e => { e.x = lx + breiteE(e) / 2; e.y = Y + 320; lx += breiteE(e) + LUECKE; });
    K.einpassen(d, true);
    return d;
  };
  // ein freier Platz fuer die Ellipse e an ihrem Zeichen o: oben zuerst (an einer Raute unten), sonst weiter aussen
  K.freierPlatz = function (d, o, e) {
    const m = K.mass(e), ww = o.art === "b" ? [90, 125, 55, 160, 20, -90] : [-90, -125, -55, -155, -25, 90, 125, 55];
    const frei = (x, y) => !d.el.some(z => z !== e && z !== o && [[0, 0], [m.rx * .9, 0], [-m.rx * .9, 0], [0, m.ry], [0, -m.ry]].some(([a, b]) => K.trifft(z, x + a, y + b)));
    for (const ring of [1, 1.45, 1.9]) for (const w of ww) {
      const r = w * Math.PI / 180, x = o.x + Math.cos(r) * 130 * ring, y = o.y + Math.sin(r) * 112 * ring;
      if (y > 20 && x > 30 && frei(x, y)) return { x: Math.round(x / 8) * 8, y: Math.round(y / 8) * 8 };
    }
    return { x: o.x, y: o.y - 120 };
  };
  // ein neues Zeichen ablegen (beim Markieren): Rechtecke und Rauten in einer Reihe, in der Folge des Texts -- so steht
  // die Raute „kommen … vor“ von selbst zwischen Fall und Person; lose Ellipsen oben, bis sie jemand anhaengt
  K.ablegen = function (d, e) {
    const halb = z => { const m = K.mass(z); return { b: m.w ? m.w / 2 : m.rx || m.hw, h: m.h ? m.h / 2 : m.ry || m.hh }; };
    const me = halb(e);
    const frei = (x, y) => !d.el.some(z => { if (z === e) return false; const hz = halb(z); return Math.abs(z.x - x) < me.b + hz.b + 22 && Math.abs(z.y - y) < me.h + hz.h + 12; });
    const reihen = e.art === "e" ? [64, 128] : [250, 440];
    for (const y of reihen) for (let x = me.b + 24; x < 4000; x += 8) if (frei(x, y)) return { x: Math.round(x / 8) * 8, y };
    return { x: me.b + 24, y: reihen[0] };
  };
  // alles ins Positive schieben (ein Rand bleibt), auf 8 px einrasten
  K.einpassen = function (d, ganz) {
    if (!d.el.length) return;
    let mx = Infinity, my = Infinity;
    d.el.forEach(e => { const m = K.mass(e); mx = Math.min(mx, e.x - (m.w ? m.w / 2 : m.rx || m.hw)); my = Math.min(my, e.y - (m.h ? m.h / 2 : m.ry || m.hh)); });
    const dx = ganz ? 24 - mx : Math.max(0, 24 - mx), dy = ganz ? 24 - my : Math.max(0, 24 - my);   // von Hand gelegt: nur schieben, was ueber den Rand ragt
    d.el.forEach(e => { e.x = Math.round((e.x + dx) / 8) * 8; e.y = Math.round((e.y + dy) / 8) * 8; });
  };

  // ─── Pruefen ────────────────────────────────────────────────────────────────────────────────────────────────
  // Gibt [{art: "form"|"aufgabe"|"text", chip, text, ids}] -- leer heisst: passt.
  const pl = (n, ein, mehr) => n === 1 ? ein : mehr;
  K.form = function (d) {
    const m = [];
    const name = e => e.name.trim() || "(ohne Namen)";
    d.el.forEach(e => {
      if (!e.name.trim()) m.push({ art: "form", chip: "Form", text: "Ein" + (e.art === "e" ? "e Ellipse" : e.art === "b" ? "e Raute" : " Rechteck") + " hat noch keinen Namen.", ids: [e.id] });
      // eine Stelle aus dem Text ist kein Name („als Zeugin, als Verdächtiger, …“) -- Rauten duerfen drei Woerter haben
      else if (/,/.test(e.name) || e.name.trim().split(/\s+/).length > (e.art === "b" ? 3 : 2))
        m.push({ art: "form", chip: name(e).length > 20 ? name(e).slice(0, 18) + "…" : name(e), text: "Ein Zeichen trägt einen kurzen Namen, nicht die Stelle aus dem Text – ein, zwei Wörter genügen.", ids: [e.id] });
    });
    d.li.forEach(l => {
      const a = K.el(d, l.a), b = K.el(d, l.b); if (!a || !b) return;
      const p = [a.art, b.art].sort().join("");
      if (p === "dd") m.push({ art: "form", chip: "Form", text: "Zwischen zwei Rechtecken steht immer eine Raute: " + name(a) + " und " + name(b) + " sind direkt verbunden.", ids: [l.id] });
      else if (p === "ee") m.push({ art: "form", chip: "Form", text: "Eine Ellipse hängt an einem Rechteck oder einer Raute, nie an einer anderen Ellipse: " + name(a) + " – " + name(b) + ".", ids: [l.id] });
      else if (p === "bb") m.push({ art: "form", chip: "Form", text: "Zwei Rauten verbindet keine Linie: " + name(a) + " – " + name(b) + ".", ids: [l.id] });
    });
    d.el.filter(e => e.art === "e").forEach(e => {
      const o = K.nachbarn(d, e.id).filter(x => x.art !== "e");
      if (!K.linienVon(d, e.id).length) m.push({ art: "form", chip: name(e), text: "Die Ellipse " + name(e) + " hängt an nichts.", ids: [e.id] });
      else if (o.length > 1) m.push({ art: "form", chip: name(e), text: "Die Ellipse " + name(e) + " hängt an " + o.length + " Zeichen – eine Eigenschaft gehört zu genau einem.", ids: [e.id] });
      if (e.key && o.length === 1 && o[0].art === "b") m.push({ art: "form", chip: name(e), text: "Eine Eigenschaft an einer Raute wird nicht unterstrichen – den Schlüssel hat ein Rechteck.", ids: [e.id] });
    });
    d.el.filter(e => e.art === "b").forEach(e => {
      const n = K.nachbarn(d, e.id).filter(x => x.art === "d").length;
      if (n !== 2) m.push({ art: "form", chip: "◇ " + name(e), text: "Die Raute " + name(e) + " verbindet " + (n === 0 ? "kein Rechteck" : n === 1 ? "ein Rechteck" : n + " Rechtecke") + " – eine Raute verbindet zwei.", ids: [e.id] });
    });
    const gesehen = {};
    d.el.filter(e => e.art === "d").forEach(e => {
      const k = K.norm(e.name); if (k && gesehen[k]) m.push({ art: "form", chip: name(e), text: "Zwei Rechtecke heißen " + name(e) + " – ein Ding steht einmal im Diagramm.", ids: [e.id] }); gesehen[k] = 1;
      if (!K.nachbarn(d, e.id).some(x => x.art === "e" && x.key) && e.name.trim())
        m.push({ art: "form", chip: name(e), text: "Das Rechteck " + name(e) + " hat noch keinen Schlüssel – woran unterscheidest du zwei davon?", ids: [e.id] });
    });
    return m;
  };

  K.pruefen = function (d, soll, text) {
    const m = K.form(d);
    if (text != null) {
      const offen = d.marken.filter(mk => !d.el.some(e => e.anker === mk.id));
      if (offen.length) m.push({ art: "text", chip: "Text", text: offen.length === 1 ? "Eine markierte Stelle hat noch kein Zeichen – sie ist im Text wellig unterstrichen."
        : offen.length + " markierte Stellen haben noch kein Zeichen – sie sind im Text wellig unterstrichen.", ids: [] });
    }
    if (!soll) return m;
    const G = soll.gegen || {};
    const gegen = (...stellen) => { for (const s of stellen) { const t = G[K.schluesselStelle(s)]; if (t) return t; } return null; };
    const passt = (namen, n) => namen.some(x => K.norm(x) === K.norm(n));
    const nm = e => e.name.trim();
    const rects = d.el.filter(e => e.art === "d"), rauten = d.el.filter(e => e.art === "b");
    const ellipsen = d.el.filter(e => e.art === "e");
    const besitzer = e => K.nachbarn(d, e.id).find(x => x.art !== "e") || null;
    // Rechtecke zuordnen
    const zu = new Map();   // soll-Ding -> Rechteck
    soll.dinge.forEach(sd => { const r = rects.find(x => passt(sd.namen, x.name) && ![...zu.values()].includes(x)); if (r) zu.set(sd, r); });
    const sollVon = r => [...zu.entries()].find(([, x]) => x === r);
    // Wo im Soll steht eine Eigenschaft mit diesem Namen? -> [{wo: soll-Ding|Beziehung, a}]
    const sollAttr = n => {
      const out = [];
      soll.dinge.forEach(sd => sd.attrs.forEach(a => { if (passt(a.namen, n)) out.push({ wo: sd, a, ding: true }); }));
      soll.bez.forEach(sb => sb.attrs.forEach(a => { if (passt(a.namen, n)) out.push({ wo: sb, a, ding: false }); }));
      return out;
    };
    const gemeldet = new Set();
    let eigFehlt = 0;
    // fehlende Dinge: als Ellipse gezeichnet? sonst gezaehlt
    let dingFehlt = 0;
    soll.dinge.forEach(sd => {
      if (zu.has(sd)) return;
      const als = ellipsen.find(e => passt(sd.namen, e.name));
      if (als) {
        const o = besitzer(als); gemeldet.add(als.id);
        m.push({ art: "aufgabe", chip: (o ? nm(o) + " · " : "") + nm(als), text: gegen(sd.namen[0]) ||
          nm(als) + " ist bei dir eine Eigenschaft" + (o ? " von " + nm(o) : "") + ". Laut Text hat " + nm(als) + " selbst Eigenschaften – wohin mit ihnen?", ids: [] });
      } else dingFehlt++;
    });
    if (dingFehlt) m.push({ art: "aufgabe", chip: "Text", text: "Im Text steckt noch " + dingFehlt + " " + pl(dingFehlt, "Ding", "Dinge") + " ohne Rechteck.", ids: [] });
    // Rechtecke, die nicht in der Aufgabe stehen
    rects.forEach(r => {
      if (sollVon(r) || !nm(r)) return;
      const alsAttr = sollAttr(r.name);
      m.push({ art: "aufgabe", chip: nm(r), text: alsAttr.length ? "Laut Text hat " + nm(r) + " keine eigenen Eigenschaften – es beschreibt etwas anderes."
        : nm(r) + " kommt im Text nicht als Ding vor.", ids: [] });
    });
    // Rauten zuordnen: nach den zwei Rechtecken, die sie verbinden (Namen zaehlen nur bei mehreren Kandidaten)
    const rz = new Map();   // soll-Beziehung -> Raute
    soll.bez.forEach(sb => {
      const ra = [...zu.entries()].find(([sd]) => passt(sd.namen, sb.a)), rb = [...zu.entries()].find(([sd]) => passt(sd.namen, sb.b));
      if (!ra || !rb) return;
      const kand = rauten.filter(x => ![...rz.values()].includes(x) && (() => { const n = K.nachbarn(d, x.id).filter(y => y.art === "d"); return n.includes(ra[1]) && n.includes(rb[1]); })());
      const r = kand.find(x => passt(sb.namen, x.name)) || kand[0];
      if (r) rz.set(sb, r);
    });
    const sollVonEl = o => { if (!o) return null; for (const [s, x] of zu) if (x === o) return s; for (const [s, x] of rz) if (x === o) return s; return null; };
    const richtig = x => { const s = sollVonEl(besitzer(x)); return !!(s && s.attrs.some(a => passt(a.namen, x.name))); };
    // Eigenschaften je Zeichen (Rechteck oder Raute) gegen die Aufgabe
    const eigenschaften = (sollWo, el, istDing) => {
      const da = K.nachbarn(d, el.id).filter(x => x.art === "e");
      const name = istDing ? sollWo.namen[0] : sollWo.namen[0];
      let fehlt = 0;
      sollWo.attrs.forEach(a => {
        if (a.neu) return;
        if (da.some(x => passt(a.namen, x.name))) return;
        // woanders gezeichnet?
        const anders = ellipsen.find(x => passt(a.namen, x.name) && !da.includes(x) && !gemeldet.has(x.id) && !richtig(x));
        if (anders) {
          const o = besitzer(anders); gemeldet.add(anders.id);
          m.push({ art: "aufgabe", chip: (o ? nm(o) + " · " : "") + nm(anders), text: gegen(name + "." + a.namen[0], (o ? o.name : "") + "." + a.namen[0], a.namen[0]) ||
            nm(anders) + " hängt bei dir an " + (o ? (o.art === "b" ? "der Raute " : "") + nm(o) : "nichts") + ". Beschreibt " + nm(anders) + " wirklich " + (o ? nm(o) : "es") + " allein?", ids: [] });
        } else fehlt++;
      });
      // an einem Rechteck gezaehlt; an einer Raute nur allgemein -- „der Raute fehlt eine Eigenschaft“ verriete, wohin
      // die Rolle gehoert, und das ist die Entdeckung der Stunde (text)
      if (fehlt && istDing) m.push({ art: "aufgabe", chip: nm(el), text: "Laut Text fehlt " + nm(el) + " noch " + fehlt + " " + pl(fehlt, "Eigenschaft", "Eigenschaften") + ".", ids: [] });
      else if (fehlt) eigFehlt += fehlt;
      // zu viel, und der Schluessel
      da.forEach(x => {
        if (gemeldet.has(x.id) || !nm(x)) return;
        const hier = sollWo.attrs.find(a => passt(a.namen, x.name));
        if (hier) return;
        if (istDing && x.key && sollWo.attrs.some(a => a.neu)) return;          // ein eigener Schluessel, Name frei
        const anderswo = sollAttr(x.name), alsDing = soll.dinge.find(sd => passt(sd.namen, x.name));
        if (alsDing || anderswo.length) return;   // wird beim anderen Zeichen gemeldet
        m.push({ art: "aufgabe", chip: nm(el) + " · " + nm(x), text: "Von " + nm(x) + " steht im Text nichts.", ids: [] });
      });
      if (istDing) {
        const keys = da.filter(x => x.key);
        const sollKey = sollWo.attrs.filter(a => a.key);
        const falsch = keys.find(x => sollWo.attrs.some(a => !a.key && passt(a.namen, x.name)));
        if (falsch) m.push({ art: "aufgabe", chip: nm(el) + " · Schlüssel", text: gegen(name + ".schluessel") ||
          "Zwei Einträge in " + nm(el) + " können bei " + nm(falsch) + " denselben Wert haben – dein Schlüssel hält sie nicht auseinander.", ids: [] });
        else if (keys.length && sollKey.length && !sollKey.some(a => a.neu) && !keys.some(x => sollKey.some(a => passt(a.namen, x.name))))
          m.push({ art: "aufgabe", chip: nm(el) + " · Schlüssel", text: gegen(name + ".schluessel") || "Der Text nennt schon etwas, das jedes " + nm(el) + " von allen anderen unterscheidet.", ids: [] });
      }
    };
    zu.forEach((r, sd) => eigenschaften(sd, r, true));
    // Beziehungen
    let bezFehlt = 0;
    soll.bez.forEach(sb => {
      const ra = [...zu.entries()].find(([sd]) => passt(sd.namen, sb.a)), rb = [...zu.entries()].find(([sd]) => passt(sd.namen, sb.b));
      if (!ra || !rb) return;   // ein Rechteck fehlt -- schon gemeldet
      const r = rz.get(sb);
      if (!r) { const g = gegen(sb.namen[0]); if (g) m.push({ art: "aufgabe", chip: "Beziehung", text: g, ids: [] }); else bezFehlt++; return; }
      eigenschaften(sb, r, false);
    });
    if (eigFehlt) m.push({ art: "aufgabe", chip: "Text", text: "Im Text steckt noch " + eigFehlt + " " + pl(eigFehlt, "Eigenschaft", "Eigenschaften") + " ohne Ellipse.", ids: [] });
    if (bezFehlt) m.push({ art: "aufgabe", chip: "Text", text: "Laut Text fehlt noch " + bezFehlt + " " + pl(bezFehlt, "Beziehung", "Beziehungen") + " zwischen zwei Rechtecken.", ids: [] });
    rauten.forEach(r => {
      if ([...rz.values()].includes(r) || K.nachbarn(d, r.id).filter(y => y.art === "d").length !== 2) return;
      m.push({ art: "aufgabe", chip: "◇ " + (nm(r) || "Raute"), text: "Diese Beziehung steht so nicht im Text.", ids: [] });
    });
    return m;
  };

  // Gelesen: was das Diagramm sagt, in Worten (aus Fassung B)
  K.saetze = function (d) {
    const out = [];
    const nm = e => e.name.trim() || "…";
    d.el.filter(e => e.art === "d").forEach(e => {
      const a = K.nachbarn(d, e.id).filter(x => x.art === "e");
      if (a.length) out.push({ id: e.id, text: "Je " + nm(e) + " genau ein Wert für: " + a.map(x => nm(x) + (x.key ? " (Schlüssel)" : "")).join(" · ") });
    });
    d.el.filter(e => e.art === "b").forEach(e => {
      const r = K.nachbarn(d, e.id).filter(x => x.art === "d"), a = K.nachbarn(d, e.id).filter(x => x.art === "e");
      if (r.length === 2) out.push({ id: e.id, text: nm(r[0]) + " – " + nm(e) + " – " + nm(r[1]) + (a.length ? "; je Paar genau ein Wert für: " + a.map(nm).join(" · ") : "") });
    });
    return out;
  };

  // ─── Die Werkstatt ─────────────────────────────────────────────────────────────────────────────────────────────
  // Kuerzel immer fuer beide Systeme (Lehrer 25.11.: „nur für Mac geschrieben und beschrieben“ -- die Klasse sitzt an
  // Windows-Rechnern, der Lehrer am Mac): Strg steht vorn, ⌘ dahinter
  const ICON = {
    rueck: '<path d="M6 3.5 2.5 7 6 10.5"/><path d="M3 7h6.5a3.5 3.5 0 0 1 0 7H7"/>',
    vor: '<path d="M10 3.5 13.5 7 10 10.5"/><path d="M13 7H6.5a3.5 3.5 0 0 0 0 7H9"/>',
    ordnen: '<rect x="2" y="2" width="5" height="5" rx="1.2"/><rect x="9" y="2" width="5" height="5" rx="1.2"/><rect x="2" y="9" width="5" height="5" rx="1.2"/><rect x="9" y="9" width="5" height="5" rx="1.2"/>',
    neu: '<path d="M13.2 8a5.2 5.2 0 1 1-1.6-3.7"/><path d="M12 1.8v3h-3"/>',
    pruefen: '<path d="M3 8.5 6.5 12 13 4.5"/>',
    weg: '<path d="M3 13h10"/><path d="M4.5 10.5 10 5l2.5 2.5L7 13H4.5z"/>',
  };
  const icon = n => '<svg viewBox="0 0 16 16" width="15" height="15" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">' + ICON[n] + "</svg>";
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

  window.Werkstaetten.er = function (wurzel, opt) {
    opt = opt || {};
    const vortrag = opt.ort === "vortrag";
    const h = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
    const knopf = (cls, ic, text, titel) => { const b = h("button", cls); b.type = "button"; b.innerHTML = (ic ? icon(ic) : "") + (text ? "<span>" + esc(text) + "</span>" : ""); if (titel) { b.title = titel; b.setAttribute("aria-label", titel); } return b; };

    // Tische: der des Schritts (text/soll/quelle), dazu tische= (Objekte), dazu „Eigenes“
    const liste = [];
    if (opt.text != null || opt.soll || opt.quelle) liste.push({ name: opt.name || opt.titel || "Aufgabe", text: opt.text, soll: opt.soll, quelle: opt.quelle });
    (Array.isArray(opt.tische) ? opt.tische : []).forEach(t => { if (typeof t === "object") liste.push(t); else if (t === "eigenes") liste.push({ name: "Eigenes", eigenes: true }); });
    if (!liste.some(t => t.eigenes) && opt.eigenes !== false && !vortrag) liste.push({ name: "Eigenes", eigenes: true });
    if (!liste.length) liste.push({ name: "Eigenes", eigenes: true });
    const tische = liste.map((t, i) => {
      let soll = null, start = K.leer();
      try { soll = t.soll ? K.lesen(t.soll) : null; } catch (e) { soll = null; }
      try { if (t.quelle) start = K.diagrammAus(K.lesen(t.quelle)); } catch (e) {}
      return { kennung: t.kennung || (t.eigenes ? "eigenes" : "t" + i), name: t.name || "Tisch " + (i + 1), eigenes: !!t.eigenes,
        text: t.text != null && String(t.text).trim() ? String(t.text).trim() : null, soll, start, stufe: t.stufe || opt.stufe || "text" };
    });
    const ORT = (/#\/([^/]+)\/t\/([^/]+\/[^/]+)/.exec(typeof location !== "undefined" ? location.hash || "" : "") || []).slice(1).join(":");
    const schluessel = t => "lernraum-er:" + (t.eigenes ? "eigenes" : ORT + ":" + t.kennung);
    tische.forEach(t => {
      t.d = kopie(t.start); t.rueck = []; t.vor = [];
      if (!vortrag && (t.eigenes || ORT)) { try { const g = localStorage.getItem(schluessel(t)); if (g) { const x = JSON.parse(g); if (x && Array.isArray(x.el)) t.d = x; } } catch (e) {} }
    });
    const sichern = t => { if (vortrag || (!t.eigenes && !ORT)) return; try { localStorage.setItem(schluessel(t), JSON.stringify(t.d)); } catch (e) {} };

    let tisch = tische[0], farbe = "d", auswahl = null, hover = null, zeigMarke = null, zug = null, edit = null, pruefung = null;

    // ── das Geruest ──
    wurzel.textContent = "";
    wurzel.classList.add("er-ws");
    const kopf = h("div", "er-kopf");
    const chip = h("span", "er-chip", "ER-Diagramm");
    const reiter = h("div", "er-segment tische");
    const werkzeuge = h("div", "er-segment werkzeuge");
    const kRueck = knopf("ikon", "rueck", "", "Rückgängig (Strg+Z, am Mac ⌘+Z)");
    const kVor = knopf("ikon", "vor", "", "Wiederholen (Strg+Y oder Strg+Umschalt+Z, am Mac ⌘+Umschalt+Z)");
    const kOrdnen = knopf("ikon", "ordnen", "Ordnen", "Ordnen: alles neu hinlegen");
    const kNeu = knopf("ikon", "neu", "", "Von vorn");
    const kKlein = knopf("ikon", "", "A−", "Kleiner zeigen"), kGross = knopf("ikon", "", "A+", "Größer zeigen");
    werkzeuge.append(kRueck, kVor, kOrdnen, kNeu, kKlein, kGross);
    const kPruef = knopf("primaer", "pruefen", "Prüfen", "Gegen die Aufgabe prüfen");
    const rechts = h("span", "rechts"); rechts.append(werkzeuge, kPruef);
    kopf.append(chip, reiter, rechts);

    const mitte = h("div", "er-mitte");
    const textSpalte = h("div", "er-text");
    const textKopf = h("div", "er-etikett", "Der Auftrag");
    const farben = h("div", "er-segment farben");
    const fKnoepfe = {};
    [["d", "Ding"], ["e", "Eigenschaft"], ["b", "Beziehung"], ["weg", ""]].forEach(([k, t]) => {
      const b = k === "weg" ? knopf("ikon", "weg", "Radierer", "Radierer: eine Markierung anklicken oder darüberziehen – weg") : knopf("", "", t, "Markieren als " + t);
      if (k !== "weg") b.insertAdjacentHTML("afterbegin", '<i class="er-punkt ' + k + '"></i>');
      b.addEventListener("click", () => { farbe = k; zeichneFarben(); });
      fKnoepfe[k] = b; farben.append(b);
    });
    const textEl = h("div", "er-auftrag");
    const pillenEl = h("div", "er-pillen");
    textSpalte.append(textKopf, farben, textEl, pillenEl);
    const flaeche = h("div", "er-flaeche"); flaeche.tabIndex = 0;
    flaeche.setAttribute("aria-label", "ER-Diagramm: Doppelklick legt ein Rechteck an, am Punkt ziehen verbindet");
    const buehne = h("div", "er-buehne");
    const leer = h("p", "er-leer");
    flaeche.append(buehne, leer);
    mitte.append(textSpalte, flaeche);
    const unten = h("div", "er-unten");
    const saetzeEl = h("div", "er-saetze");
    const meldEl = h("div", "er-meldungen");
    unten.append(meldEl, saetzeEl);
    const kuerzel = h("p", "er-kuerzel");
    wurzel.append(kopf, mitte, unten, kuerzel);

    // schmal (Uebungsspalte, Vortrag neben der Folie): der Text ueber der Flaeche
    const schmal = () => { const b = wurzel.getBoundingClientRect().width; if (b && wurzel.classList.contains("schmal") !== b < 860) wurzel.classList.toggle("schmal", b < 860); };
    // im naechsten Bild, nicht im Rueckruf selbst: das Umschalten aendert die Hoehe (sonst „ResizeObserver loop“)
    if (typeof ResizeObserver !== "undefined") new ResizeObserver(() => requestAnimationFrame(schmal)).observe(wurzel);

    // ── Zustand aendern ──
    function merken() { tisch.rueck.push(kopie(tisch.d)); if (tisch.rueck.length > 80) tisch.rueck.shift(); tisch.vor = []; }
    function geaendert() { pruefung = null; sichern(tisch); alles(); }
    function rueckgaengig() { if (!tisch.rueck.length) return; tisch.vor.push(kopie(tisch.d)); tisch.d = tisch.rueck.pop(); auswahl = null; geaendert(); }
    function wiederholen() { if (!tisch.vor.length) return; tisch.rueck.push(kopie(tisch.d)); tisch.d = tisch.vor.pop(); auswahl = null; geaendert(); }
    const D = () => tisch.d;

    // ── Text und Markierungen ──
    const istWort = c => /[\p{L}\p{N}-]/u.test(c || "");
    function zeichneText() {
      textSpalte.hidden = !tisch.text;
      mitte.classList.toggle("mit-text", !!tisch.text);
      if (!tisch.text) return;
      const T = tisch.text, mk = D().marken.slice().sort((a, b) => a.von - b.von);
      textEl.textContent = "";
      let pos = 0;
      const stueck = (von, bis, m) => {
        const s = h("span", m ? "er-mark " + m.art : "", T.slice(von, bis)); s.dataset.von = von;
        if (m) {
          s.dataset.mark = m.id;
          if (pruefung && !D().el.some(e => e.anker === m.id)) s.classList.add("offen");
          if (zeigMarke === m.id) s.classList.add("zeig");
        }
        textEl.append(s);
      };
      mk.forEach(m => { if (m.von > pos) stueck(pos, m.von, null); stueck(m.von, m.bis, m); pos = m.bis; });
      if (pos < T.length) stueck(pos, T.length, null);
      zeichnePillen();
    }
    function zeichneFarben() { Object.entries(fKnoepfe).forEach(([k, b]) => b.classList.toggle("an", k === farbe)); }
    function versatz(node, o) { const r = document.createRange(); r.setStart(textEl, 0); r.setEnd(node, o); return r.toString().length; }
    // Markieren legt das Zeichen gleich an (Lehrer 25.11.: „Warum muss man erst nochmal …, um das Element auch im ER
    // anzulegen, das könnte doch auch automatisch beim Markieren passieren“). Markierung und Zeichen sind ein Paar:
    // Entmarkieren loescht das Zeichen, Loeschen des Zeichens entmarkiert, Umfaerben aendert die Form. Ein Ding wird
    // Rechteck in der Reihe, eine Beziehung Raute daneben, eine EIGENSCHAFT Ellipse LOSE oben -- woran sie haengt,
    // entscheidet die Klasse und zieht sie auf ihr Rechteck oder ihre Raute (die Rolle!). Lange Stellen („Datum, an dem
    // er begonnen hat“) oeffnen gleich das Namensfeld.
    function markeWeg(m) {
      merken();
      D().marken = D().marken.filter(x => x !== m);
      D().el.filter(e => e.anker === m.id).forEach(e => K.loeschen(D(), e.id));
      auswahl = null;
      geaendert();
    }
    const langeStelle = t => t.split(" ").length > 2 || /,/.test(t);
    function zeichenFuer(m, film) {
      const roh = tisch.text.slice(m.von, m.bis).replace(/\s+/g, " ");
      const e = K.neuesEl(D(), m.art, roh); e.anker = m.id;
      const q = K.ablegen(D(), e); e.x = q.x; e.y = q.y;
      if (!film && langeStelle(roh)) neuName = e.id;
      return e;
    }
    let neuName = null;   // das Zeichen, dessen Namensfeld nach dem Zeichnen aufgeht
    function markieren(von, bis, art, film) {
      const T = tisch.text;
      while (von > 0 && istWort(T[von - 1])) von--;
      while (bis < T.length && istWort(T[bis])) bis++;
      while (von < bis && !istWort(T[von])) von++;
      while (bis > von && !istWort(T[bis - 1])) bis--;
      if (bis <= von) return false;
      merken();
      const alt = D().marken.filter(m => !(m.bis <= von || m.von >= bis));
      const genau = alt.length === 1 && alt[0].von === von && alt[0].bis === bis ? alt[0] : null;
      // ueber genau eine Markierung gezogen: dieselbe Farbe nimmt sie weg, eine andere faerbt um (das Zeichen bleibt)
      if (genau && art !== "weg") {
        if (genau.art === art) { D().marken = D().marken.filter(m => m !== genau); D().el.filter(e => e.anker === genau.id).forEach(e => K.loeschen(D(), e.id)); }
        else { genau.art = art; D().el.filter(e => e.anker === genau.id).forEach(e => { e.art = art; if (art !== "e") e.key = false; }); }
        return true;
      }
      D().marken = D().marken.filter(m => !alt.includes(m));
      D().el.filter(e => alt.some(m => m.id === e.anker)).forEach(e => K.loeschen(D(), e.id));
      if (art !== "weg") { const m = { id: "m" + (D().n++), von, bis, art }; D().marken.push(m); auswahl = zeichenFuer(m, film).id; }
      return true;
    }
    textEl.addEventListener("mouseup", () => {
      const sel = window.getSelection();
      if (!sel || !sel.rangeCount) return;
      const r = sel.getRangeAt(0);
      if (!textEl.contains(r.startContainer) || !textEl.contains(r.endContainer)) return;
      const von = versatz(r.startContainer, r.startOffset), bis = versatz(r.endContainer, r.endOffset);
      if (bis > von) { if (markieren(von, bis, farbe)) { sel.removeAllRanges(); geaendert(); namensfeld(); } return; }
    });
    textEl.addEventListener("click", ev => {
      const s = ev.target.closest && ev.target.closest(".er-mark"); if (!s || ev.detail > 1) return;
      const sel = window.getSelection(); if (sel && !sel.isCollapsed) return;
      const m = D().marken.find(x => x.id === s.dataset.mark); if (!m) return;
      // dieselbe Farbe noch einmal oder der Radierer: weg (Lehrer 25.11.: „nicht möglich, markierte Wörter komplett
      // wieder unmarkiert zu machen“); eine andere Farbe: umfaerben
      if (farbe === "weg" || m.art === farbe) markeWeg(m);
      else { markieren(m.von, m.bis, farbe); geaendert(); }
    });
    textEl.addEventListener("pointerover", ev => {
      const s = ev.target.closest && ev.target.closest(".er-mark");
      const e = s ? D().el.find(x => x.anker === s.dataset.mark) : null;
      const id = e ? e.id : null; if (id !== hover) { hover = id; zeichneFlaeche(); }
    });
    textEl.addEventListener("pointerleave", () => { if (hover) { hover = null; zeichneFlaeche(); } });
    function namensfeld() { const e = neuName && K.el(D(), neuName); neuName = null; if (e) umbenennen(e, true); }
    function zeichnePillen() {
      pillenEl.textContent = "";
      const lose = D().el.filter(e => e.art === "e" && !K.linienVon(D(), e.id).length).length;
      pillenEl.append(h("p", "er-hinweis", !D().marken.length ? "Farbe wählen, dann im Text über die Wörter ziehen – oder ein Wort doppelt anklicken. Jede Markierung erscheint gleich auf der Fläche."
        : lose ? "Eine Eigenschaft liegt lose oben auf der Fläche, bis ihr sie auf ihr Rechteck oder ihre Raute zieht." : ""));
    }
    // ein Zeichen anhaengen (Film und Ziehen): eine Ellipse gehoert zu genau einem -- neu verbunden heisst umgehaengt
    function anhaengen(e, an) {
      if (!e || !an || e === an) return false;
      if (e.art === "e" && an.art !== "e") { D().li = D().li.filter(l => l.a !== e.id && l.b !== e.id); K.verbinden(D(), e.id, an.id); const q = K.freierPlatz(D(), an, e); e.x = q.x; e.y = q.y; return true; }
      if (e.art === "b" && an.art === "d" && K.nachbarn(D(), e.id).filter(x => x.art === "d").length < 2) { K.verbinden(D(), e.id, an.id); return true; }
      return false;
    }

    // ── die Flaeche ──
    let skala = 1;
    // Inhalt: so breit und hoch wie die Zeichen (ohne Mindestmass -- sonst schrumpft ein kleines Diagramm beim Einpassen)
    function svgMasse() {
      let w = 0, hh = 0;
      D().el.forEach(e => { const m = K.mass(e); w = Math.max(w, e.x + (m.w ? m.w / 2 : m.rx || m.hw) + 40); hh = Math.max(hh, e.y + (m.h ? m.h / 2 : m.ry || m.hh) + 40); });
      return { w, h: hh };
    }
    function zeichneFlaeche() {
      skala = (parseFloat(getComputedStyle(wurzel).fontSize) || 17.5) / 17.5;
      const M = svgMasse(), f = v => (Math.round(v * 10) / 10).toString();
      // breiter als die Flaeche: kleiner zeigen, bis 60 % -- das ganze Diagramm auf einen Blick (Probe 25.11.: die
      // Ermittlerin stand rechts abgeschnitten); was dann noch nicht passt, scrollt
      const platz = flaeche.clientWidth - 4;
      if (platz > 100 && M.w * skala > platz) skala = Math.max(skala * .6, platz / M.w);
      // die Flaeche fuellen: das Bild ist mindestens so gross wie sie (Doppelklick ins Leere trifft ueberall)
      M.w = Math.max(M.w, platz > 100 ? platz / skala : 600); M.h = Math.max(M.h, 340 / skala);
      const rot = new Set((pruefung || []).flatMap(x => x.ids || []));
      let s = '<svg class="er-bild" viewBox="0 0 ' + f(M.w) + " " + f(M.h) + '" width="' + f(M.w * skala) + '" height="' + f(M.h * skala) + '" role="img" aria-label="ER-Diagramm">';
      D().li.forEach(l => {
        const a = K.el(D(), l.a), b = K.el(D(), l.b); if (!a || !b) return;
        s += '<line class="' + (auswahl === l.id ? "gewaehlt " : "") + (rot.has(l.id) ? "rot" : "") + '" x1="' + f(a.x) + '" y1="' + f(a.y) + '" x2="' + f(b.x) + '" y2="' + f(b.y) + '"/>';
      });
      if (zug && zug.art === "linie" && zug.p) {
        const a = K.el(D(), zug.von);
        if (a) s += '<line class="gummi" x1="' + f(a.x) + '" y1="' + f(a.y) + '" x2="' + f(zug.p.x) + '" y2="' + f(zug.p.y) + '"/><circle class="gummi-ende" cx="' + f(zug.p.x) + '" cy="' + f(zug.p.y) + '" r="5"/>';
      }
      const reihe = { b: 0, e: 1, d: 2 };
      D().el.slice().sort((a, b) => reihe[a.art] - reihe[b.art]).forEach(e => {
        const m = K.mass(e);
        const cls = "z " + e.art + (auswahl === e.id ? " gewaehlt" : "") + (hover === e.id ? " gezeigt" : "") + (rot.has(e.id) ? " rot" : "") + (zug && zug.ziel === e.id ? " ziel" : "") + (edit && edit.id === e.id ? " tippt" : "");
        s += '<g class="' + cls + '">';
        if (e.art === "d") s += '<rect x="' + f(e.x - m.w / 2) + '" y="' + f(e.y - m.h / 2) + '" width="' + f(m.w) + '" height="' + f(m.h) + '"/>';
        else if (e.art === "e") s += '<ellipse cx="' + f(e.x) + '" cy="' + f(e.y) + '" rx="' + f(m.rx) + '" ry="' + f(m.ry) + '"/>';
        else s += '<path d="M' + f(e.x - m.hw) + " " + f(e.y) + " L" + f(e.x) + " " + f(e.y - m.hh) + " L" + f(e.x + m.hw) + " " + f(e.y) + " L" + f(e.x) + " " + f(e.y + m.hh) + ' Z"/>';
        s += '<text x="' + f(e.x) + '" y="' + f(e.y) + '" text-anchor="middle" dominant-baseline="central"' + (e.key ? ' text-decoration="underline"' : "") + ">" + esc(e.name || "") + "</text>";
        if (auswahl === e.id || hover === e.id) { const g = K.griffPunkt(e); s += '<circle class="griff" cx="' + f(g.x) + '" cy="' + f(g.y) + '" r="7"/>'; }
        s += "</g>";
      });
      buehne.innerHTML = s + "</svg>";
      leer.hidden = !!D().el.length;
      leer.textContent = tisch.text ? "Markiert im Text – jedes markierte Wort erscheint hier als Zeichen. Doppelklick: ein neues Rechteck." : "Doppelklick: ein neues Rechteck. Am Punkt ● ziehen: eine Eigenschaft oder eine Beziehung.";
      if (edit) editLegen();
      zeichneLeiste();
    }
    // die kleine Leiste am gewaehlten Zeichen: Schluessel, umbenennen, loeschen
    const leiste = h("div", "er-leiste"); flaeche.append(leiste);
    function zeichneLeiste() {
      const e = auswahl && K.el(D(), auswahl), l = !e && auswahl && D().li.find(x => x.id === auswahl);
      leiste.textContent = ""; leiste.hidden = !(e || l) || !!edit || !!zug;
      if (leiste.hidden) return;
      const p = e ? (() => { const m = K.mass(e); return { x: e.x + (m.w ? m.w / 2 : m.rx || m.hw), y: e.y - (m.h ? m.h / 2 : m.ry || m.hh) }; })()
        : (() => { const a = K.el(D(), l.a), b = K.el(D(), l.b); return { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }; })();
      if (e && e.art === "e") { const k = knopf(e.key ? "an" : "", "", "Schlüssel", "Schlüssel (S): unterstreichen"); k.setAttribute("aria-pressed", String(!!e.key)); k.onclick = () => schluesselUm(e); leiste.append(k); }
      if (e) { const k = knopf("", "", "umbenennen", "Umbenennen (Doppelklick, Enter)"); k.onclick = () => umbenennen(e); leiste.append(k); }
      const w = knopf("gefahr", "", "löschen", "Löschen (Entf)"); w.onclick = () => entfernen(); leiste.append(w);
      leiste.style.left = (p.x * skala + 6) + "px"; leiste.style.top = Math.max(0, p.y * skala - 40) + "px";
    }

    function punktAus(cx, cy) {
      const svg = buehne.querySelector("svg"); if (!svg) return { x: 0, y: 0 };
      const r = svg.getBoundingClientRect(); return { x: (cx - r.left) / skala, y: (cy - r.top) / skala };
    }
    function innen(cx, cy) { const r = flaeche.getBoundingClientRect(); return cx >= r.left && cx <= r.right && cy >= r.top && cy <= r.bottom; }
    function treffer(x, y, ohne) {
      const reihe = { e: 0, b: 1, d: 2 };
      return D().el.filter(e => e.id !== ohne).sort((a, b) => reihe[a.art] - reihe[b.art]).find(e => K.trifft(e, x, y)) || null;
    }
    function linieBei(x, y) {
      return D().li.find(l => {
        const a = K.el(D(), l.a), b = K.el(D(), l.b); if (!a || !b) return false;
        const vx = b.x - a.x, vy = b.y - a.y, t = Math.max(0, Math.min(1, ((x - a.x) * vx + (y - a.y) * vy) / (vx * vx + vy * vy || 1)));
        return Math.hypot(a.x + t * vx - x, a.y + t * vy - y) < 7;
      }) || null;
    }
    function griffBei(x, y) {
      for (const id of [auswahl, hover]) { const e = id && K.el(D(), id); if (e) { const g = K.griffPunkt(e); if (Math.hypot(g.x - x, g.y - y) < 12) return e; } }
      return null;
    }

    // Doppelklick: am zweiten Druck erkannt -- das Bild wird bei jedem Druck neu gezeichnet, ein dblclick-Ereignis fände
    // sein Ziel nicht mehr (Probe test/er.mjs, 25.11.)
    let letzterDruck = { t: 0, x: -99, y: -99 };
    flaeche.addEventListener("pointerdown", ev => {
      if (ev.button > 0 || edit) return;
      if (ev.target.closest(".er-leiste")) return;
      const p = punktAus(ev.clientX, ev.clientY);
      const jetzt = Date.now(), zweiter = ev.detail >= 2 || (jetzt - letzterDruck.t < 450 && Math.hypot(ev.clientX - letzterDruck.x, ev.clientY - letzterDruck.y) < 6);
      letzterDruck = zweiter ? { t: 0, x: -99, y: -99 } : { t: jetzt, x: ev.clientX, y: ev.clientY };
      if (zweiter) { ev.preventDefault(); doppelklick(p); return; }
      const g = griffBei(p.x, p.y);
      flaeche.focus({ preventScroll: true });
      if (g) { ev.preventDefault(); flaeche.setPointerCapture(ev.pointerId); zug = { art: "linie", von: g.id, p }; zeichneFlaeche(); return; }
      const e = treffer(p.x, p.y);
      if (e) { ev.preventDefault(); flaeche.setPointerCapture(ev.pointerId); auswahl = e.id; zug = { art: "schieben", id: e.id, dx: p.x - e.x, dy: p.y - e.y, p0: p, weit: false }; zeichneFlaeche(); return; }
      const l = linieBei(p.x, p.y);
      auswahl = l ? l.id : null; zeichneFlaeche();
    });
    flaeche.addEventListener("pointermove", ev => {
      const p = punktAus(ev.clientX, ev.clientY);
      if (!zug) {
        const e = treffer(p.x, p.y) || griffBei(p.x, p.y);
        const id = e ? e.id : null;
        if (id !== hover) { hover = id; const a = e && e.anker; if (a !== zeigMarke) { zeigMarke = a || null; zeichneText(); } zeichneFlaeche(); }
        return;
      }
      if (zug.art === "schieben") {
        if (!zug.weit && Math.hypot(p.x - zug.p0.x, p.y - zug.p0.y) < 3) return;
        if (!zug.weit) { merken(); zug.weit = true; wurzel.classList.add("zieht"); }
        const e = K.el(D(), zug.id); e.x = Math.max(30, Math.round((p.x - zug.dx) / 8) * 8); e.y = Math.max(26, Math.round((p.y - zug.dy) / 8) * 8);
        // eine Ellipse (oder Raute) ueber einem Zeichen, an das sie passt: das Ziel leuchtet, Loslassen haengt an
        const z = e.art !== "d" ? treffer(p.x, p.y, e.id) : null;
        zug.ziel = z && ((e.art === "e" && z.art !== "e") || (e.art === "b" && z.art === "d")) ? z.id : null;
        zeichneFlaeche();
      } else if (zug.art === "linie") {
        zug.p = p; const z = treffer(p.x, p.y, zug.von); zug.ziel = z ? z.id : null; zeichneFlaeche();
      }
    });
    flaeche.addEventListener("pointerup", ev => {
      if (!zug) return;
      const z = zug; zug = null; wurzel.classList.remove("zieht");
      if (z.art === "schieben") {
        if (z.weit) { if (z.ziel) anhaengen(K.el(D(), z.id), K.el(D(), z.ziel)); D().hand = true; geaendert(); } else zeichneFlaeche();
        return;
      }
      if (z.art === "linie") {
        const p = punktAus(ev.clientX, ev.clientY), von = K.el(D(), z.von), ziel = treffer(p.x, p.y, z.von);
        if (ziel) verbindeZeichen(von, ziel);
        else if (Math.hypot(p.x - von.x, p.y - von.y) > 30 && von.art !== "e") {
          merken(); const e = K.neuesEl(D(), "e", "", Math.round(p.x / 8) * 8, Math.round(p.y / 8) * 8); K.verbinden(D(), e.id, von.id);
          auswahl = e.id; geaendert(); umbenennen(e, true, true);
        } else zeichneFlaeche();
      }
    });
    function doppelklick(p) {
      zug = null; wurzel.classList.remove("zieht");
      const e = treffer(p.x, p.y);
      if (e) { umbenennen(e); return; }
      merken(); const r = K.neuesEl(D(), "d", "", Math.max(70, Math.round(p.x / 8) * 8), Math.max(30, Math.round(p.y / 8) * 8));
      auswahl = r.id; geaendert(); umbenennen(r, true, true);
    }
    function meldeKurz(t) { kurzMeldung = t; zeichneMeldungen(); }
    let kurzMeldung = "";
    function verbindeZeichen(a, b) {
      const p = [a.art, b.art].sort().join("");
      if (p === "ee") { meldeKurz("Eine Ellipse hängt an einem Rechteck oder einer Raute, nicht an einer Ellipse."); zeichneFlaeche(); return; }
      if (p === "bb") { meldeKurz("Zwei Rauten verbindet keine Linie – zwischen ihnen steht ein Rechteck."); zeichneFlaeche(); return; }
      merken();
      if (p === "dd") {
        // zwei Rechtecke: die Raute kommt dazwischen, ihr Name gleich danach
        const r = K.neuesEl(D(), "b", "", Math.round((a.x + b.x) / 16) * 8, Math.round((a.y + b.y) / 16) * 8);
        K.verbinden(D(), r.id, a.id); K.verbinden(D(), r.id, b.id); auswahl = r.id; geaendert(); umbenennen(r, true, true); return;
      }
      if (a.art === "e" || b.art === "e") {
        // eine Ellipse haengt an genau einem: wer sie neu verbindet, haengt sie um
        const el = a.art === "e" ? a : b;
        D().li = D().li.filter(l => !(l.a === el.id || l.b === el.id));
      }
      K.verbinden(D(), a.id, b.id); auswahl = null; kurzMeldung = ""; geaendert();
    }
    function schluesselUm(e) { if (e.art !== "e") return; merken(); e.key = !e.key; geaendert(); }
    function entfernen() {
      if (!auswahl) return;
      merken();
      const e = K.el(D(), auswahl);
      if (e && e.anker) D().marken = D().marken.filter(m => m.id !== e.anker);   // ein Paar: das Zeichen weg, die Markierung weg
      K.loeschen(D(), auswahl); auswahl = null; geaendert();
    }

    // Namensfeld ueber dem Zeichen
    const feld = h("input", "er-feld"); feld.type = "text"; feld.spellcheck = false;
    function umbenennen(e, markieren, neu) {
      edit = { id: e.id, alt: e.name, neu: !!neu };
      feld.value = e.name; flaeche.append(feld); zeichneFlaeche(); editLegen();
      feld.focus({ preventScroll: true }); if (markieren) feld.select();
    }
    function editLegen() {
      const e = edit && K.el(D(), edit.id); if (!e) return;
      const w = Math.max(130, K.breite(feld.value || "", e.art === "d") + 40) * skala;
      feld.style.width = w + "px"; feld.style.left = (e.x * skala - w / 2) + "px"; feld.style.top = (e.y * skala - 15 * skala) + "px";
      feld.style.fontWeight = e.art === "d" ? "700" : "500";
    }
    feld.addEventListener("input", editLegen);
    function editEnde(ok) {
      if (!edit) return;
      const e = K.el(D(), edit.id), war = edit; edit = null; feld.remove();
      if (!e) { alles(); return; }
      const t = feld.value.replace(/\s+/g, " ").trim();
      if (!ok || !t) {
        if (war.neu && !t) { K.loeschen(D(), e.id); if (tisch.rueck.length) tisch.rueck.pop(); auswahl = null; }
        else e.name = war.alt;
        alles(); flaeche.focus({ preventScroll: true }); return;
      }
      if (t !== war.alt) { if (!war.neu) merken(); e.name = t; geaendert(); }
      else alles();
      flaeche.focus({ preventScroll: true });
    }
    feld.addEventListener("keydown", ev => { ev.stopPropagation(); if (ev.key === "Enter") { ev.preventDefault(); editEnde(true); } else if (ev.key === "Escape") { ev.preventDefault(); editEnde(false); } });
    feld.addEventListener("blur", () => editEnde(true));

    // Die Tasten hoert das Dokument (Capture), solange zuletzt in die Werkstatt geklickt wurde: Nach dem Markieren im Text
    // oder dem Ziehen auf der Flaeche steht der Fokus nicht in der Werkstatt, und ⌘Z ging an den Browser, der zurueck wollte
    // (Lehrer 25.11.). Ein Klick ausserhalb gibt die Tasten wieder frei; ist die Werkstatt weg, haengt der Hoerer sich ab.
    let aktiv = false;
    const beiDruck = ev => { if (!wurzel.isConnected) { document.removeEventListener("pointerdown", beiDruck, true); return; } aktiv = wurzel.contains(ev.target); };
    document.addEventListener("pointerdown", beiDruck, true);
    const beiTaste = ev => {
      if (!wurzel.isConnected) { document.removeEventListener("keydown", beiTaste, true); return; }
      if (!aktiv && !wurzel.contains(document.activeElement)) return;
      const ziel = document.activeElement || ev.target;
      if (edit || (ziel && (/INPUT|TEXTAREA|SELECT/.test(ziel.tagName) || ziel.isContentEditable || (ziel.closest && ziel.closest(".cm-editor"))))) return;
      if ((ev.metaKey || ev.ctrlKey) && /^[zy]$/i.test(ev.key)) ev.stopPropagation();
      const mod = ev.metaKey || ev.ctrlKey;
      if (mod && ev.key.toLowerCase() === "z") { ev.preventDefault(); if (ev.shiftKey) wiederholen(); else rueckgaengig(); return; }
      if (mod && ev.key.toLowerCase() === "y") { ev.preventDefault(); wiederholen(); return; }
      if (ev.key === "Escape") { if (zug) { zug = null; wurzel.classList.remove("zieht"); } auswahl = null; zeichneFlaeche(); return; }
      const e = auswahl && K.el(D(), auswahl);
      if ((ev.key === "Delete" || ev.key === "Backspace") && auswahl) { ev.preventDefault(); entfernen(); return; }
      if (e && (ev.key === "s" || ev.key === "S") && !mod) { ev.preventDefault(); schluesselUm(e); return; }
      if (e && (ev.key === "Enter" || ev.key === "F2")) { ev.preventDefault(); umbenennen(e, true); }
    };
    document.addEventListener("keydown", beiTaste, true);

    // ── unten: Meldungen und Saetze ──
    function zeichneMeldungen() {
      meldEl.textContent = "";
      if (kurzMeldung) meldEl.append(h("div", "er-meldung kurz", kurzMeldung));
      if (!pruefung) return;
      if (!pruefung.length) {
        const ok = h("div", "er-pruefung ok"); ok.append(h("span", "er-pruefung-titel", "Geprüft: passt"),
          document.createTextNode(tisch.soll ? " – jedes Ding, jede Eigenschaft und jede Beziehung aus dem Text hat ihr Zeichen." : " – die Form stimmt."));
        meldEl.append(ok); return;
      }
      const MAX = 5;
      pruefung.slice(0, MAX).forEach(x => {
        const k = h("div", "er-meldung " + x.art); k.append(h("span", "er-meldung-chip", x.chip), h("span", "", x.text)); meldEl.append(k);
      });
      if (pruefung.length > MAX) meldEl.append(h("p", "er-mehr", "… und " + (pruefung.length - MAX) + " weitere – erst diese."));
    }
    function zeichneSaetze() {
      saetzeEl.textContent = "";
      const s = K.saetze(D()); if (!s.length) return;
      saetzeEl.append(h("div", "er-etikett", "So liest sich dein Diagramm"));
      s.forEach(x => { const p = h("span", "er-satz" + (auswahl === x.id ? " gewaehlt" : ""), x.text); saetzeEl.append(p); });
    }
    function zeichneKopf() {
      reiter.textContent = ""; reiter.hidden = tische.length < 2;
      tische.forEach(t => { const b = knopf(t === tisch ? "an" : "", "", t.name); b.onclick = () => { if (t === tisch) return; tisch = t; auswahl = null; pruefung = null; kurzMeldung = ""; alles(); }; reiter.append(b); });
      kRueck.disabled = !tisch.rueck.length; kVor.disabled = !tisch.vor.length;
      kPruef.querySelector("span").textContent = "Prüfen";
      kPruef.title = tisch.soll ? "Gegen die Aufgabe prüfen" : "Die Form prüfen";
    }
    function zeichneKuerzel() {
      const k = (t) => "<kbd>" + t + "</kbd>";
      kuerzel.innerHTML = (tisch.text ? "Farbe wählen, dann über den Text <b>ziehen</b>: markieren – das Zeichen erscheint auf der Fläche · dieselbe Farbe noch einmal oder der Radierer: weg · <b>Ellipse auf ihr Rechteck oder ihre Raute ziehen</b>: hängt daran · " : "") +
        k("Doppelklick") + " ins Leere: Rechteck · am Punkt ● ziehen: auf ein Zeichen eine Linie, ins Leere eine Eigenschaft · Zeichen ziehen: verschieben · " +
        k("Doppelklick") + " auf ein Zeichen: umbenennen · " + k("S") + " Schlüssel · " + k("Entf") + " oder " + k("⌫") + " löschen · " + k("Strg") + "+" + k("Z") + " (Mac: " + k("⌘") + "+" + k("Z") + ") rückgängig, " + k("Strg") + "+" + k("Y") + " wiederholen · " + k("Esc") + " abbrechen";
    }
    function alles() { zeichneKopf(); zeichneFarben(); zeichneText(); zeichneFlaeche(); zeichneMeldungen(); zeichneSaetze(); zeichneKuerzel(); schmal(); }

    function pruefen() { kurzMeldung = ""; pruefung = K.pruefen(D(), tisch.soll, tisch.text); auswahl = null; zeichneText(); zeichneFlaeche(); zeichneMeldungen(); }
    function ordnen() { merken(); D().hand = false; K.ordnen(D()); geaendert(); }
    function vonVorn() { merken(); tisch.d = kopie(tisch.start); auswahl = null; geaendert(); }
    kRueck.addEventListener("click", rueckgaengig);
    kVor.addEventListener("click", wiederholen);
    kOrdnen.addEventListener("click", ordnen);
    kNeu.addEventListener("click", vonVorn);
    kPruef.addEventListener("click", pruefen);
    const zoom = d => { if (typeof schriftAendern === "function") schriftAendern(d, "werkstatt"); else wurzel.style.fontSize = Math.max(60, Math.min(180, (parseFloat(wurzel.style.fontSize) || 100) + d * 15)) + "%"; alles(); };
    kKlein.addEventListener("click", () => zoom(-1));
    kGross.addEventListener("click", () => zoom(1));

    alles();

    // ─── Film (Vortrag, wie der Code-Film) ───
    const ART_WORT = { ding: "d", eigenschaft: "e", beziehung: "b" };
    function finde(ref) {
      ref = String(ref || "").trim(); if (!ref) return null;
      const i = ref.indexOf(".");
      if (i > 0) {
        const o = finde(ref.slice(0, i)); if (!o) return null;
        return K.nachbarn(D(), o.id).find(x => x.art === "e" && K.norm(x.name) === K.norm(ref.slice(i + 1))) || null;
      }
      const reihe = { d: 0, b: 1, e: 2 };
      return D().el.slice().sort((a, b) => reihe[a.art] - reihe[b.art]).find(e => K.norm(e.name) === K.norm(ref)) || null;
    }
    function filmSchritt(x) {
      const b = String(x.befehl || ""), pfeil = b.split("→").map(s => s.trim());
      const a = x.aktion;
      if (a === "markiere") {
        const [stelle, art] = b.split("|").map(s => s.trim()), mm = /^(.*?)(?:#(\d+))?$/.exec(stelle);
        if (!tisch.text) return;
        let von = -1; for (let n = 0; n < (+mm[2] || 1); n++) von = tisch.text.indexOf(mm[1], von + 1);
        if (von >= 0) { markieren(von, von + mm[1].length, ART_WORT[art] || "d", true); }
      } else if (a === "ziehe") {
        const ziel = pfeil[1] ? finde(pfeil[1]) : null, [stelle, name] = pfeil[0].split("=").map(s => s.trim()), mm = /^(.*?)(?:#(\d+))?$/.exec(stelle);
        const ms = D().marken.filter(m => tisch.text.slice(m.von, m.bis) === mm[1]).sort((p, q) => p.von - q.von);
        const m = ms[(+mm[2] || 1) - 1];
        if (!m) return;
        // das Zeichen dieser Stelle (beim Markieren angelegt) benennen und anhaengen -- fehlt es, entsteht es hier
        merken();
        const e = D().el.find(x => x.anker === m.id) || zeichenFuer(m, true);
        if (name) e.name = name;
        if (ziel) anhaengen(e, ziel);
        K.ordnen(D());
      } else if (a === "ding") { merken(); K.neuesEl(D(), "d", b.trim()); K.ordnen(D()); }
      else if (a === "eigenschaft") { const o = finde(pfeil[1]); merken(); const e = K.neuesEl(D(), "e", pfeil[0]); if (o) K.verbinden(D(), e.id, o.id); K.ordnen(D()); }
      else if (a === "beziehung") { merken(); const r = K.neuesEl(D(), "b", pfeil[0]); (pfeil[1] || "").split(",").map(s => finde(s)).forEach(o => { if (o) K.verbinden(D(), r.id, o.id); }); K.ordnen(D()); }
      else if (a === "verbinde" || a === "haenge") {
        const p = finde(pfeil[0]), q = finde(pfeil[1]); if (!p || !q) return;
        merken(); if (a === "haenge") D().li = D().li.filter(l => l.a !== p.id && l.b !== p.id); K.verbinden(D(), p.id, q.id); K.ordnen(D());
      } else if (a === "schluessel") { const e = finde(b); if (e && e.art === "e") { merken(); e.key = !e.key; } }
      else if (a === "umbenennen") { const [alt, neu] = b.split("=").map(s => s.trim()); const e = finde(alt); if (e && neu) { merken(); e.name = neu; K.ordnen(D()); } }
      else if (a === "loesche") { const e = finde(b); if (e) { merken(); if (e.anker) D().marken = D().marken.filter(m => m.id !== e.anker); K.loeschen(D(), e.id); K.ordnen(D()); } }
      else if (a === "pruefen") { sichern(tisch); alles(); pruefen(); return; }
      else if (a === "ordnen") { ordnen(); return; }
      else if (a === "tisch") { const t = tische.find(t => K.norm(t.name) === K.norm(x.wert) || t.kennung === x.wert); if (t) { tisch = t; pruefung = null; } }
      else if (a === "neu") { tisch.d = kopie(tisch.start); tisch.rueck = []; pruefung = null; }
      auswahl = null; pruefung = a === "halt" ? pruefung : null; sichern(tisch); alles();
    }
    function filmHerstellen(liste) {
      tische.forEach(t => { t.d = kopie(t.start); t.rueck = []; t.vor = []; });
      tisch = tische[0]; pruefung = null; auswahl = null; edit = null; feld.remove(); kurzMeldung = "";
      liste.forEach(x => filmSchritt(Object.assign({}, x)));
      if (edit) editEnde(true);
      alles();
      if (liste.length && liste[liste.length - 1].aktion === "pruefen") pruefen();
    }
    return {
      zustand: () => kopie(tisch.d), tisch: () => tisch.name, pruefung: () => pruefung && kopie(pruefung), pruefen: () => { pruefen(); return kopie(pruefung); },
      film: { spielen: x => { if (edit) editEnde(true); filmSchritt(Object.assign({}, x)); }, herstellen: filmHerstellen, laeuft: () => false },
    };
  };
  window.Werkstaetten.er.kern = K;
  window.Werkstaetten.er.einleitung = "Die Werkstatt ER: Markiert im Auftrag, was ein Ding, eine Eigenschaft und eine Beziehung ist. Jede Markierung erscheint gleich auf der Fläche; eine Eigenschaft zieht ihr auf ihr Rechteck oder ihre Raute – so wird aus dem Text ein ER-Diagramm wie im Abitur: Rechteck, Ellipse, Raute, der Schlüssel unterstrichen. „Prüfen“ nennt ein Gegenbeispiel, nie die Lösung.";
  window.Werkstaetten.er.kurz = "ER-Diagramm aus dem Text: markieren, die Eigenschaften anhängen, „Prüfen“ nennt ein Gegenbeispiel.";
})();
