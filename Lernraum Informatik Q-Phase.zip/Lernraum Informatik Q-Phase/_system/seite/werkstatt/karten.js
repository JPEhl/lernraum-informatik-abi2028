// Werkstatt "Karten" -- Mitgliedskarten des Schachportals, verdeckt: Der Tisch sagt nur, welche von zwei Karten die
// hoehere Wertung hat, und zaehlt. iq1 schach, Teil II (16.11.2026). Drei Attrappen im Film (verdeckt und frei · offen
// mit zwei Zeigern · der Tisch fuehrt eine Vorschrift aus); Lehrerwahl: Fassung A „verdeckt und frei“. Anlass ist sein
// Wunsch, „die Schüler am Anfang auch experimentieren zu lassen. Sie sollen selbst möglichst ‚effiziente‘ Sortierungen
// entwerfen“ -- offene Karten sortiert das Auge, also liegen sie verdeckt, und „effizient“ heisst: wenige Vergleiche.
// Tische (LT9: ein Tisch erscheint erst mit seinem Thema):
//   sortieren -- sortieren: je zwei beliebige Karten vergleichen, tauschen, aufdecken; 4, 8 oder 16 Karten
//   zaehlen   -- sortieren, bubblesort: erst schaetzen, dann zaehlt der Tisch den Bubblesort; Tabelle und Kurve
//   nachbarn  -- bubblesort: nur das Paar am Zeiger -- vergleichen, tauschen, weiter; nach jedem Durchgang liegt eine fest
//   halbieren -- halbieren: sortiert und verdeckt, jede aufgedeckte Karte ist eine Frage
//   ablegen   -- sortieren (Uebung, Expertenaufgabe): Karten in NEUE Reihen legen statt tauschen -- Auswaehlen in eine
//                neue Reihe, Einsortieren in eine neue Reihe, Mischen zweier sortierter Reihen (Lehrer 17.11.2026: „bei den
//                Karten eine Möglichkeit einzurichten, auch nicht in place Algorithmen herauszufinden“). Gezaehlt wird nur
//                der Vergleich; Legen kostet nichts (gezaehlt als „gelegt“, kein Vergleich).
// Kein Rueckgaengig: Ein Vergleich, der gezaehlt ist, bleibt gezaehlt. „von vorn“ legt dieselben Karten wieder hin.
// Ziehen (Lehrer 16.11.2026: „per Drag and Drop auf den Tisch und wieder zurück“ -- „und trotzdem auch mit Knöpfen“):
// am Tisch sortieren laesst sich eine Karte zusaetzlich zum Klick auf den Vergleichstisch und von dort zurueck in die
// Reihe ziehen -- mit Zeiger-Ereignissen (Maus, Finger, Stift), ueber denselben Codeweg wie Klick und Knopf.
// „als Python zeigen“ gibt es nur, wo der Schritt python="ja" traegt (nachbarn, halbieren): Aus Plaetzen werden Indizes.
// Einbinden: Werkstaetten.karten(element, {tisch: "sortieren"} | {tische: "sortieren|zaehlen|ablegen"})
//   -> { zustand, film: {spielen, herstellen, laeuft} }
// Film (bauen.py, WERKSTATT_FILM): + vergleiche: 3 6 · + tausche · + aufdecken · + karten: 16 · + paar · + weiter ·
//   + durchgang · + schaetze: 30 · + lauf · + suche: 1418 · + decke: 8 · + python · + neu · + halt
window.Werkstaetten = window.Werkstaetten || {};
window.Werkstaetten.karten = function (wurzel, opt) {
  opt = opt || {};
  // die zwanzig Mitglieder in der Reihenfolge ihrer Anmeldung -- dieselben wie in rangliste/mitglieder.py
  const MITGLIEDER = [["Aylin", 1480], ["Bence", 1215], ["Chiara", 1630], ["Dawit", 1342], ["Emre", 1105], ["Finja", 1577], ["Goran", 1290],
    ["Hanh", 1418], ["Ilias", 1048], ["Jule", 1466], ["Kofi", 1712], ["Liv", 1322], ["Milan", 1189], ["Nuria", 1540], ["Oskar", 1401],
    ["Pari", 1273], ["Quinn", 1433], ["Rosa", 1163], ["Samir", 1502], ["Tuana", 1251]];
  // fuer den Tisch zaehlen: bis 64 Karten -- die zwanzig, danach Wertungen aus einer festen Folge (kein Zufall im Vortrag)
  const VIELE = MITGLIEDER.map(m => m[1]);
  for (let i = 20, x = 7; i < 64; i++) { x = (x * 73 + 41) % 997; VIELE.push(1000 + x); }
  // halbieren: sortiert, mit Luecken und einer Wertung, die zweimal vorkommt
  const SORTIERT = [1048, 1105, 1163, 1215, 1215, 1290, 1342, 1377, 1418, 1466, 1502, 1540, 1577, 1630, 1712];
  const SUCHEN = [1418, 1105, 1630, 1215, 1540];
  const NAMEN = { sortieren: "Sortieren", zaehlen: "Zählen", nachbarn: "Nur Nachbarn", halbieren: "Halbieren", ablegen: "Ablegen" };
  const STUFEN = [4, 8, 16, 32, 64];
  const tische = String(opt.tische || opt.tisch || "sortieren").split("|").map(t => t.trim()).filter(t => NAMEN[t]);
  if (!tische.length) tische.push("sortieren");
  const mitPython = opt.python === "ja";

  const h = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
  const knopf = (text, cls, fn) => { const b = h("button", cls || "", text); b.type = "button"; b.onclick = fn; return b; };
  const platz = i => i + 1;

  let tisch = tische[0];
  const eigen = {};             // was das Paar am Tisch sortieren geschafft hat: Karten -> Vergleiche (fuer den Tisch zaehlen)
  let z = neu(tisch);

  function neu(t, behalte) {
    if (t === "sortieren" || t === "nachbarn") {
      const n = behalte && behalte.n || parseInt(opt.karten, 10) || 8;
      return { tisch: t, n, reihe: (behalte && behalte.start || MITGLIEDER.slice(0, n).map((m, i) => i)).slice(), start: behalte && behalte.start || MITGLIEDER.slice(0, n).map((m, i) => i),
        wahl: [], allein: "links", vergleiche: 0, tausche: 0, offen: false, urteil: "", protokoll: [], zeiger: 0, fest: 0, durchgang: 1, verglichen: false, python: false };
    }
    if (t === "ablegen") {
      // reihen: die Reihen, die Karten tragen (leere verschwinden), je mit einem Buchstaben, der bleibt; dazu liegt immer
      // eine leere „neue Reihe“ bereit. wahl: Kennungen der Karten (nicht Plaetze) -- die Plaetze wandern beim Legen.
      const n = behalte && behalte.n || parseInt(opt.karten, 10) || 8;
      const start = (behalte && behalte.start || MITGLIEDER.slice(0, n).map((m, i) => i)).slice();
      return { tisch: t, n, start, reihen: [{ name: "A", karten: start.slice() }], zuletzt: 0,
        wahl: [], allein: "links", vergleiche: 0, gelegt: 0, offen: false, urteil: "", protokoll: [], verglichen: false, python: false };
    }
    if (t === "zaehlen") return { tisch: t, n: 4, geschaetzt: {}, eigen: Object.assign({}, eigen), bubble: {}, meldung: "" };
    return { tisch: t, ziel: behalte && behalte.ziel || SUCHEN[0], offen: [], links: 0, rechts: SORTIERT.length - 1, fragen: 0, gefunden: -1, urteil: "", protokoll: [], python: false };
  }
  const kopie = o => JSON.parse(JSON.stringify(o));

  // ─── rechnen ───────────────────────────────────────────────────────────────────────
  // Der Vergleichstisch hat zwei feste Plätze, links und rechts (Lehrer 18.11.2026: „wenn man die linke Karte vom
  // Vergleichsstapel wieder zurücklegt, [rückt] die rechte Karte nach links … Sie soll aber wieder an die freie Stelle im
  // Kartendeck gehen“): Wer zurückgelegt wird, geht in die Reihe, die andere bleibt, wo sie liegt, und die nächste
  // gewählte Karte füllt den freien Platz. z.wahl liest den Tisch von links nach rechts (0, 1 oder 2 Karten) -- als Folge
  // bleibt es, was Vergleich, Tausch und Urteil lesen; liegt nur eine Karte dort, sagt z.allein, auf welchem Platz.
  // Für beide Tische mit einzelnem Zurücklegen (sortieren: Plätze, ablegen: Kennungen der Karten).
  const tischPlaetze = () => z.wahl.length === 2 ? z.wahl.slice() : z.wahl.length === 1 ? (z.allein === "rechts" ? [null, z.wahl[0]] : [z.wahl[0], null]) : [null, null];
  // welche Ablage die nächste Karte füllt (ein voller Tisch wird geräumt, dann links)
  const freieAblage = () => z.wahl.length === 1 && z.allein === "links" ? 1 : 0;
  function auflegen(x) {
    if (z.wahl.length === 2) z.wahl = [];
    if (!z.wahl.length) { z.wahl = [x]; z.allein = "links"; }
    else z.wahl = z.allein === "rechts" ? [x, z.wahl[0]] : [z.wahl[0], x];
  }
  function wegnehmen(x) {
    const i = z.wahl.indexOf(x); if (i < 0) return;
    if (z.wahl.length === 2) z.allein = i === 0 ? "rechts" : "links";
    z.wahl = z.wahl.filter(y => y !== x);
  }
  const wert = i => MITGLIEDER[z.reihe[i]][1];
  function schreibe(text, code) { z.protokoll.unshift(z.python && code ? code : text); if (z.protokoll.length > 60) z.protokoll.pop(); }
  function vergleiche(a, b) {
    if (z.offen || a === b) return;
    z.vergleiche++; z.wahl = [a, b]; z.verglichen = true;
    const hoeher = wert(a) > wert(b) ? a : b;
    z.urteil = z.python ? "liste[" + a + "].get_wertung() > liste[" + b + "].get_wertung()  →  " + (wert(a) > wert(b) ? "True" : "False")
      : "Platz " + platz(a) + " und Platz " + platz(b) + ": Die höhere Wertung liegt auf Platz " + platz(hoeher) + ".";
    schreibe(platz(a) + " ? " + platz(b) + " – höher: Platz " + platz(hoeher), "liste[" + a + "] > liste[" + b + "]: " + (wert(a) > wert(b) ? "True" : "False"));
  }
  function tausche() {
    if (z.offen || z.wahl.length !== 2) return;
    const [a, b] = z.wahl; [z.reihe[a], z.reihe[b]] = [z.reihe[b], z.reihe[a]]; z.tausche++;
    z.urteil = z.python ? "merke = liste[" + a + "]   liste[" + a + "] = liste[" + b + "]   liste[" + b + "] = merke" : "Getauscht: Platz " + platz(a) + " und Platz " + platz(b) + ".";
    schreibe(platz(a) + " ↔ " + platz(b) + " getauscht", "liste[" + a + "] ↔ liste[" + b + "]");
    if (z.tisch === "sortieren") z.wahl = [];
  }
  // Tisch sortieren: eine Karte der Reihe wählen (Klick oder auf den Tisch gezogen) -- die zweite ist ein Vergleich;
  // ihr leerer Platz angeklickt legt sie zurück, eine dritte räumt den Tisch
  function waehle(i) {
    if (z.offen || z.tisch !== "sortieren") return;
    if (z.wahl.includes(i)) zurueck(i);
    else { auflegen(i); if (z.wahl.length === 2) vergleiche(z.wahl[0], z.wahl[1]); else { z.urteil = ""; z.verglichen = false; } }
  }
  // Tisch sortieren: eine Karte vom Vergleichstisch zurück auf ihren Platz (Klick auf die Karte dort oder in die Reihe
  // gezogen, ihr leerer Platz angeklickt) -- die andere bleibt auf ihrer Seite des Tischs
  function zurueck(i) {
    if (z.offen || z.tisch !== "sortieren") return;
    wegnehmen(i); z.urteil = ""; z.verglichen = false;
  }
  const sortiert = () => z.reihe.every((k, i) => !i || MITGLIEDER[z.reihe[i - 1]][1] <= MITGLIEDER[k][1]);
  function aufdecken() {
    if (z.tisch === "ablegen") { aufdeckenAblegen(); return; }
    if (z.offen) return;
    z.offen = true; z.wahl = [];
    const gut = sortiert();
    z.urteil = gut ? "Sortiert – mit " + z.vergleiche + (z.vergleiche === 1 ? " Vergleich" : " Vergleichen") + " und " + z.tausche + (z.tausche === 1 ? " Tausch." : " Täuschen.")
      : "Noch nicht sortiert. " + z.vergleiche + " Vergleiche, " + z.tausche + " Täusche.";
    if (gut && z.tisch === "sortieren") { eigen[z.n] = z.vergleiche; try { sessionStorage.setItem("lernraum.karten.eigen", JSON.stringify(eigen)); } catch (e) {} }
  }
  // Tisch nachbarn: das Paar am Zeiger
  const paarEnde = () => z.n - 1 - z.fest;                   // der letzte Platz, an dem noch ein Paar beginnt, ist paarEnde - 1
  function paar() { if (!z.offen && z.fest < z.n - 1) vergleiche(z.zeiger, z.zeiger + 1); }
  function weiter() {
    if (z.offen || z.fest >= z.n - 1) return;
    z.wahl = []; z.verglichen = false; z.zeiger++;
    if (z.zeiger >= paarEnde()) {
      z.fest++; z.zeiger = 0;
      if (z.fest >= z.n - 1) { z.fest = z.n; z.urteil = "Kein Paar mehr übrig – " + z.vergleiche + " Vergleiche."; schreibe("fertig nach " + (z.durchgang) + " Durchgängen"); }
      else { schreibe("Durchgang " + z.durchgang + " zu Ende – Platz " + platz(z.n - z.fest) + " liegt fest"); z.durchgang++; z.urteil = "Durchgang " + z.durchgang + ": Die letzte Karte liegt fest."; }
    } else z.urteil = "";
  }
  function durchgang() {
    if (z.offen || z.fest >= z.n - 1) return;
    const d = z.durchgang;
    while (z.durchgang === d && z.fest < z.n - 1) { paar(); if (wert(z.zeiger) > wert(z.zeiger + 1)) tausche(); weiter(); }
  }
  // Tisch zaehlen: der Bubblesort mit zwei Schleifen, ohne fruehen Abbruch -- gezaehlt, nicht ausgerechnet
  function bubbleZaehlen(n) {
    const a = VIELE.slice(0, n); let v = 0;
    for (let d = 0; d < n - 1; d++) for (let i = 0; i < n - 1 - d; i++) { v++; if (a[i] > a[i + 1]) { const m = a[i]; a[i] = a[i + 1]; a[i + 1] = m; } }
    return v;
  }
  function lauf() {
    if (z.geschaetzt[z.n] == null || z.geschaetzt[z.n] === "") { z.meldung = "Erst schätzen: Wie viele Vergleiche braucht der Bubblesort bei " + z.n + " Karten?"; return; }
    z.bubble[z.n] = bubbleZaehlen(z.n); z.meldung = z.n + " Karten: " + z.bubble[z.n] + " Vergleiche.";
  }
  // Tisch halbieren
  function decke(i) {
    if (z.gefunden >= 0 || z.links > z.rechts || z.offen.includes(i) || i < 0 || i >= SORTIERT.length) return;
    z.offen.push(i); z.fragen++;
    const w = SORTIERT[i];
    if (w === z.ziel) { z.gefunden = i; z.urteil = "Platz " + platz(i) + " zeigt " + w + ": gefunden – nach " + z.fragen + (z.fragen === 1 ? " Frage." : " Fragen."); schreibe("Platz " + platz(i) + ": " + w + " – gefunden", "liste[" + i + "] == " + z.ziel); return; }
    if (w < z.ziel) { z.links = Math.max(z.links, i + 1); z.urteil = "Platz " + platz(i) + " zeigt " + w + ": zu niedrig – alles links davon fällt weg."; schreibe("Platz " + platz(i) + ": " + w + " – zu niedrig", "liste[" + i + "] < " + z.ziel + ": links = " + (i + 1)); }
    else { z.rechts = Math.min(z.rechts, i - 1); z.urteil = "Platz " + platz(i) + " zeigt " + w + ": zu hoch – alles rechts davon fällt weg."; schreibe("Platz " + platz(i) + ": " + w + " – zu hoch", "liste[" + i + "] > " + z.ziel + ": rechts = " + (i - 1)); }
    if (z.links > z.rechts) z.urteil += " Kein Platz bleibt: Die Wertung " + z.ziel + " gibt es nicht.";
  }
  // Tisch ablegen (17.11.2026): Karten in neue Reihen legen. Eine Karte heißt nach ihrem Ort, „B2“ = Reihe B, Platz 2 --
  // wie ein Index wandert der Ort, wenn davor eine Karte weggenommen oder eingefügt wird.
  const BUCHSTABEN = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const wertK = k => MITGLIEDER[k][1];
  function ort(k) { for (const r of z.reihen) { const i = r.karten.indexOf(k); if (i >= 0) return { r, i }; } return null; }
  const ortName = k => { const o = ort(k); return o ? o.r.name + (o.i + 1) : "?"; };
  // der Buchstabe der nächsten neuen Reihe: der nächste freie nach dem zuletzt vergebenen (höchstens 16 Reihen tragen Karten)
  function naechsteReihe() { const belegt = new Set(z.reihen.map(r => r.name)); for (let s = 1; s <= 26; s++) { const i = (z.zuletzt + s) % 26; if (!belegt.has(BUCHSTABEN[i])) return i; } return 0; }
  function waehleK(k) {
    if (z.offen || z.tisch !== "ablegen" || !ort(k)) return;
    if (z.wahl.includes(k)) { zurueckK(k); return; }
    auflegen(k);
    if (z.wahl.length === 2) vergleicheK(z.wahl[0], z.wahl[1]); else { z.urteil = ""; z.verglichen = false; }
  }
  function vergleicheK(a, b) {
    z.vergleiche++; z.verglichen = true;
    const hoeher = wertK(a) > wertK(b) ? a : b;
    z.urteil = ortName(a) + " und " + ortName(b) + ": Die höhere Wertung liegt auf " + ortName(hoeher) + ".";
    schreibe(ortName(a) + " ? " + ortName(b) + " – höher: " + ortName(hoeher));
  }
  function zurueckK(k) {
    if (z.offen || z.tisch !== "ablegen") return;
    wegnehmen(k); z.urteil = ""; z.verglichen = false;
  }
  // eine Karte in Reihe `name` vor Platz pos+1 legen (pos = Länge: ans Ende); name null: in eine neue Reihe.
  // Kostet keinen Vergleich. Liegt die Karte auf dem Vergleichstisch, verlässt sie ihn -- die andere bleibt liegen, auf
  // ihrer Seite.
  function lege(k, name, pos) {
    if (z.offen || z.tisch !== "ablegen") return false;
    const q = ort(k); if (!q) return false;
    const von = q.r.name + (q.i + 1);
    let ziel = null, neueI = -1;
    if (name == null) { neueI = naechsteReihe(); ziel = { name: BUCHSTABEN[neueI], karten: [] }; pos = 0; }
    else {
      ziel = z.reihen.find(r => r.name === name); if (!ziel) return false;
      pos = Math.max(0, Math.min(pos == null ? ziel.karten.length : pos, ziel.karten.length));
      // an den eigenen Platz: Das ist kein Legen -- liegt sie auf dem Tisch, geht sie zurück
      if (ziel === q.r && (pos === q.i || pos === q.i + 1)) { if (z.wahl.includes(k)) zurueckK(k); return false; }
    }
    q.r.karten.splice(q.i, 1);
    if (ziel === q.r && pos > q.i) pos--;
    ziel.karten.splice(pos, 0, k);
    if (neueI >= 0) { z.zuletzt = neueI; z.reihen.push(ziel); }
    z.reihen = z.reihen.filter(r => r.karten.length);
    z.gelegt++;
    if (z.wahl.includes(k)) { wegnehmen(k); z.verglichen = false; }
    const nach = ortName(k);
    z.urteil = "Gelegt: " + von + " → " + nach + (neueI >= 0 ? " (neue Reihe " + ziel.name + ")" : "") + ". Kein Vergleich – Legen kostet nichts.";
    schreibe(von + " → " + nach + " gelegt");
    return true;
  }
  const reiheSortiert = r => r.karten.every((k, i) => !i || wertK(r.karten[i - 1]) <= wertK(k));
  function aufdeckenAblegen() {
    if (z.offen) return;
    z.offen = true; z.wahl = []; z.verglichen = false;
    const v = z.vergleiche + (z.vergleiche === 1 ? " Vergleich" : " Vergleiche");
    if (z.reihen.length === 1 && reiheSortiert(z.reihen[0])) {
      z.urteil = "Sortiert – alle Karten in Reihe " + z.reihen[0].name + ", mit " + z.vergleiche + (z.vergleiche === 1 ? " Vergleich." : " Vergleichen.");
      eigen[z.n] = z.vergleiche; try { sessionStorage.setItem("lernraum.karten.eigen", JSON.stringify(eigen)); } catch (e) {}
    } else if (z.reihen.length === 1) z.urteil = "Noch nicht sortiert. " + v + ".";
    else {
      const s = z.reihen.filter(r => r.karten.length > 1 && reiheSortiert(r)).map(r => r.name);
      z.urteil = "Noch nicht fertig: Die Karten liegen in " + z.reihen.length + " Reihen. " + (s.length ? "Unter sich sortiert: Reihe " + s.join(", ") + ". " : "") + v + ".";
    }
  }

  // ─── zeichnen ──────────────────────────────────────────────────────────────────────
  wurzel.textContent = "";
  wurzel.classList.add("kartentisch");
  const reiter = h("div", "kt-reiter"), flaeche = h("div", "kt-flaeche");
  if (tische.length > 1) wurzel.append(reiter);
  wurzel.append(flaeche);
  function wechsle(t) { tisch = t; z = neu(t); zeichnen(); }

  function zaehler(...paare) { const d = h("div", "kt-zaehler"); for (const [name, zahl] of paare) { const k = h("div"); k.append(h("small", "", name), h("strong", "", String(zahl))); d.append(k); } return d; }
  function protokollEl() { const u = h("ul", "kt-protokoll" + (z.python ? " code" : "")); z.protokoll.forEach(t => u.append(h("li", "", t))); return u; }
  let eng = false;
  // Tastatur (Tisch ablegen): Nach dem Neuzeichnen steht der Fokus wieder dort, wo er war -- auf dem Element mit demselben
  // data-fokus, sonst auf der Karte, um die es ging (fokusWunsch, nach dem Legen: die gelegte Karte)
  let fokusWunsch = null;
  function karte(inhalt, i, cls, fn) {
    const k = knopf("", "kt-karte " + cls, fn);
    if (inhalt) k.append(h("span", "kt-name", inhalt[0]), h("span", "kt-wert", String(inhalt[1])));
    // enge Reihe (mehr als 8 Karten): unter den Karten nur die Zahl -- „Platz 10“ bis „Platz 15“ lagen übereinander (Fotos iq1 halbieren, 16.11.)
    k.append(h("span", "kt-platz", (z.python ? "[" + i + "]" : (eng && i > 0 ? "" : "Platz ") + platz(i))));
    k.setAttribute("aria-label", (inhalt ? inhalt[0] + " " + inhalt[1] + ", " : "verdeckte Karte, ") + "Platz " + platz(i));
    return k;
  }
  function pillen(aktiv, fn, werte) { const d = h("div", "kt-pillen"); d.append(h("span", "", "Karten")); (werte || STUFEN).forEach(n => d.append(knopf(String(n), "kt-pille" + (n === aktiv ? " an" : ""), () => fn(n)))); return d; }

  // Karten gleiten sichtbar an ihren neuen Ort (Durchsicht iq1, 16.11.2026: „Das Tauschen sollte visuell animiert
  // werden“ · „Das Tauschen/Anschauen etc. sollte klarer animiert werden“): Die Fläche wird bei jedem Schritt neu
  // gezeichnet; jede Karte trägt ihre Kennung (data-karte), und wer danach woanders liegt, fährt von der alten Lage
  // dorthin -- vom Platz auf den Vergleichstisch, über Kreuz beim Tausch, zurück in die Reihe.
  const ohneBewegung = !!(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);
  function lagen() { const m = new Map(); flaeche.querySelectorAll("[data-karte]").forEach(e => m.set(e.dataset.karte, e.getBoundingClientRect())); return m; }
  function gleiten(vorher) {
    if (ohneBewegung || !vorher.size) return;
    flaeche.querySelectorAll("[data-karte]").forEach(e => {
      const a = vorher.get(e.dataset.karte); if (!a || !e.animate) return;
      const b = e.getBoundingClientRect(), dx = a.left - b.left, dy = a.top - b.top;
      if (!b.width || (Math.abs(dx) < 1 && Math.abs(dy) < 1)) return;
      e.animate([{ transformOrigin: "0 0", transform: "translate(" + dx + "px, " + dy + "px) scale(" + (a.width / b.width) + ")", zIndex: 3 }, { transformOrigin: "0 0", transform: "none", zIndex: 3 }],
        { duration: 560, easing: "cubic-bezier(.2,.7,.3,1)" });
    });
  }
  // ─── ziehen (16.11.2026) ──────────────────────────────────────────────────────────
  // Zeiger-Ereignisse statt der Drag-and-Drop-Schnittstelle von HTML5: Die kennt den Finger am Tablet nicht. Ein Druck,
  // der sich weniger als die Schwelle bewegt, bleibt ein Klick (der Browser schickt click, onclick tut das Übrige). Was das
  // Loslassen bewirkt, entscheiden dieselben Funktionen wie Klick und Knopf: waehle(), zurueck(), tausche().
  //   Reihe → Tisch:  über dem Vergleichstisch loslassen = die Karte anklicken
  //   Tisch → Reihe:  über der Reihe loslassen = die Karte dort anklicken (nur sie geht zurück, auf ihren Platz);
  //                   über dem leeren Platz der ANDEREN Karte loslassen = „tauschen“
  //   daneben loslassen: Die Karte gleitet zurück, nichts ist geschehen.
  // Schwelle in Pixeln: Der Finger wackelt beim Tippen mehr als die Maus -- ein Tipp soll nicht als abgebrochener Zug enden
  const SCHWELLE = 6, SCHWELLE_FINGER = 10;
  let zug = null;               // {el, art: "reihe"|"tisch", i, id, x0, y0, schwelle, los, geist}
  let geschluckt = 0;           // wann der letzte Zug endete -- der click, den der Browser danach schickt, zählt nicht
  const nachZug = ev => { const ja = geschluckt > 0 && ev.detail > 0 && Date.now() - geschluckt < 500; geschluckt = 0; return ja; };
  const andere = () => zug && zug.art === "tisch" && z.wahl.length === 2 ? z.wahl.find(x => x !== zug.i) : null;
  const leerplatz = i => i == null ? null : flaeche.querySelector('.kt-karte.leerplatz[data-platz="' + i + '"]');
  // Großzügige Ziele (Lehrer 17.11.2026: „die Karten rasten nur bei genauem Zielen ein -- wenn man zu schnell oder etwas
  // zu ungenau ist, klappt es nicht“): Es zählt nicht nur die Spitze des Zeigers, sondern auch die gezogene Karte selbst
  // (ihre Mitte, oder dass sie das Ziel überhaupt berührt), und um jedes Ziel liegt ein Rand, der mitzählt -- zur
  // anderen Zone hin bis an deren Kante, damit die Lücke zwischen Reihe und Tisch nicht ins Leere führt; nach unten
  // reicht der Tisch über Urteilszeile und Knöpfe, damit ein schneller Wurf über das Ziel hinaus noch ankommt.
  const RAND = 48, UNTEN = 140;
  const imFeld = (f, x, y) => x >= f.left && x <= f.right && y >= f.top && y <= f.bottom;
  const beruehrt = (a, b) => a.left < b.right && a.right > b.left && a.top < b.bottom && a.bottom > b.top;
  function zielBei(x, y) {
    const k = zug.el.getBoundingClientRect(), mx = (k.left + k.right) / 2, my = (k.top + k.bottom) / 2;
    const tisch = flaeche.querySelector(".kt-tisch"), reihe = flaeche.querySelector(".kt-reihe");
    if (!tisch || !reihe) return null;
    const t = tisch.getBoundingClientRect(), r = reihe.getBoundingClientRect();
    const trifft = (feld, echt) => imFeld(feld, x, y) || imFeld(feld, mx, my) || beruehrt(k, echt);
    if (zug.art === "reihe") {
      const feld = { left: t.left - RAND, right: t.right + RAND, top: Math.min(t.top - RAND, r.bottom), bottom: t.bottom + UNTEN };
      return trifft(feld, t) ? "tisch" : null;
    }
    const feld = { left: r.left - RAND, right: r.right + RAND, top: r.top - RAND, bottom: Math.max(r.bottom + RAND, t.top) };
    if (!trifft(feld, r)) return null;
    // Tauschen: Die Mitte der Karte liegt über dem leeren Platz der anderen (mit einer halben Kartenbreite Spiel) --
    // und näher an ihm als am eigenen Platz, damit bei vielen schmalen Karten das Zurücklegen nicht zum Tausch wird
    const p = leerplatz(andere()), e = leerplatz(zug.i);
    if (p) {
      const pr = p.getBoundingClientRect(), spiel = (pr.right - pr.left) / 2, pm = (pr.left + pr.right) / 2;
      const em = e ? (e.getBoundingClientRect().left + e.getBoundingClientRect().right) / 2 : Infinity;
      if (mx >= pr.left - spiel && mx <= pr.right + spiel && Math.abs(mx - pm) < Math.abs(mx - em)) return "tausch";
    }
    return "zurueck";
  }
  function markiere(ziel) {
    flaeche.querySelectorAll(".drueber").forEach(e => e.classList.remove("drueber"));
    if (ziel === "tisch") {
      const t = flaeche.querySelector(".kt-tisch"), frei = t.querySelectorAll(".kt-ablage")[freieAblage()];
      t.classList.add("drueber"); if (frei) frei.classList.add("drueber");
    } else if (ziel) { const p = leerplatz(ziel === "tausch" ? andere() : zug.i); if (p) p.classList.add("drueber"); }
  }
  // Tisch ablegen: Ziele sind der Vergleichstisch (nur für Karten aus einer Reihe), jede Lücke einer Reihe, die neue
  // Reihe und -- für eine Tischkarte -- ihr eigener leerer Platz. Welche Reihe: die unter dem Zeiger, sonst die unter der
  // Mitte der Karte (mit einem Rand); welche Lücke: nach der Mitte der Karte zwischen den Mitten der Karten der Reihe.
  const RAND_REIHE = 18;
  const umFeld = (r, px, py, m) => px >= r.left - m && px <= r.right + m && py >= r.top - m && py <= r.bottom + m;
  function alZielBei(x, y) {
    const k = zug.el.getBoundingClientRect(), mx = (k.left + k.right) / 2, my = (k.top + k.bottom) / 2;
    let beste = null;
    flaeche.querySelectorAll(".kt-zeile").forEach(e => {
      const r = e.getBoundingClientRect(), d = umFeld(r, x, y, RAND_REIHE) ? 0 : umFeld(r, mx, my, RAND_REIHE) ? 1 : null;
      if (d != null && (!beste || d < beste.d)) beste = { d, e };
    });
    if (beste) return alInReihe(beste.e, mx);
    const t = flaeche.querySelector(".kt-tisch");
    if (zug.art === "reihe" && t) { const r = t.getBoundingClientRect(); if (umFeld(r, x, y, RAND) || umFeld(r, mx, my, RAND) || beruehrt(k, r)) return { art: "tisch" }; }
    return null;
  }
  function alInReihe(e, mx) {
    if (e.classList.contains("kt-neu")) return { art: "neu" };
    let pos = 0;
    e.querySelectorAll(".kt-zeilenkarten > .kt-karte").forEach((c, i) => { const r = c === zug.el ? zug.r0 : c.getBoundingClientRect(); if (mx > (r.left + r.right) / 2) pos = i + 1; });
    const o = ort(zug.i);
    if (o && o.r.name === e.dataset.reihe && (pos === o.i || pos === o.i + 1)) return zug.art === "tisch" ? { art: "zurueck" } : null;
    return { art: "luecke", reihe: e.dataset.reihe, pos };
  }
  function alMarkiere(ziel) {
    flaeche.querySelectorAll(".drueber").forEach(e => e.classList.remove("drueber"));
    if (!ziel) return;
    let e = null;
    if (ziel.art === "tisch") { e = flaeche.querySelector(".kt-tisch"); const frei = e.querySelectorAll(".kt-ablage")[freieAblage()]; if (frei) frei.classList.add("drueber"); }
    else if (ziel.art === "neu") e = flaeche.querySelector(".kt-neu");
    else if (ziel.art === "zurueck") e = flaeche.querySelector('.kt-karte.leerplatz[data-k="' + zug.i + '"]');
    else e = flaeche.querySelector('.kt-luecke[data-reihe="' + ziel.reihe + '"][data-pos="' + ziel.pos + '"]');
    if (e) e.classList.add("drueber");
  }
  function alWirkung(ziel, k) {
    if (ziel.art === "tisch") waehleK(k);
    else if (ziel.art === "neu") lege(k, null);
    else if (ziel.art === "luecke") lege(k, ziel.reihe, ziel.pos);
    else zurueckK(k);
  }
  function zugBeginnt() {
    zug.los = true;
    // eine Karte, die noch gleitet oder pulst, folgt sonst nicht dem Zeiger
    if (zug.el.getAnimations) zug.el.getAnimations().forEach(a => a.cancel());
    zug.el.classList.add("zieht");
    if (z.tisch === "ablegen") {
      // während des Zugs zeigen alle Lücken, dass man dort ablegen kann
      flaeche.classList.add("al-zug");
      if (zug.art === "reihe") { const t = flaeche.querySelector(".kt-tisch"); if (t) t.classList.add("kt-ziel"); zug.geist = h("span", "kt-geist"); zug.el.append(zug.geist); }
      else { const e = flaeche.querySelector('.kt-karte.leerplatz[data-k="' + zug.i + '"]'); if (e) e.classList.add("kt-ziel"); }
      return;
    }
    if (zug.art === "reihe") {
      flaeche.querySelector(".kt-tisch").classList.add("kt-ziel");
      // wo die Karte lag, bleibt ihr leerer Platz stehen: ein Umriss, der gegen den Zug verschoben wird
      zug.geist = h("span", "kt-geist"); zug.el.append(zug.geist);
    }
    else {
      const eigen = leerplatz(zug.i), fremd = leerplatz(andere());
      if (eigen) eigen.classList.add("kt-ziel");
      if (fremd) { fremd.classList.add("kt-ziel"); fremd.append(h("span", "kt-tauschziel", "tauschen")); }
    }
  }
  // einen laufenden Zug ohne Wirkung beenden (vor jedem Zeichnen, bei pointercancel)
  function zugLoesen() {
    if (!zug) return;
    const g = zug; zug = null;
    try { g.el.releasePointerCapture(g.id); } catch (e) {}
    if (!g.los) return;
    g.el.classList.remove("zieht"); g.el.style.transform = ""; if (g.geist) g.geist.remove();
    flaeche.classList.remove("al-zug");
    flaeche.querySelectorAll(".kt-ziel, .drueber").forEach(e => e.classList.remove("kt-ziel", "drueber"));
    flaeche.querySelectorAll(".kt-tauschziel").forEach(e => e.remove());
  }
  function zugEndet(ev, gilt) {
    if (!zug || ev.pointerId !== zug.id) return;
    if (!zug.los) { zugLoesen(); return; }                 // kein Zug, ein Klick
    // ein schneller Zug: Das Loslassen kann weiter sein als die letzte Bewegung -- die Karte erst dorthin setzen
    if (gilt) { const dx = ev.clientX - zug.x0, dy = ev.clientY - zug.y0; zug.el.style.transform = "translate(" + dx + "px, " + dy + "px)"; }
    const g = zug, ziel = gilt ? (z.tisch === "ablegen" ? alZielBei : zielBei)(ev.clientX, ev.clientY) : null;
    geschluckt = Date.now();
    if (!ziel) { const vorher = lagen(); zugLoesen(); gleiten(vorher); return; }
    // die Karte bleibt bis zum Zeichnen, wo sie losgelassen wurde: Von dort gleitet sie an ihren Ort
    zug = null; try { g.el.releasePointerCapture(g.id); } catch (e) {}
    if (z.tisch === "ablegen") { alWirkung(ziel, g.i); if (ziel.art !== "tisch") fokusWunsch = "k" + g.i; }
    else if (ziel === "tisch") waehle(g.i); else if (ziel === "tausch") tausche(); else zurueck(g.i);
    zeichnen();
  }
  function ziehbar(el, art, i) {
    el.classList.add("ziehbar");
    // die Karte kann beim Loslassen schon aus der Seite genommen sein (neu gezeichnet) -- dann erreicht der click nur noch sie
    const klick = el.onclick; el.onclick = ev => { if (!nachZug(ev)) klick.call(el, ev); };
    el.addEventListener("pointerdown", ev => {
      if (ev.button !== 0 || ev.isPrimary === false) return;
      zugLoesen();                                         // ein Zug, dessen Ende nie ankam, sperrt nichts
      zug = { el, art, i, id: ev.pointerId, x0: ev.clientX, y0: ev.clientY, schwelle: ev.pointerType === "touch" ? SCHWELLE_FINGER : SCHWELLE, los: false, r0: el.getBoundingClientRect() };
      try { el.setPointerCapture(ev.pointerId); } catch (e) {}
    });
    el.addEventListener("pointermove", ev => {
      if (!zug || zug.el !== el || ev.pointerId !== zug.id) return;
      const dx = ev.clientX - zug.x0, dy = ev.clientY - zug.y0;
      if (!zug.los) { if (Math.hypot(dx, dy) < zug.schwelle) return; zugBeginnt(); }
      el.style.transform = "translate(" + dx + "px, " + dy + "px)";
      if (zug.geist) zug.geist.style.transform = "translate(" + -dx + "px, " + -dy + "px)";
      if (z.tisch === "ablegen") alMarkiere(alZielBei(ev.clientX, ev.clientY)); else markiere(zielBei(ev.clientX, ev.clientY));
    });
    el.addEventListener("pointerup", ev => { if (zug && zug.el === el) zugEndet(ev, true); });
    el.addEventListener("pointercancel", ev => { if (zug && zug.el === el) zugEndet(ev, false); });
    el.addEventListener("lostpointercapture", ev => { if (zug && zug.el === el) zugEndet(ev, false); });
  }
  // nach einem Zug schickt der Browser noch einen click (Maus: sofort; Finger: bei kleinem Weg) -- der ist kein Klick.
  // Tastatur und click() aus einem Skript (detail 0) gehen durch, ebenso jeder Klick nach einem neuen Druck.
  flaeche.addEventListener("pointerdown", () => { geschluckt = 0; }, true);
  flaeche.addEventListener("click", ev => { if (nachZug(ev)) { ev.stopPropagation(); ev.preventDefault(); } }, true);

  function zeichnen() {
    zugLoesen();
    const vorher = lagen();
    const aktiv = document.activeElement, fokusVorher = aktiv && flaeche.contains(aktiv) ? aktiv.dataset.fokus : null;
    const fokus = fokusWunsch || fokusVorher; fokusWunsch = null;
    reiter.replaceChildren(...tische.map(t => knopf(NAMEN[t], t === tisch ? "aktiv" : "", () => wechsle(t))));
    flaeche.replaceChildren();
    flaeche.className = "kt-flaeche kt-" + z.tisch;
    if (z.tisch === "sortieren" || z.tisch === "nachbarn") zeichneReihe();
    else if (z.tisch === "zaehlen") zeichneZaehlen();
    else if (z.tisch === "ablegen") zeichneAblegen();
    else zeichneHalbieren();
    tischWieReihe();
    // nur wenn der Fokus vorher in der Werkstatt lag (Tastatur oder ein Knopf) -- sonst zöge er die Seite hierher
    if (fokusVorher && fokus) {
      const e = flaeche.querySelector('[data-fokus="' + fokus + '"]') || (/^t\d+$/.test(fokus) ? flaeche.querySelector('[data-fokus="k' + fokus.slice(1) + '"]') : null);
      if (e) e.focus({ preventScroll: true });
    }
    gleiten(vorher);
  }
  // Die Karten auf dem Vergleichstisch sind so groß wie die in der Reihe (Lehrer 17.11.2026: „verwirrend finde ich nur,
  // dass im Browser die Tischkarten viel kleiner sind als die Karten am Platz und in der Vorschau in VS Code ist es
  // andersrum“). Die Reihe teilt sich die Breite (höchstens 5.8em je Karte), die Ablage war fest 3.5em -- breit war die
  // Reihe größer, schmal kleiner. Jetzt misst die Werkstatt eine Karte der Reihe und gibt ihre Breite an den Tisch weiter,
  // nach jedem Zeichnen und wenn sich die Breite der Werkstatt ändert.
  function tischWieReihe() {
    if (z.tisch === "ablegen") { ablegenBreite(); return; }
    const k = flaeche.querySelector(".kt-reihe .kt-karte");
    if (!k) { flaeche.style.removeProperty("--kt-kartenbreite"); return; }
    const b = k.getBoundingClientRect().width;
    if (b > 0) flaeche.style.setProperty("--kt-kartenbreite", b.toFixed(1) + "px");
  }
  // nur auf die BREITE der Werkstatt hören, und erst im nächsten Bild messen: Die neue Ablagenbreite ändert die Höhe der
  // Fläche -- ein Beobachter, der darauf wieder misst, liefe im Kreis („ResizeObserver loop …“, als Skriptfehler gemeldet)
  let breiteZuletzt = -1;
  if (typeof ResizeObserver === "function") new ResizeObserver(eintraege => {
    const b = Math.round(eintraege[eintraege.length - 1].contentRect.width);
    if (b === breiteZuletzt) return;
    breiteZuletzt = b;
    requestAnimationFrame(() => { if (!zug) tischWieReihe(); });
  }).observe(flaeche);
  // Der Vergleichstisch (Durchsicht iq1, 16.11.2026: „Ich hätte gerne einen Tisch, auf den man zwei Karten legen kann
  // und das Programm zeigt an, welche Karte größer ist“): Die zwei gewählten Karten liegen hier, verdeckt; zwischen
  // ihnen steht das Zeichen, über der höheren „höher“. Ein Klick auf eine Karte legt sie zurück (sortieren) -- ebenso,
  // wer sie in die Reihe zieht.
  // Die zwei Ablagen sind feste Plätze (18.11.): Eine Karte, die zurückgeht, lässt ihre Ablage leer, die andere bleibt.
  // Ein leerer Platz neben einer Karte heißt „zweite Karte“, gleich auf welcher Seite.
  const leerText = (seite, andere) => andere != null || seite ? "zweite Karte" : "erste Karte";
  function tischEl(nachbarn) {
    const t = h("div", "kt-tisch"), [a, b] = tischPlaetze();
    const hoeher = z.verglichen && z.wahl.length === 2 ? (wert(a) > wert(b) ? a : b) : null;
    const ablage = (i, text, seite) => {
      const d = h("div", "kt-ablage");
      if (i == null) { d.append(h("span", "kt-ablage-leer", text)); return d; }
      const k = knopf("", "kt-tischkarte" + (i === hoeher ? " hoeher" : ""), () => { if (nachbarn) return; zurueck(i); zeichnen(); });
      k.dataset.karte = String(z.reihe[i]);
      k.append(h("span", "kt-platz", z.python ? "[" + i + "]" : "Platz " + platz(i)));
      if (i === hoeher) k.append(h("span", "kt-hoeher", "höher"));
      if (!nachbarn) { k.title = "zurücklegen – anklicken oder in die Reihe ziehen"; ziehbar(k, "tisch", i); }
      k.setAttribute("aria-label", "verdeckte Karte von Platz " + platz(i) + " auf dem Vergleichstisch, " + seite + (i === hoeher ? ", die höhere" : ""));
      d.append(k); return d;
    };
    t.append(h("span", "kt-tischname", "Vergleichstisch"), ablage(a, nachbarn ? "links" : leerText(0, b), "links"),
      h("span", "kt-zeichen" + (hoeher == null ? " offen" : ""), hoeher == null ? "?" : hoeher === a ? ">" : "<"), ablage(b, nachbarn ? "rechts" : leerText(1, a), "rechts"));
    return t;
  }
  function zeichneReihe() {
    const nachbarn = z.tisch === "nachbarn";
    const links = h("div", "kt-links"), seite = h("div", "kt-seite");
    links.append(h("p", "kt-auftrag", nachbarn ? "Verglichen wird nur das Paar am Zeiger. Nach jedem Durchgang liegt hinten eine Karte mehr fest."
      : "Zwei Karten anklicken oder ziehen: Sie kommen auf den Vergleichstisch, und er zeigt, welche die höhere Wertung hat. Sortiert heißt: die niedrigste Wertung auf Platz 1."));
    // die Wahl 4 · 8 · 16 nur, wo der Schritt keine feste Kartenzahl nennt (karten="4" im Vortrag)
    if (!nachbarn && !opt.karten) links.append(pillen(z.n, n => { z = neu("sortieren", { n }); zeichnen(); }, [4, 8, 16]));
    eng = z.n > 8;
    const reihe = h("div", "kt-reihe" + (eng ? " viele" : ""));
    z.reihe.forEach((k, i) => {
      // eine gewählte Karte liegt auf dem Vergleichstisch -- in der Reihe bleibt ihr leerer Platz (anklicken legt sie zurück)
      const gehoben = !z.offen && z.wahl.includes(i);
      const cls = (gehoben ? "leerplatz" : z.offen ? "auf" : "zu") + (nachbarn && i >= z.n - z.fest ? " fest" : "");
      const el = karte(z.offen ? MITGLIEDER[k] : null, i, cls, () => {
        if (z.offen || nachbarn) return;
        waehle(i);
        zeichnen();
      });
      if (!gehoben) el.dataset.karte = String(k);
      el.dataset.platz = String(i);
      // ziehen darf, wer klicken darf: eine verdeckte Karte am Tisch sortieren (nicht der leere Platz, nicht „nur Nachbarn“)
      if (!gehoben && !z.offen && !nachbarn) ziehbar(el, "reihe", i);
      if (nachbarn && !z.offen && z.fest < z.n - 1 && (i === z.zeiger || i === z.zeiger + 1)) { el.classList.add("zeiger"); el.append(h("span", "kt-zeiger", i === z.zeiger ? "links" : "rechts")); }
      reihe.append(el);
    });
    links.append(reihe);
    if (!z.offen && !(nachbarn && z.fest >= z.n - 1)) links.append(tischEl(nachbarn));
    links.append(h("div", "kt-urteil" + (z.python ? " code" : "") + (z.urteil ? "" : " leer"), z.urteil || (nachbarn ? "Durchgang " + z.durchgang + ": vergleichen, wenn nötig tauschen, weiter." : z.wahl.length ? "Noch eine Karte." : "Wählt zwei Karten.")));
    const kn = h("div", "kt-knoepfe");
    const fertig = z.offen || (nachbarn && z.fest >= z.n);
    if (nachbarn) {
      const b1 = knopf("vergleichen", "", () => { paar(); zeichnen(); }), b2 = knopf("tauschen", "primaer", () => { tausche(); zeichnen(); }), b3 = knopf("weiter", "", () => { weiter(); zeichnen(); }), b4 = knopf("ganzer Durchgang", "", () => { durchgang(); zeichnen(); });
      b1.disabled = z.offen || z.fest >= z.n - 1 || z.verglichen; b2.disabled = z.offen || !z.verglichen || z.wahl.length !== 2; b3.disabled = b4.disabled = z.offen || z.fest >= z.n - 1;
      kn.append(b1, b2, b3, b4);
    } else {
      const b = knopf("tauschen", "primaer", () => { tausche(); zeichnen(); }); b.disabled = z.offen || z.wahl.length !== 2;
      // zurücklegen (Durchsicht 16.11.: „Man muss Karten, die man ausgewählt hat, mühsam wieder abwählen“)
      const zl = knopf("zurücklegen", "", () => { z.wahl = []; z.urteil = ""; z.verglichen = false; zeichnen(); }); zl.disabled = z.offen || !z.wahl.length;
      kn.append(b, zl);
    }
    const auf = knopf("aufdecken – sortiert?", "", () => { aufdecken(); zeichnen(); }); auf.disabled = z.offen;
    // „von vorn“ und „neu mischen“ ohne die ruhige Farbe (Durchsicht 16.11.: „sehen ausgegraut aus, als könne man es nicht anwählen“)
    kn.append(auf, knopf("von vorn", "", () => { z = neu(z.tisch, { n: z.n, start: z.start }); zeichnen(); }));
    if (!nachbarn) kn.append(knopf("neu mischen", "", () => { const s = z.start.slice(); for (let i = s.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [s[i], s[j]] = [s[j], s[i]]; } z = neu("sortieren", { n: z.n, start: s }); zeichnen(); }));
    if (mitPython) kn.append(knopf(z.python ? "in Worten zeigen" : "als Python zeigen", "", () => { z.python = !z.python; z.urteil = ""; zeichnen(); }));
    links.append(kn);
    if (fertig && z.offen && !sortiert()) links.append(h("p", "kt-hinweis", "„von vorn“ legt dieselben Karten wieder verdeckt hin."));
    seite.append(nachbarn ? zaehler(["Vergleiche", z.vergleiche], ["Täusche", z.tausche], ["Durchgang", Math.min(z.durchgang, z.n - 1)]) : zaehler(["Vergleiche", z.vergleiche], ["Täusche", z.tausche]), h("h3", "", "Protokoll"), protokollEl());
    flaeche.append(links, seite);
  }
  function zeichneZaehlen() {
    const links = h("div", "kt-links"), rechts = h("div", "kt-kurve");
    links.append(h("p", "kt-auftrag", "Dasselbe Verfahren mit mehr Karten: Was kostet es? Erst schätzen, dann zählt der Tisch den Bubblesort."), pillen(z.n, n => { z.n = n; z.meldung = ""; zeichnen(); }));
    const t = h("table", "kt-tabelle"), kopf = h("tr"); ["Karten", "geschätzt", "euer Verfahren", "Bubblesort"].forEach(x => kopf.append(h("th", "", x))); t.append(kopf);
    STUFEN.forEach(n => {
      const tr = h("tr", n === z.n ? "an" : ""); tr.append(h("td", "", String(n)));
      for (const feld of ["geschaetzt", "eigen"]) {
        const td = h("td"), ein = h("input"); ein.type = "text"; ein.inputMode = "numeric"; ein.value = z[feld][n] == null ? "" : z[feld][n];
        ein.setAttribute("aria-label", (feld === "eigen" ? "euer Verfahren" : "geschätzt") + " bei " + n + " Karten");
        ein.onchange = () => { const v = ein.value.trim(); z[feld][n] = /^\d+$/.test(v) ? parseInt(v, 10) : ""; if (feld === "eigen") eigen[n] = z.eigen[n]; zeichnen(); };
        td.append(ein); tr.append(td);
      }
      tr.append(h("td", "kt-bubble", z.bubble[n] == null ? "" : String(z.bubble[n]))); t.append(tr);
    });
    const kn = h("div", "kt-knoepfe"); kn.append(knopf("Bubblesort bei " + z.n + " Karten zählen", "primaer", () => { lauf(); zeichnen(); }), knopf("von vorn", "ruhig", () => { z = neu("zaehlen"); zeichnen(); }));
    links.append(t, kn, h("p", "kt-urteil" + (z.meldung ? "" : " leer"), z.meldung || "Doppelt so viele Karten – wie viel mehr Vergleiche?"));
    rechts.innerHTML = kurve();
    flaeche.append(links, rechts);
  }
  function kurve() {
    const B = 420, H = 280, L = 50, U = 232, R = 404, O = 20;
    const zahlen = k => Object.keys(z[k]).filter(n => z[k][n] !== "" && z[k][n] != null).map(n => [parseInt(n, 10), z[k][n]]);
    const pb = zahlen("bubble"), pe = zahlen("eigen"), alle = pb.concat(pe);
    const nMax = Math.max(16, ...alle.map(p => p[0])), vMax = Math.max(40, ...alle.map(p => p[1]), nMax);
    const x = n => L + (R - L) * n / nMax, y = v => U - (U - O) * v / vMax;
    let s = '<svg viewBox="0 0 ' + B + ' ' + H + '" role="img" aria-label="Vergleiche über der Zahl der Karten"><line class="achse" x1="' + L + '" y1="' + U + '" x2="' + R + '" y2="' + U + '"/><line class="achse" x1="' + L + '" y1="' + U + '" x2="' + L + '" y2="' + O + '"/>';
    STUFEN.filter(n => n <= nMax).forEach(n => { s += '<text class="zahl" x="' + x(n) + '" y="' + (U + 20) + '" text-anchor="middle">' + n + '</text>'; });
    s += '<text class="zahl" x="' + (L - 6) + '" y="' + (U + 4) + '" text-anchor="end">0</text><text class="zahl" x="' + (L - 6) + '" y="' + (O + 4) + '" text-anchor="end">' + vMax + '</text><text class="zahl" x="' + ((L + R) / 2) + '" y="' + (H - 6) + '" text-anchor="middle">Karten</text>';
    s += '<line class="gerade" x1="' + x(0) + '" y1="' + y(0) + '" x2="' + x(nMax) + '" y2="' + y(nMax) + '"/><text class="leg grau" x="' + (R - 4) + '" y="' + (y(nMax) - 8) + '" text-anchor="end">ein Vergleich je Karte</text>';
    if (pb.length >= 2) { pb.sort((a, b) => a[0] - b[0]); s += '<polyline class="linie" points="' + pb.map(p => x(p[0]) + "," + y(p[1])).join(" ") + '"/>'; }
    pb.forEach(p => { s += '<circle class="punkt" cx="' + x(p[0]) + '" cy="' + y(p[1]) + '" r="5.5"/>'; });
    pe.forEach(p => { s += '<rect class="eigen" x="' + (x(p[0]) - 5) + '" y="' + (y(p[1]) - 5) + '" width="10" height="10"/>'; });
    if (pb.length) s += '<text class="leg blau" x="' + (L + 14) + '" y="' + (O + 14) + '">● Bubblesort</text>';
    if (pe.length) s += '<text class="leg amber" x="' + (L + 14) + '" y="' + (O + 32) + '">■ euer Verfahren</text>';
    return s + "</svg>";
  }
  function zeichneHalbieren() {
    const links = h("div", "kt-links"), seite = h("div", "kt-seite");
    links.append(h("p", "kt-auftrag", "Sortiert und verdeckt. Jede aufgedeckte Karte ist eine Frage."), h("p", "kt-gesucht", "Gesucht: die Wertung " + z.ziel));
    eng = true;
    const reihe = h("div", "kt-reihe viele");
    SORTIERT.forEach((w, i) => {
      const auf = z.offen.includes(i), weg = !auf && (i < z.links || i > z.rechts || z.gefunden >= 0);
      reihe.append(karte(auf ? ["", w] : null, i, (auf ? "auf" : "zu") + (weg ? " weg" : "") + (i === z.gefunden ? " treffer" : auf ? " wahl" : ""), () => { decke(i); zeichnen(); }));
    });
    links.append(reihe, h("div", "kt-urteil" + (z.python ? " code" : "") + (z.urteil ? "" : " leer"), z.urteil || "Welche Karte deckt ihr zuerst auf?"));
    const kn = h("div", "kt-knoepfe");
    kn.append(knopf("neue Suche", "", () => { z = neu("halbieren", { ziel: SUCHEN[(SUCHEN.indexOf(z.ziel) + 1) % SUCHEN.length] }); zeichnen(); }),
      knopf("eine Wertung, die es nicht gibt", "", () => { z = neu("halbieren", { ziel: 1400 }); zeichnen(); }), knopf("von vorn", "ruhig", () => { z = neu("halbieren", { ziel: z.ziel }); zeichnen(); }));
    if (mitPython) kn.append(knopf(z.python ? "in Worten zeigen" : "als Python zeigen", "ruhig", () => { z.python = !z.python; zeichnen(); }));
    links.append(kn);
    seite.append(zaehler(["Fragen", z.fragen], ["noch möglich", z.gefunden >= 0 ? 1 : Math.max(0, z.rechts - z.links + 1)]), h("h3", "", "Protokoll"), protokollEl());
    flaeche.append(links, seite);
  }

  // ─── Tisch ablegen (17.11.2026) ────────────────────────────────────────────────────
  // Oben der Vergleichstisch (er bleibt stehen, wenn Reihen kommen und gehen), darunter Urteil und Knöpfe, unten die
  // Reihen nebeneinander, solange Platz ist, und immer eine leere „neue Reihe“. Liegt eine Karte ALLEIN auf dem Tisch,
  // werden die Lücken zwischen den Karten zu Knöpfen „hierhin legen“ -- so geht alles auch mit Klick und Tastatur.
  // Ziehen: aus einer Reihe auf den Tisch, in eine Lücke oder die neue Reihe; vom Tisch in eine Lücke, die neue Reihe
  // oder zurück auf den eigenen Platz.
  function alTisch() {
    const t = h("div", "kt-tisch"), [a, b] = tischPlaetze();
    const hoeher = z.verglichen && z.wahl.length === 2 ? (wertK(a) > wertK(b) ? a : b) : null;
    const ablage = (k, text, seite) => {
      const d = h("div", "kt-ablage");
      if (k == null) { d.append(h("span", "kt-ablage-leer", text)); return d; }
      const c = knopf("", "kt-tischkarte" + (k === hoeher ? " hoeher" : ""), () => { zurueckK(k); zeichnen(); });
      c.dataset.karte = String(k); c.dataset.fokus = "t" + k;
      c.append(h("span", "kt-platz", ortName(k)));
      if (k === hoeher) c.append(h("span", "kt-hoeher", "höher"));
      c.title = "anklicken: zurücklegen · in eine Reihe ziehen: dort hinlegen";
      c.setAttribute("aria-label", "verdeckte Karte von " + ortName(k) + " auf dem Vergleichstisch, " + seite + (k === hoeher ? ", die höhere" : "") + " – anklicken legt sie zurück");
      ziehbar(c, "tisch", k);
      d.append(c); return d;
    };
    t.append(h("span", "kt-tischname", "Vergleichstisch"), ablage(a, leerText(0, b), "links"),
      h("span", "kt-zeichen" + (hoeher == null ? " offen" : ""), hoeher == null ? "?" : hoeher === a ? ">" : "<"), ablage(b, leerText(1, a), "rechts"));
    return t;
  }
  function alReihen() {
    const hand = !z.offen && z.wahl.length === 1 ? z.wahl[0] : null;
    const box = h("div", "kt-reihen");
    z.reihen.forEach(r => {
      const zeile = h("div", "kt-zeile"), karten = h("div", "kt-zeilenkarten");
      zeile.dataset.reihe = r.name;
      zeile.append(h("span", "kt-zeilenname", "Reihe " + r.name));
      const eigenPos = hand == null ? -1 : r.karten.indexOf(hand);
      const luecke = pos => {
        const l = h("span", "kt-luecke"); l.dataset.reihe = r.name; l.dataset.pos = String(pos);
        if (hand != null && !(eigenPos >= 0 && (pos === eigenPos || pos === eigenPos + 1))) {
          const wo = "Reihe " + r.name + (pos < r.karten.length ? ", vor Platz " + (pos + 1) : r.karten.length ? ", ans Ende" : "");
          const b = knopf("", "kt-legen", () => { lege(hand, r.name, pos); fokusWunsch = "k" + hand; zeichnen(); });
          b.title = "hierhin legen: " + wo; b.setAttribute("aria-label", "Karte vom Tisch hierhin legen: " + wo); b.dataset.fokus = "l" + r.name + pos;
          l.append(b);
        }
        return l;
      };
      r.karten.forEach((k, i) => {
        karten.append(luecke(i));
        const gehoben = !z.offen && z.wahl.includes(k);
        const el = knopf("", "kt-karte " + (gehoben ? "leerplatz" : z.offen ? "auf" : "zu"), () => { if (z.offen) return; waehleK(k); zeichnen(); });
        if (z.offen) el.append(h("span", "kt-name", MITGLIEDER[k][0]), h("span", "kt-wert", String(MITGLIEDER[k][1])));
        el.append(h("span", "kt-platz", r.name + (i + 1)));
        el.setAttribute("aria-label", gehoben ? "leerer Platz " + r.name + (i + 1) + ", die Karte liegt auf dem Vergleichstisch – anklicken legt sie zurück"
          : (z.offen ? MITGLIEDER[k][0] + " " + MITGLIEDER[k][1] : "verdeckte Karte") + ", Reihe " + r.name + ", Platz " + (i + 1));
        if (!gehoben) el.dataset.karte = String(k);
        el.dataset.k = String(k); el.dataset.fokus = "k" + k;
        if (!gehoben && !z.offen) ziehbar(el, "reihe", k);
        karten.append(el);
      });
      karten.append(luecke(r.karten.length));
      zeile.append(karten); box.append(zeile);
    });
    if (!z.offen) {
      const name = BUCHSTABEN[naechsteReihe()], neu_ = h("div", "kt-zeile kt-neu");
      neu_.append(h("span", "kt-zeilenname", "neue Reihe"));
      const feld = hand != null ? knopf("", "kt-neufeld", () => { lege(hand, null); fokusWunsch = "k" + hand; zeichnen(); }) : h("span", "kt-neufeld");
      feld.append(h("span", "", hand != null ? "hierhin legen" : "leer"));
      if (hand != null) { feld.dataset.fokus = "neu"; feld.title = "in eine neue Reihe legen (Reihe " + name + ")"; feld.setAttribute("aria-label", "Karte vom Tisch in eine neue Reihe legen, Reihe " + name); }
      neu_.append(feld); box.append(neu_);
    }
    return box;
  }
  function zeichneAblegen() {
    stilAblegen();
    const links = h("div", "kt-links"), seite = h("div", "kt-seite");
    links.append(h("p", "kt-auftrag", "Zwei Karten auf den Vergleichstisch: Er zeigt, welche die höhere Wertung hat. Liegt eine Karte allein dort, legt ihr sie in eine Lücke einer Reihe oder in eine neue Reihe – anklicken oder ziehen. Gezählt wird nur der Vergleich: Legen kostet nichts."));
    if (!opt.karten) links.append(pillen(z.n, n => { z = neu("ablegen", { n }); zeichnen(); }, [4, 8, 16]));
    eng = z.n > 8;
    if (!z.offen) links.append(alTisch());
    links.append(h("div", "kt-urteil" + (z.urteil ? "" : " leer"), z.urteil || (z.wahl.length === 1 ? "Noch eine Karte zum Vergleichen – oder diese hinlegen." : z.wahl.length === 2 ? "Eine der zwei hinlegen: in eine Reihe ziehen. Oder eine zurücklegen." : "Wählt zwei Karten.")));
    const kn = h("div", "kt-knoepfe");
    const zl = knopf("zurücklegen", "", () => { z.wahl = []; z.urteil = ""; z.verglichen = false; zeichnen(); }); zl.disabled = z.offen || !z.wahl.length;
    const auf = knopf("aufdecken – sortiert?", "", () => { aufdecken(); zeichnen(); }); auf.disabled = z.offen;
    kn.append(zl, auf, knopf("von vorn", "", () => { z = neu("ablegen", { n: z.n, start: z.start }); zeichnen(); }),
      knopf("neu mischen", "", () => { const s = z.start.slice(); for (let i = s.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [s[i], s[j]] = [s[j], s[i]]; } z = neu("ablegen", { n: z.n, start: s }); zeichnen(); }));
    links.append(kn, alReihen());
    if (z.offen && !(z.reihen.length === 1 && reiheSortiert(z.reihen[0]))) links.append(h("p", "kt-hinweis", "„von vorn“ legt dieselben Karten wieder verdeckt in Reihe A."));
    seite.append(zaehler(["Vergleiche", z.vergleiche], ["gelegt", z.gelegt]), h("h3", "", "Protokoll"), protokollEl());
    flaeche.append(links, seite);
  }
  // Kartenbreite: alle Reihen gleich, so dass Reihe A mit allen Karten in die Spalte passt (höchstens 5em); der
  // Vergleichstisch übernimmt sie (--kt-kartenbreite wie an den anderen Tischen)
  function ablegenBreite() {
    const l = flaeche.querySelector(".kt-links"); if (!l) return;
    const B = l.getBoundingClientRect().width; if (!B) return;
    const fs = parseFloat(getComputedStyle(flaeche).fontSize) || 16, lu = z.n > 8 ? 6 : 10;
    const w = Math.max(16, Math.min(5 * fs, (B - (z.n + 1) * lu - 0.8 * fs - 4) / z.n));
    flaeche.style.setProperty("--kt-al-breite", w.toFixed(1) + "px");
    flaeche.style.setProperty("--kt-al-luecke", lu + "px");
    flaeche.style.setProperty("--kt-kartenbreite", w.toFixed(1) + "px");
  }
  // Die Stile des Tischs ablegen stehen hier (wie die übrigen Kartenstile in seite.css zu ergänzen, wenn der Tisch bleibt)
  function stilAblegen() {
    if (document.getElementById("kt-ablegen-stil")) return;
    const s = document.createElement("style"); s.id = "kt-ablegen-stil";
    s.textContent = [
      ".kartentisch .kt-ablegen .kt-tisch { margin: .2em 0 .3em; }",
      ".kartentisch .kt-reihen { display: flex; flex-wrap: wrap; gap: .7em .9em; align-items: flex-start; margin: .9em 0 0; }",
      ".kartentisch .kt-zeile { border: 1px solid var(--linie); border-radius: 12px; background: var(--blau-zart); padding: .25em .4em 1.55em; position: relative; min-width: 0; }",
      ".kartentisch .kt-zeilenname { display: block; font-size: .68em; letter-spacing: .08em; text-transform: uppercase; color: var(--grau); margin: 0 0 .3em .15em; white-space: nowrap; }",
      ".kartentisch .kt-zeilenkarten { display: flex; align-items: stretch; }",
      ".kartentisch .kt-ablegen .kt-karte { flex: 0 0 var(--kt-al-breite, 4em); width: var(--kt-al-breite, 4em); max-width: none; }",
      ".kartentisch .kt-ablegen .kt-karte .kt-wert { font-size: 1.05em; }",
      ".kartentisch .kt-ablegen .kt-karte .kt-name { font-size: .64em; }",
      ".kartentisch .kt-luecke { flex: 0 0 var(--kt-al-luecke, 10px); position: relative; }",
      ".kartentisch .kt-luecke::after { content: ''; position: absolute; top: 8%; bottom: 8%; left: 50%; width: 0; border-left: 2px dashed transparent; transform: translateX(-1px); pointer-events: none; }",
      ".kartentisch .kt-flaeche.al-zug .kt-luecke::after { border-left-color: var(--blau-mittel); opacity: .5; }",
      ".kartentisch .kt-flaeche.al-zug .kt-luecke.drueber::after { border-left: 6px solid var(--blau); opacity: 1; transform: translateX(-3px); }",
      ".kartentisch button.kt-legen { position: absolute; top: 0; bottom: 0; left: -7px; right: -7px; z-index: 2; padding: 0; border: 0; border-radius: 6px; background: none; box-shadow: none; min-width: 0; }",
      ".kartentisch button.kt-legen::before { content: ''; position: absolute; top: 6%; bottom: 6%; left: 50%; width: 0; margin-left: -1.5px; border-left: 3px dashed var(--blau-mittel); }",
      ".kartentisch button.kt-legen:hover, .kartentisch button.kt-legen:active { background: none; transform: none; }",
      ".kartentisch button.kt-legen:hover::before, .kartentisch button.kt-legen:focus-visible::before { border-left: 7px solid var(--blau); margin-left: -3.5px; border-radius: 3px; }",
      ".kartentisch .kt-flaeche.al-zug button.kt-legen::before { opacity: 0; }",
      ".kartentisch .kt-neu { background: none; border: 1.5px dashed #cfc9bb; }",
      ".kartentisch .kt-neu.drueber { border-style: solid; border-color: var(--blau); background: var(--blau-hell); box-shadow: 0 0 0 3px var(--blau-hell); }",
      ".kartentisch .kt-neufeld { display: flex; align-items: center; justify-content: center; text-align: center; width: calc(var(--kt-al-breite, 4em) + 2 * var(--kt-al-luecke, 10px)); min-width: 5.6em; height: calc(var(--kt-al-breite, 4em) * 4 / 3); min-height: 3.6em; font-size: .78em; color: var(--grau); padding: 0 .2em; box-sizing: border-box; }",
      ".kartentisch button.kt-neufeld { border: 2px solid var(--blau-mittel); border-radius: 10px; background: var(--karte); color: var(--blau); font-size: .78em; }",
      ".kartentisch .kt-flaeche.al-zug button.kt-neufeld { border-style: dashed; }",
      ".kartentisch .kt-ablegen .kt-karte.leerplatz.kt-ziel { border-color: var(--blau-mittel); }",
      ".kartentisch .kt-ablegen .kt-karte.leerplatz.drueber { border-style: solid; border-color: var(--blau); background: var(--blau-hell); }"
    ].join("\n");
    document.head.append(s);
  }

  try { Object.assign(eigen, JSON.parse(sessionStorage.getItem("lernraum.karten.eigen") || "{}")); } catch (e) {}
  if (z.tisch === "zaehlen") z.eigen = Object.assign({}, eigen);
  zeichnen();

  // ─── Film (Vortrag, wie der Code-Film) ─────────────────────────────────────────────
  function filmSchritt(x) {
    const a = x.aktion, zahl = v => parseInt(v, 10);
    // der Tisch ablegen hat (noch) keine eigenen Filmschritte -- er steht in keinem Vortrag; von vorn, Kartenzahl und
    // aufdecken gehen, alles andere gehört zu den anderen Tischen
    if (z.tisch === "ablegen" && !["neu", "karten", "aufdecken"].includes(a)) return;
    if (a === "neu") z = neu(z.tisch, z.tisch === "halbieren" ? { ziel: z.ziel } : { n: z.n, start: z.start });
    else if (a === "karten") { if (z.tisch === "zaehlen") { z.n = zahl(x.wert); z.meldung = ""; } else z = neu(z.tisch, { n: zahl(x.wert) }); }
    else if (a === "vergleiche") vergleiche(zahl(x.von) - 1, zahl(x.nach) - 1);
    else if (a === "tausche") tausche();
    else if (a === "aufdecken") aufdecken();
    else if (a === "paar") paar();
    else if (a === "weiter") weiter();
    else if (a === "durchgang") durchgang();
    else if (a === "schaetze") z.geschaetzt[z.n] = zahl(x.wert);
    else if (a === "lauf") lauf();
    else if (a === "suche") z = neu("halbieren", { ziel: zahl(x.wert) });
    else if (a === "decke") decke(zahl(x.wert) - 1);
    else if (a === "python") z.python = true;
  }
  function filmHerstellen(liste) { z = neu(tisch); if (z.tisch === "zaehlen") z.eigen = {}; liste.forEach(filmSchritt); zeichnen(); }
  return { zustand: () => kopie(z), film: { spielen: x => { filmSchritt(x); zeichnen(); }, herstellen: filmHerstellen, laeuft: () => false } };
};
window.Werkstaetten.karten.einleitung = "Mitgliedskarten des Schachportals, verdeckt: Der Tisch sagt nur, welche von zwei Karten die höhere Wertung hat – und zählt jeden Vergleich.";
