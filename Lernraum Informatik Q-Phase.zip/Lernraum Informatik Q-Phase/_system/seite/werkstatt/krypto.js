// Werkstatt "Krypto" -- Verfahren der Kryptologie zum Anfassen (i11 `geheim`, 18.11.2026). Lehrer 18.11.: „für i11
// Kapitel 4 und 5 wünsche ich mir etwas mehr ‚Enaktivität‘ am Rechner … verschiedene Krypto-Verfahren ähnlich
// CrypTool (nur schöner, aber dafür nur für ein paar Verfahren) ausprobieren … und auch damit Übungen und
// Arbeitsphasen bearbeiten“. Drei Attrappen (geheim/planung/werkstatt_attrappen/krypto_attrappen.html), Lehrer: „Sieht
// alles sehr gut aus“, dann „Entscheide du alles“ -- gebaut ist Fassung B (die Leitung) als Rahmen, mit den Tischen
// von A und der Kette von C als Labor (ENTSCHEIDUNGEN.md daneben).
// Tische (LT9: ein Tisch erscheint erst mit seinem Thema):
//   scheibe        -- caesar: die Caesar-Scheibe, ziehen oder − +; außen der eingetippte Text, innen, was daraus wird
//   leitung        -- ab caesar: Amara schickt, Eva am Router sieht nur die Leitung, Bao liest mit seinem Schlüssel;
//                     „verdecken“ für zwei Paare an einem Rechner. Ab knacken trägt Evas Spalte das Durchprobieren
//                     (Option eva="durchprobieren" oder der Tisch durchprobieren unter den Tischen) und Amara den
//                     Gartenzaun (der Tisch zaun unter den Tischen oder verfahren="caesar|zaun")
//   durchprobieren -- knacken: Evas Spalte allein, mit festen Zetteln; jede aufgedeckte Zeile ist ein Versuch
//   haeufigkeit    -- knacken: die Balken eines Zettels gegen Deutsch, Deutsch verschiebbar
//   zaun           -- knacken: der Gartenzaun (Transposition), Latten 2 bis 5
//   farben         -- tauschen: Diffie-Hellman mit Farben, Schritt für Schritt; dieselbe Farbe auf beiden Seiten
//   zahlen         -- tauschen: dasselbe mit Basis hoch Geheimzahl, Rest beim Teiler (23 · 101 · 1009); Eva probiert
//   labor          -- die Kette aus Bausteinen (Caesar, Geheimalphabet, Gartenzaun, Rückwärts) mit Schlüsselraum;
//                     welche Bausteine es gibt, sagt bausteine="caesar|wort|zaun|rueck" (ohne: alle)
// Gemessen und geprüft wird auf der Seite der Übung: Die Aufgaben fragen ab, was die Klasse am Tisch gefunden hat
// (wie in der Werkstatt Netz). Die Werkstatt selbst bewertet nichts.
// Ziehen (nur die Scheibe) markiert keinen Text: user-select: none und preventDefault beim Druck.
// Einbinden: Werkstaetten.krypto(element, {tisch: "scheibe"} | {tische: "scheibe|leitung|labor", bausteine: …})
//   -> { zustand, film: {spielen, herstellen, laeuft} }
// Film (bauen.py, WERKSTATT_FILM["krypto"]): + tippe: … · + drehe: 3 · + einsetzen · + verfahren: caesar ·
//   + schluessel: 7 · + bao: 7 · + verdecken · + aufdecken · + zettel: router · + probiere: 3 · + alle · + das: 10 ·
//   + verschiebe: 7 · + latten: 3 · + amara: rot · + weiter · + teiler: 23 · + dazu: zaun · + stelle: 2 5 ·
//   + weg: 2 · + neu · + halt
window.Werkstaetten = window.Werkstaetten || {};
window.Werkstaetten.krypto = function (wurzel, opt) {
  opt = opt || {};
  const ABC = "abcdefghijklmnopqrstuvwxyz";
  const NAMEN = { scheibe: "Scheibe", leitung: "Leitung", durchprobieren: "Durchprobieren", haeufigkeit: "Häufigkeit",
    zaun: "Gartenzaun", farben: "Farben", zahlen: "Zahlen", labor: "Labor" };
  const tische = String(opt.tische || opt.tisch || "scheibe").split("|").map(t => t.trim()).filter(t => NAMEN[t]);
  if (!tische.length) tische.push("scheibe");
  const evaProbiert = opt.eva === "durchprobieren" || tische.includes("durchprobieren");
  const mitZaun = tische.includes("zaun") || String(opt.verfahren || "").split("|").includes("zaun");
  const SVGNS = (() => { const d = document.createElement("div"); d.innerHTML = "<svg></svg>"; return d.firstChild.namespaceURI; })();

  // ─── rechnen ───────────────────────────────────────────────────────────────────────
  const mod = (a, n) => ((a % n) + n) % n;
  const schiebe = (t, k) => [...String(t).toLowerCase()].map(c => { const i = ABC.indexOf(c); return i < 0 ? c : ABC[mod(i + k, 26)]; }).join("");
  const nurBuchstaben = t => [...String(t).toLowerCase()].filter(c => ABC.includes(c)).join("");
  // Gartenzaun: die Buchstaben im Zickzack auf n Latten, dann Latte für Latte gelesen (Leerzeichen und Zeichen fallen
  // weg -- wie in der Erklärung: „aula um acht“ wird mit zwei Latten zu „aluahuamct“)
  function latteVon(laenge, n) { const r = []; let z = 0, d = 1; for (let i = 0; i < laenge; i++) { r.push(z); if (n > 1) { if (z === 0) d = 1; else if (z === n - 1) d = -1; z += d; } } return r; }
  function zaunVer(t, n) { const b = nurBuchstaben(t), l = latteVon(b.length, n); let aus = ""; for (let j = 0; j < n; j++) for (let i = 0; i < b.length; i++) if (l[i] === j) aus += b[i]; return aus; }
  function zaunEnt(g, n) {
    const b = nurBuchstaben(g), l = latteVon(b.length, n), stuecke = []; let p = 0;
    for (let j = 0; j < n; j++) { const anz = l.filter(x => x === j).length; stuecke.push([...b.slice(p, p + anz)]); p += anz; }
    return l.map(j => stuecke[j].shift()).join("");
  }
  const rueckwaerts = t => [...String(t)].reverse().join("");
  function alphabetAusWort(wort) { let a = ""; for (const c of String(wort).toLowerCase() + ABC) if (ABC.includes(c) && !a.includes(c)) a += c; return a; }
  const ersetze = (t, g) => [...String(t).toLowerCase()].map(c => { const i = ABC.indexOf(c); return i < 0 ? c : g[i]; }).join("");
  function potenzRest(b, e, t) { let r = 1; for (let i = 0; i < e; i++) r = r * b % t; return r; }
  const DEUTSCH = { e: 17.4, n: 9.78, i: 7.55, s: 7.27, r: 7.0, a: 6.51, t: 6.15, d: 5.08, h: 4.76, u: 4.35, l: 3.44, c: 3.06, g: 3.01,
    m: 2.53, o: 2.51, b: 1.89, w: 1.89, f: 1.66, k: 1.21, z: 1.13, p: .79, v: .67, j: .27, y: .04, x: .03, q: .02 };

  // feste Zettel (Vortrag und Übung von knacken) -- dieselben Texte rechnen pruefung.py und die Aufgaben nach
  const LANG = "die loetkolben spielen am freitag um acht in der aula bringt eure freunde mit der eintritt ist frei wer selbst mitspielen will meldet sich bei amara oder bao im musikraum die proben sind dienstags nach der sechsten stunde wir suchen noch eine stimme fuer den refrain und jemanden der das licht steuert";
  const ZETTEL = [
    { id: "router", name: "Vortrag: vom Router", verfahren: "caesar", k: 10, text: schiebe("treffen nach der probe hinter der buehne, bringt die neuen saiten mit", 10) },
    { id: "kontrabass", name: "Aufgabe 1", verfahren: "caesar", k: 17, text: schiebe("bringt den kontrabass mit, der hausmeister hat ihn im heizungskeller versteckt", 17) },
    { id: "lang", name: "Vortrag: ein langer Zettel", verfahren: "caesar", k: 7, text: schiebe(LANG, 7) },
    { id: "alphabet", name: "Vortrag: Amaras Geheimalphabet", verfahren: "wort", k: null, text: ersetze(LANG, "qwertzuiopasdfghjklyxcvbnm") },
    { id: "satz1", name: "Aufgabe 3: Zettel 1", verfahren: "zaun", k: 2, text: zaunVer("die zugabe kommt nach dem letzten lied", 2) },
    { id: "satz2", name: "Aufgabe 3: Zettel 2", verfahren: "caesar", k: 7, text: schiebe("die zugabe kommt nach dem letzten lied", 7) },
    { id: "stapel1", name: "Aufgabe 5: Zettel 1", verfahren: "caesar", k: 19, text: schiebe("wir treffen uns am freitag nach der sechsten stunde vor dem musikraum, die anderen bringen die kabel und die verstaerker mit", 19) },
    { id: "stapel2", name: "Aufgabe 5: Zettel 2", verfahren: "zaun", k: 3, text: zaunVer("der hausmeister darf nichts erfahren", 3) },
    { id: "stapel3", name: "Aufgabe 5: Zettel 3", verfahren: "caesar", k: 3, text: schiebe("ruf an", 3) },
  ];
  const zettelVon = id => ZETTEL.find(z => z.id === id) || ZETTEL[0];

  // Farben mischen: gleiche Teile Farbe -- das geometrische Mittel der Anteile je Kanal. Gemischt wird eine LISTE von
  // Zutaten, sortiert: Wer dieselben Zutaten in anderer Reihenfolge mischt, bekommt genau dieselbe Farbe.
  const FARBE = { gelb: [250, 214, 60], rot: [214, 64, 52], blau: [52, 110, 200], gruen: [70, 160, 90], lila: [130, 80, 190] };
  const FARBNAME = { gelb: "Gelb", rot: "Rot", blau: "Blau", gruen: "Grün", lila: "Lila" };
  const GEHEIMFARBEN = ["rot", "blau", "gruen", "lila"];
  function mische(zutaten) {
    const z = zutaten.slice().sort();
    return [0, 1, 2].map(i => Math.round(255 * Math.pow(z.reduce((p, n) => p * FARBE[n][i] / 255, 1), 1 / z.length)));
  }
  const rgb = f => "rgb(" + f.join(", ") + ")";
  const TEILER = { 23: 5, 101: 2, 1009: 11 };   // je Teiler eine Basis, die jede Zahl von 1 bis Teiler − 1 trifft

  // ─── Zustand je Tisch (bleibt beim Wechsel des Reiters stehen) ─────────────────────
  const zahlOpt = (n, d) => { const v = parseInt(opt[n], 10); return isNaN(v) ? d : v; };
  function neu(t) {
    if (t === "scheibe") return { k: mod(zahlOpt("schluessel", 3), 26), text: opt.text != null ? String(opt.text) : "aula um acht" };
    if (t === "leitung") return { text: opt.text != null ? String(opt.text) : "probe heute in der aula", verfahren: "caesar", k: 7, bk: 7, verdeckt: false, eva: evaNeu() };
    if (t === "durchprobieren") return { zettel: zettelVon(opt.zettel || "router").id, eva: evaNeu() };
    if (t === "haeufigkeit") return { zettel: opt.zettel && zettelVon(opt.zettel) ? zettelVon(opt.zettel).id : "lang", eigen: "", v: 0 };
    if (t === "zaun") return { text: opt.text != null ? String(opt.text) : "auftritt freitag", n: 2 };
    if (t === "farben") return { a: "rot", b: "blau", stufe: 0 };
    if (t === "zahlen") return { p: 23, a: 6, b: 9, stufe: 0, versucht: [], gefunden: null };
    return { text: opt.text != null ? String(opt.text) : "treffen nach der probe", kette: anfangsKette() };
  }
  const evaNeu = () => ({ offen: [], versuche: 0, gefunden: null, falsch: null });
  const kopie = o => JSON.parse(JSON.stringify(o));
  const Z = {};
  let tisch = tische[0];
  const z = () => (Z[tisch] = Z[tisch] || neu(tisch));

  // ─── Bausteine ─────────────────────────────────────────────────────────────────────
  const h = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
  const knopf = (text, cls, fn, fokus, aria) => { const b = h("button", cls || "", text); b.type = "button"; b.onclick = fn; if (fokus) b.dataset.fokus = fokus; if (aria) b.setAttribute("aria-label", aria); return b; };
  const s = (tag, at, text) => { const e = document.createElementNS(SVGNS, tag); for (const k in at || {}) e.setAttribute(k, at[k]); if (text != null) e.textContent = text; return e; };
  const feld = (etikett, inhalt) => { const d = h("div", "kr-feld"); d.append(h("span", "kr-etikett", etikett), inhalt); return d; };
  const textEl = (t, cls) => h("div", "kr-text" + (cls ? " " + cls : ""), t);
  function zaehlKnopf(wert, kleiner, groesser, fokus, aria) {
    const d = h("div", "kr-zaehl");
    d.append(knopf("−", "", kleiner, fokus + "-", aria + " kleiner"), h("span", "kr-zahl", String(wert)), knopf("+", "", groesser, fokus + "+", aria + " größer"));
    return d;
  }
  function eingabe(wert, fokus, aria, fn, zeilen) {
    const e = zeilen ? h("textarea") : h("input"); if (zeilen) e.rows = zeilen; else e.type = "text"; e.value = wert; e.autocomplete = "off"; e.spellcheck = false; e.dataset.fokus = fokus; e.setAttribute("aria-label", aria);
    e.addEventListener("input", () => { fn(e.value); auf(); });
    return e;
  }
  function wahl(werte, aktiv, fn, fokus, aria) {
    const e = h("select"); e.dataset.fokus = fokus; e.setAttribute("aria-label", aria);
    werte.forEach(([v, t]) => { const o = h("option", "", t); o.value = v; o.selected = v === aktiv; e.append(o); });
    e.addEventListener("change", () => { fn(e.value); zeichnen(); });
    return e;
  }
  function mitFokus(fn) {
    const a = document.activeElement, f = a && wurzel.contains(a) ? a.dataset.fokus : null;
    const caret = f && (a.tagName === "TEXTAREA" || (a.tagName === "INPUT" && a.type === "text")) ? [a.selectionStart, a.selectionEnd] : null;
    fn();
    if (!f) return;
    const e = wurzel.querySelector('[data-fokus="' + f + '"]');
    if (e && e !== document.activeElement) { e.focus({ preventScroll: true }); if (caret) try { e.setSelectionRange(caret[0], caret[1]); } catch (x) {} }
  }

  stil();
  wurzel.classList.add("kryptotisch");
  const reiter = h("div", "kr-reiter"); reiter.setAttribute("role", "tablist"); reiter.setAttribute("aria-label", "Tische der Werkstatt");
  const flaeche = h("div", "kr-flaeche");
  wurzel.replaceChildren(...(tische.length > 1 ? [reiter] : []), flaeche);
  let auf = () => {};          // frischt den Tisch auf, ohne ihn neu zu bauen (Eingaben behalten Fokus und Schreibmarke)

  function zeichnen() {
    mitFokus(() => {
      reiter.replaceChildren(...tische.map(t => { const b = knopf(NAMEN[t], t === tisch ? "aktiv" : "", () => { tisch = t; zeichnen(); }, "reiter-" + t); b.setAttribute("role", "tab"); b.setAttribute("aria-selected", String(t === tisch)); return b; }));
      flaeche.replaceChildren();
      flaeche.className = "kr-flaeche kr-tisch-" + tisch;
      auf = ({ scheibe: baueScheibe, leitung: baueLeitung, durchprobieren: baueDurchprobieren, haeufigkeit: baueHaeufigkeit,
        zaun: baueZaun, farben: baueFarben, zahlen: baueZahlen, labor: baueLabor })[tisch]() || (() => {});
      auf();
    });
  }

  // ─── Tisch scheibe ─────────────────────────────────────────────────────────────────
  function baueScheibe() {
    const zs = z();
    const links = h("div", "kr-scheibe-wrap");
    const svg = s("svg", { viewBox: "-160 -160 320 320", class: "kr-scheibe", role: "slider", tabindex: "0", "aria-label": "Caesar-Scheibe: außen der eingetippte Text, innen, was daraus wird. Ziehen am Ring oder Pfeiltasten drehen.", "aria-valuemin": "0", "aria-valuemax": "25" });
    svg.dataset.fokus = "scheibe";
    const zahl = h("span", "kr-zahl");
    const regler = h("div", "kr-zaehl");
    regler.append(knopf("−", "", () => drehe(zs.k - 1), "sk-", "Schlüssel kleiner"), h("span", "kr-etikett", "Schlüssel"), zahl, knopf("+", "", () => drehe(zs.k + 1), "sk+", "Schlüssel größer"));
    links.append(svg, regler);
    const rechts = h("div", "kr-mitte");
    const ein = eingabe(zs.text, "scheibe-text", "Text außen auf der Scheibe", v => { zs.text = v; });
    const aus = textEl("", "geheim"); aus.setAttribute("aria-live", "polite");
    rechts.append(feld("außen · was ihr eintippt", ein), feld("innen · was daraus wird", aus),
      h("div", "kr-knoepfe"), h("p", "kr-hinweis", "Ziehen am Ring dreht ihn -- oder − und +, auf der Scheibe auch die Pfeiltasten. „innen nach außen“ setzt das Ergebnis oben ein: Dann dreht ihr weiter."));
    rechts.children[2].append(knopf("innen nach außen ↑", "", () => { zs.text = schiebe(zs.text, zs.k); ein.value = zs.text; auf(); }, "einsetzen"));
    flaeche.append(links, rechts);
    function drehe(k) { zs.k = mod(k, 26); auf(); }
    // ziehen: der Winkel wird Schritt für Schritt aufsummiert (über die Grenze bei ±180° hinweg); ein Buchstabenfeld
    // ist 360°/26 -- im Uhrzeigersinn ziehen schiebt den inneren Ring mit, der Schlüssel wird kleiner
    let zug = null;
    const winkel = e => { const r = svg.getBoundingClientRect(); return Math.atan2(e.clientY - r.top - r.height / 2, e.clientX - r.left - r.width / 2); };
    svg.addEventListener("pointerdown", e => { if (e.button !== 0) return; e.preventDefault(); zug = { id: e.pointerId, w: winkel(e), summe: 0, k0: zs.k }; try { svg.setPointerCapture(e.pointerId); } catch (x) {} svg.classList.add("zieht"); svg.focus({ preventScroll: true }); });
    svg.addEventListener("pointermove", e => {
      if (!zug || e.pointerId !== zug.id) return;
      e.preventDefault();
      const w = winkel(e); let d = w - zug.w; if (d > Math.PI) d -= 2 * Math.PI; if (d < -Math.PI) d += 2 * Math.PI;
      zug.summe += d; zug.w = w;
      const k = mod(zug.k0 - Math.round(zug.summe / (2 * Math.PI / 26)), 26);
      if (k !== zs.k) { zs.k = k; auf(); }
    });
    const ende = e => { if (zug && e.pointerId === zug.id) { zug = null; svg.classList.remove("zieht"); } };
    svg.addEventListener("pointerup", ende); svg.addEventListener("pointercancel", ende); svg.addEventListener("lostpointercapture", ende);
    svg.addEventListener("selectstart", e => e.preventDefault());
    svg.addEventListener("keydown", e => {
      const d = { ArrowRight: 1, ArrowUp: 1, ArrowLeft: -1, ArrowDown: -1 }[e.key];
      if (d) { e.preventDefault(); drehe(zs.k + d); } else if (e.key === "Home") { e.preventDefault(); drehe(0); }
    });
    return () => {
      svg.replaceChildren();
      svg.append(s("circle", { r: 150, class: "kr-ring-aussen" }), s("circle", { r: 104, class: "kr-ring-innen" }), s("circle", { r: 58, class: "kr-ring-mitte" }));
      for (let i = 0; i < 26; i++) {
        const w = (i / 26) * 2 * Math.PI - Math.PI / 2, w2 = w + Math.PI / 26;
        svg.append(s("line", { x1: Math.cos(w2) * 104, y1: Math.sin(w2) * 104, x2: Math.cos(w2) * 150, y2: Math.sin(w2) * 150, class: "kr-strich" }));
        svg.append(s("text", { x: Math.cos(w) * 128, y: Math.sin(w) * 128 + 6, class: "kr-aussen" + (i === 0 ? " oben" : "") }, ABC[i]));
        svg.append(s("text", { x: Math.cos(w) * 81, y: Math.sin(w) * 81 + 6, class: "kr-innen" + (i === 0 ? " oben" : "") }, ABC[(i + zs.k) % 26]));
      }
      svg.append(s("path", { d: "M -7 -160 L 7 -160 L 0 -151 Z", class: "kr-zeiger" }));
      svg.append(s("text", { x: 0, y: -2, class: "kr-mitte-text" }, "a → " + ABC[zs.k]));
      svg.append(s("text", { x: 0, y: 17, class: "kr-mitte-klein" }, "+" + zs.k));
      svg.setAttribute("aria-valuenow", String(zs.k));
      svg.setAttribute("aria-valuetext", "Schlüssel " + zs.k + ": aus a wird " + ABC[zs.k]);
      zahl.textContent = String(zs.k);
      aus.textContent = schiebe(zs.text, zs.k);
    };
  }

  // ─── Evas Spalte: durchprobieren (Tisch leitung mit eva, Tisch durchprobieren) ──────
  // Jede Zeile ist ein Schlüssel, verdeckt. Aufdecken ist ein Versuch; „das ist es“ an einer aufgedeckten Zeile sagt,
  // ob Bao das lesen würde. „alle aufdecken“ ist der Brute-Force-Angriff: jeder Schlüssel ein Versuch.
  const schluesselVon = v => v === "zaun" ? [2, 3, 4, 5] : v === "caesar" ? Array.from({ length: 25 }, (x, i) => i + 1) : [];
  const zurueck = (g, v, k) => v === "zaun" ? zaunEnt(g, k) : v === "caesar" ? schiebe(g, -k) : g;
  function evaSpalte(e, geheim, verfahren, richtig, neuZeichnen) {
    const box = h("div", "kr-eva-probe");
    const alle = schluesselVon(verfahren);
    if (!alle.length) { box.append(h("p", "kr-hinweis", verfahren === "keins" ? "Nichts zu probieren: Eva liest mit." : "Ein Geheimalphabet hat zu viele Schlüssel für eine Liste.")); return box; }
    const kopf = h("div", "kr-zaehler");
    const zelle = (n, w) => { const k = h("div"); k.append(h("small", "", n), h("strong", "", String(w))); return k; };
    kopf.append(zelle("Versuche", e.versuche), zelle("höchstens", alle.length));
    const liste = h("div", "kr-liste"); liste.setAttribute("role", "list");
    for (const k of alle) {
      const offen = e.offen.includes(k), zeile = h("div", "kr-zeile" + (offen ? " offen" : "") + (e.gefunden === k ? " treffer" : "") + (e.falsch === k ? " falsch" : ""));
      zeile.setAttribute("role", "listitem");
      const probe = knopf("", "kr-probe", () => { if (!e.offen.includes(k) && e.gefunden == null) { e.offen.push(k); e.versuche++; e.falsch = null; neuZeichnen(); } }, "p" + k,
        offen ? (verfahren === "zaun" ? k + " Latten: " : "Schlüssel " + k + ": ") + zurueck(geheim, verfahren, k) : (verfahren === "zaun" ? k + " Latten" : "Schlüssel " + k) + " -- aufdecken ist ein Versuch");
      probe.append(h("span", "kr-k", verfahren === "zaun" ? k + " L" : String(k)), h("span", "kr-probetext", offen ? zurueck(geheim, verfahren, k) : "· · ·"));
      zeile.append(probe);
      if (offen && e.gefunden == null) zeile.append(knopf("das ist es", "kr-das", () => { if (k === richtig) e.gefunden = k; else e.falsch = k; neuZeichnen(); }, "d" + k, "Das ist es: " + (verfahren === "zaun" ? k + " Latten" : "Schlüssel " + k)));
      liste.append(zeile);
    }
    const urteil = h("p", "kr-urteil"); urteil.setAttribute("role", "status");
    if (e.gefunden != null) { urteil.classList.add("ok"); urteil.textContent = "Eva hat es: " + (verfahren === "zaun" ? e.gefunden + " Latten" : "Schlüssel " + e.gefunden) + " -- nach " + e.versuche + (e.versuche === 1 ? " Versuch." : " Versuchen."); }
    else if (e.falsch != null) { urteil.classList.add("nicht"); urteil.textContent = "Das liest Bao nicht. Weiter probieren."; }
    else urteil.textContent = e.versuche ? "Noch nicht gefunden." : (verfahren === "zaun" ? "Gartenzaun: Eva probiert die Zahl der Latten." : "Caesar: Eva probiert die Schlüssel.");
    const knoepfe = h("div", "kr-knoepfe");
    knoepfe.append(knopf("alle aufdecken", "", () => { if (e.gefunden != null) return; for (const k of alle) if (!e.offen.includes(k)) { e.offen.push(k); e.versuche++; } neuZeichnen(); }, "alle"),
      knopf("↺ von vorn", "", () => { Object.assign(e, evaNeu()); neuZeichnen(); }, "eva-neu"));
    box.append(kopf, liste, urteil, knoepfe);
    return box;
  }

  // ─── Tisch leitung ─────────────────────────────────────────────────────────────────
  const verschluessle = (t, v, k) => v === "caesar" ? schiebe(t, k) : v === "zaun" ? zaunVer(t, k) : String(t).toLowerCase();
  function baueLeitung() {
    const zl = z();
    const raster = h("div", "kr-drei");
    const amara = h("section", "kr-person"), eva = h("section", "kr-person kr-eva"), bao = h("section", "kr-person");
    amara.append(h("h3", "", "Amara schickt"));
    const ein = eingabe(zl.text, "leitung-text", "Nachricht von Amara", v => { zl.text = v; zl.eva = evaNeu(); }, 2);
    const amaraInhalt = h("div", "kr-stapel"), baoInhalt = h("div", "kr-stapel"), evaInhalt = h("div", "kr-stapel");
    amara.append(amaraInhalt); eva.append(h("h3", "", "Eva am Router"), evaInhalt); bao.append(h("h3", "", "Bao liest"), baoInhalt);
    raster.append(amara, eva, bao);
    const leiste = h("div", "kr-knoepfe kr-leiste");
    flaeche.append(leiste, raster);
    const verfahren = [["caesar", "Caesar"]].concat(mitZaun ? [["zaun", "Gartenzaun"]] : []).concat([["keins", "ohne Verschlüsselung"]]);
    if (!verfahren.some(v => v[0] === zl.verfahren)) zl.verfahren = "caesar";
    const grenzen = () => zl.verfahren === "zaun" ? [2, 5] : [1, 25];
    const setze = (n, k) => { const [a, b] = grenzen(); zl[n] = Math.max(a, Math.min(b, k)); if (n === "k") zl.eva = evaNeu(); zeichnen(); };
    return () => {
      const [lo, hi] = grenzen(); zl.k = Math.max(lo, Math.min(hi, zl.k)); zl.bk = Math.max(lo, Math.min(hi, zl.bk));
      const leitungText = verschluessle(zl.text, zl.verfahren, zl.k);
      leiste.replaceChildren(knopf(zl.verdeckt ? "aufdecken" : "verdecken – Eva ist dran", zl.verdeckt ? "aktiv" : "", () => { zl.verdeckt = !zl.verdeckt; zeichnen(); }, "verdecken"),
        h("span", "kr-hinweis", zl.verdeckt ? "Amaras Nachricht und die Schlüssel sind verdeckt. Eva sieht nur, was über den Router geht." : "Zwei Paare, ein Rechner: Ein Paar schickt, dann „verdecken“, und das andere Paar ist Eva."));
      mitFokus(() => {
        amaraInhalt.replaceChildren(
          feld("Nachricht", zl.verdeckt ? textEl("verdeckt", "verdeckt") : ein),
          feld("Verfahren", wahl(verfahren, zl.verfahren, v => { zl.verfahren = v; zl.k = v === "zaun" ? 2 : 7; zl.bk = zl.k; zl.eva = evaNeu(); }, "verfahren", "Verfahren")),
          zl.verfahren === "keins" ? h("p", "kr-hinweis", "Ohne Schlüssel.") : feld(zl.verfahren === "zaun" ? "Latten" : "Schlüssel", zl.verdeckt ? textEl("?", "verdeckt") : zaehlKnopf(zl.k, () => setze("k", zl.k - 1), () => setze("k", zl.k + 1), "ak", "Amaras Schlüssel")));
        const evaFelder = [feld("Das kommt am Router vorbei", textEl(leitungText, "geheim")),
          h("p", "kr-hinweis", zl.verfahren === "keins" ? "Eva liest alles -- wie eine Postkarte." : "Eva weiß: " + (zl.verfahren === "zaun" ? "Gartenzaun" : "Caesar") + ". Den Schlüssel weiß sie nicht.")];
        if (evaProbiert) evaFelder.push(evaSpalte(zl.eva, leitungText, zl.verfahren, zl.k, zeichnen));
        evaInhalt.replaceChildren(...evaFelder);
        baoInhalt.replaceChildren(
          zl.verfahren === "keins" ? h("p", "kr-hinweis", "Bao braucht nichts.") : feld(zl.verfahren === "zaun" ? "Baos Latten" : "Baos Schlüssel", zl.verdeckt ? textEl("?", "verdeckt") : zaehlKnopf(zl.bk, () => setze("bk", zl.bk - 1), () => setze("bk", zl.bk + 1), "bk", "Baos Schlüssel")),
          feld("Bao liest", zl.verdeckt ? textEl("verdeckt", "verdeckt") : textEl(zurueck(leitungText, zl.verfahren, zl.bk), zl.verfahren !== "keins" && zl.bk !== zl.k ? "salat" : "")));
      });
    };
  }

  // ─── Tisch durchprobieren ──────────────────────────────────────────────────────────
  function baueDurchprobieren() {
    const zd = z();
    const box = h("section", "kr-person kr-eva kr-allein");
    flaeche.append(box);
    return () => mitFokus(() => {
      const zt = zettelVon(zd.zettel);
      box.replaceChildren(h("h3", "", "Eva probiert durch"),
        feld("Zettel", wahl(ZETTEL.filter(x => x.verfahren !== "wort").map(x => [x.id, x.name]), zt.id, v => { zd.zettel = v; zd.eva = evaNeu(); }, "zettel", "Zettel")),
        feld("Abgefangen", textEl(zt.text, "geheim")),
        h("p", "kr-hinweis", "Eva weiß: " + (zt.verfahren === "zaun" ? "Gartenzaun" : "Caesar") + ". Jede Zeile, die ihr aufdeckt, ist ein Versuch."),
        evaSpalte(zd.eva, zt.text, zt.verfahren, zt.k, auf));
    });
  }

  // ─── Tisch haeufigkeit ─────────────────────────────────────────────────────────────
  function baueHaeufigkeit() {
    const zh = z();
    const oben = h("div", "kr-zwei"), svgBox = h("div", "kr-balken-box"), unten = h("div", "kr-knoepfe kr-schieber");
    const info = h("p", "kr-info"); info.setAttribute("role", "status");
    flaeche.append(oben, svgBox, unten, info);
    const regler = h("input"); regler.type = "range"; regler.min = "0"; regler.max = "25"; regler.dataset.fokus = "schieber"; regler.setAttribute("aria-label", "Deutsch verschieben um");
    regler.addEventListener("input", () => { zh.v = parseInt(regler.value, 10); auf(); });
    const zahl = h("span", "kr-zahl");
    unten.append(h("span", "kr-etikett", "Deutsch verschieben"), knopf("−", "", () => { zh.v = mod(zh.v - 1, 26); auf(); }, "v-", "Deutsch um eins weniger verschieben"), regler,
      knopf("+", "", () => { zh.v = mod(zh.v + 1, 26); auf(); }, "v+", "Deutsch um eins weiter verschieben"), h("span", "", "um"), zahl);
    const wahlEl = wahl(ZETTEL.map(x => [x.id, x.name]).concat([["eigen", "eigener Text"]]), zh.zettel, v => { zh.zettel = v; }, "zettel", "Zettel");
    const eigen = eingabe(zh.eigen, "eigen", "eigener Text", v => { zh.eigen = v; });
    const text = () => zh.zettel === "eigen" ? zh.eigen.toLowerCase() : zettelVon(zh.zettel).text;
    const geheimEl = textEl("", "geheim klein"), klarEl = textEl("", "klein");
    oben.append(h("div", "kr-mitte"), h("div", "kr-mitte"));
    oben.children[0].append(feld("Zettel", wahlEl), zh.zettel === "eigen" ? feld("Text", eigen) : feld("Abgefangen", geheimEl));
    oben.children[1].append(feld("um die Verschiebung zurückgeschoben", klarEl));
    return () => {
      const t = text(), zaehl = {}; let n = 0;
      for (const c of t) if (ABC.includes(c)) { zaehl[c] = (zaehl[c] || 0) + 1; n++; }
      regler.value = String(zh.v); zahl.textContent = String(zh.v);
      geheimEl.textContent = t.length > 110 ? t.slice(0, 110) + " …" : t;
      const klar = schiebe(t, -zh.v); klarEl.textContent = klar.length > 110 ? klar.slice(0, 110) + " …" : klar;
      const B = 780, b = B / 26, OBEN = 86, UNTEN = 200, F = 4.2;
      const svg = s("svg", { viewBox: "0 0 " + B + " 220", class: "kr-balken", role: "img", "aria-label": "Häufigkeit der Buchstaben: oben der Zettel, unten Deutsch, um " + zh.v + " verschoben" });
      svg.append(s("text", { x: 4, y: 13, class: "kr-achse" }, "Zettel"), s("text", { x: 4, y: 120, class: "kr-achse" }, "Deutsch, verschoben um " + zh.v));
      let max = 0, maxC = "a";
      for (let i = 0; i < 26; i++) {
        const c = ABC[i], x = i * b + 4, w = b - 8, anteil = n ? (zaehl[c] || 0) / n * 100 : 0;
        if ((zaehl[c] || 0) > max) { max = zaehl[c]; maxC = c; }
        const h1 = Math.min(72, anteil * F), dq = ABC[mod(i - zh.v, 26)], h2 = DEUTSCH[dq] * F;
        svg.append(s("rect", { x, y: OBEN - h1, width: w, height: h1, rx: 4, class: "kr-b-zettel" }));
        svg.append(s("rect", { x, y: UNTEN - h2, width: w, height: h2, rx: 4, class: "kr-b-deutsch" + (dq === "e" ? " e" : "") }));
        svg.append(s("text", { x: x + w / 2, y: OBEN + 15, class: "kr-b-zettel-t" }, c));
        svg.append(s("text", { x: x + w / 2, y: UNTEN + 16, class: "kr-b-deutsch-t" }, dq));
      }
      svgBox.replaceChildren(svg);
      info.textContent = n ? "Am häufigsten auf dem Zettel: " + maxC + " (" + max + "-mal von " + n + " Buchstaben) · Abstand zum e: " + mod(ABC.indexOf(maxC) - 4, 26) : "Auf dem Zettel steht noch kein Buchstabe.";
    };
  }

  // ─── Tisch zaun ────────────────────────────────────────────────────────────────────
  function baueZaun() {
    const zz = z();
    const links = h("div", "kr-mitte"), svgBox = h("div", "kr-zaun-box");
    const ein = eingabe(zz.text, "zaun-text", "Klartext", v => { zz.text = v; });
    const zahlBox = h("div"), aus = textEl("", "geheim");
    links.append(feld("Klartext", ein), feld("Latten", zahlBox), feld("Geheimtext", aus), h("p", "kr-hinweis", "Kein Buchstabe ändert sich -- nur die Reihenfolge. Leerzeichen und Satzzeichen fallen weg."));
    flaeche.append(links, svgBox);
    return () => mitFokus(() => {
      zahlBox.replaceChildren(zaehlKnopf(zz.n, () => { zz.n = Math.max(2, zz.n - 1); auf(); }, () => { zz.n = Math.min(5, zz.n + 1); auf(); }, "latten", "Zahl der Latten"));
      const b = nurBuchstaben(zz.text), l = latteVon(b.length, zz.n);
      aus.textContent = zaunVer(zz.text, zz.n);
      const W = 520, dx = Math.min(30, (W - 30) / Math.max(1, b.length)), dy = zz.n > 1 ? 130 / (zz.n - 1) : 0;
      const svg = s("svg", { viewBox: "0 0 " + W + " 170", class: "kr-zaun", role: "img", "aria-label": "Gartenzaun: " + zz.n + " Latten, die Buchstaben im Zickzack" });
      for (let r = 0; r < zz.n; r++) svg.append(s("line", { x1: 8, x2: W - 8, y1: 20 + r * dy, y2: 20 + r * dy, class: "kr-latte" }));
      const punkte = [...b].map((c, i) => [16 + i * dx, 20 + l[i] * dy]);
      if (punkte.length > 1) svg.append(s("polyline", { points: punkte.map(p => p.join(",")).join(" "), class: "kr-zickzack" }));
      [...b].forEach((c, i) => svg.append(s("text", { x: punkte[i][0], y: punkte[i][1] + 5, class: "kr-zaun-t" }, c)));
      svgBox.replaceChildren(svg);
    });
  }

  // ─── Tisch farben ──────────────────────────────────────────────────────────────────
  const STUFEN_FARBEN = ["Verabredet: Gelb, für alle", "Geheim: jede Seite wählt eine Farbe", "Geschickt: Gelb und das Geheimnis gemischt",
    "Gemischt: das Geheimnis in die Mischung der anderen", "Eva mischt, was sie hat"];
  function stufenLeiste(namen, zs, max) {
    // eine Zeile: die Knöpfe, dann „Schritt n von 5“ und was gerade geschieht (die Liste aller Schritte nahm am Beamer
    // den Platz der drei Spalten)
    const d = h("div", "kr-stufen");
    const ol = h("p", "kr-stufe-jetzt"); ol.setAttribute("aria-live", "polite");
    ol.append(h("span", "kr-stufe-nr", "Schritt " + (zs.stufe + 1) + " von " + namen.length), h("span", "", namen[zs.stufe]));
    const kn = h("div", "kr-knoepfe");
    const weiter = knopf("▸ weiter", "", () => { zs.stufe = Math.min(max, zs.stufe + 1); zeichnen(); }, "weiter"); weiter.disabled = zs.stufe >= max;
    kn.append(weiter, knopf("alles zeigen", "", () => { zs.stufe = max; zeichnen(); }, "alles"), knopf("↺ von vorn", "", () => { zs.stufe = 0; if (zs.versucht) { zs.versucht = []; zs.gefunden = null; } zeichnen(); }, "neu"));
    d.append(kn, ol);
    return d;
  }
  const klecks = (f, cls, aria) => { const k = h("div", "kr-klecks" + (cls ? " " + cls : "")); if (f) k.style.background = rgb(f); else k.classList.add("leer"); if (aria) { k.setAttribute("role", "img"); k.setAttribute("aria-label", aria); } return k; };
  function farbwahl(aktiv, fn, wer) {
    const d = h("div", "kr-farbwahl");
    GEHEIMFARBEN.forEach(n => { const b = knopf("", "kr-farbknopf", () => { fn(n); zeichnen(); }, wer + "-" + n, wer + " wählt " + FARBNAME[n]); b.style.background = rgb(FARBE[n]); b.setAttribute("aria-pressed", String(n === aktiv)); d.append(b); });
    return d;
  }
  function farbenRechnen(zf) {
    const vonA = mische(["gelb", zf.a]), vonB = mische(["gelb", zf.b]);
    return { vonA, vonB, beiA: mische(["gelb", zf.b, zf.a]), beiB: mische(["gelb", zf.a, zf.b]), eva: mische(["gelb", zf.a, "gelb", zf.b]) };
  }
  function baueFarben() {
    const zf = z();
    return () => mitFokus(() => {
      const f = farbenRechnen(zf), st = zf.stufe;
      const spalte = (cls, titel) => { const sp = h("section", "kr-person kr-topf" + (cls ? " " + cls : "")); sp.append(h("h3", "", titel)); return sp; };
      const amara = spalte("", "Amara"), eva = spalte("kr-eva", "Eva sieht"), bao = spalte("", "Bao");
      const zeile = (etikett, inhalt) => { const d = h("div", "kr-topfzeile"); d.append(h("span", "kr-etikett", etikett), inhalt); return d; };
      amara.append(zeile("geheim" + (st >= 1 ? ": " + FARBNAME[zf.a] : ""), h("div", "kr-reihe", null)));
      amara.lastChild.lastChild.append(farbwahl(zf.a, n => { zf.a = n; }, "Amara"), st >= 1 ? klecks(FARBE[zf.a], "klein", "Amaras Geheimnis") : klecks(null, "klein"));
      bao.append(zeile("geheim" + (st >= 1 ? ": " + FARBNAME[zf.b] : ""), h("div", "kr-reihe", null)));
      bao.lastChild.lastChild.append(farbwahl(zf.b, n => { zf.b = n; }, "Bao"), st >= 1 ? klecks(FARBE[zf.b], "klein", "Baos Geheimnis") : klecks(null, "klein"));
      eva.append(zeile("für alle: Gelb", klecks(FARBE.gelb, "klein", "Gelb, für alle sichtbar")));
      if (st >= 2) {
        amara.append(zeile("schickt Gelb + " + FARBNAME[zf.a], klecks(f.vonA, "", "Amaras Mischung")));
        bao.append(zeile("schickt Gelb + " + FARBNAME[zf.b], klecks(f.vonB, "", "Baos Mischung")));
        const zwei = h("div", "kr-reihe"); zwei.append(klecks(f.vonA, "klein", "Amaras Mischung, über den Router"), klecks(f.vonB, "klein", "Baos Mischung, über den Router"));
        eva.append(zeile("über den Router: beide Mischungen", zwei));
      }
      if (st >= 3) {
        amara.append(zeile("mischt " + FARBNAME[zf.a] + " in Baos Mischung", klecks(f.beiA, "gross kr-gemeinsam-a", "die Farbe bei Amara")));
        bao.append(zeile("mischt " + FARBNAME[zf.b] + " in Amaras Mischung", klecks(f.beiB, "gross kr-gemeinsam-b", "die Farbe bei Bao")));
      }
      if (st >= 4) {
        const vergleich = h("div", "kr-reihe"); vergleich.append(klecks(f.eva, "gross kr-evamisch", "Evas Mischung"), klecks(f.beiA, "klein", "zum Vergleich: die Farbe von Amara und Bao"));
        eva.append(zeile("mischt beide Mischungen", vergleich), h("p", "kr-hinweis", "Nicht dieselbe: In Evas Mischung ist Gelb zweimal. " + FARBNAME[zf.a] + " oder " + FARBNAME[zf.b] + " holt sie aus keiner Mischung heraus."));
      }
      const raster = h("div", "kr-drei"); raster.append(amara, eva, bao);
      const satz = h("p", "kr-info"); satz.setAttribute("role", "status");
      satz.textContent = st >= 3 ? (rgb(f.beiA) === rgb(f.beiB) ? "Dieselbe Farbe auf beiden Seiten: Gelb, " + FARBNAME[zf.a] + " und " + FARBNAME[zf.b] + " -- nur in anderer Reihenfolge gemischt. Verschickt wurde keines der Geheimnisse." : "")
        : st === 2 ? "Eva hat jetzt alles, was über den Router ging: Gelb und zwei Mischungen." : "";
      flaeche.replaceChildren(stufenLeiste(STUFEN_FARBEN, zf, 4), raster, satz);
    });
  }

  // ─── Tisch zahlen ──────────────────────────────────────────────────────────────────
  const STUFEN_ZAHLEN = ["Verabredet: Basis und Teiler, für alle", "Geheim: jede Seite wählt eine Zahl", "Geschickt: die Basis so oft malgenommen",
    "Gemischt: die Zahl der anderen so oft malgenommen", "Eva probiert"];
  function kette(b, e, t) {
    if (e > 12) return "… " + e + "-mal malgenommen: " + potenzRest(b, e, t);
    const w = [1]; for (let i = 0; i < e; i++) w.push(w[w.length - 1] * b % t);
    return w.join(" → ");
  }
  function zahlenRechnen(zn) {
    const b = TEILER[zn.p];
    const vonA = potenzRest(b, zn.a, zn.p), vonB = potenzRest(b, zn.b, zn.p);
    return { basis: b, vonA, vonB, beiA: potenzRest(vonB, zn.a, zn.p), beiB: potenzRest(vonA, zn.b, zn.p) };
  }
  function evaVersuch(zn) {
    if (zn.gefunden != null || zn.versucht.length >= zn.p - 1) return;
    const r = zahlenRechnen(zn), k = zn.versucht.length + 1, w = potenzRest(r.basis, k, zn.p);
    zn.versucht.push(w);
    if (w === r.vonA) zn.gefunden = k;
  }
  function baueZahlen() {
    const zn = z();
    return () => mitFokus(() => {
      const r = zahlenRechnen(zn), st = zn.stufe;
      const spalte = (cls, titel) => { const sp = h("section", "kr-person" + (cls ? " " + cls : "")); sp.append(h("h3", "", titel)); return sp; };
      const amara = spalte("", "Amara"), eva = spalte("kr-eva", "Eva sieht"), bao = spalte("", "Bao");
      const setze = (wer, v) => { zn[wer] = Math.max(1, Math.min(zn.p - 1, v)); zn.versucht = []; zn.gefunden = null; zeichnen(); };
      // − und + für kleine Schritte, das Feld für eine große Zahl (Teiler 1009), „würfeln“ wie randint
      const geheim = wer => { const d = zaehlKnopf(zn[wer], () => setze(wer, zn[wer] - 1), () => setze(wer, zn[wer] + 1), "g" + wer, (wer === "a" ? "Amaras" : "Baos") + " Geheimzahl");
        const f = h("input", "kr-nummer"); f.type = "number"; f.min = "1"; f.max = String(zn.p - 1); f.value = String(zn[wer]); f.dataset.fokus = "n" + wer;
        f.setAttribute("aria-label", (wer === "a" ? "Amaras" : "Baos") + " Geheimzahl eintippen");
        f.addEventListener("change", () => { const v = parseInt(f.value, 10); if (!isNaN(v)) setze(wer, v); });
        d.querySelector(".kr-zahl").replaceWith(f);
        d.append(knopf("würfeln", "", () => setze(wer, 1 + Math.floor(Math.random() * (zn.p - 1))), "w" + wer, "Geheimzahl würfeln")); return d; };
      const pillen = h("div", "kr-pillen"); pillen.append(h("span", "kr-etikett", "Teiler"));
      Object.keys(TEILER).forEach(p => pillen.append(knopf(p, "kr-pille" + (+p === zn.p ? " aktiv" : ""), () => { zn.p = +p; zn.a = Math.min(zn.a, zn.p - 1); zn.b = Math.min(zn.b, zn.p - 1); zn.versucht = []; zn.gefunden = null; zeichnen(); }, "teiler" + p)));
      amara.append(feld("Geheimzahl", st >= 1 ? geheim("a") : textEl("noch nicht gewählt", "leer")));
      bao.append(feld("Geheimzahl", st >= 1 ? geheim("b") : textEl("noch nicht gewählt", "leer")));
      eva.append(feld("für alle", h("span", "kr-gross-zahl kr-klein-zahl", "Basis " + r.basis + " · Teiler " + zn.p)), h("p", "kr-hinweis", "Mischen: mit " + r.basis + " malnehmen, nach jedem Mal nur den Rest beim Teilen durch " + zn.p + " behalten -- so oft, wie die Geheimzahl sagt."));
      if (st >= 2) {
        amara.append(feld("rechnet " + zn.a + "-mal", textEl(kette(r.basis, zn.a, zn.p), "klein")), feld("schickt", h("span", "kr-gross-zahl kr-von-a", String(r.vonA))));
        bao.append(feld("rechnet " + zn.b + "-mal", textEl(kette(r.basis, zn.b, zn.p), "klein")), feld("schickt", h("span", "kr-gross-zahl kr-von-b", String(r.vonB))));
        eva.append(feld("über den Router", textEl("Amara schickt " + r.vonA + " · Bao schickt " + r.vonB, "geheim")));
      }
      if (st >= 3) {
        amara.append(feld("mischt Baos " + r.vonB + " " + zn.a + "-mal", h("span", "kr-gross-zahl kr-gemeinsam-a", String(r.beiA))));
        bao.append(feld("mischt Amaras " + r.vonA + " " + zn.b + "-mal", h("span", "kr-gross-zahl kr-gemeinsam-b", String(r.beiB))));
      }
      if (st >= 4) {
        const box = h("div", "kr-eva-probe");
        const kopf = h("div", "kr-zaehler"); const zelle = (n, w) => { const k = h("div"); k.append(h("small", "", n), h("strong", "", String(w))); return k; };
        kopf.append(zelle("Versuche", zn.versucht.length), zelle("höchstens", zn.p - 1));
        const liste = h("div", "kr-versuchliste");
        const zeigen = zn.versucht.length > 30 ? zn.versucht.slice(-30) : zn.versucht, ab = zn.versucht.length - zeigen.length;
        zeigen.forEach((w, i) => liste.append(h("span", w === r.vonA ? "treffer" : "", (ab + i + 1) + "-mal: " + w)));
        const urteil = h("p", "kr-urteil"); urteil.setAttribute("role", "status");
        urteil.textContent = zn.gefunden != null ? "Eva hat Amaras Geheimzahl: " + zn.gefunden + " -- nach " + zn.versucht.length + (zn.versucht.length === 1 ? " Versuch" : " Versuchen") + ". Damit rechnet sie den Schlüssel: " + potenzRest(r.vonB, zn.gefunden, zn.p) + "."
          : "Eva sucht die Geheimzahl, aus der " + r.vonA + " wird: 1-mal, 2-mal, 3-mal …";
        if (zn.gefunden != null) urteil.classList.add("ok");
        const kn = h("div", "kr-knoepfe");
        kn.append(knopf("nächster Versuch", "", () => { evaVersuch(zn); zeichnen(); }, "versuch"), knopf("alle probieren", "", () => { while (zn.gefunden == null && zn.versucht.length < zn.p - 1) evaVersuch(zn); zeichnen(); }, "alle"));
        box.append(kopf, liste, urteil, kn);
        eva.append(box);
      }
      const raster = h("div", "kr-drei"); raster.append(amara, eva, bao);
      const satz = h("p", "kr-info"); satz.setAttribute("role", "status");
      satz.textContent = st >= 3 && r.beiA === r.beiB ? "Dieselbe Zahl auf beiden Seiten: " + r.beiA + ". Beide haben " + r.basis + " insgesamt " + zn.a + " · " + zn.b + "-mal malgenommen, nur in anderer Reihenfolge." : "";
      const kopf = h("div", "kr-kopfzeile"); kopf.append(pillen, stufenLeiste(STUFEN_ZAHLEN, zn, 4));
      flaeche.replaceChildren(kopf, raster, satz);
    });
  }

  // ─── Tisch labor ───────────────────────────────────────────────────────────────────
  const BAUSTEIN = {
    caesar: { name: "Caesar", schluessel: 25, rechnung: "25", start: 3, min: 1, max: 25, art: "ersetzt" },
    wort: { name: "Geheimalphabet", schluessel: null, rechnung: "26!", start: "band", art: "ersetzt" },
    zaun: { name: "Gartenzaun", schluessel: 4, rechnung: "4", start: 2, min: 2, max: 5, art: "stellt um" },
    rueck: { name: "Rückwärts", schluessel: 1, rechnung: "1", start: null, art: "stellt um" },
  };
  const FAK26 = 403291461126605635584000000n;      // 26! -- so viele Geheimalphabete gibt es
  const bausteine = String(opt.bausteine || "caesar|wort|zaun|rueck").split("|").map(t => t.trim()).filter(t => BAUSTEIN[t]);
  function anfangsKette() {
    const k = String(opt.kette || "caesar").split("|").map(t => t.trim()).filter(t => BAUSTEIN[t] && bausteine.includes(t));
    return (k.length ? k : bausteine.slice(0, 1)).map(art => ({ art, k: BAUSTEIN[art].start }));
  }
  function anwenden(t, b) {
    if (b.art === "caesar") return schiebe(t, b.k);
    if (b.art === "wort") return ersetze(t, alphabetAusWort(b.k));
    if (b.art === "zaun") return zaunVer(t, b.k);
    return rueckwaerts(String(t).toLowerCase());
  }
  const zahlText = n => { const t = n.toString(); return t.length <= 12 ? BigInt(t).toLocaleString("de-DE") : "etwa " + t[0] + "," + t[1] + " · 10^" + (t.length - 1); };
  function laborRechnen(kette) {
    let produkt = 1n; const teile = [];
    kette.forEach(b => { const n = b.art === "wort" ? FAK26 : BigInt(BAUSTEIN[b.art].schluessel); produkt *= n; teile.push(BAUSTEIN[b.art].rechnung); });
    const caesar = kette.filter(b => b.art === "caesar").length, wort = kette.filter(b => b.art === "wort").length, zaun = kette.filter(b => b.art === "zaun").length;
    // Was Eva wirklich probiert: Alle ersetzenden Bausteine zusammen sind EINE Ersetzung (zweimal Caesar ist ein Caesar,
    // Caesar und Geheimalphabet ein Geheimalphabet), umstellende Bausteine ändern daran nichts. Rückwärts hat keinen
    // Schlüssel -- Eva kennt die Kette (Kerckhoffs).
    const ersetzen = wort ? FAK26 : caesar ? 25n : 1n, umstellen = 4n ** BigInt(zaun);
    return { laenge: kette.length, produkt, rechnung: teile.length ? teile.join(" · ") : "–", eva: ersetzen * umstellen, gezaehlt: umstellen, caesar, wort, zaun };
  }
  function baueLabor() {
    const zl = z();
    const ein = eingabe(zl.text, "labor-text", "Klartext der Kette", v => { zl.text = v; });
    return () => mitFokus(() => {
      const r = laborRechnen(zl.kette);
      const reihe = h("div", "kr-kette");
      const block = (cls, titel, inhalt) => { const d = h("div", "kr-block" + (cls ? " " + cls : "")); d.append(h("span", "kr-art", titel), inhalt); return d; };
      reihe.append(block("t", "Klartext", ein));
      let t = zl.text;
      zl.kette.forEach((b, i) => {
        reihe.append(h("span", "kr-pfeil", "→"));
        const B = BAUSTEIN[b.art], inhalt = h("div", "kr-stapel");
        if (b.art === "wort") inhalt.append(eingabe(b.k, "wort" + i, "Schlüsselwort von Baustein " + (i + 1), v => { b.k = v; }));
        else if (b.art === "rueck") inhalt.append(h("span", "kr-hinweis", "ohne Schlüssel"));
        else inhalt.append(zaehlKnopf(b.k, () => { b.k = Math.max(B.min, b.k - 1); auf(); }, () => { b.k = Math.min(B.max, b.k + 1); auf(); }, "b" + i, B.name + " " + (i + 1) + ": " + (b.art === "zaun" ? "Latten" : "Schlüssel")));
        t = anwenden(t, b);
        inhalt.append(textEl(t, "geheim klein"));
        const d = block(b.art === "caesar" || b.art === "wort" ? "ersetzt" : "umstellt", (i + 1) + " · " + B.name + (b.art === "zaun" ? " (Latten)" : ""), inhalt);
        d.append(knopf("✕", "kr-weg", () => { zl.kette.splice(i, 1); zeichnen(); }, "weg" + i, B.name + " " + (i + 1) + " entfernen"));
        reihe.append(d);
      });
      reihe.append(h("span", "kr-pfeil", "→"), block("e", "Geheimtext", textEl(t, "geheim")));
      const dazu = h("div", "kr-knoepfe");
      dazu.append(h("span", "kr-etikett", "Baustein dazu"));
      bausteine.forEach(art => { const b = knopf("+ " + BAUSTEIN[art].name, "", () => { if (zl.kette.length < 5) { zl.kette.push({ art, k: BAUSTEIN[art].start }); zeichnen(); } }, "dazu-" + art); b.disabled = zl.kette.length >= 5; dazu.append(b); });
      const ergebnis = h("div", "kr-ergebnis");
      const kachel = (titel, zahl, unter, cls) => { const d = h("div", "kr-kachel" + (cls ? " " + cls : "")); d.append(h("small", "", titel), h("strong", "", zahl), h("span", "kr-hinweis", unter)); return d; };
      ergebnis.append(
        kachel("Länge der Kette", String(r.laenge), r.laenge === 1 ? "Baustein" : "Bausteine", "kr-laenge"),
        kachel("Schlüssel der Kette", zahlText(r.produkt), r.rechnung, "kr-raum"),
        kachel("Eva probiert alles durch", "höchstens " + zahlText(r.eva), r.caesar > 1 && !r.wort ? "zweimal Caesar ist wieder ein Caesar" : r.wort && r.caesar ? "Caesar und Geheimalphabet sind zusammen ein Geheimalphabet" : "jede Kombination, die etwas anderes ergibt", "kr-eva-zahl"),
        kachel("Eva zählt zuerst", (r.caesar || r.wort ? "höchstens " : "") + zahlText(r.gezaehlt), r.wort ? "dazu Buchstabe für Buchstabe raten, wie beim Geheimalphabet" : r.caesar ? "der Caesar-Teil fällt mit einem Balken" : "ohne Ersetzen gibt es nichts zu zählen", "kr-gezaehlt"));
      const satz = h("p", "kr-info"); satz.setAttribute("role", "status");
      satz.textContent = !zl.kette.length ? "Noch kein Baustein: Der Geheimtext ist der Klartext."
        : (r.caesar || r.wort) ? "Kein Baustein verwischt die Häufigkeiten: Ersetzen gibt den Balken nur andere Namen, Umstellen lässt sie stehen."
          : "Nur umgestellt: Die Häufigkeiten sehen aus wie Deutsch.";
      flaeche.replaceChildren(reihe, dazu, ergebnis, satz);
    });
  }

  // ─── Stile (wie die übrigen Werkstattstile in seite.css; hier, damit der Baustein für sich steht) ──
  function stil() {
    if (document.getElementById("kr-stil")) return;
    const st = document.createElement("style"); st.id = "kr-stil";
    st.textContent = [
      ".kryptotisch { --kr-lila: var(--lila, #7a5af5); --kr-lila-hell: #efeafe; --kr-eva: var(--rot, #d6453d); font-size: 1em; }",
      ".kryptotisch .kr-reiter { display: flex; flex-wrap: wrap; gap: .4em; margin: 0 0 .7em; }",
      ".kryptotisch .kr-reiter button.aktiv, .kryptotisch .kr-pille.aktiv, .kryptotisch .kr-leiste button.aktiv { background: var(--blau); border-color: var(--blau); color: #fff; }",
      ".kryptotisch .kr-flaeche { display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1fr); gap: 1.1em; align-items: start; }",
      ".kryptotisch .kr-flaeche.kr-tisch-leitung, .kryptotisch .kr-flaeche.kr-tisch-haeufigkeit, .kryptotisch .kr-flaeche.kr-tisch-farben, .kryptotisch .kr-flaeche.kr-tisch-zahlen, .kryptotisch .kr-flaeche.kr-tisch-labor, .kryptotisch .kr-flaeche.kr-tisch-durchprobieren { grid-template-columns: minmax(0, 1fr); }",
      "@media (max-width: 760px) { .kryptotisch .kr-flaeche { grid-template-columns: minmax(0, 1fr); } }",
      ".kryptotisch .kr-feld { display: grid; gap: .25em; min-width: 0; }",
      ".kryptotisch .kr-etikett { font-family: var(--chip); font-size: .95em; letter-spacing: .05em; text-transform: uppercase; color: var(--grau); }",
      ".kryptotisch input[type=text], .kryptotisch textarea, .kryptotisch select { font: 1em var(--mono); border: 1.5px solid var(--linie); border-radius: 12px; padding: .45em .65em; background: var(--karte); color: var(--tinte); min-width: 0; width: 100%; box-sizing: border-box; }",
      ".kryptotisch select { font-family: var(--sans); } .kryptotisch textarea { resize: vertical; line-height: 1.35; }",
      ".kryptotisch input.kr-nummer { font: 1.4em var(--chip); width: 4.2em; text-align: center; border: 1.5px solid var(--linie); border-radius: 12px; padding: .1em .2em; background: var(--karte); color: var(--tinte); }",
      ".kryptotisch .kr-text { font-family: var(--mono); font-size: 1.02em; background: var(--karte); border: 1.5px solid var(--linie); border-radius: 12px; padding: .5em .7em; word-break: break-word; min-height: 1.4em; }",
      ".kryptotisch .kr-text.klein { font-size: .86em; }",
      ".kryptotisch .kr-text.geheim { color: var(--kr-lila); letter-spacing: .03em; }",
      ".kryptotisch .kr-text.verdeckt { color: var(--grau); background: repeating-linear-gradient(45deg, #eeeae2 0 8px, #f6f3ed 8px 16px); }",
      ".kryptotisch .kr-text.salat { color: var(--grau); }",
      ".kryptotisch .kr-text.leer { color: var(--grau); font-family: var(--sans); font-size: .9em; }",
      ".kryptotisch .kr-mitte, .kryptotisch .kr-stapel { display: grid; gap: .7em; min-width: 0; }",
      ".kryptotisch .kr-knoepfe { display: flex; flex-wrap: wrap; gap: .45em; align-items: center; }",
      ".kryptotisch .kr-zaehl { display: inline-flex; gap: .45em; align-items: center; flex-wrap: wrap; }",
      ".kryptotisch .kr-zahl { font-family: var(--chip); font-size: 1.8em; line-height: 1; min-width: 1.3em; text-align: center; font-variant-numeric: tabular-nums; }",
      ".kryptotisch .kr-hinweis { color: var(--grau); font-size: .86em; margin: 0; }",
      ".kryptotisch .kr-info { margin: .4em 0 0; font-size: .95em; }",
      ".kryptotisch .kr-urteil { margin: .2em 0; font-size: .92em; } .kryptotisch .ok { color: var(--mint); font-weight: 600; } .kryptotisch .nicht { color: var(--koralle); font-weight: 600; }",
      // Scheibe
      ".kryptotisch .kr-scheibe-wrap { display: grid; justify-items: center; gap: .5em; }",
      ".kryptotisch .kr-scheibe { width: min(20em, 100%); height: auto; aspect-ratio: 1; align-self: start; touch-action: none; cursor: grab; user-select: none; -webkit-user-select: none; -webkit-touch-callout: none; border-radius: 50%; }",
      ".kryptotisch .kr-scheibe.zieht { cursor: grabbing; }",
      ".kryptotisch .kr-scheibe:focus-visible { outline: 3px solid var(--blau); outline-offset: 3px; }",
      ".kryptotisch .kr-scheibe text { pointer-events: none; user-select: none; -webkit-user-select: none; font-family: var(--mono); text-anchor: middle; }",
      ".kryptotisch .kr-ring-aussen { fill: var(--karte); stroke: var(--linie); stroke-width: 2; } .kryptotisch .kr-ring-innen { fill: var(--kr-lila-hell); stroke: var(--linie); stroke-width: 2; } .kryptotisch .kr-ring-mitte { fill: var(--karte); stroke: var(--linie); stroke-width: 2; }",
      ".kryptotisch .kr-strich { stroke: var(--linie); } .kryptotisch .kr-aussen { font-size: 17px; fill: var(--tinte); } .kryptotisch .kr-innen { font-size: 16px; fill: var(--kr-lila); } .kryptotisch .kr-scheibe .oben { font-weight: 700; }",
      ".kryptotisch .kr-zeiger { fill: var(--blau); } .kryptotisch .kr-mitte-text { font-size: 14px; fill: var(--tinte); } .kryptotisch .kr-mitte-klein { font-size: 12px; fill: var(--grau); }",
      // Leitung, Farben, Zahlen: drei Spalten
      ".kryptotisch .kr-drei { display: grid; grid-template-columns: repeat(auto-fit, minmax(min(100%, 10.5em), 1fr)); gap: .9em; align-items: start; }",
      ".kryptotisch .kr-person { background: var(--karte); border: 1px solid var(--linie); border-radius: 16px; padding: .8em .9em; display: grid; gap: .6em; min-width: 0; }",
      ".kryptotisch .kr-person h3 { margin: 0; font-size: 1.05em; display: flex; align-items: center; gap: .45em; }",
      ".kryptotisch .kr-person h3::before { content: ''; width: .75em; height: .75em; border-radius: 50%; background: var(--blau); flex: none; }",
      ".kryptotisch .kr-drei > .kr-person:last-child h3::before { background: var(--mint); }",
      ".kryptotisch .kr-person.kr-eva { outline: 2px dashed var(--kr-eva); outline-offset: -2px; } .kryptotisch .kr-person.kr-eva h3::before { background: var(--kr-eva); }",
      ".kryptotisch .kr-person.kr-allein { max-width: 46em; }",
      ".kryptotisch .kr-leiste { margin: 0 0 .7em; }",
      // Evas Liste
      ".kryptotisch .kr-eva-probe { display: grid; gap: .5em; }",
      ".kryptotisch .kr-zaehler { display: flex; flex-wrap: wrap; gap: .5em; } .kryptotisch .kr-zaehler > div { background: var(--blau-zart); border: 1px solid var(--linie); border-radius: 10px; padding: .2em .7em; display: grid; } .kryptotisch .kr-zaehler small { color: var(--grau); font-size: .75em; } .kryptotisch .kr-zaehler strong { font-family: var(--chip); font-size: 1.5em; line-height: 1.1; font-variant-numeric: tabular-nums; }",
      ".kryptotisch .kr-drei .kr-liste { max-height: 8.6em; } .kryptotisch .kr-liste { max-height: 15em; overflow: auto; border: 1.5px solid var(--linie); border-radius: 12px; background: var(--karte); }",
      ".kryptotisch .kr-zeile { display: flex; align-items: center; border-bottom: 1px solid var(--linie); } .kryptotisch .kr-zeile:last-child { border-bottom: 0; }",
      ".kryptotisch button.kr-probe { flex: 1 1 auto; display: grid; grid-template-columns: 2.6em minmax(0, 1fr); gap: .4em; text-align: left; border: 0; border-radius: 0; background: none; box-shadow: none; color: var(--tinte); font: .9em var(--mono); padding: .3em .6em; min-width: 0; }",
      ".kryptotisch button.kr-probe:hover { background: var(--blau-hell); transform: none; }",
      ".kryptotisch .kr-k { color: var(--grau); } .kryptotisch .kr-probetext { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; } .kryptotisch .kr-zeile:not(.offen) .kr-probetext { color: #b9b2a6; letter-spacing: .2em; }",
      ".kryptotisch .kr-zeile.treffer { background: var(--mint-hell); } .kryptotisch .kr-zeile.falsch { background: var(--koralle-hell); }",
      ".kryptotisch button.kr-das { flex: none; font-size: .78em; padding: .15em .6em; margin-right: .4em; }",
      // Häufigkeit
      ".kryptotisch .kr-tisch-haeufigkeit .kr-text.klein { max-height: 4.2em; overflow: hidden; } .kryptotisch .kr-tisch-haeufigkeit { gap: .6em; }",
      ".kryptotisch .kr-zwei { display: grid; grid-template-columns: repeat(auto-fit, minmax(16em, 1fr)); gap: .9em; }",
      ".kryptotisch .kr-balken { width: 100%; height: auto; display: block; } .kryptotisch .kr-balken text { font-family: var(--mono); font-size: 12px; text-anchor: middle; }",
      ".kryptotisch .kr-achse { fill: var(--grau); text-anchor: start !important; } .kryptotisch .kr-b-zettel { fill: var(--kr-lila); } .kryptotisch .kr-b-deutsch { fill: var(--blau); opacity: .7; } .kryptotisch .kr-b-deutsch.e { opacity: 1; }",
      ".kryptotisch .kr-b-zettel-t { fill: var(--kr-lila); } .kryptotisch .kr-b-deutsch-t { fill: var(--blau); }",
      ".kryptotisch .kr-schieber input[type=range] { flex: 1 1 12em; min-width: 8em; }",
      // Gartenzaun
      ".kryptotisch .kr-zaun { width: 100%; height: auto; } .kryptotisch .kr-latte { stroke: var(--linie); stroke-width: 9; stroke-linecap: round; } .kryptotisch .kr-zickzack { fill: none; stroke: var(--blau-mittel); stroke-width: 1.5; stroke-dasharray: 3 4; } .kryptotisch .kr-zaun-t { font-family: var(--mono); font-size: 15px; font-weight: 600; fill: var(--tinte); text-anchor: middle; }",
      // Farben und Zahlen
      ".kryptotisch .kr-stufen { display: flex; flex-wrap: wrap; gap: .4em .9em; align-items: center; margin: 0 0 .7em; }",
      ".kryptotisch .kr-stufe-jetzt { margin: 0; display: flex; gap: .5em; align-items: baseline; flex-wrap: wrap; font-weight: 600; } .kryptotisch .kr-stufe-nr { font-family: var(--chip); font-size: 1.05em; letter-spacing: .05em; text-transform: uppercase; color: var(--grau); font-weight: 400; }",
      ".kryptotisch .kr-topfzeile { display: grid; gap: .3em; justify-items: start; }",
      ".kryptotisch .kr-reihe { display: flex; gap: .5em; align-items: center; flex-wrap: wrap; }",
      ".kryptotisch .kr-klecks { width: 4em; height: 4em; border-radius: 46% 54% 50% 50% / 52% 46% 54% 48%; box-shadow: inset 0 -6px 12px rgba(0,0,0,.15); transition: background-color .3s; flex: none; }",
      ".kryptotisch .kr-klecks.klein { width: 2.6em; height: 2.6em; } .kryptotisch .kr-klecks.gross { width: 5em; height: 5em; } .kryptotisch .kr-klecks.leer { background: none; border: 2px dashed #cfc9bb; box-shadow: none; }",
      ".kryptotisch .kr-farbwahl { display: flex; gap: .35em; } .kryptotisch button.kr-farbknopf { width: 1.9em; height: 1.9em; min-width: 0; padding: 0; border-radius: 50%; border: 2px solid var(--linie); box-shadow: none; }",
      ".kryptotisch button.kr-farbknopf[aria-pressed=true] { outline: 3px solid var(--tinte); outline-offset: 1px; }",
      ".kryptotisch .kr-pillen { display: flex; flex-wrap: wrap; gap: .4em; align-items: center; margin: 0 0 .6em; }",
      ".kryptotisch .kr-kopfzeile { display: flex; flex-wrap: wrap; gap: 0 1.4em; align-items: center; } .kryptotisch .kr-kopfzeile > * { margin-bottom: .6em; }",
      ".kryptotisch .kr-gross-zahl { font-family: var(--chip); font-size: 2.2em; line-height: 1; font-variant-numeric: tabular-nums; } .kryptotisch .kr-klein-zahl { font-size: 1.5em; }",
      ".kryptotisch .kr-versuchliste { display: flex; flex-wrap: wrap; gap: .3em; font: .82em var(--mono); } .kryptotisch .kr-versuchliste span { background: var(--blau-zart); border-radius: 6px; padding: .05em .4em; } .kryptotisch .kr-versuchliste .treffer { background: var(--mint-hell); font-weight: 700; }",
      // Labor
      ".kryptotisch .kr-kette { display: flex; flex-wrap: wrap; gap: .5em; align-items: stretch; margin: 0 0 .7em; }",
      ".kryptotisch .kr-block { background: var(--karte); border: 1px solid var(--linie); border-radius: 14px; padding: .55em .7em; display: grid; gap: .35em; min-width: 9em; max-width: 15em; position: relative; align-content: start; }",
      ".kryptotisch .kr-block.t { background: var(--blau-zart); } .kryptotisch .kr-block.e { background: var(--kr-lila-hell); } .kryptotisch .kr-block.ersetzt { border-top: 4px solid var(--kr-lila); } .kryptotisch .kr-block.umstellt { border-top: 4px solid var(--amber); }",
      ".kryptotisch .kr-art { font-family: var(--chip); font-size: 1em; text-transform: uppercase; letter-spacing: .05em; padding-right: 1.4em; }",
      ".kryptotisch .kr-pfeil { align-self: center; color: var(--grau); font-size: 1.3em; }",
      ".kryptotisch button.kr-weg { position: absolute; top: .25em; right: .3em; border: 0; background: none; box-shadow: none; color: var(--grau); padding: .1em .3em; min-width: 0; font-size: .9em; }",
      ".kryptotisch .kr-ergebnis { display: grid; grid-template-columns: repeat(auto-fit, minmax(11em, 1fr)); gap: .6em; margin: .8em 0 0; }",
      ".kryptotisch .kr-kachel { background: var(--karte); border: 1px solid var(--linie); border-radius: 12px; padding: .5em .7em; display: grid; gap: .1em; } .kryptotisch .kr-kachel small { color: var(--grau); font-size: .78em; } .kryptotisch .kr-kachel strong { font-family: var(--chip); font-size: 1.55em; line-height: 1.1; font-variant-numeric: tabular-nums; }",
      "@media (prefers-reduced-motion: reduce) { .kryptotisch .kr-klecks { transition: none; } }",
    ].join("\n");
    document.head.append(st);
  }

  zeichnen();

  // ─── Film (Vortrag, wie der Code-Film) ─────────────────────────────────────────────
  function filmSchritt(x) {
    const a = x.aktion, zahl = v => parseInt(v, 10), zs = z();
    if (a === "neu") { Z[tisch] = neu(tisch); return; }
    if (a === "halt") return;
    if (a === "tippe") { if ("text" in zs) zs.text = x.befehl; if (zs.eva) zs.eva = evaNeu(); if (tisch === "haeufigkeit") { zs.zettel = "eigen"; zs.eigen = x.befehl; } return; }
    if (tisch === "scheibe") { if (a === "drehe") zs.k = mod(zahl(x.wert), 26); else if (a === "einsetzen") zs.text = schiebe(zs.text, zs.k); return; }
    if (tisch === "leitung") {
      if (a === "verfahren" && (x.wert === "caesar" || x.wert === "keins" || (x.wert === "zaun" && mitZaun))) { zs.verfahren = x.wert; zs.k = zs.bk = x.wert === "zaun" ? 2 : 7; zs.eva = evaNeu(); }
      else if (a === "schluessel") { zs.k = zahl(x.wert); zs.eva = evaNeu(); }
      else if (a === "bao") zs.bk = zahl(x.wert);
      else if (a === "verdecken") zs.verdeckt = true;
      else if (a === "aufdecken") zs.verdeckt = false;
      else evaFilm(zs.eva, a, x, schluesselVon(zs.verfahren), zs.k);
      return;
    }
    if (tisch === "durchprobieren") {
      if (a === "zettel") { zs.zettel = zettelVon(x.wert).id; zs.eva = evaNeu(); }
      else { const zt = zettelVon(zs.zettel); evaFilm(zs.eva, a, x, schluesselVon(zt.verfahren), zt.k); }
      return;
    }
    if (tisch === "haeufigkeit") { if (a === "zettel") zs.zettel = zettelVon(x.wert).id; else if (a === "verschiebe") zs.v = mod(zahl(x.wert), 26); return; }
    if (tisch === "zaun") { if (a === "latten") zs.n = Math.max(2, Math.min(5, zahl(x.wert))); return; }
    if (tisch === "farben") {
      if (a === "amara" && FARBE[x.wert]) zs.a = x.wert; else if (a === "bao" && FARBE[x.wert]) zs.b = x.wert;
      else if (a === "weiter") zs.stufe = Math.min(4, zs.stufe + 1);
      return;
    }
    if (tisch === "zahlen") {
      if (a === "teiler" && TEILER[x.wert]) { zs.p = zahl(x.wert); zs.versucht = []; zs.gefunden = null; }
      else if (a === "amara") { zs.a = Math.max(1, Math.min(zs.p - 1, zahl(x.wert))); zs.versucht = []; zs.gefunden = null; }
      else if (a === "bao") zs.b = Math.max(1, Math.min(zs.p - 1, zahl(x.wert)));
      else if (a === "weiter") zs.stufe = Math.min(4, zs.stufe + 1);
      else if (a === "probiere") { const bis = zahl(x.wert); while (zs.gefunden == null && zs.versucht.length < Math.min(bis, zs.p - 1)) evaVersuch(zs); }
      else if (a === "alle") while (zs.gefunden == null && zs.versucht.length < zs.p - 1) evaVersuch(zs);
      return;
    }
    if (tisch === "labor") {
      if (a === "dazu" && BAUSTEIN[x.wert] && bausteine.includes(x.wert) && zs.kette.length < 5) zs.kette.push({ art: x.wert, k: BAUSTEIN[x.wert].start });
      else if (a === "stelle") { const b = zs.kette[zahl(x.nr) - 1]; if (b && b.art === "wort") b.k = x.wert; else if (b && b.art !== "rueck") b.k = Math.max(BAUSTEIN[b.art].min, Math.min(BAUSTEIN[b.art].max, zahl(x.wert))); }
      else if (a === "weg") zs.kette.splice(zahl(x.wert) - 1, 1);
    }
  }
  function evaFilm(e, a, x, alle, richtig) {
    const k = parseInt(x.wert, 10);
    if (a === "probiere" && alle.includes(k) && !e.offen.includes(k) && e.gefunden == null) { e.offen.push(k); e.versuche++; e.falsch = null; }
    else if (a === "alle" && e.gefunden == null) { for (const s of alle) if (!e.offen.includes(s)) { e.offen.push(s); e.versuche++; } }
    else if (a === "das" && e.offen.includes(k) && e.gefunden == null) { if (k === richtig) e.gefunden = k; else e.falsch = k; }
  }
  function filmHerstellen(liste) { Z[tisch] = neu(tisch); liste.forEach(filmSchritt); zeichnen(); }
  function zustand() {
    const zs = kopie(z()), aus = Object.assign({ tisch }, zs);
    if (tisch === "scheibe") aus.ausgabe = schiebe(zs.text, zs.k);
    if (tisch === "leitung") { aus.leitungText = verschluessle(zs.text, zs.verfahren, zs.k); aus.baoLiest = zurueck(aus.leitungText, zs.verfahren, zs.bk); }
    if (tisch === "durchprobieren") aus.zettelText = zettelVon(zs.zettel).text;
    if (tisch === "zaun") aus.ausgabe = zaunVer(zs.text, zs.n);
    if (tisch === "farben") aus.farben = farbenRechnen(zs);
    if (tisch === "zahlen") aus.zahlen = zahlenRechnen(zs);
    if (tisch === "labor") { const r = laborRechnen(zs.kette); aus.labor = { laenge: r.laenge, produkt: r.produkt.toString(), eva: r.eva.toString(), gezaehlt: r.gezaehlt.toString() }; let t = zs.text; zs.kette.forEach(b => { t = anwenden(t, b); }); aus.ausgabe = t; }
    return aus;
  }
  return { zustand, film: { spielen: x => { filmSchritt(x); zeichnen(); }, herstellen: filmHerstellen, laeuft: () => false } };
};
window.Werkstaetten.krypto.einleitung = "Verfahren der Kryptologie zum Anfassen: drehen, schicken, mithören, zählen, mischen. Die Seite rechnet mit, bewertet aber nichts -- was ihr findet, tragt ihr in die Aufgaben ein.";
window.Werkstaetten.krypto.einleitungFuer = o => {
  const t = String((o || {}).tische || (o || {}).tisch || "").split("|");
  if (t.includes("farben") || t.includes("zahlen")) return "Schlüsseltausch zum Anfassen: Amara und Bao mischen, Eva sieht alles, was über den Router geht. Schritt für Schritt mit „weiter“ -- was ihr findet, tragt ihr in die Aufgaben ein.";
  if (t.includes("durchprobieren") || t.includes("haeufigkeit")) return "Ihr seid Eva: Zettel abfangen, Schlüssel durchprobieren, Buchstaben zählen. Die Seite zählt eure Versuche -- was ihr findet, tragt ihr in die Aufgaben ein.";
  return window.Werkstaetten.krypto.einleitung;
};
