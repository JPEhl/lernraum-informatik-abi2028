"""Selbstcheck „Vererbung“ -- prueft das Programm im Ordner schach/ (es laeuft partie.py).

Die Unterklassen stehen in figur.py; die Aufstellung im Spiel ruft neue_figur (vorbereitet). Der Check prueft ueber
OBJEKTE, die er selbst baut (LC8): erzeuge("Turm", "weiß", 4, 2), rufe(turm, "passt", …) -- die Helfer folgen der Kette
der Oberklassen (rufe ueber getattr, attribute ueber __mro__; am Bau nachgesehen, 17.11.2026).

Wie der Check sieht, dass eine Unterklasse ihre EIGENE passt hat (ueberschreiben, LC2: Verhalten, nicht Woerter): Er
nimmt der Figur fuer die Dauer einer Probe ihre passt weg (sie sagt dann immer False) und fragt die Unterklasse noch
einmal. Zieht der Turm dann nicht mehr, zog er bis dahin ueber die Kette der Figur. Danach steht passt wieder da.
Ebenso prueft er die Auflage der Expertenaufgabe (kein Code kopiert): Er aendert fuer eine Probe die Regel von Turm und
Springer -- fragt der Kanzler sie, aendert sich seine Antwort mit; hat er sie abgeschrieben, nicht.

Fallen (LC5): Ein Konstruktor ohne super().__init__ laesst das Objekt ohne Art, Farbe und Feld -- der erste Getter
bricht dann mit AttributeError ab; deshalb fragt der Check vorher, ob das Objekt seine Attribute hat. In der
Unterklasse ist self.__zeile ein ANDERES Attribut (_Turm__zeile) -- passt bricht dann ab; die Meldung sagt, dass die
Unterklasse ueber die Getter fragt. Zeile und Spalte vertauscht -- deshalb steht jede Probefigur auf (4, 2), nicht auf
(4, 4). Bauer: weiss zieht nach oben, schwarz nach unten, zwei Felder nur vom Start; schlagen schraeg -- deshalb beide
Farben. Der Springer springt: darf darf fuer ihn den Weg nicht fragen -- deshalb ein Springer, dessen Weg besetzt ist.

Startzustand (Arbeitsordner, vorbereitet): partie.py laeuft und spielt wie am Ende von Teil I. Offen ist genau
Aufgabe 2 ★, alles andere wartet (LC1). An der Loesung passt alles.
"""
import ast
import importlib
import sys

from pruefen import erwarte, braucht, arbeit, flaeche, quelltext, erzeuge, rufe, attribute, klasse

TITEL = "Vererbung · Selbstcheck"
EINGABEN = []
DIAGRAMMTYPEN = {"String", "integer", "boolean", "Integer", "Boolean"}
ARTEN = ["Turm", "Springer", "Läufer", "Dame", "König", "Läufer", "Springer", "Turm"]
# Name der Unterklasse -> Art (der Text, den get_art nennt)
KLASSEN = {"Turm": "Turm", "Laeufer": "Läufer", "Dame": "Dame", "Koenig": "König", "Springer": "Springer",
           "Bauer": "Bauer"}
UMLAUT = {"Laeufer": "Läufer", "Koenig": "König"}
# fuer die Saetze der Meldungen
EIN = {"Turm": "Ein Turm", "Laeufer": "Ein Läufer", "Dame": "Eine Dame", "Koenig": "Ein König",
       "Springer": "Ein Springer", "Bauer": "Ein Bauer"}
DER = {"Turm": "Der Turm", "Laeufer": "Der Läufer", "Dame": "Die Dame", "Koenig": "Der König",
       "Springer": "Der Springer", "Bauer": "Der Bauer"}
# je Unterklasse: Startfeld und Proben (Ziel -> passt) -- Zeile und Spalte verschieden, jede Regel mit Ja und Nein
PROBEN = {
    "Turm": ("weiß", 4, 2, [((4, 7), True), ((0, 2), True), ((2, 4), False), ((5, 3), False)]),
    "Laeufer": ("weiß", 4, 2, [((2, 4), True), ((7, 5), True), ((4, 7), False), ((5, 2), False)]),
    "Dame": ("schwarz", 4, 2, [((4, 7), True), ((1, 5), True), ((6, 3), False), ((2, 3), False)]),
    "Koenig": ("weiß", 4, 2, [((3, 1), True), ((5, 2), True), ((2, 2), False), ((4, 4), False)]),
    "Springer": ("schwarz", 4, 2, [((2, 3), True), ((5, 4), True), ((3, 3), False), ((4, 4), False)]),
    "Bauer": ("weiß", 6, 2, [((5, 2), True), ((4, 2), True), ((3, 2), False), ((5, 3), False)]),
}


def _ok(pruefung):
    try:
        pruefung()
    except AssertionError:
        return False
    return True


def _modul(name):
    return _laden(name)[0]


def _laden(name):
    """(Modul, Meldung) -- die Meldung nennt, woran das Laden scheitert (kanzler.py laedt partie.py nicht: Ein Fehler
    dort zeigt sich beim Ausfuehren nicht, nur hier)."""
    m = sys.modules.get(name)
    if m is not None:
        return m, ""
    try:
        return importlib.import_module(name), ""
    except Exception as e:  # noqa: BLE001 -- das Laden scheitert im Code der Klasse: ein Befund mit Zeile
        zeile = getattr(e, "lineno", None)
        if zeile is None:
            tb = e.__traceback__
            while tb is not None:
                if tb.tb_frame.f_code.co_filename.endswith(name + ".py"):
                    zeile = tb.tb_lineno
                tb = tb.tb_next
        return None, "%s%s: %s" % (type(e).__name__, " in Zeile %d" % zeile if zeile else "", str(e)[:80])


def _figur():
    return klasse("Figur")


def _neue_figur():
    return getattr(_modul("figur"), "neue_figur", None)


def _unterklasse(name):
    """Die Unterklasse name -- mit einer eigenen Meldung, wenn sie mit Umlaut heisst oder nicht von Figur erbt."""
    k = klasse(name)
    if k is None and name in UMLAUT and klasse(UMLAUT[name]) is not None:
        erwarte(False, "Die Klasse heißt bei euch %s -- Namen im Code stehen ohne Umlaut: %s." % (UMLAUT[name], name))
    erwarte(k is not None, "In figur.py gibt es noch keine Klasse %s." % name)
    erwarte(isinstance(k, type) and issubclass(k, _figur()) and k is not _figur(),
            "%s ist noch keine Unterklasse der Figur -- in der Kopfzeile der Klasse fehlt, wovon sie erbt." % name)
    return k


def _baue(name, farbe, zeile, spalte):
    """Ein Objekt der Unterklasse -- und vorher die Frage, ob es die Attribute der Figur hat (super().__init__)."""
    k = _unterklasse(name)
    obj = erzeuge(k, farbe, zeile, spalte)
    a = attribute(obj)
    erwarte(all(n in a.privat for n in ("__art", "__farbe", "__zeile", "__spalte")),
            "%s hat noch keine Art, keine Farbe oder kein Feld -- ruft der Konstruktor von %s den Konstruktor der "
            "Figur?" % (EIN[name], name))
    art = rufe(obj, "get_art")
    erwarte(art == KLASSEN[name], "%s(%r, %d, %d).get_art() gibt %r statt %r -- welche Art gibt sein Konstruktor an die "
            "Figur weiter?" % (name, farbe, zeile, spalte, art, KLASSEN[name]))
    platz = [rufe(obj, "get_farbe"), rufe(obj, "get_zeile"), rufe(obj, "get_spalte")]
    erwarte(platz == [farbe, zeile, spalte], "%s(%r, %d, %d) nennt Farbe, Zeile, Spalte %r -- in welcher Reihenfolge "
            "gibt der Konstruktor sie an die Figur weiter?" % (name, farbe, zeile, spalte, platz))
    return obj


class _OhneKette:
    """Fuer die Dauer einer Probe sagt passt der FIGUR immer False -- eine Unterklasse mit eigener passt merkt es nicht."""

    def __enter__(self):
        self.f = _figur()
        self.alt = self.f.__dict__.get("passt")
        self.f.passt = lambda self_, zeile, spalte: False
        return self

    def __exit__(self, *_):
        if self.alt is None:
            del self.f.passt
        else:
            self.f.passt = self.alt


def _passt(obj, ziel):
    return rufe(obj, "passt", ziel[0], ziel[1])


def _regel(name):
    """passt der Unterklasse name an ihren Proben -- erst wie sie ist, dann ohne die Kette der Figur."""
    farbe, zeile, spalte, proben = PROBEN[name]
    obj = _baue(name, farbe, zeile, spalte)
    for ziel, soll in proben:
        try:
            ist = _passt(obj, ziel)
        except AssertionError as e:
            if "_%s__" % name in str(e):
                erwarte(False, "%s.passt bricht ab: In der Unterklasse ist self.__zeile ein anderes Attribut als in der "
                        "Figur -- privat heißt: auch die Unterklasse kommt nicht daran. Sie fragt über die Getter." % name)
            raise
        erwarte(ist is soll, "%s auf Zeile %d, Spalte %d: passt(%d, %d) gibt %r statt %r."
                % (EIN[name], zeile, spalte, ziel[0], ziel[1], ist, soll))
    with _OhneKette():
        anders = [ziel for ziel, soll in proben if _passt(obj, ziel) is not soll]
    erwarte(not anders, "%s zieht noch über die Kette in passt der Figur -- die Klasse %s hat noch keine eigene passt."
            % (DER[name], name))


def _im_spiel(namen):
    """Steht im Spiel jede Figur dieser Arten als Objekt ihrer Unterklasse? (Die Aufstellung ruft neue_figur.)"""
    nf = _neue_figur()
    erwarte(callable(nf), "In figur.py fehlt neue_figur -- sie stand ganz unten. Seht in der Shell nach.")
    for name in namen:
        k = klasse(name)
        f = nf(KLASSEN[name], "weiß", 7, 0)
        erwarte(isinstance(f, k), "neue_figur(%r, …) gibt noch %s zurück, kein Objekt der Klasse %s -- so stellt "
                "das Spiel keine auf." % (KLASSEN[name], "eine Figur" if type(f).__name__ == "Figur"
                                          else "ein Objekt der Klasse " + type(f).__name__, name))
    s = erzeuge("Spiel")
    for zeile in (0, 1, 6, 7):
        for spalte in range(8):
            f = rufe(s, "figur_auf", zeile, spalte)
            art = rufe(f, "get_art")
            name = next((n for n, a in KLASSEN.items() if a == art), None)
            if name in namen:
                erwarte(type(f).__name__ == name, "Im Spiel steht auf Zeile %d, Spalte %d %s %s als %s, nicht als %s."
                        % (zeile, spalte, art, rufe(f, "get_farbe"), type(f).__name__, name))


def _alle_da():
    return _ok(pruefe_20_turm_laeufer) and _ok(pruefe_25_alle)


def pruefe_00_grundlage():
    """Grundlage · figur.py und spiel.py laden, das Programm hat eine Zeichenfläche"""
    erwarte(_figur() is not None, "In figur.py steht keine Klasse Figur mehr -- seht in der Shell nach.")
    erwarte(klasse("Spiel") is not None, "In spiel.py steht keine Klasse Spiel mehr -- seht in der Shell nach.")
    erwarte(flaeche() is not None, "Das Programm bricht ab, bevor es eine Zeichenfläche hat -- seht in der Shell nach.")
    g = getattr(arbeit(), "FELDGROESSE", None)
    erwarte(isinstance(g, int) and g > 0, "FELDGROESSE ist keine ganze Zahl über 0 -- oben in partie.py.")


def pruefe_20_turm_laeufer():
    """Aufgabe 2 ★ · Turm und Laeufer erben von der Figur und haben ihre eigene passt; das Spiel stellt sie auf"""
    _regel("Turm")
    _regel("Laeufer")
    _im_spiel(["Turm", "Laeufer"])


def pruefe_25_alle():
    """Aufgabe 2 ★★ · Dame, Koenig, Springer und Bauer auch -- jede Figur im Spiel ist ein Objekt ihrer Unterklasse"""
    braucht(_ok(pruefe_20_turm_laeufer), "Erst Turm und Laeufer (Aufgabe 2 ★).")
    for name in ("Dame", "Koenig", "Springer", "Bauer"):
        _regel(name)
    # der schwarze Bauer zieht nach unten
    bauer = _baue("Bauer", "schwarz", 1, 5)
    for ziel, soll in (((2, 5), True), ((3, 5), True), ((0, 5), False)):
        ist = _passt(bauer, ziel)
        erwarte(ist is soll, "Ein schwarzer Bauer auf Zeile 1, Spalte 5: passt(%d, %d) gibt %r statt %r -- Schwarz "
                "zieht nach unten." % (ziel[0], ziel[1], ist, soll))
    _im_spiel(list(KLASSEN))


def pruefe_28_ohne_kette():
    """Aufgabe 2 ★★★ · passt und schlaegt der Figur fragen nicht mehr nach der Art"""
    braucht(_ok(pruefe_25_alle), "Erst alle sechs Unterklassen (Aufgabe 2 ★★).")
    for art in ("Turm", "Dame", "Springer", "Bauer"):
        f = erzeuge(_figur(), art, "weiß", 6, 2)
        ziehen = [z for z in ((6, 7), (4, 4), (4, 1), (5, 2), (5, 3)) if rufe(f, "passt", *z)]
        erwarte(not ziehen, "Eine Figur der Art %s, die keine Unterklasse ist, zieht noch nach %s -- in passt der Figur "
                "steht noch die Frage nach der Art." % (art, ziehen[0] if ziehen else ""))
    f = erzeuge(_figur(), "Bauer", "weiß", 6, 2)
    erwarte(rufe(f, "schlaegt", 5, 3) is False, "Eine Figur der Art Bauer, die keine Unterklasse ist, schlägt noch "
            "schräg -- in schlaegt der Figur steht noch die Frage nach der Art.")
    for farbe, zeile, proben in (("weiß", 6, (((5, 3), True), ((5, 1), True), ((5, 2), False), ((4, 3), False))),
                                 ("schwarz", 1, (((2, 3), True), ((2, 1), True), ((2, 2), False), ((0, 3), False)))):
        bauer = _baue("Bauer", farbe, zeile, 2)
        for ziel, soll in proben:
            ist = rufe(bauer, "schlaegt", *ziel)
            erwarte(ist is soll, "Ein %s Bauer auf Zeile %d, Spalte 2: schlaegt(%d, %d) gibt %r statt %r -- der Bauer "
                    "schlägt schräg nach vorn." % ("weißer" if farbe == "weiß" else "schwarzer", zeile, ziel[0],
                                                   ziel[1], ist, soll))
    turm = _baue("Turm", "weiß", 4, 2)
    erwarte(rufe(turm, "schlaegt", 4, 7) is True, "Ein Turm auf Zeile 4, Spalte 2 schlägt nicht mehr nach (4, 7) -- "
            "geschlagen wird, wie gezogen wird (passt).")


def pruefe_50_wert():
    """Aufgabe 5 ★★ · get_wert steht in den Unterklassen, die Figur selbst ist 0 wert"""
    braucht(_alle_da(), "Erst alle sechs Unterklassen (Aufgabe 2 ★★).")
    f = erzeuge(_figur(), "Dame", "weiß", 4, 2)
    erwarte(rufe(f, "get_wert") == 0, "Eine Figur der Art Dame, die keine Unterklasse ist, ist noch %r wert -- in "
            "get_wert der Figur steht noch die Frage nach der Art." % rufe(f, "get_wert"))
    for name, wert in (("Turm", 5), ("Laeufer", 3), ("Springer", 3), ("Dame", 9), ("Bauer", 1), ("Koenig", 0)):
        obj = _baue(name, "weiß", 4, 2)
        ist = rufe(obj, "get_wert")
        erwarte(ist == wert, "%s ist %r wert statt %r." % (EIN[name], ist, wert))
    s = erzeuge("Spiel")
    ist = rufe(s, "materialwert", "weiß")
    erwarte(ist == 39, "Am Start ist Weiß %r wert statt 39." % (ist,))


def pruefe_55_springt():
    """Aufgabe 5 ★★★ · darf fragt springt, nicht mehr nach der Art Springer"""
    braucht(_alle_da(), "Erst alle sechs Unterklassen (Aufgabe 2 ★★).")
    erwarte(hasattr(_figur(), "springt"), "Die Figur hat noch keine Methode springt.")
    f = erzeuge(_figur(), "Springer", "weiß", 4, 2)
    erwarte(rufe(f, "springt", 2, 3) is False, "Eine Figur, die keine Unterklasse ist, springt -- springt der Figur "
            "sagt False.")
    erwarte(rufe(_baue("Springer", "weiß", 4, 2), "springt", 2, 3) is True, "Ein Springer sagt auf springt(2, 3) "
            "noch nicht True.")
    erwarte(rufe(_baue("Turm", "weiß", 4, 2), "springt", 4, 7) is False, "Ein Turm sagt auf springt(4, 7) True -- er "
            "springt nicht.")
    s = erzeuge("Spiel")
    springer = rufe(s, "figur_auf", 7, 1)
    # Probe: Der Springer heisst fuer einen Moment anders. Fragt darf nach der Art, sucht es einen Weg -- und der ist
    # besetzt (der Bauer auf (6, 2)).
    alt = springer._Figur__art
    springer._Figur__art = "Pferd"
    try:
        ist = rufe(springer, "darf", 5, 2, s)
    finally:
        springer._Figur__art = alt
    erwarte(ist is True, "darf fragt noch nach der Art Springer: Ein Springer, dessen Art anders heißt, springt nicht "
            "mehr über den Bauern. Fragt darf die Figur, ob sie springt?")
    turm = rufe(s, "figur_auf", 7, 0)
    erwarte(rufe(turm, "darf", 5, 0, s) is False, "Der Turm auf (7, 0) darf nach (5, 0) -- über den eigenen Bauern.")


def pruefe_60_kanzler():
    """Aufgabe 6 ★★★ · Der Kanzler zieht wie Turm oder Springer, ohne Code zu kopieren"""
    braucht(_alle_da(), "Erst alle sechs Unterklassen (Aufgabe 2 ★★).")
    # darf muss fragen koennen, ob eine Figur springt -- sonst springt der Kanzler nie (LC3: eigene Voraussetzung)
    braucht(_ok(pruefe_55_springt), "Erst springt (Aufgabe 5 ★★★): Der Kanzler springt nur bei manchen Zügen.")
    m, warum = _laden("kanzler")
    erwarte(m is not None, "kanzler.py lässt sich nicht laden (%s). „Ausführen“ startet partie.py und lädt kanzler.py "
            "nicht -- diesen Fehler zeigt nur der Selbstcheck." % warum)
    k = getattr(m, "Kanzler", None)
    erwarte(isinstance(k, type), "In kanzler.py gibt es noch keine Klasse Kanzler.")
    erwarte(issubclass(k, _figur()), "Der Kanzler ist noch keine Figur -- wovon erbt er?")
    kanzler = erzeuge(k, "weiß", 4, 2)
    erwarte(rufe(kanzler, "get_art") == "Kanzler" and rufe(kanzler, "get_zeile") == 4,
            "Kanzler('weiß', 4, 2) nennt nicht die Art 'Kanzler' und Zeile 4.")
    for ziel, soll in (((4, 7), True), ((0, 2), True), ((2, 3), True), ((5, 4), True), ((2, 4), False),
                       ((3, 3), False), ((6, 5), False)):
        ist = _passt(kanzler, ziel)
        erwarte(ist is soll, "Ein Kanzler auf Zeile 4, Spalte 2: passt(%d, %d) gibt %r statt %r." % (ziel[0], ziel[1],
                                                                                                ist, soll))
    # die Auflage: Aendert sich die Regel von Turm und Springer, aendert sich der Kanzler mit
    turm, springer = klasse("Turm"), klasse("Springer")
    alt = {c: c.__dict__.get("passt") for c in (turm, springer)}
    try:
        turm.passt = lambda self_, z, s: False
        springer.passt = lambda self_, z, s: False
        nie = _passt(kanzler, (4, 7)) or _passt(kanzler, (2, 3))
        turm.passt = lambda self_, z, s: True
        immer = _passt(kanzler, (3, 3))
    finally:
        for c, m in alt.items():
            if m is None:
                del c.passt
            else:
                c.passt = m
    erwarte(not nie and immer, "Der Kanzler zieht richtig -- aber er hat eine Regel abgeschrieben: Ändert sich die "
            "Regel des Turms oder des Springers, zieht er weiter wie vorher. Die Auflage: fragen statt kopieren.")
    # am Brett: als Springer springt er, als Turm nicht
    s = erzeuge("Spiel")
    feld = attribute(s).get("__feld")
    erwarte(isinstance(feld, list), "Das Spiel hat kein Spielfeld self.__feld mehr.")
    k2 = erzeuge(k, "weiß", 5, 3)
    feld[5][3] = k2
    try:
        sprung = rufe(k2, "darf", 3, 2, s)
        gerade = rufe(k2, "darf", 2, 3, s)
        versperrt = rufe(k2, "darf", 0, 3, s)
    finally:
        feld[5][3] = None
    erwarte(sprung is True, "Ein Kanzler auf (5, 3) darf nicht wie ein Springer nach (3, 2) -- darf sucht für ihn "
            "einen Weg. Springt er bei diesem Zug?")
    erwarte(gerade is True, "Ein Kanzler auf (5, 3) darf nicht nach (2, 3), obwohl der Weg frei ist.")
    erwarte(versperrt is False, "Ein Kanzler auf (5, 3) darf nach (0, 3) -- über den schwarzen Bauern. Wie ein Turm "
            "springt er nicht.")


def pruefe_90_hints():
    """Hinweis · Jede Methode der Unterklassen mit Type Hints (kein Stern)"""
    braucht(_ok(pruefe_20_turm_laeufer), "Erst Turm und Laeufer.")
    ohne, diagramm = [], []
    try:
        baum = ast.parse(quelltext("figur.py"))
    except (SyntaxError, OSError, TypeError):
        return
    for klasse_ in (k for k in baum.body if isinstance(k, ast.ClassDef) and k.name != "Figur"):
        for k in (f for f in klasse_.body if isinstance(f, ast.FunctionDef)):
            for a in k.args.args + [k]:
                typ = a.annotation if isinstance(a, ast.arg) else a.returns
                if typ is not None and any(isinstance(x, ast.Name) and x.id in DIAGRAMMTYPEN for x in ast.walk(typ)):
                    diagramm.append("%s.%s (%s)" % (klasse_.name, k.name, ast.unparse(typ)))
            parameter = [a for a in k.args.args if a.arg != "self"]
            if any(a.annotation is None for a in parameter) or (k.returns is None and k.name != "__init__"):
                ohne.append("%s.%s" % (klasse_.name, k.name))
    erwarte(not diagramm, "Hier steht ein Typ in der Schreibweise des Diagramms: %s. In Python heißt er str, int, "
            "float oder bool." % ", ".join(diagramm))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer oder an einem Parameter): %s. Es läuft auch ohne; "
            "vereinbart ist es trotzdem." % ", ".join(ohne))
