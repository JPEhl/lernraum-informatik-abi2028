# kanzler.py -- Expertenaufgabe 6: Der
# Kanzler zieht wie ein Turm oder wie ein
# Springer. Das Spiel stellt ihn nicht
# auf; der Selbstcheck baut ihn sich.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from figur import Figur


# Hier steht eure Klasse Kanzler.
