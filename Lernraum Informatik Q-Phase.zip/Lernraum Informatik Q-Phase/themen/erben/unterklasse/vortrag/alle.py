# alle.py -- Turm, Läufer und Springer
# als Unterklassen. Die Figur selbst
# zieht nirgendwohin.


class Figur:

    def __init__(self, art: str, farbe: str, zeile: int, spalte: int):
        self.__art = art
        self.__farbe = farbe
        self.__zeile = zeile
        self.__spalte = spalte

    def get_art(self) -> str:
        return self.__art

    def get_zeile(self) -> int:
        return self.__zeile

    def get_spalte(self) -> int:
        return self.__spalte

    def passt(self, zeile: int, spalte: int) -> bool:
        return False


class Turm(Figur):

    def __init__(self, farbe: str, zeile: int, spalte: int):
        super().__init__("Turm", farbe, zeile, spalte)

    def passt(self, zeile: int, spalte: int) -> bool:
        hoch = abs(zeile - self.get_zeile())
        quer = abs(spalte - self.get_spalte())
        return hoch == 0 or quer == 0


class Laeufer(Figur):

    def __init__(self, farbe: str, zeile: int, spalte: int):
        super().__init__("Läufer", farbe, zeile, spalte)

    def passt(self, zeile: int, spalte: int) -> bool:
        hoch = abs(zeile - self.get_zeile())
        quer = abs(spalte - self.get_spalte())
        return hoch == quer


class Springer(Figur):

    def __init__(self, farbe: str, zeile: int, spalte: int):
        super().__init__("Springer", farbe, zeile, spalte)

    def passt(self, zeile: int, spalte: int) -> bool:
        hoch = abs(zeile - self.get_zeile())
        quer = abs(spalte - self.get_spalte())
        return hoch * quer == 2
