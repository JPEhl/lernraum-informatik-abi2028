# kette.py -- eine kleine Figur, gebaut
# wie in figur.py: passt fragt zuerst
# nach der Art.


class Figur:

    def __init__(self, art: str, farbe: str, zeile: int, spalte: int):
        self.__art = art
        self.__farbe = farbe
        self.__zeile = zeile
        self.__spalte = spalte

    def get_art(self) -> str:
        return self.__art

    def get_zeile(self) -> int:
        return self.__zeile

    def get_spalte(self) -> int:
        return self.__spalte

    def passt(self, zeile: int, spalte: int) -> bool:
        hoch = abs(zeile - self.__zeile)
        quer = abs(spalte - self.__spalte)
        if self.__art == "Läufer":
            return hoch == quer
        elif self.__art == "Turm":
            return hoch == 0 or quer == 0
        elif self.__art == "Springer":
            return hoch * quer == 2
        elif self.__art == "Kanzler":
            wie_turm = hoch == 0 or quer == 0
            return wie_turm or hoch * quer == 2
        else:
            return False


turm = Figur("Turm", "weiß", 7, 0)
springer = Figur("Springer", "weiß", 7, 1)
print(turm.passt(3, 0))
print(springer.passt(5, 2))
kanzler = Figur("Kanzler", "weiß", 4, 4)
print(kanzler.passt(2, 3))
