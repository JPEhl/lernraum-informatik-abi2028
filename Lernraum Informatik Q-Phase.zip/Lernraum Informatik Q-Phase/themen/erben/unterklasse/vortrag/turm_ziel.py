# turm.py -- die kleine Figur aus
# kette.py, ohne den Kanzler. Der Turm
# bekommt seine eigene Klasse.


class Figur:

    def __init__(self, art: str, farbe: str, zeile: int, spalte: int):
        self.__art = art
        self.__farbe = farbe
        self.__zeile = zeile
        self.__spalte = spalte

    def get_art(self) -> str:
        return self.__art

    def get_zeile(self) -> int:
        return self.__zeile

    def get_spalte(self) -> int:
        return self.__spalte

    def passt(self, zeile: int, spalte: int) -> bool:
        hoch = abs(zeile - self.__zeile)
        quer = abs(spalte - self.__spalte)
        if self.__art == "Läufer":
            return hoch == quer
        elif self.__art == "Springer":
            return hoch * quer == 2
        else:
            return False


class Turm(Figur):

    def __init__(self, farbe: str, zeile: int, spalte: int):
        super().__init__("Turm", farbe, zeile, spalte)

    def passt(self, zeile: int, spalte: int) -> bool:
        hoch = abs(zeile - self.get_zeile())
        quer = abs(spalte - self.get_spalte())
        return hoch == 0 or quer == 0


turm = Turm("weiß", 7, 0)
springer = Figur("Springer", "weiß", 7, 1)
print(turm.get_art(), turm.get_zeile())
print(turm.passt(3, 0))
print(springer.passt(5, 2))
