"""Selbstcheck „Stapel und verkettete Liste“ -- prueft das Programm im Ordner schach/ (es laeuft partie.py).

Der Stapel wird ueber OBJEKTE geprueft, die der Check selbst baut (LC8): erzeuge, rufe, attribute. Was er auflegt, sind
Texte ("a", "b", …) -- ein Element haelt, was es bekommt; fuer hat_gezogen baut er echte Figuren und Zuege. Das Brett
liest er wie ein Mensch (LC6) an FRISCHEN Laeufen, auf denen er klickt wie die Maus (klick_auf), auch auf die Leiste.

Fallen (LC5): peek gibt das Element statt des Zugs zurueck -- deshalb `is` gegen das, was aufgelegt wurde. peek nimmt
weg wie pop -- deshalb zweimal peek. pop am leeren Stapel stuerzt ab -- deshalb dreimal auflegen, viermal pop. Eine
Python-Liste statt der Kette besteht das Verhalten -- deshalb eine eigene Pruefung der Kette (Aufgabe 2 ★, nach dem
Verhalten). anzahl schiebt self.__oberstes weiter (stimmt einmal, danach ist der Stapel leer) -- deshalb zweimal anzahl
und danach peek. hat_gezogen vergleicht die Art statt der Figur -- deshalb ein zweiter Turm derselben Farbe; `else:
return False` in der Schleife -- deshalb liegt der gesuchte Zug UNTEN. Zurueck: push vergessen -- das Brett aendert
sich nicht; der alte Pfeil bleibt -- deshalb die Pfeile nach jedem Zurueck. Warteschlange: vorn statt hinten angestellt
-- deshalb drei anstellen und den ersten fragen; letztes nach dem Leeren nicht zurueckgesetzt -- deshalb leeren und neu
anstellen. Verlauf: ein neuer Zug leert den zweiten Stapel nicht -- deshalb nach dem Wiederholen ein neuer Zug.

Startzustand (Arbeitsordner, vorbereitet): partie.py laeuft und zeigt das Brett mit der Leiste „Zug zurück“, ein Klick
darauf tut nichts; jeder Rumpf im Stapel ist pass. Offen ist genau Aufgabe 2 ★ (pruefe_20_stapel), alles andere wartet
(LC1). Mehr 6 und Expertenaufgabe 7 warten, bis in ihrer Datei ein Rumpf nicht mehr pass ist.
"""
import ast
import importlib
import sys

import pruefen
from pruefen import erwarte, braucht, arbeit, flaeche, quelltext, anspielen, erzeuge, rufe, attribute, klasse, \
    klick_auf

TITEL = "Stapel und verkettete Liste · Selbstcheck"
EINGABEN = []
HINTS = {"push": {"None"}, "pop": {"Zug"}, "peek": {"Zug"}, "ist_leer": {"bool"}, "anzahl": {"int"},
         "hat_gezogen": {"bool"}, "get_zug": {"Zug"}, "get_naechstes": {"Element"}, "set_naechstes": {"None"}}
DIAGRAMMTYPEN = {"String", "integer", "boolean", "Integer", "Boolean"}
BLAU = "#1565c0"


def _ok(pruefung):
    try:
        pruefung()
    except AssertionError:
        return False
    return True


def _modul(name):
    m = sys.modules.get(name)
    if m is not None:
        return m
    try:
        return importlib.import_module(name)
    except Exception:  # noqa: BLE001 -- dann gibt es das Modul fuer den Check nicht
        return None


def _stapelklasse():
    k = klasse("Stapel")
    if k is None:
        k = getattr(_modul("stapel"), "Stapel", None)
    return k if isinstance(k, type) else None


def _stapel():
    return erzeuge(_stapelklasse())


def _hat(objekt, methode):
    return callable(getattr(objekt, methode, None))


def _unberuehrt(datei, klassenname):
    """Steht in der Klasse jeder Rumpf noch auf pass (bis auf __init__)? Dann ist die Aufgabe nicht angefangen."""
    try:
        baum = ast.parse(quelltext(datei))
    except (SyntaxError, OSError, TypeError):
        return False
    for k in ast.walk(baum):
        if isinstance(k, ast.ClassDef) and k.name == klassenname:
            for f in k.body:
                if isinstance(f, ast.FunctionDef) and f.name != "__init__":
                    if not (len(f.body) == 1 and isinstance(f.body[0], ast.Pass)):
                        return False
            if klassenname == "Verlauf":
                init = [f for f in k.body if isinstance(f, ast.FunctionDef) and f.name == "__init__"]
                if init and not (len(init[0].body) == 1 and isinstance(init[0].body[0], ast.Pass)):
                    return False
            return True
    return False


def _stapel_ok():
    return _stapelklasse() is not None and _ok(pruefe_20_stapel) and _ok(pruefe_22_pop) and _ok(pruefe_24_kette)


# ── das Brett: frische Laeufe, Klicks wie mit der Maus ───────────────────────────────────────────────────────────────

def _lauf():
    """partie.py noch einmal, frisch. Gibt (Flaeche, Feldgroesse, Namensraum) -- die Flaeche ist None, wenn das
    Programm nicht bis zum Ende lief."""
    alt_q = pruefen._QUELLE
    pruefen._QUELLE = alt_q + "\nprint('--ENDE--')\n"
    try:
        aus, ns = anspielen([])
    finally:
        pruefen._QUELLE = alt_q
    return (ns.get("flaeche") if "--ENDE--" in aus else None), ns.get("FELDGROESSE"), ns


def _klick(c, x, y, wo):
    alt = pruefen._FENSTER
    pruefen._FENSTER = c.winfo_toplevel()
    try:
        return klick_auf(x, y, wo=wo)
    finally:
        pruefen._FENSTER = alt


def _feld(c, g, feld):
    return _klick(c, feld[1] * g + g // 2, feld[0] * g + g // 2, "Zeile %d, Spalte %d" % feld)


def _zug(c, g, von, nach):
    _feld(c, g, von)
    _feld(c, g, nach)


def _leiste(c, g):
    return _klick(c, 4 * g, 8 * g + 15, "die Leiste „Zug zurück“")


def _was(spiel, feld):
    f = rufe(spiel, "figur_auf", *feld)
    return None if f is None else (rufe(f, "get_art"), rufe(f, "get_farbe"))


def _pfeile(c):
    return [tuple(int(v) for v in c.coords(i)) for i in c.find_all()
            if c.type(i) == "line" and c.itemcget(i, "fill") == BLAU]


# ── die Pruefungen ───────────────────────────────────────────────────────────────────────────────────────────────────

def pruefe_00_grundlage():
    """Grundlage · stapel.py lädt, das Programm hat eine Zeichenfläche"""
    erwarte(_stapelklasse() is not None, "In stapel.py steht keine Klasse Stapel -- oder stapel.py lässt sich nicht "
            "laden. Seht in der Shell nach.")
    erwarte(klasse("Element") is not None or getattr(_modul("stapel"), "Element", None) is not None,
            "In stapel.py steht keine Klasse Element mehr -- seht in der Shell nach.")
    erwarte(flaeche() is not None, "Das Programm bricht ab, bevor es eine Zeichenfläche hat -- seht in der Shell nach.")
    g = getattr(arbeit(), "FELDGROESSE", None)
    erwarte(isinstance(g, int) and g > 0, "FELDGROESSE ist keine ganze Zahl über 0 -- oben in partie.py.")


def pruefe_20_stapel():
    """Aufgabe 2 · Der Stapel: ist_leer, push und peek"""
    s = _stapel()
    leer = rufe(s, "ist_leer")
    erwarte(leer is True, "Ein neuer Stapel sagt bei ist_leer() noch nicht True, sondern %r." % (leer,))
    erwarte(rufe(s, "peek") is None, "peek() an einem leeren Stapel gibt nicht None zurück.")
    rufe(s, "push", "a")
    oben = rufe(s, "peek")
    erwarte(oben == "a", "Nach push(\"a\") gibt peek() nicht \"a\" zurück, sondern %s -- peek gibt den Zug, der oben "
            "liegt, nicht sein Element." % (type(oben).__name__ if oben is not None else "None"))
    erwarte(rufe(s, "ist_leer") is False, "Nach einem push sagt ist_leer() noch nicht False.")
    rufe(s, "push", "b")
    erwarte(rufe(s, "peek") == "b", "Nach push(\"a\") und push(\"b\") gibt peek() nicht \"b\" zurück -- oben liegt, "
            "was zuletzt kam.")
    erwarte(rufe(s, "peek") == "b", "Ein zweites peek() gibt nicht mehr \"b\" zurück -- peek schaut nur nach, es nimmt "
            "nichts weg.")


def pruefe_22_pop():
    """Aufgabe 2 · pop gibt in umgekehrter Folge zurück, am leeren Stapel None"""
    braucht(_ok(pruefe_20_stapel), "Erst push, peek und ist_leer.")
    s = _stapel()
    for t in ("a", "b", "c"):
        rufe(s, "push", t)
    folge = [rufe(s, "pop") for _ in range(3)]
    erwarte(folge == ["c", "b", "a"], "Nach push von \"a\", \"b\", \"c\" geben drei pop() %s zurück statt \"c\", \"b\", "
            "\"a\"." % ", ".join(repr(x) for x in folge))
    erwarte(rufe(s, "ist_leer") is True, "Nach drei push und drei pop sagt ist_leer() nicht True.")
    erwarte(rufe(s, "pop") is None, "pop() am leeren Stapel gibt nicht None zurück.")
    rufe(s, "push", "d")
    erwarte(rufe(s, "peek") == "d", "Ein Stapel, der einmal leer war, nimmt nichts Neues mehr an: Nach push(\"d\") "
            "gibt peek() nicht \"d\" zurück.")


def pruefe_24_kette():
    """Aufgabe 2 · Der Stapel ist eine Kette aus Elementen"""
    braucht(_ok(pruefe_20_stapel) and _ok(pruefe_22_pop), "Erst push, peek, ist_leer und pop.")
    s = _stapel()
    rufe(s, "push", "a")
    rufe(s, "push", "b")
    a = attribute(s)
    listen = [n for n, w in a.items() if isinstance(w, list)]
    erwarte(not listen, "Im Stapel steht eine Python-Liste (self.%s). Gebaut wird er als Kette: Er kennt nur sein "
            "oberstes Element." % (listen[0] if listen else ""))
    erwarte("__oberstes" in a.privat, "Der Stapel hat kein privates Attribut oberstes mehr -- wie im Klassendiagramm: "
            "self.__oberstes.")
    oben = a["__oberstes"]
    erwarte(type(oben).__name__ == "Element", "Nach zwei push steht in self.__oberstes kein Element, sondern %r." % (oben,))
    innen = attribute(oben)
    erwarte(innen.get("__zug") == "b", "Das oberste Element hält nach push(\"a\") und push(\"b\") nicht \"b\".")
    darunter = innen.get("__naechstes")
    erwarte(type(darunter).__name__ == "Element" and attribute(darunter).get("__zug") == "a",
            "Das oberste Element zeigt mit naechstes nicht auf das Element, das vorher oben lag.")
    erwarte(attribute(darunter).get("__naechstes") is None, "Das unterste Element zeigt mit naechstes nicht auf None.")


def pruefe_30_zurueck():
    """Aufgabe 2 ★★ · Zug zurück: Klick für Klick, bis zum Anfang"""
    braucht(_stapel_ok(), "Erst der Stapel (Aufgabe 2 ★).")
    c, g, ns = _lauf()
    erwarte(c is not None and isinstance(g, int), "partie.py läuft nicht bis zum Ende -- seht in der Shell nach.")
    spiel = ns.get("spiel")
    erwarte(spiel is not None, "In partie.py gibt es kein Spiel mehr (spiel = Spiel()).")
    _zug(c, g, (6, 4), (4, 4))
    _zug(c, g, (1, 3), (2, 3))
    erwarte(_was(spiel, (2, 3)) == ("Bauer", "schwarz"), "Die zwei Züge zum Probieren (weißer Bauer zwei vor, schwarzer "
            "Bauer eins vor) gelingen nicht mehr -- seht in der Shell nach.")
    _leiste(c, g)
    erwarte(_was(spiel, (1, 3)) == ("Bauer", "schwarz") and _was(spiel, (2, 3)) is None,
            "Nach zwei Zügen und einem Klick auf „Zug zurück“ steht der schwarze Bauer nicht wieder auf seinem "
            "Startfeld (Zeile 1, Spalte 3) -- der Klick ändert am Brett noch nichts.")
    erwarte(_was(spiel, (4, 4)) == ("Bauer", "weiß"), "Ein Klick auf „Zug zurück“ hat mehr als einen Zug zurückgenommen.")
    pfeile = _pfeile(c)
    soll = (4 * g + g // 2, 6 * g + g // 2, 4 * g + g // 2, 4 * g + g // 2)
    erwarte(pfeile == [soll], "Nach dem Zurück zeigt der blaue Pfeil nicht den Zug, der jetzt oben liegt (den Zug des "
            "weißen Bauern) -- zu sehen sind %d blaue Pfeile." % len(pfeile))
    _leiste(c, g)
    erwarte(_was(spiel, (6, 4)) == ("Bauer", "weiß") and _was(spiel, (4, 4)) is None,
            "Der zweite Klick auf „Zug zurück“ stellt den weißen Bauern nicht wieder auf sein Startfeld.")
    erwarte(not _pfeile(c), "Nach dem letzten Zurück ist kein Zug mehr übrig -- es steht aber noch ein blauer Pfeil.")
    _leiste(c, g)
    _zug(c, g, (6, 4), (4, 4))
    erwarte(_was(spiel, (4, 4)) == ("Bauer", "weiß"), "Nach dem Zurücknehmen bis zum Anfang (und einem Klick mehr) "
            "lässt sich nicht weiterspielen.")


def pruefe_40_anzahl():
    """Aufgabe 3 · anzahl() zählt die Züge und lässt den Stapel, wie er ist"""
    braucht(_stapel_ok(), "Erst der Stapel (Aufgabe 2 ★).")
    s = _stapel()
    erwarte(_hat(s, "anzahl"), "Im Stapel gibt es noch keine Methode anzahl().")
    erwarte(rufe(s, "anzahl") == 0, "anzahl() an einem leeren Stapel gibt nicht 0 zurück.")
    for t in ("a", "b", "c"):
        rufe(s, "push", t)
    erste = rufe(s, "anzahl")
    erwarte(erste == 3, "Nach drei push gibt anzahl() %r zurück statt 3." % (erste,))
    zweite = rufe(s, "anzahl")
    oben = rufe(s, "peek")
    erwarte(zweite == 3 and oben == "c", "Ein zweites anzahl() gibt %r zurück, und oben liegt %r -- nach dem Zählen "
            "liegt nicht mehr alles im Stapel." % (zweite, oben))
    rufe(s, "pop")
    erwarte(rufe(s, "anzahl") == 2, "Nach einem pop gibt anzahl() nicht 2 zurück.")


def pruefe_42_hat_gezogen():
    """Aufgabe 3 ★★ · hat_gezogen(figur) findet genau diese Figur, auch unten"""
    braucht(_stapel_ok(), "Erst der Stapel (Aufgabe 2 ★).")
    s = _stapel()
    erwarte(_hat(s, "hat_gezogen"), "Im Stapel gibt es noch keine Methode hat_gezogen(figur).")
    turm = erzeuge("Figur", "Turm", "weiß", 7, 0)
    anderer = erzeuge("Figur", "Turm", "weiß", 7, 7)
    dame = erzeuge("Figur", "Dame", "weiß", 7, 3)
    laeufer = erzeuge("Figur", "Läufer", "weiß", 7, 2)
    erwarte(rufe(s, "hat_gezogen", turm) is False, "An einem leeren Stapel sagt hat_gezogen nicht False.")
    turmzug, damenzug = erzeuge("Zug", turm, 5, 0), erzeuge("Zug", dame, 4, 3)
    rufe(s, "push", turmzug)
    rufe(s, "push", damenzug)
    erwarte(rufe(s, "hat_gezogen", turm) is True, "Der Zug des Turms liegt unten im Stapel -- hat_gezogen(turm) sagt "
            "aber nicht True.")
    erwarte(rufe(s, "hat_gezogen", dame) is True, "Der Zug der Dame liegt oben -- hat_gezogen(dame) sagt nicht True.")
    erwarte(rufe(s, "hat_gezogen", anderer) is False, "Ein anderer weißer Turm hat nicht gezogen -- hat_gezogen sagt "
            "für ihn aber nicht False. Gefragt ist genau diese Figur, nicht eine derselben Art.")
    erwarte(rufe(s, "hat_gezogen", laeufer) is False, "Der Läufer hat nicht gezogen -- hat_gezogen sagt nicht False.")
    erwarte(rufe(s, "pop") is damenzug and rufe(s, "pop") is turmzug, "Nach hat_gezogen liegen nicht mehr beide Züge "
            "im Stapel.")


def pruefe_60_warteschlange():
    """Aufgabe 6 ★★ · Warteschlange: anstellen und den Ersten nennen"""
    braucht(not _unberuehrt("warteschlange.py", "Warteschlange"), "Aufgabe 6 ist noch nicht angefangen.")
    k = getattr(_modul("warteschlange"), "Warteschlange", None)
    erwarte(isinstance(k, type), "In warteschlange.py steht keine Klasse Warteschlange -- oder die Datei lässt sich "
            "nicht laden. Seht in der Shell nach.")
    w = erzeuge(k)
    erwarte(rufe(w, "ist_leer") is True, "Eine neue Warteschlange sagt bei ist_leer() nicht True.")
    erwarte(rufe(w, "erstes_element") is None, "erstes_element() an einer leeren Schlange gibt nicht None zurück.")
    for n in ("Ines", "Tarek", "Mila"):
        rufe(w, "einfuegen", n)
    erste = rufe(w, "erstes_element")
    erwarte(erste == "Ines", "Ines, Tarek und Mila stellen sich an -- erstes_element() nennt %r statt Ines." % (erste,))
    erwarte(rufe(w, "ist_leer") is False, "Mit drei Namen sagt ist_leer() nicht False.")
    a = attribute(w)
    erwarte(not [x for x in a.values() if isinstance(x, list)], "In der Warteschlange steht eine Python-Liste -- "
            "gebaut wird sie als Kette aus Plätzen.")


def pruefe_62_loeschen():
    """Aufgabe 6 ★★★ · Der Erste darf ans Brett -- auch nach einer leeren Schlange"""
    braucht(_ok(pruefe_60_warteschlange), "Erst anstellen und den Ersten nennen.")
    w = erzeuge(getattr(_modul("warteschlange"), "Warteschlange"))
    for n in ("Ines", "Tarek", "Mila"):
        rufe(w, "einfuegen", n)
    rufe(w, "erstes_loeschen")
    erwarte(rufe(w, "erstes_element") == "Tarek", "Nach einem erstes_loeschen() ist Tarek nicht der Erste.")
    rufe(w, "erstes_loeschen")
    rufe(w, "erstes_loeschen")
    erwarte(rufe(w, "ist_leer") is True, "Drei anstellen, dreimal löschen -- ist_leer() sagt nicht True.")
    rufe(w, "erstes_loeschen")
    rufe(w, "einfuegen", "Jonte")
    rufe(w, "einfuegen", "Pia")
    erste = rufe(w, "erstes_element")
    erwarte(erste == "Jonte", "Nach dem Leeren stellen sich Jonte und Pia an -- erstes_element() nennt %r statt Jonte."
            % (erste,))
    rufe(w, "erstes_loeschen")
    erwarte(rufe(w, "erstes_element") == "Pia", "Nach dem Leeren, zwei Namen und einem Löschen ist Pia nicht die Erste.")


def pruefe_70_verlauf():
    """Aufgabe 7 ★★★ · Zug zurück und wieder vor -- nur mit Stapeln"""
    braucht(not _unberuehrt("verlauf.py", "Verlauf"), "Die Expertenaufgabe ist noch nicht angefangen.")
    braucht(_stapel_ok(), "Erst der Stapel (Aufgabe 2 ★).")
    k = getattr(_modul("verlauf"), "Verlauf", None)
    erwarte(isinstance(k, type), "In verlauf.py steht keine Klasse Verlauf -- oder die Datei lässt sich nicht laden.")
    try:
        baum = ast.parse(quelltext("verlauf.py"))
    except (SyntaxError, OSError, TypeError):
        baum = ast.parse("")
    liste = any(isinstance(n, (ast.List, ast.ListComp)) or (isinstance(n, ast.Call) and isinstance(n.func, ast.Name)
                                                             and n.func.id == "list") for n in ast.walk(baum))
    erwarte(not liste, "Die Auflage: keine Liste in verlauf.py -- nur Stapel.")
    v = erzeuge(k)
    fremd = [n for n, w in attribute(v).items() if type(w).__name__ != "Stapel"]
    erwarte(not fremd, "Die Auflage: Der Verlauf hält nur Stapel -- self.%s ist keiner." % (fremd[0] if fremd else ""))
    for t in ("a", "b", "c"):
        rufe(v, "gezogen", t)
    folge = [rufe(v, "zuruecknehmen"), rufe(v, "zuruecknehmen"), rufe(v, "wiederholen"), rufe(v, "wiederholen"),
             rufe(v, "wiederholen")]
    erwarte(folge == ["c", "b", "b", "c", None], "a, b, c gezogen; zweimal zurück, dreimal wiederholen -- zurück kommt "
            "%s statt c, b, b, c, None." % ", ".join(repr(x) for x in folge))
    rufe(v, "zuruecknehmen")
    rufe(v, "gezogen", "d")
    nach_neu = rufe(v, "wiederholen")
    erwarte(nach_neu is None, "Nach einem neuen Zug lässt sich %r noch wiederholen -- ein neuer Zug löscht, was sich "
            "wiederholen ließe." % (nach_neu,))
    rest = [rufe(v, "zuruecknehmen") for _ in range(4)]
    erwarte(rest == ["d", "b", "a", None], "Danach kommt beim Zurücknehmen %s statt d, b, a, None."
            % ", ".join(repr(x) for x in rest))


def pruefe_90_hints():
    """Hinweis · Jede Methode in stapel.py mit Type Hints (kein Stern)"""
    braucht(_stapel_ok(), "Erst der Stapel (Aufgabe 2 ★).")
    ohne, falsch, diagramm = [], [], []
    try:
        baum = ast.parse(quelltext("stapel.py"))
    except (SyntaxError, OSError, TypeError):
        return
    for k in ast.walk(baum):
        if not isinstance(k, ast.FunctionDef):
            continue
        for a in k.args.args + [k]:
            typ = a.annotation if isinstance(a, ast.arg) else a.returns
            if typ is not None and any(isinstance(x, ast.Name) and x.id in DIAGRAMMTYPEN for x in ast.walk(typ)):
                diagramm.append("%s (%s)" % (k.name, ast.unparse(typ)))
        parameter = [a for a in k.args.args if a.arg != "self"]
        if any(a.annotation is None for a in parameter) or (k.returns is None and k.name != "__init__"):
            ohne.append(k.name)
        elif k.name in HINTS and ast.unparse(k.returns).replace(" ", "") not in HINTS[k.name]:
            falsch.append("%s -> %s" % (k.name, " oder ".join(sorted(HINTS[k.name]))))
    erwarte(not diagramm, "Hier steht ein Typ in der Schreibweise des Diagramms: %s. In Python heißt er str, int, "
            "float oder bool." % ", ".join(diagramm))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer oder an einem Parameter): %s. Es läuft auch ohne; "
            "vereinbart ist es trotzdem." % ", ".join(ohne))
    erwarte(not falsch, "Dieser Type Hint passt nicht zu dem, was zurückkommt -- erwartet: %s." % ", ".join(falsch))
