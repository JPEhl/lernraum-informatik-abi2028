# stapel.py -- die gespielten Züge als
# Stapel: eine Kette aus Elementen. Ein
# Element hält einen Zug und kennt das
# nächste darunter, der Stapel nur das
# oberste. Element ist fertig; im Stapel
# stehen die Köpfe nach dem Diagramm.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from zug import Zug


class Element:

    def __init__(self, zug: Zug):
        self.__zug = zug
        self.__naechstes: Element = None

    def get_zug(self) -> Zug:
        return self.__zug

    def get_naechstes(self) -> Element:
        return self.__naechstes

    def set_naechstes(self, naechstes: Element) -> None:
        self.__naechstes = naechstes


class Stapel:

    def __init__(self):
        self.__oberstes: Element = None

    def push(self, zug: Zug) -> None:
        pass

    def pop(self) -> Zug:
        pass

    def peek(self) -> Zug:
        pass

    def ist_leer(self) -> bool:
        pass
