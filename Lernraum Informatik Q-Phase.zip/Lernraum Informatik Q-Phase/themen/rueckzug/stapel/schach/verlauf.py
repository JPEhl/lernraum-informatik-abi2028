# verlauf.py -- für Expert*innen, Aufgabe
# 7: Zug zurück UND Zug wieder vor. Steht
# in keinem Stand. Die Auflage: keine
# Liste -- nur Stapel aus stapel.py.

from stapel import Stapel
from zug import Zug


class Verlauf:

    def __init__(self):
        pass

    def gezogen(self, zug: Zug) -> None:
        pass

    def zuruecknehmen(self) -> Zug:
        pass

    def wiederholen(self) -> Zug:
        pass
