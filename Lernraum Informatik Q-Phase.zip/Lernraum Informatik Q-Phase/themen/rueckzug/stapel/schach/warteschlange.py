# warteschlange.py -- Mehr, Aufgabe 6:
# Wer als Nächstes ans Brett darf. Eine
# Kette aus Plätzen: Jeder Platz hält einen
# Namen und kennt den Platz dahinter.
# Steht in keinem Stand.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations


class Platz:

    def __init__(self, name: str):
        self.__name = name
        self.__naechster: Platz = None

    def get_name(self) -> str:
        return self.__name

    def get_naechster(self) -> Platz:
        return self.__naechster

    def set_naechster(self, naechster: Platz) -> None:
        self.__naechster = naechster


class Warteschlange:

    def __init__(self):
        self.__erstes: Platz = None
        self.__letztes: Platz = None

    def ist_leer(self) -> bool:
        pass

    def einfuegen(self, name: str) -> None:
        pass

    def erstes_element(self) -> str:
        pass

    def erstes_loeschen(self) -> None:
        pass
