# stapel.py -- die gespielten Züge als
# Stapel: eine Kette aus Elementen.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from figur import Figur
from zug import Zug


class Element:

    def __init__(self, zug: Zug):
        self.__zug = zug
        self.__naechstes: Element = None

    def get_zug(self) -> Zug:
        return self.__zug

    def get_naechstes(self) -> Element:
        return self.__naechstes

    def set_naechstes(self, naechstes: Element) -> None:
        self.__naechstes = naechstes
