# stapel.py -- die gespielten Züge als
# Stapel: eine Kette aus Elementen.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from figur import Figur
from zug import Zug


class Element:

    def __init__(self, zug: Zug):
        self.__zug = zug
        self.__naechstes: Element = None

    def get_zug(self) -> Zug:
        return self.__zug

    def get_naechstes(self) -> Element:
        return self.__naechstes

    def set_naechstes(self, naechstes: Element) -> None:
        self.__naechstes = naechstes


class Stapel:

    def __init__(self):
        self.__oberstes: Element = None

    def push(self, zug: Zug) -> None:
        neues = Element(zug)
        neues.set_naechstes(self.__oberstes)
        self.__oberstes = neues

    def pop(self) -> Zug:
        if self.__oberstes == None:
            return None
        zug = self.__oberstes.get_zug()
        self.__oberstes = self.__oberstes.get_naechstes()
        return zug


bauer = Figur("Bauer", "weiß", 6, 4)
dame = Figur("Dame", "weiß", 7, 3)
gespielt = Stapel()
gespielt.push(Zug(bauer, 4, 4))
gespielt.push(Zug(dame, 4, 6))
zug = gespielt.pop()
print(zug.get_figur().get_art())
zug = gespielt.pop()
print(zug.get_figur().get_art())
print(gespielt.pop())
