# mitglied.py -- gegeben: ein Mitglied des
# Schachportals mit Name und Wertung.
# Hier stehen Mitglieder, die schon
# gespielt haben -- ihre Wertung gibt
# man beim Bauen mit.
# Lesen dürft ihr, ändern nicht.


class Mitglied:

    def __init__(self, name: str, wertung: int):
        self.__name = name
        self.__wertung = wertung

    def get_name(self) -> str:
        return self.__name

    def get_wertung(self) -> int:
        return self.__wertung
