# figur.py -- die Klasse Figur.
# Hier schreibt ihr sie, nach ihrem
# Klassendiagramm (Aufgabe 2 und 3).

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
