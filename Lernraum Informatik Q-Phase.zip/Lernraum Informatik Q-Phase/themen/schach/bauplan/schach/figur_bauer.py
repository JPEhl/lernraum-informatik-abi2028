# figur_bauer.py -- Expertenaufgabe: die
# Klasse Figur mit dem Bauern. Kopiert
# eure Klasse aus figur.py hierher.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
