# figur.py -- gegeben: die Klasse Figur.
# Ihr benutzt sie, ohne hineinzusehen.
# Was sie weiß und kann, steht in der
# Erklärung.


class Figur:

    def __init__(self, art: str, farbe: str, zeile: int, spalte: int):
        self.art = art
        self.farbe = farbe
        self.zeile = zeile
        self.spalte = spalte

    def get_wert(self) -> int:
        if self.art == "Bauer":
            return 1
        elif self.art == "Springer" or self.art == "Läufer":
            return 3
        elif self.art == "Turm":
            return 5
        elif self.art == "Dame":
            return 9
        else:
            return 0

    def ziehen(self, zeile: int, spalte: int) -> None:
        self.zeile = zeile
        self.spalte = spalte

    def passt(self, zeile: int, spalte: int) -> bool:
        hoch = abs(zeile - self.zeile)
        quer = abs(spalte - self.spalte)
        if hoch == 0 and quer == 0:
            return False
        if self.art == "Turm":
            return hoch == 0 or quer == 0
        elif self.art == "Läufer":
            return hoch == quer
        elif self.art == "Dame":
            return hoch == 0 or quer == 0 or hoch == quer
        elif self.art == "König":
            return hoch <= 1 and quer <= 1
        elif self.art == "Springer":
            return hoch * quer == 2
        elif self.art == "Bauer":
            if self.farbe == "weiß":
                vor = self.zeile - zeile
                am_start = self.zeile == 6
            else:
                vor = zeile - self.zeile
                am_start = self.zeile == 1
            return quer == 0 and (vor == 1 or (vor == 2 and am_start))
        else:
            return False
