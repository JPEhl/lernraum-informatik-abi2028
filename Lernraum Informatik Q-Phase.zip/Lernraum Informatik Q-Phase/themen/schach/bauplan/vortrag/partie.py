# partie.py -- das Schachbrett.
# Die weiße Dame ist ein Objekt. Sie
# zieht per Klick -- nur dorthin, wohin
# eine Dame darf: Das sagt passt.

from zeichenflaeche import neue_flaeche, zeichne_bild, bei_klick, zeige
from figur import Figur

FELDGROESSE = 60
HELL = "#eeeed2"
DUNKEL = "#769656"

flaeche = neue_flaeche(8 * FELDGROESSE, 8 * FELDGROESSE)


# ------------------------ das Brett

def zeichne_felder() -> None:
    for zeile in range(8):
        for spalte in range(8):
            x = spalte * FELDGROESSE
            y = zeile * FELDGROESSE
            if (zeile + spalte) % 2 == 0:
                farbe = HELL
            else:
                farbe = DUNKEL
            flaeche.create_rectangle(x, y, x + FELDGROESSE, y + FELDGROESSE,
                                     fill=farbe, outline=farbe)


def zeichne_figur(name: str, zeile: int, spalte: int) -> None:
    zeichne_bild(name, spalte * FELDGROESSE, zeile * FELDGROESSE, FELDGROESSE)


def hebe_hervor(zeile: int, spalte: int) -> None:
    x = spalte * FELDGROESSE
    y = zeile * FELDGROESSE
    flaeche.create_rectangle(x, y, x + FELDGROESSE, y + FELDGROESSE,
                             outline="red", width=4)


def zeichne_punkt(zeile: int, spalte: int) -> None:
    x = spalte * FELDGROESSE + FELDGROESSE // 2
    y = zeile * FELDGROESSE + FELDGROESSE // 2
    r = FELDGROESSE // 6
    if (zeile + spalte) % 2 == 0:
        farbe = "#babaa4"
    else:
        farbe = "#5c7543"
    flaeche.create_oval(x - r, y - r, x + r, y + r,
                        fill=farbe, outline=farbe)


# ------------------------ die Aufstellung

dame = Figur("Dame", "weiß", 7, 3)


def zeige_ziele() -> None:
    for zeile in range(8):
        for spalte in range(8):
            if dame.passt(zeile, spalte):
                zeichne_punkt(zeile, spalte)


def zeichne_alles() -> None:
    flaeche.delete("all")
    zeichne_felder()
    zeichne_figur("turm-s", 0, 0)
    zeichne_figur("springer-s", 0, 1)
    zeichne_figur("laeufer-s", 0, 2)
    zeichne_figur("dame-s", 0, 3)
    zeichne_figur("koenig-s", 0, 4)
    zeichne_figur("laeufer-s", 0, 5)
    zeichne_figur("springer-s", 0, 6)
    zeichne_figur("turm-s", 0, 7)
    for spalte in range(8):
        zeichne_figur("bauer-s", 1, spalte)
    for spalte in range(8):
        zeichne_figur("bauer-w", 6, spalte)
    zeichne_figur("turm-w", 7, 0)
    zeichne_figur("springer-w", 7, 1)
    zeichne_figur("laeufer-w", 7, 2)
    zeichne_figur("dame-w", dame.zeile, dame.spalte)
    zeichne_figur("koenig-w", 7, 4)
    zeichne_figur("laeufer-w", 7, 5)
    zeichne_figur("springer-w", 7, 6)
    zeichne_figur("turm-w", 7, 7)
    zeige_ziele()


# ------------------------ der Klick

def klick(x: int, y: int) -> None:
    spalte = x // FELDGROESSE
    zeile = y // FELDGROESSE
    if dame.passt(zeile, spalte):
        dame.ziehen(zeile, spalte)
    zeichne_alles()


zeichne_alles()
bei_klick(klick)
zeige()
