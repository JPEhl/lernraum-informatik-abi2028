wort = "Läufer"
klein = wort.lower()
print(wort)
print(klein)
wort.upper()
