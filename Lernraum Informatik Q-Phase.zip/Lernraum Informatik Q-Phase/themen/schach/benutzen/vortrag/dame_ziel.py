# dame.py -- oben, was ihr aus partie.py kennt.
from zeichenflaeche import neue_flaeche, zeichne_bild, zeige
from figur import Figur

FELDGROESSE = 60
HELL = "#eeeed2"
DUNKEL = "#769656"
flaeche = neue_flaeche(8 * FELDGROESSE, 8 * FELDGROESSE)


def zeichne_felder() -> None:
    for zeile in range(8):
        for spalte in range(8):
            x = spalte * FELDGROESSE
            y = zeile * FELDGROESSE
            if (zeile + spalte) % 2 == 0:
                farbe = HELL
            else:
                farbe = DUNKEL
            flaeche.create_rectangle(x, y, x + FELDGROESSE, y + FELDGROESSE,
                                     fill=farbe, outline=farbe)


def zeichne_figur(name: str, zeile: int, spalte: int) -> None:
    zeichne_bild(name, spalte * FELDGROESSE, zeile * FELDGROESSE, FELDGROESSE)


def hebe_hervor(zeile: int, spalte: int) -> None:
    x = spalte * FELDGROESSE
    y = zeile * FELDGROESSE
    flaeche.create_rectangle(x, y, x + FELDGROESSE, y + FELDGROESSE,
                             outline="red", width=4)


zeichne_felder()

dame = Figur("Dame", "weiß", 7, 3)
print(dame.get_wert())
print(dame.passt(3, 3))
print(dame.passt(4, 5))
dame.ziehen(3, 3)
turm = Figur("Turm", "schwarz", 0, 0)

zeichne_figur("dame-w", dame.zeile, dame.spalte)
hebe_hervor(dame.zeile, dame.spalte)
zeichne_figur("turm-s", turm.zeile, turm.spalte)
zeige()
