# zug.py -- ein Zug: welche Figur, wohin.
# Hier arbeitet ihr (Aufgabe 2).

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from figur import Figur


class Zug:

    def __init__(self, figur: str, zeile: int, spalte: int):
        self.__figur = figur
        self.__zeile = zeile
        self.__spalte = spalte

    def get_figur(self) -> str:
        return self.__figur

    def get_zeile(self) -> int:
        return self.__zeile

    def get_spalte(self) -> int:
        return self.__spalte
