# zug_zurueck.py -- Expertenaufgabe: ein
# Zug, der sich zurücknehmen lässt.
# Kopiert eure Klasse Zug hierher.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from figur import Figur
