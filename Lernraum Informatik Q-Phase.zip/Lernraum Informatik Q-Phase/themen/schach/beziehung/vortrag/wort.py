# wort.py -- ein Zug als Pfeil auf dem Brett.
# Die Figur kommt aus figur.py, wie nach
# "Kapselung".

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from zeichenflaeche import neue_flaeche, zeichne_bild, zeige
from figur import Figur

FELDGROESSE = 60
flaeche = neue_flaeche(8 * FELDGROESSE, 8 * FELDGROESSE)


def zeichne_felder() -> None:
    for zeile in range(8):
        for spalte in range(8):
            x = spalte * FELDGROESSE
            y = zeile * FELDGROESSE
            if (zeile + spalte) % 2 == 0:
                farbe = "#eeeed2"
            else:
                farbe = "#769656"
            flaeche.create_rectangle(x, y, x + FELDGROESSE, y + FELDGROESSE,
                                     fill=farbe, outline=farbe)


def zeichne_figur(name: str, zeile: int, spalte: int) -> None:
    zeichne_bild(name, spalte * FELDGROESSE, zeile * FELDGROESSE, FELDGROESSE)


class Zug:

    def __init__(self, figur: str, zeile: int, spalte: int):
        self.__figur = figur
        self.__zeile = zeile
        self.__spalte = spalte

    def get_figur(self) -> str:
        return self.__figur

    def get_zeile(self) -> int:
        return self.__zeile

    def get_spalte(self) -> int:
        return self.__spalte


def zeichne_pfeil(zug: Zug) -> None:
    mitte = FELDGROESSE // 2
    x1 = zug.get_figur().get_spalte() * FELDGROESSE + mitte
    y1 = zug.get_figur().get_zeile() * FELDGROESSE + mitte
    x2 = zug.get_spalte() * FELDGROESSE + mitte
    y2 = zug.get_zeile() * FELDGROESSE + mitte
    flaeche.create_line(x1, y1, x2, y2, fill="#1565c0", width=6,
                        arrow="last", arrowshape=(18, 22, 7))


zeichne_felder()
dame = Figur("Dame", "weiß", 7, 3)
zug = Zug("Dame", 3, 3)
zeichne_figur("dame-w", dame.get_zeile(), dame.get_spalte())
zeige()
