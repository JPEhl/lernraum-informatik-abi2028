for zeile in range(2):
    for spalte in range(3):
        print("Feld", zeile, spalte)
