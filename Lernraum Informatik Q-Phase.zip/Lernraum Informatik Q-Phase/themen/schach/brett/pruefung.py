"""Selbstcheck „Die Zeichenschleife“ -- prueft das Programm im Ordner schach/ (es laeuft partie.py).

Die Flaeche wird gelesen wie von einem Menschen (LC6): ein Feld ueber seine Lage und die Farbe, die man dort SIEHT,
eine Figur ueber bild_auf. Die Funktionen der Klasse ruft der Check selbst auf, mit einer EIGENEN Feldgroesse (50)
und eigenen Feldern (LC2) -- so faellt eine fest eingetippte 70 auf, und vertauschte x und y bekommen ihre Meldung.
Die Feldgroesse wird danach zurueckgesetzt; was der Check zeichnet, liegt auf der Flaeche obendrauf und stoert die
Pruefungen davor nicht (sie lesen die Lage ihrer eigenen Dinge).

Aufgabe 3 (seit dem Umbau nach Schnitt A, 15.11.2026): Der Check KLICKT wie die Maus (klick_auf, LC6) -- ebenfalls
mit Feldgroesse 50, in die Mitte eines Feldes, das noch keinen Rahmen hat. Ein Klick zeichnet bei einer Loesung mit
zeichne_alles() das ganze Brett neu (in 50); die Pruefungen danach lesen nur, was sie selbst zeichnen.
"""
import ast

from pruefen import erwarte, braucht, arbeit, flaeche, rechtecke, bilder, bild_auf, funktion, quelltext, klick_auf

TITEL = "Die Zeichenschleife · Selbstcheck"
EINGABEN = []
PROBE = 50
HINTS = {"zeichne_felder": "None", "zeichne_figur": "None", "hebe_hervor": "None", "zeichne_alles": "None",
         "klick": "None", "beschrifte": "None"}


def _g():
    return getattr(arbeit(), "FELDGROESSE", None)


def _mitte(zeile, spalte, g):
    return spalte * g + g // 2, zeile * g + g // 2


def _sichtbar(x, y):
    """Die Farbe, die man an (x, y) sieht: die oberste Fuellung eines Rechtecks dort ("" = keine)."""
    for x1, y1, x2, y2, fuellung in reversed(rechtecke()):
        if fuellung and x1 <= x < x2 and y1 <= y < y2:
            return fuellung
    return ""


def _neu_mit_probe(name, *angaben):
    """Ruft die Funktion name mit FELDGROESSE = PROBE auf. Gibt die Dinge, die dabei auf die Flaeche kamen --
    oder einen Text, wenn der Aufruf abbricht."""
    f = funktion(name)
    c = flaeche()
    vorher = set(c.find_all())
    alt = f.__globals__.get("FELDGROESSE")
    f.__globals__["FELDGROESSE"] = PROBE
    try:
        f(*angaben)
    except Exception as e:  # noqa: BLE001 -- der Abbruch ist der Befund
        return "%s(%s) bricht ab: %s: %s" % (name, ", ".join(map(str, angaben)), type(e).__name__, e)
    finally:
        f.__globals__["FELDGROESSE"] = alt
    return [i for i in c.find_all() if i not in vorher]


def _rahmen(dinge):
    """Die ungefuellten Rechtecke unter dinge, als (x1, y1, x2, y2) in ganzen Zahlen."""
    c = flaeche()
    return [tuple(round(v) for v in c.coords(i)) for i in dinge
            if c.type(i) == "rectangle" and not c.itemcget(i, "fill") and c.itemcget(i, "outline")]


def _feld(zeile, spalte, g):
    return (spalte * g, zeile * g, (spalte + 1) * g, (zeile + 1) * g)


def _hervor_geht():
    """Rahmt hebe_hervor mit eigener Feldgroesse das richtige Feld ein? (nur fuer braucht)"""
    if funktion("hebe_hervor") is None:
        return False
    neu = _neu_mit_probe("hebe_hervor", 2, 5)
    return not isinstance(neu, str) and _feld(2, 5, PROBE) in _rahmen(neu)


def _klick_mit_probe(zeile, spalte, wo):
    """Klickt mit FELDGROESSE = PROBE in die Mitte des Feldes (zeile, spalte). Gibt (shell, rahmen vorher, rahmen
    nachher) -- die Rahmen als Menge von (x1, y1, x2, y2). Bricht der Klick ab, meldet klick_auf das (Offen)."""
    # die Namen, mit denen klick rechnet (wie in _neu_mit_probe: __globals__ der Funktion, nicht arbeit())
    g, c = funktion("klick").__globals__, flaeche()
    vorher = set(_rahmen(c.find_all()))
    alt = g.get("FELDGROESSE")
    g["FELDGROESSE"] = PROBE
    try:
        shell = klick_auf(*_mitte(zeile, spalte, PROBE), wo=wo)
    finally:
        g["FELDGROESSE"] = alt
    return shell, vorher, set(_rahmen(c.find_all()))


def _feld_von(rahmen):
    """Das Feld (zeile, spalte), das ein Rahmen bei Feldgroesse PROBE genau einnimmt -- sonst None."""
    x1, y1, x2, y2 = rahmen
    if x1 % PROBE or y1 % PROBE or x2 - x1 != PROBE or y2 - y1 != PROBE:
        return None
    return y1 // PROBE, x1 // PROBE


def _klick_geht():
    """Rahmt ein Klick (mit eigener Feldgroesse) genau das angeklickte Feld? (nur fuer braucht)"""
    if funktion("klick") is None or not _hervor_geht():
        return False
    try:
        shell, vorher, nachher = _klick_mit_probe(6, 1, "Zeile 6, Spalte 1")
    except AssertionError:
        return False
    return _feld(6, 1, PROBE) in nachher - vorher


def _defs():
    baum = ast.parse(quelltext("partie.py"))
    return [(k.name, k) for k in baum.body if isinstance(k, ast.FunctionDef)]


def pruefe_00_laeuft():
    """Grundlage · Das Programm läuft und malt Brett und Figuren"""
    erwarte(flaeche() is not None, "Keine Zeichenfläche -- bricht das Programm vor neue_flaeche ab? Seht in der Shell nach.")
    g = _g()
    erwarte(isinstance(g, int) and g > 0, "FELDGROESSE ist keine ganze Zahl über 0 -- oben in partie.py.")
    felder = [r for r in rechtecke() if r[4]]
    erwarte(len(felder) >= 64, "Auf der Fläche liegen %d gefüllte Felder statt 64 -- in zeichne_felder." % len(felder))
    zahl = len(bilder())
    erwarte(zahl == 32, "Auf dem Brett stehen %d Figuren statt 32 -- unter „die Aufstellung“." % zahl)


def pruefe_20_groesse_farben():
    """Aufgabe 2 · Feldgröße 60 und zwei eigene Farben"""
    g = _g()
    erwarte(g == 60, "FELDGROESSE ist %s, verlangt ist 60 -- oben in partie.py." % g)
    breite = int(flaeche()["width"])
    erwarte(breite == 480, "Die Fläche ist %d Pixel breit, bei Feldgröße 60 wären es 480." % breite)
    hell, dunkel = _sichtbar(*_mitte(0, 0, g)), _sichtbar(*_mitte(0, 1, g))
    erwarte(hell != dunkel, "Feld (0, 0) und Feld (0, 1) haben dieselbe Farbe.")
    erwarte(hell.lower() != "#f0d9b5" or dunkel.lower() != "#b58863",
            "Die Felder haben noch die alten Farben -- HELL und DUNKEL stehen oben in partie.py.")
    erwarte(hell.lower() != "#f0d9b5" and dunkel.lower() != "#b58863",
            "Eine Farbe ist neu, die andere noch die alte.")
    figur = bild_auf(*_mitte(7, 3, g))
    erwarte(figur == "dame-w.png", "Das Brett ist kleiner, aber auf Zeile 7, Spalte 3 steht nicht die weiße Dame.")


def pruefe_30_hervor():
    """Aufgabe 3 · hebe_hervor rahmt das Feld ein, das es bekommt"""
    braucht(funktion("hebe_hervor") is not None, "Erst die Funktion hebe_hervor in partie.py.")
    neu = _neu_mit_probe("hebe_hervor", 2, 5)
    erwarte(not isinstance(neu, str), neu)
    rahmen = _rahmen(neu)
    gefuellt = [i for i in neu if flaeche().type(i) == "rectangle" and flaeche().itemcget(i, "fill")]
    erwarte(rahmen or not gefuellt, "hebe_hervor(2, 5) malt ein gefülltes Rechteck -- ein Rahmen ist durchsichtig, "
            "ohne fill, mit einer Farbe für den Rand.")
    erwarte(rahmen, "hebe_hervor(2, 5) malt keinen Rahmen auf die Fläche.")
    ziel = _feld(2, 5, PROBE)
    vertauscht = ziel not in rahmen and (_feld(5, 2, PROBE) in rahmen or _feld(5, 2, 70) in rahmen
                                         or _feld(5, 2, 60) in rahmen)
    erwarte(not vertauscht, "hebe_hervor(2, 5) rahmt Zeile 5, Spalte 2 ein -- x und y sind vertauscht.")
    fest = ziel not in rahmen and (_feld(2, 5, 70) in rahmen or _feld(2, 5, 60) in rahmen)
    erwarte(not fest, "Mit einer anderen Feldgröße liegt der Rahmen daneben -- rechnet hebe_hervor mit einer "
            "festen Zahl statt mit FELDGROESSE?")
    erwarte(ziel in rahmen, "hebe_hervor(2, 5) malt einen Rahmen, aber nicht genau um Zeile 2, Spalte 5.")


def pruefe_31_klick():
    """Aufgabe 3 · Ein Klick rahmt das angeklickte Feld"""
    braucht(_hervor_geht(), "Erst hebe_hervor.")
    braucht(funktion("klick") is not None, "Die Funktion klick fehlt in partie.py -- sie steht im Start unter „der Klick“.")
    shell, vorher, nachher = _klick_mit_probe(4, 6, "Zeile 4, Spalte 6")
    ziel = _feld(4, 6, PROBE)
    neu = nachher - vorher
    gedruckt = shell.strip().splitlines()[-1] if shell.strip() else ""
    erwarte(neu or ziel in nachher, "Ein Klick auf Zeile 4, Spalte 6 rahmt kein Feld" + (
        " -- die Shell zeigt nur „%s“." % gedruckt if gedruckt else "."))
    felder = {_feld_von(r) for r in neu}
    erwarte(None not in felder, "Ein Klick auf Zeile 4, Spalte 6 malt einen Rahmen, der nicht genau auf einem Feld "
            "liegt -- sind Zeile und Spalte ganze Zahlen?")
    erwarte((6, 4) not in felder or ziel in nachher, "Ein Klick auf Zeile 4, Spalte 6 rahmt Zeile 6, Spalte 4 -- "
            "Zeile und Spalte sind vertauscht.")
    fest = [(y // f, x // f) for f in (60, 70) for x, y in [_mitte(4, 6, PROBE)]]
    erwarte(ziel in nachher or not (felder & set(fest)), "Mit einer anderen Feldgröße rahmt der Klick das falsche "
            "Feld -- rechnet klick mit einer festen Zahl statt mit FELDGROESSE?")
    erwarte(ziel in nachher, "Ein Klick auf Zeile 4, Spalte 6 rahmt ein anderes Feld.")


def pruefe_35_nur_eins():
    """Aufgabe 3 ★★ · Nach jedem Klick ist nur das neue Feld gerahmt"""
    braucht(_klick_geht(), "Erst muss ein Klick sein Feld rahmen.")
    _klick_mit_probe(2, 2, "Zeile 2, Spalte 2")
    shell, vorher, nachher = _klick_mit_probe(5, 3, "Zeile 5, Spalte 3")
    ziel = _feld(5, 3, PROBE)
    erwarte(ziel in nachher, "Ein Klick auf Zeile 5, Spalte 3 rahmt dieses Feld nicht mehr.")
    # erst, was man vom Brett sieht (übermalte Figuren), dann die Rahmen -- unter neuen Feldern liegt ein alter
    # Rahmen unsichtbar, die Meldung „die alten Rahmen bleiben stehen“ träfe dort nicht
    felder = len([r for r in rechtecke() if r[4]])
    erwarte(felder == 64, "Nach den Klicks liegen %d Felder auf der Fläche statt 64 -- wird neu gemalt, ohne das "
            "Alte wegzuräumen?" % felder)
    zahl = len(bilder())
    erwarte(zahl == 32, "Nach dem Klick stehen %d Figuren auf dem Brett statt 32." % zahl)
    dame = bild_auf(*_mitte(7, 3, PROBE))
    erwarte(dame == "dame-w.png", "Nach dem Klick steht auf Zeile 7, Spalte 3 nicht mehr die weiße Dame.")
    andere = len(nachher - {ziel})
    erwarte(not andere, "Nach dem Klick auf Zeile 5, Spalte 3 sind noch %d andere Felder gerahmt -- die alten "
            "Rahmen bleiben stehen." % andere)


def pruefe_60_beschriften():
    """Aufgabe 6 ★★ · Das Brett trägt a bis h und 1 bis 8"""
    braucht(funktion("beschrifte") is not None, "Erst die Funktion beschrifte.")
    neu = _neu_mit_probe("beschrifte")
    erwarte(not isinstance(neu, str), neu)
    c = flaeche()
    texte = [(str(c.itemcget(i, "text")), *[round(v) for v in c.coords(i)[:2]]) for i in neu if c.type(i) == "text"]
    erwarte(texte, "beschrifte() schreibt nichts auf die Fläche.")

    def steht_in(text, zeile, spalte):
        x1, y1, x2, y2 = _feld(zeile, spalte, PROBE)
        return any(t == text and x1 <= x < x2 and y1 <= y < y2 for t, x, y in texte)
    fehlt = [b for s, b in enumerate("abcdefgh") if not steht_in(b, 7, s)]
    erwarte(not fehlt, "In der untersten Reihe steht nicht im richtigen Feld: %s." % ", ".join(fehlt))
    fehlt = [str(8 - z) for z in range(8) if not steht_in(str(8 - z), z, 0)]
    erwarte(not fehlt, "In der linken Spalte steht nicht im richtigen Feld: %s (oben die 8, unten die 1)." % ", ".join(fehlt))


def pruefe_70_eine_schleife():
    """Aufgabe 7 ★★★ · zeichne_felder mit einer einzigen Schleife"""
    defs = dict(_defs())
    braucht("zeichne_felder" in defs, "zeichne_felder fehlt.")
    schleifen = [k for k in ast.walk(defs["zeichne_felder"]) if isinstance(k, (ast.For, ast.While))]
    braucht(len(schleifen) == 1, "zeichne_felder hat noch %d Schleifen." % len(schleifen))
    erwarte(isinstance(schleifen[0], ast.For), "Verlangt ist eine for-Schleife.")
    neu = _neu_mit_probe("zeichne_felder")
    erwarte(not isinstance(neu, str), neu)
    c, m = flaeche(), arbeit()
    felder = {}
    for i in neu:
        if c.type(i) == "rectangle" and c.itemcget(i, "fill"):
            x1, y1 = [round(v) for v in c.coords(i)[:2]]
            felder[(y1 // PROBE, x1 // PROBE)] = c.itemcget(i, "fill")
    erwarte(len(neu) == 64, "zeichne_felder malt %d Rechtecke statt 64." % len(neu))
    falsch = [(z, s) for z in range(8) for s in range(8)
              if felder.get((z, s)) != (m.HELL if (z + s) % 2 == 0 else m.DUNKEL)]
    erwarte(not falsch, "Das Muster stimmt nicht, zuerst bei Zeile %d, Spalte %d." % falsch[0] if falsch else "")


def pruefe_90_hints():
    """Hinweis · Jedes def mit Type Hints -- auch an den Parametern (kein Stern)"""
    ohne, falsch = [], []
    for name, k in _defs():
        if k.returns is None or any(a.annotation is None for a in k.args.args):
            ohne.append(name)
        elif name in HINTS and ast.unparse(k.returns).replace(" ", "") != HINTS[name]:
            falsch.append("%s -> %s" % (name, HINTS[name]))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer oder an einem Parameter): %s. Es läuft auch ohne; "
            "vereinbart ist es trotzdem." % ", ".join(ohne))
    erwarte(not falsch, "Dieser Type Hint passt nicht zu dem, was zurückkommt -- erwartet: %s." % ", ".join(falsch))
