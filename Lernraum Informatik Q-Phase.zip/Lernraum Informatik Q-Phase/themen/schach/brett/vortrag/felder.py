# felder.py -- die 64 Felder, klein gebaut.
from zeichenflaeche import neue_flaeche, zeige

FELDGROESSE = 70
flaeche = neue_flaeche(8 * FELDGROESSE, 8 * FELDGROESSE)

zeige()
