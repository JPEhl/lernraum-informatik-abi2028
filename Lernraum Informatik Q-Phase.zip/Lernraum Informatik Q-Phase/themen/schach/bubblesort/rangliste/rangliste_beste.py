# rangliste_beste.py -- Experten-
# aufgabe: die besten k Mitglieder,
# ohne alles zu sortieren. Kopiert eure
# Klasse Rangliste hierher.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from mitglied import Mitglied
