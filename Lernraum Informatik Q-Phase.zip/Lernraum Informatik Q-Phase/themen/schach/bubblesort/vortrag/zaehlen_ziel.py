# zaehlen.py -- derselbe Bubblesort,
# jetzt zählt er seine Vergleiche.


class Wertungen:

    def __init__(self, zahlen: list[int]):
        self.__zahlen = zahlen

    def get_zahlen(self) -> list[int]:
        return self.__zahlen

    def sortiere(self) -> int:
        zahlen = self.__zahlen
        vergleiche = 0
        for nummer in range(1, len(zahlen)):
            for platz in range(len(zahlen) - nummer):
                vergleiche = vergleiche + 1
                if zahlen[platz] > zahlen[platz + 1]:
                    merke = zahlen[platz]
                    zahlen[platz] = zahlen[platz + 1]
                    zahlen[platz + 1] = merke
        return vergleiche


wertungen = Wertungen(
    [1480, 1215, 1630, 1342,
     1105, 1577, 1290, 1418,
     1048, 1466, 1712, 1322,
     1189, 1540, 1401, 1273]
)
vergleiche = wertungen.sortiere()
print(wertungen.get_zahlen())
print(vergleiche)
