"""Selbstcheck „Objektlisten“ -- prueft das Programm im Ordner schach/ (es laeuft partie.py).

Der Spieler haelt seine Figuren. Der Check prueft die Klasse Spieler ueber OBJEKTE, die er selbst baut (LC8): erzeuge,
rufe, attribute -- mit eigenen Figuren in eigener Reihenfolge, damit eine Antwort nicht zufaellig zur Aufstellung
passt. Das Brett liest er wie ein Mensch (LC6): welches Bild auf welchem Feld liegt.

Seit dem Umbau nach Schnitt A (16.11.2026) ist partie.py ein Programm mit Klick, und der Arbeitsordner ist
vorbereitet: Wer auf einem Feld steht, sagt figur_auf_feld -- am Start ueber sechs Namen. Aufgabe 3 ★★ laesst die
Funktion die zwei Spieler fragen; ob dann wirklich ALLE 32 gewaehlt werden koennen, zeigt ein FRISCHER Lauf, auf dem
der Check klickt wie die Maus (klick_auf): ein schwarzer Bauer laesst sich waehlen und zieht, die Shell nennt das
Material, die weisse Dame markiert nur noch leere Felder.

Seit der Reihensichtung Teil I (16.11.2026, Befund 12) liegt der Bauer in passt im Arbeitsordner (figur.py, „neu
dazugelegt“): Die Klasse schreibt ihn hier nicht mehr, Aufgabe 3 ★★ prueft ihn deshalb nicht mehr als eigene Leistung
-- der Lauf mit Klick benutzt ihn nur. Und (Befund 14): Wer Mehr 6 macht, rahmt in zeichne_alles die wertvollste
schwarze Figur; diesen einen Rahmen zaehlt die Pflichtpruefung nicht mit (_gewaehlt_und_ziele fragt den schwarzen
Spieler des frischen Laufs selbst, welche Figur das ist) -- sonst wuerde die Loesung mit Mehr 6 an Aufgabe 3 ★★ rot,
und ein Fehler in wertvollste faerbte die Pflicht (LC3).

Fallen (LC5): materialwert mit `return` in der Schleife liefert den ersten Wert -- deshalb mehrere Figuren, und nie
eine Probe, deren erste Figur schon die Summe ist. finde_figur mit vertauschter Zeile und Spalte faellt nur an einem
Feld auf, dessen Zeile nicht seine Spalte ist. wertvollste mit Startwert 0 findet nichts, wenn nur der Koenig (Wert
0) da ist. zeichne_alle wird an einem leeren Streifen des Bretts (Zeile 4) mit eigenen Figuren geprueft, nicht an der
Aufstellung, die schon dasteht.

Startzustand (Arbeitsordner): partie.py laeuft, spieler.py hat nur den Kopf. Offen ist genau Aufgabe 2 ★, alles
andere wartet (LC1).
"""
import ast
import importlib
import re
import sys

import pruefen
from pruefen import erwarte, braucht, arbeit, flaeche, bild_auf, ohne_kommentare, quelltext, anspielen, erzeuge, \
    rufe, attribute, klasse, klick_auf

TITEL = "Objektlisten · Selbstcheck"
EINGABEN = []
HINTS = {"aufnehmen": {"None"}, "anzahl": {"int"}, "zeichne_alle": {"None"}, "materialwert": {"int"},
         "finde_figur": {"Figur"}, "wertvollste": {"Figur"}}
DIAGRAMMTYPEN = {"String", "integer", "boolean", "Integer", "Boolean"}


def _g():
    return getattr(arbeit(), "FELDGROESSE", None)


def _bild(zeile, spalte):
    g = _g()
    return bild_auf(spalte * g + g // 2, zeile * g + g // 2)


def _wo(feld):
    return "Zeile %d, Spalte %d" % tuple(feld)


_LAUF = {}     # die Namen des letzten frischen Laufs (fuer _gewaehlt_und_ziele)


def _spiel():
    """partie.py noch einmal, frisch. Gibt (Flaeche, Feldgroesse, letzte Fehlerzeile) -- die Flaeche ist None, wenn
    das Programm nicht bis zum Ende lief."""
    alt_q = pruefen._QUELLE
    pruefen._QUELLE = alt_q + "\nprint('--ENDE--')\n"
    try:
        aus, ns = anspielen([])
    finally:
        pruefen._QUELLE = alt_q
    zeilen = [z for z in aus.strip().splitlines() if z.strip() and "--ENDE--" not in z]
    fehler = zeilen[-1] if zeilen and "Error" in zeilen[-1] else ""
    _LAUF.clear()
    _LAUF.update(ns)
    return (ns.get("flaeche") if "--ENDE--" in aus else None), ns.get("FELDGROESSE"), fehler


def _klick(c, feld, g):
    alt = pruefen._FENSTER
    pruefen._FENSTER = c.winfo_toplevel()
    try:
        return klick_auf(feld[1] * g + g // 2, feld[0] * g + g // 2, wo=_wo(feld))
    finally:
        pruefen._FENSTER = alt


def _bilder_auf(c, feld, g):
    """ALLE Bilder, die auf dem Feld liegen (zwei Figuren auf einem Feld sind in diesem Thema moeglich)."""
    aus = []
    for i in c.find_all():
        if c.type(i) == "image":
            k = c.coords(i)
            if (int(k[1]) // g, int(k[0]) // g) == tuple(feld):
                aus.append(pruefen._bilddatei(c, c.itemcget(i, "image")))
    return sorted(aus)


def _markiert(c, g):
    """Die markierten Felder auf c als Menge von (zeile, spalte): das rot gerahmte Feld der gewaehlten Figur und die
    Felder mit einem Punkt -- ihre Ziele (seit 16.11.2026; ein Rahmen als Ziel zaehlt weiter)."""
    felder = set()
    for i in c.find_all():
        if c.type(i) == "rectangle" and not c.itemcget(i, "fill") and c.itemcget(i, "outline"):
            x1, y1, x2, y2 = (round(v) for v in c.coords(i))
            if x1 % g == 0 and y1 % g == 0 and x2 - x1 == g and y2 - y1 == g:
                felder.add((y1 // g, x1 // g))
        elif c.type(i) == "oval":
            # ein Punkt mitten im Feld: ein Ziel (seit 16.11.2026 zeichnet zeige_ziele Punkte statt Rahmen)
            x1, y1, x2, y2 = (round(v) for v in c.coords(i))
            if (x1 + x2) // 2 % g == g // 2 and (y1 + y2) // 2 % g == g // 2:
                felder.add(((y1 + y2) // 2 // g, (x1 + x2) // 2 // g))
    return felder


def _gewaehlt_und_ziele(c, g, gewaehlt=None):
    """Was fuer die Pflicht markiert ist: das Feld der gewaehlten Figur und ihre Ziele. Mehr 6 rahmt dazu in
    zeichne_alles die wertvollste schwarze Figur -- dieser Rahmen zaehlt nicht mit: Die Spieler des frischen Laufs
    werden selbst gefragt, welche Figur das ist (so faerbt auch ein falsches wertvollste oder der Rahmen beim
    falschen Spieler die Pflicht nicht; das zeigt Aufgabe 6). Das Feld der gewaehlten Figur bleibt immer stehen."""
    felder = _markiert(c, g)
    for wert in list(_LAUF.values()):
        if type(wert).__name__ == "Spieler" and hasattr(wert, "wertvollste"):
            try:
                figur = wert.wertvollste()
                feld = (figur.get_zeile(), figur.get_spalte())
            except Exception:  # noqa: BLE001 -- dann gibt es fuer den Check keinen Rahmen aus Mehr 6
                continue
            if feld != gewaehlt:
                felder.discard(feld)
    return felder


def _ok(pruefung):
    try:
        pruefung()
    except AssertionError:
        return False
    return True


def _spieler_im_programm():
    """Die Spieler, die partie.py gebaut hat, je mit der Zahl ihrer Figuren und ihrer Farbe."""
    aus = []
    for wert in vars(arbeit()).values():
        if type(wert).__name__ == "Spieler":
            a = attribute(wert)
            figuren = a.get("__figuren")
            aus.append((a.get("__farbe"), len(figuren) if isinstance(figuren, list) else None))
    return aus


def _feste_bilder(endung):
    """Zeilen in partie.py, die eine Figur noch als festes Bild setzen: zeichne_figur("…-w", …)."""
    return re.findall(r'zeichne_figur\(\s*"[a-z]+-%s"' % endung, ohne_kommentare())


def _figuren(*arten):
    return [erzeuge("Figur", art, "weiß", 7, spalte) for spalte, art in enumerate(arten)]


def _spieler_mit(*arten):
    s = erzeuge("Spieler", "weiß")
    figuren = _figuren(*arten)
    for f in figuren:
        rufe(s, "aufnehmen", f)
    return s, figuren


def _sammelt():
    """aufnehmen haengt an dieselbe Liste an -- Grundlage fuer jede Methode ueber der Liste (Aufgabe 3, Mehr 6)."""
    k = klasse("Spieler")
    if k is None or not hasattr(k, "aufnehmen") or not hasattr(k, "anzahl"):
        return False
    try:
        s, _ = _spieler_mit("Turm", "Läufer", "Dame")
        return rufe(s, "anzahl") == 3
    except AssertionError:
        return False


def pruefe_00_grundlage():
    """Grundlage · figur.py lädt, das Programm hat eine Zeichenfläche"""
    erwarte(klasse("Figur") is not None, "In figur.py steht keine Klasse Figur mehr -- seht in der Shell nach.")
    erwarte(flaeche() is not None, "Das Programm bricht ab, bevor es eine Zeichenfläche hat -- seht in der Shell nach.")
    g = _g()
    erwarte(isinstance(g, int) and g > 0, "FELDGROESSE ist keine ganze Zahl über 0 -- oben in partie.py.")


def pruefe_20_spieler():
    """Aufgabe 2 · Der Spieler hält seine Figuren und zeichnet sie -- Weiß ohne ein festes Bild"""
    erwarte(klasse("Spieler") is not None, "In spieler.py steht noch keine Klasse Spieler -- und partie.py muss sie "
            "mit from spieler import Spieler laden.")
    s = erzeuge("Spieler", "weiß")
    offen = sorted(attribute(s).oeffentlich)
    erwarte(not offen, "Ein Spieler zeigt %s offen -- im Diagramm steht davor ein Minus." % ", ".join(offen))
    erwarte(rufe(s, "anzahl") == 0, "Ein neuer Spieler hat %r Figuren statt 0 -- beginnt die Liste leer?"
            % (rufe(s, "anzahl"),))
    s, figuren = _spieler_mit("Turm", "Läufer", "Dame")
    erwarte(rufe(s, "anzahl") == 3, "Nach drei aufnehmen sagt anzahl() %r statt 3 -- entsteht die Liste bei jedem "
            "aufnehmen neu?" % (rufe(s, "anzahl"),))
    # zeichnen auf dem leeren Streifen Zeile 4, mit eigenen Figuren
    g = _g()
    leer = erzeuge("Spieler", "schwarz")
    for art, spalte in (("Turm", 0), ("Läufer", 2), ("König", 7)):
        rufe(leer, "aufnehmen", erzeuge("Figur", art, "schwarz", 4, spalte))
    rufe(leer, "zeichne_alle", g)
    ist = [_bild(4, 0), _bild(4, 2), _bild(4, 7)]
    falsch = ["auf Zeile 4, Spalte %d %s statt %s" % (spalte, ("das Bild " + bild[:-4]) if bild else "nichts", soll[:-4])
              for spalte, bild, soll in zip((0, 2, 7), ist, ("turm-s.png", "laeufer-s.png", "koenig-s.png")) if bild != soll]
    erwarte(not falsch, "Ein Spieler mit einem schwarzen Turm (4, 0), Läufer (4, 2) und König (4, 7) zeichnet seine "
            "Figuren -- danach liegt %s. Aus welchem Wert der Figur wird in zeichne_alle x, aus welchem y, und "
            "welches Bild gehört zu ihr?" % "; ".join(falsch))
    im = _spieler_im_programm()
    erwarte(any(n == 16 for _, n in im), "In partie.py hält kein Spieler die sechzehn weißen Figuren (gefunden: %s)."
            % (", ".join("%s mit %s" % (f, n) for f, n in im) or "kein Spieler"))
    rest = _feste_bilder("w")
    erwarte(not rest, "In partie.py setzt zeichne_figur noch %d weiße Figur(en) als festes Bild -- die zeichnet jetzt "
            "der Spieler." % len(rest))
    fehlt = [(z, s) for z, s, b in ((7, 0, "turm-w.png"), (7, 4, "koenig-w.png"), (6, 5, "bauer-w.png"),
                                    (7, 3, "dame-w.png"), (7, 6, "springer-w.png"), (7, 5, "laeufer-w.png"))
             if _bild(z, s) != b]
    erwarte(not fehlt, "Auf dem Brett fehlt eine weiße Figur auf %s -- nimmt der Spieler alle sechzehn auf, auch die "
            "fünf, die es schon als Objekte gibt?" % ", ".join(map(str, fehlt)))


def pruefe_25_schwarz():
    """Aufgabe 2 ★★ · Schwarz ist auch ein Spieler -- das ganze Brett kommt aus Objekten"""
    braucht(_ok(pruefe_20_spieler), "Erst zeichnet der weiße Spieler.")
    im = _spieler_im_programm()
    erwarte(sum(1 for _, n in im if n == 16) >= 2, "In partie.py halten nicht zwei Spieler je sechzehn Figuren "
            "(gefunden: %s)." % ", ".join("%s mit %s" % (f, n) for f, n in im))
    rest = _feste_bilder("s")
    erwarte(not rest, "In partie.py setzt zeichne_figur noch %d schwarze Figur(en) als festes Bild." % len(rest))
    fehlt = [(z, s) for z, s, b in ((0, 0, "turm-s.png"), (0, 4, "koenig-s.png"), (0, 5, "laeufer-s.png"),
                                    (1, 1, "bauer-s.png"), (1, 6, "bauer-s.png")) if _bild(z, s) != b]
    erwarte(not fehlt, "Auf dem Brett fehlt eine schwarze Figur auf %s." % ", ".join(map(str, fehlt)))


def pruefe_30_findet_und_zaehlt():
    """Aufgabe 3 · Der Spieler findet die Figur auf einem Feld und zählt seinen Materialwert"""
    braucht(_sammelt(), "Erst nimmt der Spieler seine Figuren auf (Aufgabe 2).")
    k = klasse("Spieler")
    erwarte(hasattr(k, "finde_figur"), "Der Spieler hält seine Figuren. Welche auf einem Feld steht, kann er noch "
            "nicht sagen -- finde_figur fehlt in spieler.py.")
    s, figuren = _spieler_mit("Turm", "Läufer", "Dame")
    gefunden = rufe(s, "finde_figur", 7, 1)
    erwarte(gefunden is not None, "Ein Spieler mit Turm (7, 0), Läufer (7, 1), Dame (7, 2): finde_figur(7, 1) gibt "
            "None zurück -- dort steht der Läufer.")
    andere = [name for name, f in zip(("den Turm von Zeile 7, Spalte 0", "", "die Dame von Zeile 7, Spalte 2"), figuren)
              if f is gefunden and name]
    erwarte(not andere, "Ein Spieler mit Turm (7, 0), Läufer (7, 1), Dame (7, 2): finde_figur(7, 1) gibt %s zurück -- "
            "auf Zeile 7, Spalte 1 steht der Läufer. Woran erkennt die Suche das Feld?" % (andere[0] if andere else ""))
    erwarte(gefunden is figuren[1], "finde_figur(7, 1) gibt nicht genau den Läufer zurück, der dort steht -- "
            "zurückkommen soll die Figur selbst, nicht ihr Name und keine neue.")
    erwarte(rufe(s, "finde_figur", 7, 2) is figuren[2], "finde_figur(7, 2) gibt nicht die Dame zurück -- geht die "
            "Schleife durch alle Figuren?")
    leer = rufe(s, "finde_figur", 3, 3)
    erwarte(leer is None, "Auf Zeile 3, Spalte 3 steht keine Figur des Spielers -- finde_figur(3, 3) gibt %r statt "
            "None." % (leer,))
    quer = rufe(s, "finde_figur", 1, 7)
    erwarte(quer is None, "finde_figur(1, 7) findet den Läufer, der auf Zeile 7, Spalte 1 steht -- Zeile und Spalte "
            "sind vertauscht.")
    erwarte(hasattr(k, "materialwert"), "finde_figur stimmt. Es fehlt noch materialwert in spieler.py.")
    falsch = []
    for arten, soll in ((("Turm", "König", "Dame", "Bauer"), 15), (("Bauer", "Bauer", "Springer"), 5), ((), 0)):
        s, _ = _spieler_mit(*arten)
        antwort = rufe(s, "materialwert")
        if antwort != soll:
            falsch.append("%s: %r statt %r" % (", ".join(arten) or "ohne Figuren", antwort, soll))
    erwarte(not falsch, "materialwert antwortet: %s. Fragt die Methode alle Figuren, bevor sie antwortet?"
            % "; ".join(falsch))


def pruefe_35_alle_32():
    """Aufgabe 3 ★★ · Jede der 32 Figuren lässt sich wählen, die Shell nennt das Material"""
    braucht(_ok(pruefe_30_findet_und_zaehlt), "Erst findet und zählt der Spieler.")
    braucht(_ok(pruefe_25_schwarz), "Erst sind beide Spieler aufgestellt (Aufgabe 2 ★★).")
    c, g, fehler = _spiel()
    erwarte(c is not None, "partie.py bricht ab, bevor das Brett fertig ist%s." % (" (%s)" % fehler if fehler else ""))
    _klick(c, (1, 4), g)
    ist = _gewaehlt_und_ziele(c, g, (1, 4))
    erwarte((1, 4) in ist, "Ein Klick auf den schwarzen Bauern auf Zeile 1, Spalte 4 wählt ihn nicht -- kennt "
            "figur_auf_feld ihn? Es soll die zwei Spieler fragen, nicht mehr die sechs Namen.")
    erwarte(ist == {(1, 4), (2, 4), (3, 4)}, "Der schwarze Bauer auf Zeile 1, Spalte 4 ist gewählt. Markiert sein "
            "sollen sein Feld und seine zwei Ziele davor -- es sind %d Felder." % len(ist))
    shell = _klick(c, (3, 4), g)
    erwarte(_bilder_auf(c, (3, 4), g) == ["bauer-s.png"] and not _bilder_auf(c, (1, 4), g), "Der gewählte Bauer zieht "
            "nicht von Zeile 1, Spalte 4 nach Zeile 3, Spalte 4.")
    erwarte(not _gewaehlt_und_ziele(c, g), "Nach dem Zug ist noch etwas markiert -- danach soll nichts mehr gewählt sein.")
    zahlen = re.findall(r"\d+", shell)
    erwarte(shell.strip(), "Der Bauer ist gezogen, in der Shell steht aber nichts -- nach jedem Zug, der galt, nennt "
            "sie das Material beider Spieler.")
    erwarte(zahlen == ["39", "39"] and "Weiß" in shell and "Schwarz" in shell, "Nach dem ersten Zug hat jeder Spieler "
            "39. In der Shell steht: %s" % shell.strip()[:70])
    _klick(c, (7, 3), g)
    ist = _gewaehlt_und_ziele(c, g, (7, 3))
    soll = {(7, 3), (5, 3), (4, 3), (3, 3), (2, 3), (5, 1), (4, 0), (5, 5), (4, 6), (3, 7)}
    erwarte((6, 3) not in ist, "Die weiße Dame ist gewählt, und das Feld des Bauern vor ihr ist markiert -- "
            "figur_auf_feld findet ihn noch nicht: Fragt es beide Spieler?")
    erwarte(ist == soll, "Die weiße Dame auf Zeile 7, Spalte 3 ist gewählt. Markiert sein sollen ihr Feld und die "
            "leeren Felder ihrer Gangart (zehn) -- es sind %d." % len(ist))
    _klick(c, (7, 0), g)
    ist = _gewaehlt_und_ziele(c, g, (7, 0))
    erwarte((7, 0) in ist and (7, 3) not in ist, "Die Dame ist gewählt; ein Klick auf den weißen Turm auf Zeile 7, "
            "Spalte 0 soll umwählen -- gerahmt ist nicht sein Feld.")


def pruefe_60_wertvollste():
    """Aufgabe 6 ★★ · Die wertvollste Figur"""
    braucht(_sammelt(), "Erst nimmt der Spieler seine Figuren auf (Aufgabe 2).")
    braucht(hasattr(klasse("Spieler"), "wertvollste"), "Erst die Methode wertvollste in spieler.py.")
    s, figuren = _spieler_mit("Bauer", "Dame", "Turm")
    erwarte(rufe(s, "wertvollste") is figuren[1], "Bauer, Dame, Turm: wertvollste() gibt nicht genau die Dame zurück, "
            "die aufgenommen wurde.")
    s, figuren = _spieler_mit("König")
    erwarte(rufe(s, "wertvollste") is figuren[0], "Ein Spieler, der nur noch seinen König hat (Wert 0): wertvollste() "
            "gibt nicht den König zurück. Womit fängt euer Vergleich an?")
    # ... und am Brett (seit 16.11.2026; bis dahin prüfte niemand den Teil in partie.py -- die Lösungsdatei hatte ihn
    # nicht): Am Start ist nichts gewählt, gerahmt ist allein die wertvollste schwarze Figur
    braucht(_ok(pruefe_25_schwarz), "wertvollste stimmt. Für das Brett braucht es Schwarz als Spieler (Aufgabe 2 ★★).")
    c, g, fehler = _spiel()
    erwarte(c is not None, "partie.py bricht ab, bevor das Brett fertig ist%s." % (" (%s)" % fehler if fehler else ""))
    gerahmt = sorted(_markiert(c, g))
    erwarte(gerahmt == [(0, 3)], "wertvollste stimmt. Am Brett soll damit die wertvollste schwarze Figur rot gerahmt "
            "sein -- am Start die Dame auf Zeile 0, Spalte 3. Gerahmt ist: %s."
            % (", ".join(_wo(f) for f in gerahmt) or "kein Feld"))


def _modul(name):
    m = sys.modules.get(name)
    if m is not None:
        return m
    try:
        return importlib.import_module(name)
    except Exception:  # noqa: BLE001 -- dann gibt es das Modul fuer den Check nicht
        return None


def pruefe_70_alle_zuege():
    """Aufgabe 7 ★★★ · spieler_zuege.py: Der Spieler nennt alle Züge seiner Figuren -- keiner auf eine eigene"""
    m = _modul("spieler_zuege")
    k = getattr(m, "Spieler", None) if m is not None else None
    braucht(isinstance(k, type) and hasattr(k, "alle_zuege"), "Erst die Klasse Spieler mit alle_zuege in "
            "spieler_zuege.py.")
    s = erzeuge(k, "weiß")
    turm = erzeuge("Figur", "Turm", "weiß", 4, 2)
    bauer = erzeuge("Figur", "Bauer", "weiß", 6, 2)
    koenig = erzeuge("Figur", "König", "weiß", 4, 3)
    for f in (turm, bauer, koenig):
        rufe(s, "aufnehmen", f)
    zuege = rufe(s, "alle_zuege")
    erwarte(isinstance(zuege, list), "alle_zuege gibt %r zurück -- erwartet ist eine Liste von Zügen." % (zuege,))
    erwarte(zuege and all(type(z).__name__ == "Zug" for z in zuege), "In der Liste von alle_zuege stehen nicht nur "
            "Zug-Objekte.")
    ist = {(id(rufe(z, "get_figur")), rufe(z, "get_zeile"), rufe(z, "get_spalte")) for z in zuege}
    erwarte(all(i in (id(turm), id(bauer), id(koenig)) for i, _, _ in ist), "Ein Zug in der Liste hält keine der "
            "Figuren des Spielers -- im Zug steht die Figur selbst.")
    eigene = {(4, 2), (6, 2), (4, 3)}
    auf_eigene = sorted((z, sp) for _, z, sp in ist if (z, sp) in eigene)
    erwarte(not auf_eigene, "Die Auflage: kein Zug auf ein Feld, auf dem eine eigene Figur steht -- hier führt einer "
            "nach %s." % _wo(auf_eigene[0]) if auf_eigene else "")
    soll = set()
    for f, art, von in ((turm, "Turm", (4, 2)), (bauer, "Bauer", (6, 2)), (koenig, "König", (4, 3))):
        for z in range(8):
            for sp in range(8):
                if (z, sp) not in eigene and rufe(f, "passt", z, sp) is True:
                    soll.add((id(f), z, sp))
    erwarte(len(zuege) == len(ist), "In der Liste steht ein Zug doppelt.")
    erwarte(ist == soll, "Turm (4, 2), Bauer (6, 2), König (4, 3): alle_zuege nennt %d Züge, es sind %d -- jede Figur, "
            "jedes Feld, zu dem sie Ja sagt und auf dem keine eigene steht." % (len(ist), len(soll)))
    erwarte(not rufe(erzeuge(k, "schwarz"), "alle_zuege"), "Ein Spieler ohne Figuren hat keine Züge -- alle_zuege "
            "gibt keine leere Liste zurück.")


def pruefe_90_hints():
    """Hinweis · Jede Methode in spieler.py mit Type Hints (kein Stern)"""
    braucht(_ok(pruefe_20_spieler), "Erst steht der Spieler.")
    ohne, falsch, diagramm = [], [], []
    try:
        baum = ast.parse(quelltext("spieler.py"))
    except (SyntaxError, OSError, TypeError):
        return
    for k in ast.walk(baum):
        if not isinstance(k, ast.FunctionDef):
            continue
        for a in k.args.args + [k]:
            typ = a.annotation if isinstance(a, ast.arg) else a.returns
            if typ is not None and any(isinstance(x, ast.Name) and x.id in DIAGRAMMTYPEN for x in ast.walk(typ)):
                diagramm.append("%s (%s)" % (k.name, ast.unparse(typ)))
        parameter = [a for a in k.args.args if a.arg != "self"]
        if any(a.annotation is None for a in parameter) or (k.returns is None and k.name != "__init__"):
            ohne.append(k.name)
        elif k.name in HINTS and ast.unparse(k.returns).replace(" ", "") not in HINTS[k.name]:
            falsch.append("%s -> %s" % (k.name, " oder ".join(sorted(HINTS[k.name]))))
    erwarte(not diagramm, "Hier steht ein Typ in der Schreibweise des Diagramms: %s. In Python heißt er str, int, "
            "float oder bool." % ", ".join(diagramm))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer oder an einem Parameter): %s. Es läuft auch ohne; "
            "vereinbart ist es trotzdem." % ", ".join(ohne))
    erwarte(not falsch, "Dieser Type Hint passt nicht zu dem, was zurückkommt -- erwartet: %s." % ", ".join(falsch))
