# spieler_zuege.py -- Expertenaufgabe: ein
# Spieler, der alle seine Züge nennt.
# Kopiert eure Klasse Spieler hierher.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from zeichenflaeche import zeichne_bild
from figur import Figur
from zug import Zug
