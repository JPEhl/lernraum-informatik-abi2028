# weiss.py -- die weiße Seite als ein Objekt.
# Die Figur kommt aus figur.py (gekapselt,
# dazu bildname()).

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from zeichenflaeche import neue_flaeche, zeichne_bild, zeige
from figur import Figur

FELDGROESSE = 60
flaeche = neue_flaeche(8 * FELDGROESSE, 8 * FELDGROESSE)


def zeichne_felder() -> None:
    for zeile in range(8):
        for spalte in range(8):
            x = spalte * FELDGROESSE
            y = zeile * FELDGROESSE
            if (zeile + spalte) % 2 == 0:
                farbe = "#eeeed2"
            else:
                farbe = "#769656"
            flaeche.create_rectangle(x, y, x + FELDGROESSE, y + FELDGROESSE,
                                     fill=farbe, outline=farbe)


dame = Figur("Dame", "weiß", 7, 3)

zeichne_felder()
zeige()
