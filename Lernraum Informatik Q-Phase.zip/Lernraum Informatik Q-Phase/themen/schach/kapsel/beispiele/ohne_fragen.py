class Figur:

    def __init__(self, art: str, farbe: str,
                 zeile: int, spalte: int):
        self.art = art
        self.farbe = farbe
        self.__zeile = zeile
        self.__spalte = spalte

    def set_zeile(self, zeile: int) -> None:
        if zeile >= 0 and zeile <= 7:
            self.__zeile = zeile

    def get_zeile(self) -> int:
        return self.__zeile


dame = Figur("Dame", "weiß", 5, 3)
dame.zeile = 0
print(dame.get_zeile())
print(dame.zeile)
