"""Selbstcheck „Kapselung: Getter und Setter“ -- prueft das Programm im Ordner schach/ (es laeuft partie.py).

Die Klasse kapselt ihre figur.py aus bauplan. Der Check prueft die Klasse ueber OBJEKTE, die er selbst baut (LC8):
erzeuge, rufe, attribute -- mit Zeile ungleich Spalte (sonst faellt ein vertauschter Getter nicht auf).

Seit dem Umbau nach Schnitt A (15.11.2026) ist partie.py ein Programm mit Klick und drei Figuren. Das Brett liest
der Check deshalb an einem FRISCHEN Lauf, auf dem er klickt wie die Maus (klick_auf, LC6): Turm waehlen, ziehen,
Laeufer waehlen, ziehen -- gelesen wird, was man sieht. Ob partie.py die Figuren nur ueber Methoden liest, zeigt
derselbe Lauf mit `from figur_nummer import Figur` (die gegebene Figur, innen eine Nummer). Ob klick nur noch ziehen
ruft (Aufgabe 3 ★★), zeigt ein Lauf mit einer Probe-Figur, deren passt immer Nein sagt und deren ziehen trotzdem zieht.

ziehen prueft ab Aufgabe 3 ★★ selbst die Gangart. Bis dahin fragt der Check ziehen nur mit Zuegen, die zu einem Turm
passen -- so stimmen dieselben Pruefungen vor und nach der Stufe.

Startzustand (= nach_bauplan): die Grundlage passt, offen ist genau Aufgabe 2 ★ (die Attribute sind noch oeffentlich),
alles andere wartet.

Seit der Reihensichtung Teil I (16.11.2026, Befund 15, Probe K2): Ein Setter, der ein Feld des Bretts abweist (0 oder
7), liess die Figuren der Aufstellung auf Zeile 0 entstehen -- und rot wurde ZUERST „Aufgabe 2 · partie.py liest ueber
die Getter“, mit einer Meldung, die zu den Gettern schickte. Jetzt wartet die Brett-Pruefung von Aufgabe 2, sobald es
Setter gibt und eine Figur ihretwegen nicht auf ihr Feld kommt (_setter_stoeren_die_aufstellung); rot ist dann nur
Aufgabe 3, mit der Meldung zum Setter (LC3: ein Fehler faerbt nur seine eigene Pruefung).
"""
import ast
import importlib
import re
import sys
import types

import pruefen
from pruefen import erwarte, braucht, arbeit, flaeche, quelltext, anspielen, erzeuge, rufe, attribute, gedruckt, \
    klasse, klick_auf

TITEL = "Kapselung: Getter und Setter · Selbstcheck"
EINGABEN = []
HINTS = {"get_art": {"str"}, "get_farbe": {"str"}, "get_zeile": {"int"}, "get_spalte": {"int"},
         "set_zeile": {"None"}, "set_spalte": {"None"}, "get_wert": {"int"}, "ziehen": {"None", "bool"},
         "ist_gegner": {"bool"}, "passt": {"bool"}}
DIAGRAMMTYPEN = {"String", "integer", "boolean", "Integer", "Boolean"}
WERTE = (("Bauer", 1), ("Springer", 3), ("Läufer", 3), ("Turm", 5), ("Dame", 9), ("König", 0))
IMPORT = r"^from figur import Figur$"
DAME, TURM, LAEUFER = (7, 3), (7, 0), (7, 2)


def _soll(art, von, zeile, spalte):
    """Die Gangart aus bauplan: Turm gerade, Laeufer schraeg, Dame beides, sonst nie."""
    hoch, quer = abs(zeile - von[0]), abs(spalte - von[1])
    if hoch == 0 and quer == 0:
        return False
    if art == "Turm":
        return hoch == 0 or quer == 0
    if art == "Läufer":
        return hoch == quer
    if art == "Dame":
        return hoch == 0 or quer == 0 or hoch == quer
    return False


def _ziele(art, von):
    return {(z, s) for z in range(8) for s in range(8) if _soll(art, von, z, s)}


def _wo(feld):
    return "Zeile %d, Spalte %d" % tuple(feld)


class _ProbeFigur:
    """Dieselbe Schnittstelle wie die gekapselte Figur. passt sagt IMMER Nein, ziehen zieht trotzdem und sagt Ja --
    zieht eine Figur auf dem Brett, hat klick nur ziehen gerufen; bleibt sie stehen, hat klick vorher selbst gefragt."""

    def __init__(self, art, farbe, zeile, spalte):
        self._art, self._farbe, self._zeile, self._spalte = art, farbe, zeile, spalte

    def get_art(self):
        return self._art

    def get_farbe(self):
        return self._farbe

    def get_zeile(self):
        return self._zeile

    def get_spalte(self):
        return self._spalte

    def set_zeile(self, zeile):
        self._zeile = zeile

    def set_spalte(self, spalte):
        self._spalte = spalte

    def get_wert(self):
        return 0

    def ist_gegner(self, andere):
        return self._farbe != andere.get_farbe()

    def passt(self, zeile, spalte):
        return False

    def ziehen(self, zeile, spalte):
        self._zeile, self._spalte = zeile, spalte
        return True


def _spiel(ersetze=None, probe=False):
    """partie.py noch einmal, frisch. ersetze: (Muster, Ersatz) im Quelltext; probe: mit der Probe-Figur statt
    figur.py. Gibt (Flaeche, Feldgroesse, letzte Fehlerzeile) -- die Flaeche ist None, wenn das Programm nicht bis
    zum Ende lief."""
    alt_q = pruefen._QUELLE
    q = alt_q if ersetze is None else re.sub(ersetze[0], ersetze[1], alt_q, flags=re.M)
    pruefen._QUELLE = q + "\nprint('--ENDE--')\n"
    if probe:
        m = types.ModuleType("figur")
        m.Figur = _ProbeFigur
        sys.modules["figur"] = m
    try:
        aus, ns = anspielen([])
    finally:
        pruefen._QUELLE = alt_q
        if probe:
            sys.modules.pop("figur", None)
    zeilen = [z for z in aus.strip().splitlines() if z.strip() and "--ENDE--" not in z]
    fehler = zeilen[-1] if zeilen and "Error" in zeilen[-1] else ""
    return (ns.get("flaeche") if "--ENDE--" in aus else None), ns.get("FELDGROESSE"), fehler


def _klick(c, feld, g):
    """Klickt wie die Maus mitten auf das Feld -- auf der Flaeche c eines frischen Laufs. Gibt, was in der Shell
    erschien."""
    alt = pruefen._FENSTER
    pruefen._FENSTER = c.winfo_toplevel()
    try:
        return klick_auf(feld[1] * g + g // 2, feld[0] * g + g // 2, wo=_wo(feld))
    finally:
        pruefen._FENSTER = alt


def _bild(c, feld, g):
    """Das Bild, das man auf dem Feld SIEHT („dame-w.png“) -- None, wenn dort keins liegt."""
    x, y = feld[1] * g + g // 2, feld[0] * g + g // 2
    for i in reversed(c.find_all()):
        if c.type(i) == "image":
            b = c.bbox(i)
            if b and b[0] <= x < b[2] and b[1] <= y < b[3]:
                return pruefen._bilddatei(c, c.itemcget(i, "image"))
    return None


def _markiert(c, g):
    """Die markierten Felder auf c als Menge von (zeile, spalte): das rot gerahmte Feld der gewaehlten Figur und die
    Felder mit einem Punkt -- ihre Ziele (seit 16.11.2026; ein Rahmen als Ziel zaehlt weiter)."""
    felder = set()
    for i in c.find_all():
        if c.type(i) == "rectangle" and not c.itemcget(i, "fill") and c.itemcget(i, "outline"):
            x1, y1, x2, y2 = (round(v) for v in c.coords(i))
            if x1 % g == 0 and y1 % g == 0 and x2 - x1 == g and y2 - y1 == g:
                felder.add((y1 // g, x1 // g))
        elif c.type(i) == "oval":
            # ein Punkt mitten im Feld: ein Ziel (seit 16.11.2026 zeichnet zeige_ziele Punkte statt Rahmen)
            x1, y1, x2, y2 = (round(v) for v in c.coords(i))
            if (x1 + x2) // 2 % g == g // 2 and (y1 + y2) // 2 % g == g // 2:
                felder.add(((y1 + y2) // 2 // g, (x1 + x2) // 2 // g))
    return felder


def _durchspielen(c, g, womit, ziele=_ziele):
    """Das Brett wie nach bauplan: Dame gewaehlt, Turm waehlen und ziehen, Laeufer waehlen und ziehen. womit steht
    vorn in jeder Meldung („Mit figur_nummer.py “). ziele(art, von) nennt die Felder, die markiert sein sollen."""
    _ziele = ziele
    erwarte(_bild(c, DAME, g) == "dame-w.png" and _bild(c, TURM, g) == "turm-w.png"
            and _bild(c, LAEUFER, g) == "laeufer-w.png", "%sstehen Dame, Turm und Läufer am Start nicht auf Zeile 7, "
            "Spalte 3, 0 und 2." % (womit or "Am Brett "))
    erwarte(_markiert(c, g) == {DAME} | _ziele("Dame", DAME), "%ssind am Start nicht das Feld der Dame und ihre Ziele "
            "markiert." % (womit or "Am Brett "))
    _klick(c, TURM, g)
    erwarte(_markiert(c, g) == {TURM} | _ziele("Turm", TURM), "%swählt ein Klick auf den Turm ihn nicht: Markiert sind "
            "nicht sein Feld und seine Ziele." % womit)
    _klick(c, (4, 0), g)
    erwarte(_bild(c, (4, 0), g) == "turm-w.png" and _bild(c, TURM, g) != "turm-w.png", "%szieht der gewählte Turm "
            "nicht nach Zeile 4, Spalte 0." % womit)
    _klick(c, LAEUFER, g)
    _klick(c, (5, 4), g)
    erwarte(_bild(c, (5, 4), g) == "laeufer-w.png" and _bild(c, LAEUFER, g) != "laeufer-w.png", "%szieht der gewählte "
            "Läufer nicht nach Zeile 5, Spalte 4." % womit)


def _ziele_der_klasse(art, von):
    """Die Felder, zu denen die Figur der KLASSE Ja sagt. So prueft Aufgabe 2 nur, ob partie.py richtig liest -- ob
    passt selbst stimmt, sagt Aufgabe 2 ★★ (ein Fehler faerbt nur seine eigene Pruefung)."""
    figur = erzeuge("Figur", art, "weiß", *von)
    return {(z, s) for z in range(8) for s in range(8) if rufe(figur, "passt", z, s) is True}


def _modul(name):
    m = sys.modules.get(name)
    if m is not None:
        return m
    try:
        return importlib.import_module(name)
    except Exception:  # noqa: BLE001 -- dann gibt es das Modul fuer den Check nicht
        return None


def _ok(pruefung):
    """Passt eine Pruefung? (nur fuer braucht -- faengt den Befund, LC8)"""
    try:
        pruefung()
    except AssertionError:
        return False
    return True


def _getter(figur, name):
    """Der Wert ueber den Getter -- None, wenn es den Getter nicht gibt."""
    if not hasattr(figur, "get_" + name):
        return None
    return rufe(figur, "get_" + name)


def _feld_von(figur):
    return (rufe(figur, "get_zeile"), rufe(figur, "get_spalte"))


def _setter_stoeren_die_aufstellung():
    """Gibt es schon Setter (Aufgabe 3) -- und kommt eine Figur ihretwegen nicht auf ein Feld der Aufstellung? Dann
    ist das ein Fehler von Aufgabe 3: pruefe_30_setter zeigt ihn, die Brett-Pruefung von Aufgabe 2 wartet. Ohne Setter
    (der Stand nach Aufgabe 2) stoert nichts; einen Konstruktor, der Zeile und Spalte verwechselt, zeigt schon
    pruefe_20_privat."""
    k = klasse("Figur")
    if k is None or not (hasattr(k, "set_zeile") or hasattr(k, "set_spalte")):
        return False
    try:
        return any(_feld_von(erzeuge("Figur", "Turm", "weiß", *feld)) != feld for feld in (DAME, TURM, LAEUFER, (0, 5)))
    except AssertionError:
        return True


def pruefe_00_grundlage():
    """Grundlage · figur.py lädt, und partie.py hat eine Zeichenfläche"""
    erwarte(klasse("Figur") is not None, "In figur.py steht keine Klasse Figur mehr -- partie.py bricht beim Laden "
            "ab. Seht in der Shell nach.")
    erwarte(flaeche() is not None, "Das Programm bricht ab, bevor es eine Zeichenfläche hat -- seht in der Shell nach.")
    g = getattr(arbeit(), "FELDGROESSE", None)
    erwarte(isinstance(g, int) and g > 0, "FELDGROESSE ist keine ganze Zahl über 0 -- oben in partie.py.")


def pruefe_20_privat():
    """Aufgabe 2 · zeile und spalte sind privat, die Getter nennen das Feld"""
    braucht(klasse("Figur") is not None, "Erst lädt figur.py wieder.")
    turm = erzeuge("Figur", "Turm", "schwarz", 2, 5)
    werte = attribute(turm)
    offen = [n for n in ("zeile", "spalte") if n in werte.oeffentlich]
    erwarte(not offen, "Eine Figur zeigt %s noch offen -- von außen kann jeder es ändern. Im Diagramm steht davor ein "
            "Minus." % " und ".join(offen))
    fehlt = [n for n in ("__zeile", "__spalte") if n not in werte]
    erwarte(not fehlt, "Figur('Turm', 'schwarz', 2, 5) hat kein Attribut %s -- wie heißt es im Konstruktor?"
            % ", ".join(fehlt))
    ohne = [m for m in ("get_zeile", "get_spalte") if not hasattr(klasse("Figur"), m)]
    erwarte(not ohne, "Noch ohne Getter: %s -- wie liest partie.py sonst das Feld?" % ", ".join(ohne))
    z = rufe(turm, "get_zeile")
    erwarte(not (z is None and gedruckt().strip()), "get_zeile zeigt die Zeile in der Shell an, statt sie "
            "zurückzugeben.")
    s = rufe(turm, "get_spalte")
    erwarte(not (s is None and gedruckt().strip()), "get_spalte zeigt die Spalte in der Shell an, statt sie "
            "zurückzugeben.")
    erwarte((z, s) == (2, 5), "Figur('Turm', 'schwarz', 2, 5): get_zeile() gibt %r, get_spalte() gibt %r -- erwartet "
            "2 und 5." % (z, s))
    rufe(turm, "ziehen", 2, 0)
    z, s = _feld_von(turm)
    erwarte((z, s) == (2, 0), "Nach turm.ziehen(2, 0) sagen die Getter Zeile %r, Spalte %r -- schreibt ziehen noch in "
            "das alte Attribut, oder liest passt es noch?" % (z, s))


def pruefe_22_partie():
    """Aufgabe 2 · partie.py liest die drei Figuren über die Getter -- auch mit figur_nummer.py"""
    braucht(_ok(pruefe_20_privat), "Erst sind zeile und spalte privat, mit Gettern.")
    braucht(not _setter_stoeren_die_aufstellung(), "Es gibt schon Setter, und mit ihnen kommt eine Figur nicht auf "
            "jedes Feld des Bretts -- das zeigt Aufgabe 3. Danach sieht der Selbstcheck wieder auf das Brett.")
    c, g, fehler = _spiel()
    erwarte(c is not None, "Die Figur ist gekapselt, aber partie.py bricht ab, bevor das Brett fertig ist%s -- liest "
            "es eine Figur noch direkt, oder liest passt in figur.py noch das alte Attribut?"
            % (" (%s)" % fehler if fehler else ""))
    _durchspielen(c, g, "", _ziele_der_klasse)
    c2, g2, fehler = _spiel(ersetze=(IMPORT, "from figur_nummer import Figur"))
    erwarte(c2 is not None, "Mit figur_nummer.py bricht partie.py ab%s -- es liest eine Figur noch an einer Stelle ohne "
            "Methode." % (" (%s)" % fehler if fehler else ""))
    _durchspielen(c2, g2, "Mit figur_nummer.py ")


def pruefe_25_alle_privat():
    """Aufgabe 2 ★★ · Auch art und farbe sind privat -- get_wert, passt und ist_gegner stimmen weiter"""
    braucht(_ok(pruefe_20_privat), "Erst sind zeile und spalte privat, mit Gettern.")
    laeufer = erzeuge("Figur", "Läufer", "weiß", 6, 1)
    werte = attribute(laeufer)
    offen = sorted(werte.oeffentlich)
    erwarte(not offen, "Eine Figur zeigt noch offen: %s." % ", ".join(offen))
    erwarte((_getter(laeufer, "art"), _getter(laeufer, "farbe")) == ("Läufer", "weiß"),
            "Figur('Läufer', 'weiß', 6, 1): get_art() und get_farbe() geben %r und %r zurück."
            % (_getter(laeufer, "art"), _getter(laeufer, "farbe")))
    falsch = ["%s %r statt %d" % (art, rufe(erzeuge("Figur", art, "weiß", 1, 2), "get_wert"), w) for art, w in WERTE
              if rufe(erzeuge("Figur", art, "weiß", 1, 2), "get_wert") != w]
    erwarte(not falsch, "get_wert gibt zurück: %s." % ", ".join(falsch))
    for art in ("Turm", "Läufer", "Dame"):
        figur = erzeuge("Figur", art, "weiß", 4, 2)
        ja = {(z, s) for z in range(8) for s in range(8) if rufe(figur, "passt", z, s) is True}
        erwarte(ja == _ziele(art, (4, 2)), "passt stimmt für %s nicht mehr -- liest es die Art noch aus dem alten "
                "Attribut?" % {"Turm": "den Turm", "Läufer": "den Läufer", "Dame": "die Dame"}[art])
    falsch = []
    for a, b, soll in (("weiß", "schwarz", True), ("schwarz", "weiß", True), ("weiß", "weiß", False),
                       ("schwarz", "schwarz", False)):
        antwort = rufe(erzeuge("Figur", "Dame", a, 3, 3), "ist_gegner", erzeuge("Figur", "Turm", b, 0, 7))
        if antwort is not soll:
            falsch.append("%s fragt %s: %r statt %r" % (a, b, antwort, soll))
    erwarte(not falsch, "ist_gegner antwortet: %s." % "; ".join(falsch))


def pruefe_30_setter():
    """Aufgabe 3 · Die Setter lassen die Figur nicht vom Brett -- ziehen und der Konstruktor gehen über sie"""
    braucht(_ok(pruefe_20_privat), "Erst die Getter (Aufgabe 2) -- über sie sieht der Check nach.")
    ohne = [m for m in ("set_zeile", "set_spalte") if not hasattr(klasse("Figur"), m)]
    erwarte(not ohne, "Noch ohne Setter: %s." % ", ".join(ohne))
    falsch = []
    for name, start, probe, soll in (("zeile", 2, 7, 7), ("zeile", 2, 0, 0), ("zeile", 2, 8, 2), ("zeile", 2, -1, 2),
                                     ("zeile", 2, 99, 2), ("spalte", 5, 7, 7), ("spalte", 5, 0, 0),
                                     ("spalte", 5, 8, 5), ("spalte", 5, -1, 5)):
        figur = erzeuge("Figur", "Turm", "schwarz", 2, 5)
        rufe(figur, "set_" + name, probe)
        ist = rufe(figur, "get_" + name)
        if ist != soll:
            falsch.append("set_%s(%d) → get_%s() %r statt %r" % (name, probe, name, ist, soll))
    erwarte(not falsch, "Eine Figur auf Zeile 2, Spalte 5: %s." % "; ".join(falsch))
    falsch = []
    # nur Zuege, die zu einem Turm passen (in seiner Zeile oder Spalte): Sie gelten vor und nach Aufgabe 3 ★★
    for probe, soll in (((2, 0), (2, 0)), ((7, 5), (7, 5)), ((2, 9), (2, 5)), ((-1, 5), (2, 5))):
        figur = erzeuge("Figur", "Turm", "schwarz", 2, 5)
        rufe(figur, "ziehen", *probe)
        ist = _feld_von(figur)
        if ist != soll:
            falsch.append("ziehen%s → %s statt %s" % (probe, ist, soll))
    erwarte(not falsch, "Ein Turm auf Zeile 2, Spalte 5: %s -- geht ziehen über die Setter?" % "; ".join(falsch))
    falsch = []
    for angaben, soll in (((99, 0), (0, 0)), ((3, 12), (3, 0)), ((-2, -2), (0, 0)), ((6, 1), (6, 1))):
        figur = erzeuge("Figur", "Turm", "schwarz", *angaben)
        ist = _feld_von(figur)
        if ist != soll:
            falsch.append("Figur('Turm', 'schwarz', %d, %d) steht auf %s statt %s" % (angaben + (ist, soll)))
    erwarte(not falsch, "%s -- geht der Konstruktor am Setter vorbei?" % "; ".join(falsch))


def pruefe_35_regel():
    """Aufgabe 3 ★★ · Kein Zug an der Regel vorbei: ziehen prüft selbst und sagt, ob der Zug galt"""
    braucht(_ok(pruefe_30_setter), "Erst die zwei Setter.")
    for art, von, nein, ja in (("Turm", (2, 5), (4, 6), (2, 0)), ("Läufer", (6, 1), (6, 5), (4, 3))):
        ein = {"Turm": "Ein Turm", "Läufer": "Ein Läufer"}[art]
        figur = erzeuge("Figur", art, "weiß", *von)
        antwort = rufe(figur, "ziehen", *nein)
        erwarte(_feld_von(figur) == von, "%s auf %s zieht mit ziehen(%d, %d) auf ein Feld, das nicht zu ihm passt -- "
                "die Figur prüft ihren Zug noch nicht selbst." % (ein, _wo(von), nein[0], nein[1]))
        erwarte(antwort is not None, "%s bleibt bei einem Zug, der nicht passt, stehen -- aber ziehen sagt es "
                "niemandem: Es gibt nichts zurück." % ein)
        erwarte(antwort is False, "%s auf %s: ziehen(%d, %d) passt nicht und gibt trotzdem %r zurück."
                % (ein, _wo(von), nein[0], nein[1], antwort))
        antwort = rufe(figur, "ziehen", *ja)
        erwarte(_feld_von(figur) == ja, "%s auf %s zieht mit ziehen(%d, %d) nicht, obwohl das Feld zu ihm passt."
                % (ein, _wo(von), ja[0], ja[1]))
        erwarte(antwort is True, "%s auf %s: ziehen(%d, %d) gilt und gibt %r zurück statt True."
                % (ein, _wo(von), ja[0], ja[1], antwort))
    braucht(_ok(pruefe_22_partie), "ziehen prüft und antwortet. Jetzt fehlt nur noch partie.py -- erst läuft es wieder "
            "mit den Gettern (Aufgabe 2).")
    c, g, fehler = _spiel(probe=True)
    erwarte(c is not None, "partie.py bricht ab, bevor das Brett fertig ist%s." % (" (%s)" % fehler if fehler else ""))
    _klick(c, (4, 3), g)
    erwarte(_bild(c, (4, 3), g) == "dame-w.png", "ziehen prüft jetzt selbst. In partie.py fragt klick vor dem Zug aber "
            "noch mit passt -- so prüfen zwei Stellen. klick ruft nur noch ziehen.")


def pruefe_60_feld():
    """Aufgabe 6 ★★ · figur_feld.py: dieselbe Schnittstelle, innen das Feld als Text"""
    m = _modul("figur_feld")
    k = getattr(m, "Figur", None) if m is not None else None
    braucht(isinstance(k, type), "Erst die Klasse Figur in figur_feld.py.")
    braucht(all(hasattr(k, n) for n in ("get_zeile", "get_spalte", "set_zeile", "set_spalte", "passt", "ziehen")),
            "Erst hat die Figur in figur_feld.py Getter, Setter, passt und ziehen.")
    braucht(_ok(pruefe_22_partie), "Erst liest partie.py die Figuren über die Getter (Aufgabe 2) -- sonst kann der "
            "Check eure Figur nicht eintauschen.")
    dame = erzeuge(k, "Dame", "weiß", 3, 3)
    werte = attribute(dame)
    zahlen = sorted(n for n, w in werte.items() if isinstance(w, int) and not isinstance(w, bool))
    erwarte(not zahlen, "Die Auflage: kein Attribut hält Zeile oder Spalte als Zahl -- hier: %s." % ", ".join(zahlen))
    erwarte("d5" in werte.values(), "Die Dame auf Zeile 3, Spalte 3 hält nicht den Text 'd5' -- Spalte 3 ist d, Zeile 3 "
            "ist 5.")
    falsch = []
    for z in range(8):
        for sp in range(8):
            f = erzeuge(k, "Turm", "schwarz", z, sp)
            if (rufe(f, "get_zeile"), rufe(f, "get_spalte")) != (z, sp):
                falsch.append("(%d, %d)" % (z, sp))
    erwarte(not falsch, "Diese Felder kommen anders zurück, als sie gebaut wurden: %s." % ", ".join(falsch[:6]))
    # ziehen nur mit Zügen, die zu einem Turm passen -- so stimmt die Probe vor und nach Aufgabe 3 ★★
    falsch = []
    for angaben, schritte, soll in (((99, 0), [], (0, 0)), ((2, 5), [("set_zeile", 8)], (2, 5)),
                                    ((2, 5), [("set_spalte", -1)], (2, 5)), ((2, 5), [("set_zeile", 0)], (0, 5)),
                                    ((2, 5), [("set_spalte", 7)], (2, 7)), ((2, 5), [("ziehen", 7, 5)], (7, 5)),
                                    ((2, 5), [("ziehen", 2, 0)], (2, 0))):
        f = erzeuge(k, "Turm", "schwarz", *angaben)
        for schritt in schritte:
            rufe(f, *schritt)
        ist = (rufe(f, "get_zeile"), rufe(f, "get_spalte"))
        if ist != soll:
            falsch.append("Figur%s, %s → %s statt %s" % (angaben, schritte, ist, soll))
    erwarte(not falsch, "%s." % "; ".join(falsch))
    for art in ("Turm", "Läufer", "Dame"):
        figur = erzeuge(k, art, "weiß", 4, 2)
        ja = {(z, sp) for z in range(8) for sp in range(8) if rufe(figur, "passt", z, sp) is True}
        erwarte(ja == _ziele(art, (4, 2)), "In figur_feld.py stimmt passt für die Art %s nicht mehr -- woher liest "
                "passt jetzt die Zeile und die Spalte der Figur?" % art)
    c2, g2, fehler = _spiel(ersetze=(IMPORT, "from figur_feld import Figur"))
    erwarte(c2 is not None, "Mit from figur_feld import Figur bricht partie.py ab%s -- fehlt der Schnittstelle etwas?"
            % (" (%s)" % fehler if fehler else ""))
    _durchspielen(c2, g2, "Mit figur_feld.py ")


def pruefe_70_gezogen():
    """Aufgabe 7 ★★★ · figur_gezogen.py: Die Figur merkt sich, ob sie gezogen hat -- ohne Setter, der Bauer fragt es"""
    m = _modul("figur_gezogen")
    k = getattr(m, "Figur", None) if m is not None else None
    braucht(isinstance(k, type) and hasattr(k, "hat_gezogen"), "Erst die Klasse Figur mit hat_gezogen in "
            "figur_gezogen.py.")
    for art in ("Turm", "Läufer", "Dame"):
        figur = erzeuge(k, art, "weiß", 4, 2)
        ja = {(z, s) for z in range(8) for s in range(8) if rufe(figur, "passt", z, s) is True}
        erwarte(ja == _ziele(art, (4, 2)), "In figur_gezogen.py stimmt passt für die Art %s nicht mehr -- kopiert eure "
                "Klasse erst ganz herüber." % art)
    turm = erzeuge(k, "Turm", "weiß", 4, 2)
    erwarte(rufe(turm, "hat_gezogen") is False, "Eine neue Figur hat noch nicht gezogen -- hat_gezogen() gibt %r."
            % (rufe(turm, "hat_gezogen"),))
    rufe(turm, "ziehen", 5, 5)
    erwarte(rufe(turm, "hat_gezogen") is False, "Ein Turm auf Zeile 4, Spalte 2: ziehen(5, 5) gilt nicht -- trotzdem "
            "sagt hat_gezogen() danach %r." % (rufe(turm, "hat_gezogen"),))
    rufe(turm, "ziehen", 4, 6)
    erwarte(rufe(turm, "hat_gezogen") is True, "Der Turm ist nach Zeile 4, Spalte 6 gezogen -- hat_gezogen() sagt %r."
            % (rufe(turm, "hat_gezogen"),))
    rufe(turm, "ziehen", 5, 5)
    erwarte(rufe(turm, "hat_gezogen") is True, "Wer einmal gezogen hat, hat gezogen -- nach einem Zug, der nicht galt, "
            "sagt hat_gezogen() wieder False.")
    offen = sorted(attribute(turm).oeffentlich)
    erwarte(not offen, "Die Auflage: kein öffentliches Attribut -- hier: %s." % ", ".join(offen))
    setter = sorted(n for n in dir(k) if n.startswith("set_") and n not in ("set_zeile", "set_spalte"))
    erwarte(not setter, "Die Auflage: Von außen stellt niemand ein, ob eine Figur gezogen hat -- hier: %s."
            % ", ".join(setter))
    weiss = erzeuge(k, "Bauer", "weiß", 4, 4)
    for feld, soll in (((2, 4), True), ((3, 4), True), ((5, 4), False), ((1, 4), False), ((3, 5), False)):
        antwort = rufe(weiss, "passt", *feld)
        erwarte(antwort is soll, "Ein weißer Bauer auf Zeile 4, Spalte 4, der noch nicht gezogen hat, antwortet auf "
                "passt(%d, %d) mit %r statt %r." % (feld[0], feld[1], antwort, soll))
    rufe(weiss, "ziehen", 3, 4)
    for feld, soll in (((1, 4), False), ((2, 4), True)):
        antwort = rufe(weiss, "passt", *feld)
        erwarte(antwort is soll, "Der weiße Bauer ist nach Zeile 3 gezogen. Danach antwortet er auf passt(%d, %d) mit "
                "%r statt %r." % (feld[0], feld[1], antwort, soll))
    schwarz = erzeuge(k, "Bauer", "schwarz", 3, 2)
    rufe(schwarz, "ziehen", 3, 5)
    erwarte(rufe(schwarz, "passt", 5, 2) is True, "Ein schwarzer Bauer auf Zeile 3, Spalte 2: Sein erster Versuch "
            "galt nicht -- zwei Felder vor darf er weiter, passt(5, 2) gibt aber %r." % (rufe(schwarz, "passt", 5, 2),))
    rufe(schwarz, "ziehen", 4, 2)
    erwarte(rufe(schwarz, "passt", 6, 2) is False and rufe(schwarz, "passt", 5, 2) is True, "Der schwarze Bauer ist "
            "nach Zeile 4 gezogen -- jetzt darf er ein Feld vor, nicht mehr zwei.")
    sechs = False
    for f in ast.walk(ast.parse(quelltext("figur_gezogen.py"))):
        if isinstance(f, ast.FunctionDef) and f.name == "passt":
            sechs = any(isinstance(v, ast.Constant) and v.value == 6 for v in ast.walk(f))
    erwarte(not sechs, "Der Bauer zieht richtig. In passt steht aber noch die Startzeile 6 -- die Auflage ist: keine "
            "Startzeile mehr.")


def pruefe_90_hints():
    """Hinweis · Jede Methode in figur.py mit Type Hints (kein Stern)"""
    try:
        baum = ast.parse(quelltext("figur.py"))
    except SyntaxError:
        return
    ohne, falsch, diagramm = [], [], []
    for k in ast.walk(baum):
        if not isinstance(k, ast.FunctionDef):
            continue
        for a in k.args.args + [k]:
            typ = a.annotation if isinstance(a, ast.arg) else a.returns
            if typ is not None and any(isinstance(x, ast.Name) and x.id in DIAGRAMMTYPEN for x in ast.walk(typ)):
                diagramm.append("%s (%s)" % (k.name, ast.unparse(typ)))
        parameter = [a for a in k.args.args if a.arg != "self"]
        if any(a.annotation is None for a in parameter) or (k.returns is None and k.name != "__init__"):
            ohne.append(k.name)
        elif k.name in HINTS and ast.unparse(k.returns).replace(" ", "") not in HINTS[k.name]:
            falsch.append("%s -> %s" % (k.name, " oder ".join(sorted(HINTS[k.name]))))
    erwarte(not diagramm, "Hier steht ein Typ in der Schreibweise des Diagramms: %s. In Python heißt er str, int, "
            "float oder bool." % ", ".join(diagramm))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer oder an einem Parameter): %s. Es läuft auch ohne; "
            "vereinbart ist es trotzdem -- der Konstruktor braucht hinter der Klammer keinen." % ", ".join(ohne))
    erwarte(not falsch, "Dieser Type Hint passt nicht zu dem, was zurückkommt -- erwartet: %s." % ", ".join(falsch))
