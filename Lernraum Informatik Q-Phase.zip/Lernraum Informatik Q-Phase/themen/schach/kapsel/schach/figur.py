# figur.py -- die Klasse Figur, nach
# ihrem Klassendiagramm geschrieben. Eine
# Figur weiß, wie ihre Art zieht: passt.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations


class Figur:

    def __init__(self, art: str, farbe: str, zeile: int, spalte: int):
        self.art = art
        self.farbe = farbe
        self.zeile = zeile
        self.spalte = spalte

    def get_wert(self) -> int:
        if self.art == "Bauer":
            return 1
        elif self.art == "Springer" or self.art == "Läufer":
            return 3
        elif self.art == "Turm":
            return 5
        elif self.art == "Dame":
            return 9
        else:
            return 0

    def ziehen(self, zeile: int, spalte: int) -> None:
        self.zeile = zeile
        self.spalte = spalte

    def ist_gegner(self, andere: Figur) -> bool:
        return self.farbe != andere.farbe

    def passt(self, zeile: int, spalte: int) -> bool:
        hoch = abs(zeile - self.zeile)
        quer = abs(spalte - self.spalte)
        if hoch == 0 and quer == 0:
            return False
        if self.art == "Turm":
            return hoch == 0 or quer == 0
        elif self.art == "Läufer":
            return hoch == quer
        elif self.art == "Dame":
            return hoch == 0 or quer == 0 or hoch == quer
        else:
            return False
