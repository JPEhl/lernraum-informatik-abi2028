# figur_gezogen.py -- Expertenaufgabe: die
# Figur merkt sich, ob sie gezogen hat.
# Kopiert eure Klasse Figur hierher.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
