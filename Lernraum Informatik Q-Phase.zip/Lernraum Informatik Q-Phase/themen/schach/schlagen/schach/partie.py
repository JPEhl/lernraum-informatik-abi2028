# partie.py -- das Schachbrett.
# Vorbereitet für dieses Thema: Steht am
# Ziel eine Figur, fragt klick schlaegt
# (neu in figur.py) statt passt.

from zeichenflaeche import neue_flaeche, zeichne_bild, bei_klick, zeige
from figur import Figur
from zug import Zug
from bedrohung import Bedrohung
from spieler import Spieler

FELDGROESSE = 60
HELL = "#eeeed2"
DUNKEL = "#769656"

flaeche = neue_flaeche(8 * FELDGROESSE, 8 * FELDGROESSE)


# ------------------------ das Brett

def zeichne_felder() -> None:
    for zeile in range(8):
        for spalte in range(8):
            x = spalte * FELDGROESSE
            y = zeile * FELDGROESSE
            if (zeile + spalte) % 2 == 0:
                farbe = HELL
            else:
                farbe = DUNKEL
            flaeche.create_rectangle(x, y, x + FELDGROESSE, y + FELDGROESSE,
                                     fill=farbe, outline=farbe)


def zeichne_figur(name: str, zeile: int, spalte: int) -> None:
    zeichne_bild(name, spalte * FELDGROESSE, zeile * FELDGROESSE, FELDGROESSE)


def hebe_hervor(zeile: int, spalte: int) -> None:
    x = spalte * FELDGROESSE
    y = zeile * FELDGROESSE
    flaeche.create_rectangle(x, y, x + FELDGROESSE, y + FELDGROESSE,
                             outline="red", width=4)


def zeichne_punkt(zeile: int, spalte: int) -> None:
    x = spalte * FELDGROESSE + FELDGROESSE // 2
    y = zeile * FELDGROESSE + FELDGROESSE // 2
    r = FELDGROESSE // 6
    if (zeile + spalte) % 2 == 0:
        farbe = "#babaa4"
    else:
        farbe = "#5c7543"
    flaeche.create_oval(x - r, y - r, x + r, y + r,
                        fill=farbe, outline=farbe)


def zeichne_pfeil(zug: Zug) -> None:
    mitte = FELDGROESSE // 2
    x1 = zug.get_start_spalte() * FELDGROESSE + mitte
    y1 = zug.get_start_zeile() * FELDGROESSE + mitte
    x2 = zug.get_spalte() * FELDGROESSE + mitte
    y2 = zug.get_zeile() * FELDGROESSE + mitte
    flaeche.create_line(x1, y1, x2, y2, fill="#1565c0", width=6,
                        arrow="last", arrowshape=(18, 22, 7))


def zeichne_bedrohung(bedrohung: Bedrohung) -> None:
    if bedrohung.ist_echt():
        mitte = FELDGROESSE // 2
        angreifer = bedrohung.get_angreifer()
        ziel = bedrohung.get_ziel()
        x1 = angreifer.get_spalte() * FELDGROESSE + mitte
        y1 = angreifer.get_zeile() * FELDGROESSE + mitte
        x2 = ziel.get_spalte() * FELDGROESSE + mitte
        y2 = ziel.get_zeile() * FELDGROESSE + mitte
        flaeche.create_line(x1, y1, x2, y2,
                            fill="red", width=4,
                            arrow="last",
                            arrowshape=(14, 17, 6))


# ------------------------ die Aufstellung

ARTEN = ["Turm", "Springer", "Läufer", "Dame",
         "König", "Läufer", "Springer", "Turm"]

weiss = Spieler("weiß")
schwarz = Spieler("schwarz")
for spalte in range(8):
    schwarz.aufnehmen(Figur(ARTEN[spalte], "schwarz", 0, spalte))
    schwarz.aufnehmen(Figur("Bauer", "schwarz", 1, spalte))
    weiss.aufnehmen(Figur("Bauer", "weiß", 6, spalte))
    weiss.aufnehmen(Figur(ARTEN[spalte], "weiß", 7, spalte))
gewaehlt = None
letzter_zug = None


def figur_auf_feld(zeile: int, spalte: int) -> Figur:
    figur = weiss.finde_figur(zeile, spalte)
    if figur == None:
        figur = schwarz.finde_figur(zeile, spalte)
    return figur


def zeige_ziele() -> None:
    for zeile in range(8):
        for spalte in range(8):
            figur = figur_auf_feld(zeile, spalte)
            if figur == None:
                if gewaehlt.passt(zeile, spalte):
                    zeichne_punkt(zeile, spalte)
            else:
                zeichne_bedrohung(Bedrohung(gewaehlt, figur))


def zeichne_alles() -> None:
    flaeche.delete("all")
    zeichne_felder()
    weiss.zeichne_alle(FELDGROESSE)
    schwarz.zeichne_alle(FELDGROESSE)
    if gewaehlt != None:
        hebe_hervor(gewaehlt.get_zeile(), gewaehlt.get_spalte())
        zeige_ziele()
    if letzter_zug != None:
        zeichne_pfeil(letzter_zug)


# ------------------------ der Klick

def klick(x: int, y: int) -> None:
    global gewaehlt, letzter_zug
    spalte = x // FELDGROESSE
    zeile = y // FELDGROESSE
    figur = figur_auf_feld(zeile, spalte)
    if gewaehlt == None:
        gewaehlt = figur
    elif figur != None and not gewaehlt.ist_gegner(figur):
        gewaehlt = figur
    else:
        if figur == None:
            erlaubt = gewaehlt.passt(zeile, spalte)
        else:
            erlaubt = gewaehlt.schlaegt(zeile, spalte)
        if erlaubt:
            zug = Zug(gewaehlt, zeile, spalte)
            zug.ausfuehren()
            letzter_zug = zug
            gewaehlt = None
            print("Weiß:", weiss.materialwert(),
                  "Schwarz:", schwarz.materialwert())
    zeichne_alles()


zeichne_alles()
bei_klick(klick)
zeige()
