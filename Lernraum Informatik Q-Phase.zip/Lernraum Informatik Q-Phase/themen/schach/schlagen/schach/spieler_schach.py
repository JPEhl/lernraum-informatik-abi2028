# spieler_schach.py -- Expertenaufgabe:
# ein Spieler, der weiß, ob sein König im
# Schach steht. Kopiert eure Klasse
# Spieler hierher.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from zeichenflaeche import zeichne_bild
from figur import Figur
