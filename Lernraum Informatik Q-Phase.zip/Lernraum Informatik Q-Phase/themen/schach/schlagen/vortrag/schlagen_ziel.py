# schlagen.py -- die Dame schlägt.
# Das Brett zeichnet brett.py.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from brett import FELDGROESSE, zeichne_felder, zeichne_pfeil, hebe_hervor, zeige
from zeichenflaeche import zeichne_bild
from figur import Figur
from zug import Zug

ARTEN = ["Turm", "Springer", "Läufer", "Dame",
         "König", "Läufer", "Springer", "Turm"]


class Spieler:

    def __init__(self, farbe: str):
        self.__farbe = farbe
        self.__figuren: list[Figur] = []

    def aufnehmen(self, figur: Figur) -> None:
        self.__figuren.append(figur)

    def zeichne_alle(self, groesse: int) -> None:
        for figur in self.__figuren:
            zeichne_bild(figur.bildname(), figur.get_spalte() * groesse,
                         figur.get_zeile() * groesse, groesse)

    def materialwert(self) -> int:
        summe = 0
        for figur in self.__figuren:
            summe = summe + figur.get_wert()
        return summe

    def finde_figur(self, zeile: int, spalte: int) -> Figur:
        for figur in self.__figuren:
            if figur.get_zeile() == zeile and figur.get_spalte() == spalte:
                return figur
        return None

    def entferne(self, figur: Figur) -> None:
        self.__figuren.remove(figur)


dame = Figur("Dame", "weiß", 3, 3)
weiss = Spieler("weiß")
weiss.aufnehmen(dame)
schwarz = Spieler("schwarz")
for spalte in range(8):
    schwarz.aufnehmen(Figur(ARTEN[spalte], "schwarz", 0, spalte))
    schwarz.aufnehmen(Figur("Bauer", "schwarz", 1, spalte))

schlag = Zug(dame, 2, 2)
zeichne_felder()
zeichne_pfeil(schlag)
opfer = schwarz.finde_figur(schlag.get_zeile(), schlag.get_spalte())
if opfer != None:
    schwarz.entferne(opfer)
schlag.ausfuehren()
weiss.zeichne_alle(FELDGROESSE)
schwarz.zeichne_alle(FELDGROESSE)
print("Schwarz:", schwarz.materialwert())
hebe_hervor(dame.get_zeile(), dame.get_spalte())
zeige()
