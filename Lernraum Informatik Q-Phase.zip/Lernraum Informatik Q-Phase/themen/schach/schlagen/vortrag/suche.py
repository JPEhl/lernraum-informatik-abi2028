# suche.py -- wer steht auf dem Feld?
# Oben die Suche aus "Objektlisten".
# Die Figur kommt aus figur.py.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from figur import Figur


class Spieler:

    def __init__(self, farbe: str):
        self.__farbe = farbe
        self.__figuren: list[Figur] = []

    def aufnehmen(self, figur: Figur) -> None:
        self.__figuren.append(figur)

    def finde_figur(self, zeile: int, spalte: int) -> Figur:
        gefunden = None
        for figur in self.__figuren:
            if figur.get_zeile() == zeile and figur.get_spalte() == spalte:
                gefunden = figur
        return gefunden


schwarz = Spieler("schwarz")
schwarz.aufnehmen(Figur("Turm", "schwarz", 0, 0))
schwarz.aufnehmen(Figur("Springer", "schwarz", 0, 1))
schwarz.aufnehmen(Figur("König", "schwarz", 0, 4))
schwarz.aufnehmen(Figur("Bauer", "schwarz", 1, 1))
