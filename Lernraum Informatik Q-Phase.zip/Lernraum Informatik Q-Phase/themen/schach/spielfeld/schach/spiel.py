# spiel.py -- das Spiel: Es hält beide
# Spieler, das Brett als Liste von Listen
# und das Zugrecht. Die Köpfe stehen da,
# nach dem Diagramm; ihr schreibt die
# Rümpfe (Aufgabe 2 und 3).

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from zeichenflaeche import zeichne_bild
from figur import Figur
from spieler import Spieler
from zug import Zug

ARTEN = ["Turm", "Springer", "Läufer", "Dame",
         "König", "Läufer", "Springer", "Turm"]


class Spiel:

    def __init__(self):
        pass

    def __stelle(self, figur: Figur, spieler: Spieler) -> None:
        pass

    def figur_auf(self, zeile: int, spalte: int) -> Figur:
        pass

    def get_am_zug(self) -> Spieler:
        pass

    def ziehe(self, zug: Zug) -> bool:
        pass

    def ist_vorbei(self) -> bool:
        pass

    def materialwert(self, farbe: str) -> int:
        pass

    def zeichne(self, groesse: int) -> None:
        pass
