# spieler.py -- ein Spieler und seine
# Figuren: Er nimmt sie auf, kennt ihren
# Wert, entfernt sie, weiß, ob sein König
# steht, und nennt alle ab einem Wert.
#
# Seit es das Spiel gibt, fragt niemand
# mehr finde_figur und zeichne_alle: Das
# Spiel greift ins Feld (figur_auf) und
# zeichnet von dort (zeichne).

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from zeichenflaeche import zeichne_bild
from figur import Figur


class Spieler:

    def __init__(self, farbe: str):
        self.__farbe = farbe
        self.__figuren: list[Figur] = []

    # neu dazugelegt: die Farbe
    def get_farbe(self) -> str:
        return self.__farbe

    def aufnehmen(self, figur: Figur) -> None:
        self.__figuren.append(figur)

    def anzahl(self) -> int:
        return len(self.__figuren)

    def zeichne_alle(self, groesse: int) -> None:
        for figur in self.__figuren:
            x = figur.get_spalte() * groesse
            y = figur.get_zeile() * groesse
            zeichne_bild(figur.bildname(), x, y, groesse)

    def materialwert(self) -> int:
        summe = 0
        for figur in self.__figuren:
            summe = summe + figur.get_wert()
        return summe

    def finde_figur(self, zeile: int, spalte: int) -> Figur:
        for figur in self.__figuren:
            if figur.get_zeile() == zeile and figur.get_spalte() == spalte:
                return figur
        return None

    def entferne(self, figur: Figur) -> None:
        self.__figuren.remove(figur)

    def hat_koenig(self) -> bool:
        for figur in self.__figuren:
            if figur.get_art() == "König":
                return True
        return False

    def figuren_mit_wert(self, minimum: int) -> list[Figur]:
        auswahl: list[Figur] = []
        for figur in self.__figuren:
            if figur.get_wert() >= minimum:
                auswahl.append(figur)
        return auswahl
