# kleines_spiel.py -- das Spiel aus
# spielfeld.py, wie es im Vortrag entstanden
# ist (vier Figuren, kein ziehe).

from zeichenflaeche import zeichne_bild
from figur import Figur
from spieler import Spieler


class Spiel:

    def __init__(self):
        self.__weiss = Spieler("weiß")
        self.__schwarz = Spieler("schwarz")
        self.__feld: list[list[Figur]] = []
        for zeile in range(8):
            reihe: list[Figur] = []
            for spalte in range(8):
                reihe.append(None)
            self.__feld.append(reihe)
        self.__stelle(Figur("Dame", "weiß", 7, 3), self.__weiss)
        self.__stelle(Figur("König", "weiß", 7, 4), self.__weiss)
        self.__stelle(Figur("Dame", "schwarz", 0, 3), self.__schwarz)
        self.__stelle(Figur("König", "schwarz", 0, 4), self.__schwarz)

    def __stelle(self, figur: Figur, spieler: Spieler) -> None:
        spieler.aufnehmen(figur)
        self.__feld[figur.get_zeile()][figur.get_spalte()] = figur

    def figur_auf(self, zeile: int, spalte: int) -> Figur:
        return self.__feld[zeile][spalte]

    def zeichne(self, groesse: int) -> None:
        for zeile in range(8):
            for spalte in range(8):
                figur = self.__feld[zeile][spalte]
                if figur != None:
                    zeichne_bild(figur.bildname(), spalte * groesse,
                                 zeile * groesse, groesse)
