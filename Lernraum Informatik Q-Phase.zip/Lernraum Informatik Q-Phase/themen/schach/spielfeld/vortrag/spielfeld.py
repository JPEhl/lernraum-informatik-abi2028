# spielfeld.py -- das Spiel hält beide Spieler
# und das Brett. Gegeben: brett.py.

from brett import zeichne_felder, FELDGROESSE
from zeichenflaeche import zeichne_bild, zeige
from figur import Figur
from spieler import Spieler


class Spiel:

    def __init__(self):
        self.__weiss = Spieler("weiß")
        self.__schwarz = Spieler("schwarz")


spiel = Spiel()
zeichne_felder()
zeige()
