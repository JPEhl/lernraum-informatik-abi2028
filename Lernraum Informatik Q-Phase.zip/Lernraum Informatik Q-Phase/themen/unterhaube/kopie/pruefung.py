"""Selbstcheck „Verweise und Kopien“ -- prueft das Programm im Ordner schach/ (es laeuft partie.py).

Die Figur kopiert sich, und die Vorschau rechnet mit der Kopie. Der Check prueft die Klassen ueber OBJEKTE, die er
selbst baut (LC8): erzeuge, rufe -- und mit `is`, ob ein Objekt DASSELBE ist oder ein neues. Das Brett liest er an einem
FRISCHEN Lauf, auf dem er klickt wie die Maus (klick_auf, LC6): der rote Rahmen der gewaehlten Figur, die Punkte ihrer
Ziele (gefuellte Kreise), die Zahlen darin, der Ring um das Ziel mit den meisten Feldern (ein Kreis ohne Fuellung).

Startzustand (Arbeitsordner, vorbereitet): vorschau stellt `probe = figur` -- die Probe IST die Figur. Ein Klick auf
den Springer zeigt einen Punkt statt zwei, beim zweiten Klick steht der Rahmen auf einem leeren Feld. Die Grundlage
passt; offen ist genau Aufgabe 2 ★ (LC1) -- ihre erste Meldung: kopie fehlt. Alles andere wartet.

Fallen (LC5): Eine kopie(), die `self` zurueckgibt, liefert dieselben Werte -- deshalb fragt die Pruefung mit `is`.
Vertauschte Zeile und Spalte fallen nur auf, wenn sie verschieden sind (2, 5). Eine Kopie, die richtig ist, hilft am
Brett nichts, solange vorschau sie nicht benutzt -- deshalb liest ★ auch das Brett. Der Ring: Gleichstand faellt nur mit
einem Gleichstand auf (der Laeufer nach e2-e4, a7-a6 hat zwei Ziele mit 11 Feldern; das erste bekommt den Ring).
"""
import ast
import importlib
import sys

import pruefen
from pruefen import erwarte, braucht, flaeche, quelltext, anspielen, erzeuge, rufe, klasse, klick_auf

TITEL = "Verweise und Kopien · Selbstcheck"
EINGABEN = []
HINTS = {"kopie": {"Figur"}, "reichweite": {"int"}, "get_figuren": {"list[Figur]"}, "sichern": {"list[Figur]"},
         "zuruecksetzen": {"None"}}
DIAGRAMMTYPEN = {"String", "integer", "boolean", "Integer", "Boolean"}
SPRINGER, SPRINGER_LINKS = (7, 6), (7, 1)


def _wo(feld):
    return "Zeile %d, Spalte %d" % tuple(feld)


def _felder(menge):
    return " und ".join("(%d, %d)" % f for f in sorted(menge))


def _ok(pruefung):
    """Passt eine Pruefung? (nur fuer braucht -- faengt den Befund, LC8)"""
    try:
        pruefung()
    except AssertionError:
        return False
    return True


def _modul(name):
    m = sys.modules.get(name)
    if m is not None:
        return m
    try:
        return importlib.import_module(name)
    except Exception:  # noqa: BLE001 -- dann gibt es das Modul fuer den Check nicht
        return None


def _aus(datei, name):
    m = _modul(datei)
    k = getattr(m, name, None) if m is not None else None
    return k if isinstance(k, type) else None


def _spiel():
    """partie.py noch einmal, frisch. Gibt (Flaeche, Feldgroesse, letzte Fehlerzeile) -- die Flaeche ist None, wenn
    das Programm nicht bis zum Ende lief."""
    alt_q = pruefen._QUELLE
    pruefen._QUELLE = alt_q + "\nprint('--ENDE--')\n"
    try:
        aus, ns = anspielen([])
    finally:
        pruefen._QUELLE = alt_q
    zeilen = [z for z in aus.strip().splitlines() if z.strip() and "--ENDE--" not in z]
    fehler = zeilen[-1] if zeilen and "Error" in zeilen[-1] else ""
    return (ns.get("flaeche") if "--ENDE--" in aus else None), ns.get("FELDGROESSE"), fehler


def _klick(c, feld, g):
    """Klickt wie die Maus mitten auf das Feld -- auf der Flaeche c eines frischen Laufs."""
    alt = pruefen._FENSTER
    pruefen._FENSTER = c.winfo_toplevel()
    try:
        return klick_auf(feld[1] * g + g // 2, feld[0] * g + g // 2, wo=_wo(feld))
    finally:
        pruefen._FENSTER = alt


def _lesen(c, g):
    """Was man auf c sieht: (rote Rahmen, Punkte, Zahlen je Feld, Ringe, Bilder je Feld)."""
    rahmen, punkte, ringe, zahlen, bilder = set(), set(), set(), {}, {}
    for i in c.find_all():
        art = c.type(i)
        if art == "rectangle" and not c.itemcget(i, "fill") and c.itemcget(i, "outline"):
            x1, y1, x2, y2 = (round(v) for v in c.coords(i))
            if x1 % g == 0 and y1 % g == 0 and x2 - x1 == g:
                rahmen.add((y1 // g, x1 // g))
        elif art == "oval":
            x1, y1, x2, y2 = (round(v) for v in c.coords(i))
            feld = ((y1 + y2) // 2 // g, (x1 + x2) // 2 // g)
            (punkte if c.itemcget(i, "fill") else ringe).add(feld)
        elif art == "text":
            x, y = c.coords(i)[:2]
            zahlen[(int(y) // g, int(x) // g)] = c.itemcget(i, "text")
        elif art == "image":
            x, y = c.coords(i)[:2]
            bilder[(int(y) // g, int(x) // g)] = pruefen._bilddatei(c, c.itemcget(i, "image"))
    return rahmen, punkte, zahlen, ringe, bilder


def _soll(art, von):
    """Wie viele Felder erreicht eine Figur dieser Art von `von` aus nach ihrer Gangart, auf leerem Brett."""
    n = 0
    for z in range(8):
        for s in range(8):
            hoch, quer = abs(z - von[0]), abs(s - von[1])
            if hoch == 0 and quer == 0:
                continue
            if art == "Springer":
                n += hoch * quer == 2
            elif art == "Läufer":
                n += hoch == quer
    return n


def pruefe_00_grundlage():
    """Grundlage · figur.py lädt, und partie.py hat eine Zeichenfläche"""
    erwarte(klasse("Figur") is not None, "figur.py lädt nicht mehr -- partie.py bricht beim Laden ab. Seht in der "
            "Shell nach.")
    erwarte(flaeche() is not None, "Das Programm bricht ab, bevor es eine Zeichenfläche hat -- seht in der Shell nach.")


def _kopie_stimmt():
    """Der Teil von Aufgabe 2 ★, der die KLASSE prueft."""
    erwarte(hasattr(klasse("Figur"), "kopie"), "Die Figur kann sich noch nicht kopieren: In figur.py fehlt die Methode "
            "kopie() aus dem Diagramm. Probiert vorher die Vorschau am Springer aus.")
    turm = erzeuge("Figur", "Turm", "schwarz", 2, 5)
    neu = rufe(turm, "kopie")
    erwarte(neu is not None, "turm.kopie() gibt nichts zurück -- im Diagramm steht dahinter Figur.")
    erwarte(neu is not turm, "turm.kopie() gibt dieselbe Figur zurück, keine neue: kopie is turm ist True. Wo entsteht "
            "in kopie ein neues Objekt?")
    erwarte(isinstance(neu, klasse("Figur")), "turm.kopie() gibt %r zurück -- erwartet ist eine Figur." % (neu,))
    werte = [rufe(neu, m) for m in ("get_art", "get_farbe", "get_zeile", "get_spalte")]
    erwarte(werte == ["Turm", "schwarz", 2, 5], "Ein schwarzer Turm auf Zeile 2, Spalte 5: Seine Kopie ist %s, %s, auf "
            "Zeile %s, Spalte %s -- eine Kopie hat dieselben Werte." % tuple(werte))
    rufe(neu, "set_zeile", 6)
    erwarte(rufe(turm, "get_zeile") == 2, "Die Kopie geht auf Zeile 6 -- und der Turm geht mit. Ist es wirklich ein "
            "zweites Objekt?")


def pruefe_20_vorschau():
    """Aufgabe 2 · Die Figur kopiert sich, und die Vorschau verschiebt sie nicht"""
    _kopie_stimmt()
    c, g, fehler = _spiel()
    erwarte(c is not None, "partie.py bricht schon beim Start ab%s." % (" (%s)" % fehler if fehler else ""))
    _klick(c, SPRINGER, g)
    rahmen, punkte, zahlen, _, _ = _lesen(c, g)
    ziele = {(5, 5), (5, 7)}
    erwarte(rahmen == {SPRINGER} and punkte == ziele, "Ein Klick auf den Springer auf %s: Gerahmt ist %s, Punkte "
            "stehen auf %s -- erwartet sind der Rahmen auf ihm und Punkte auf (5, 5) und (5, 7). Mit welcher Figur "
            "rechnet vorschau?" % (_wo(SPRINGER), _felder(rahmen) or "nichts", _felder(punkte) or "keinem Feld"))
    soll = {f: str(_soll("Springer", f)) for f in ziele}
    erwarte({f: zahlen.get(f) for f in ziele} == soll, "In den Punkten des Springers stehen %s und %s -- von (5, 5) "
            "erreicht er 8 Felder, von (5, 7) 4." % (zahlen.get((5, 5)), zahlen.get((5, 7))))
    _klick(c, SPRINGER, g)
    rahmen = _lesen(c, g)[0]
    erwarte(rahmen == {SPRINGER}, "Klickt man den Springer ein zweites Mal an, steht der Rahmen auf %s -- der Springer "
            "steht aber auf %s. Die Vorschau hat ihn verschoben: Wer ist probe in vorschau?"
            % (", ".join(_wo(f) for f in sorted(rahmen)) or "keinem Feld", _wo(SPRINGER)))
    _klick(c, (5, 5), g)
    bilder = _lesen(c, g)[4]
    erwarte(bilder.get((5, 5)) == "springer-w.png" and bilder.get(SPRINGER) != "springer-w.png", "Nach einem Klick "
            "auf (5, 5) zieht der Springer nicht dorthin.")


def _ring(klicks, soll, wer):
    c, g, fehler = _spiel()
    erwarte(c is not None, "partie.py bricht schon beim Start ab%s." % (" (%s)" % fehler if fehler else ""))
    for feld in klicks:
        _klick(c, feld, g)
    _, punkte, zahlen, ringe, _ = _lesen(c, g)
    erwarte(ringe == {soll}, "%s: Der Ring steht %s -- erwartet auf %s, dem ersten Ziel mit den meisten Feldern "
            "(in den Punkten: %s)." % (wer, ("auf " + ", ".join(_wo(f) for f in sorted(ringe))) if ringe else "nirgends",
                                       _wo(soll), ", ".join("%s: %s" % (_wo(f), zahlen.get(f, "–")) for f in sorted(punkte))))


def pruefe_25_ring():
    """Aufgabe 2 ★★ · Ein Ring um das Ziel mit den meisten Feldern"""
    braucht(_ok(pruefe_20_vorschau), "Erst rechnet die Vorschau mit einer Kopie.")
    _ring([SPRINGER], (5, 5), "Der Springer auf %s ist gewählt" % _wo(SPRINGER))
    _ring([SPRINGER_LINKS], (5, 2), "Der Springer auf %s ist gewählt" % _wo(SPRINGER_LINKS))
    _ring([(6, 4), (4, 4), (1, 0), (2, 0), (7, 5)], (4, 2), "Nach e2-e4 und a7-a6 ist der Läufer auf Zeile 7, Spalte 5 "
          "gewählt; zwei Ziele haben gleich viele Felder")


def pruefe_50_get_figuren():
    """Aufgabe 5 ★★ · get_figuren gibt eine neue Liste mit denselben Figuren"""
    k = klasse("Spieler")
    braucht(k is not None and hasattr(k, "get_figuren"), "Erst die Methode get_figuren in spieler.py.")
    weiss = erzeuge("Spieler", "weiß")
    turm = erzeuge("Figur", "Turm", "weiß", 7, 0)
    laeufer = erzeuge("Figur", "Läufer", "weiß", 7, 2)
    rufe(weiss, "aufnehmen", turm)
    rufe(weiss, "aufnehmen", laeufer)
    raus = rufe(weiss, "get_figuren")
    erwarte(isinstance(raus, list), "get_figuren gibt %r zurück -- erwartet ist eine Liste." % (raus,))
    erwarte(len(raus) == 2, "Ein Spieler mit Turm und Läufer: get_figuren gibt eine Liste mit %d Figuren zurück."
            % len(raus))
    gleich = len(raus) == 2 and raus[0] is turm and raus[1] is laeufer
    erwarte(gleich, "Ein Spieler mit Turm und Läufer: In der Liste von get_figuren stehen nicht genau diese zwei Figuren "
            "-- dieselben, keine Kopien.")
    raus.remove(turm)
    anzahl = rufe(weiss, "anzahl")
    erwarte(anzahl == 2, "Aus der Liste von get_figuren wird der Turm entfernt -- danach hat der Spieler nur noch %s "
            "Figuren. Wessen Liste wurde geändert?" % anzahl)


def _ohne_import_copy(datei):
    try:
        baum = ast.parse(quelltext(datei))
    except (SyntaxError, OSError, TypeError):
        return True
    for k in ast.walk(baum):
        if isinstance(k, ast.Import) and any(a.name.split(".")[0] == "copy" for a in k.names):
            return False
        if isinstance(k, ast.ImportFrom) and (k.module or "").split(".")[0] == "copy":
            return False
    return True


def pruefe_60_sichern():
    """Aufgabe 6 ★★★ · spieler_sicher.py: sichern und zurücksetzen, so oft man will"""
    k = _aus("spieler_sicher", "Spieler")
    braucht(k is not None and hasattr(k, "sichern") and hasattr(k, "zuruecksetzen"),
            "Erst die Klasse Spieler mit sichern und zuruecksetzen in spieler_sicher.py.")
    braucht(_ok(_kopie_stimmt), "Erst kann sich die Figur kopieren (Aufgabe 2).")
    erwarte(_ohne_import_copy("spieler_sicher.py"), "Die Auflage: kein import zum Kopieren -- ihr kopiert selbst.")
    weiss = erzeuge(k, "weiß")
    turm = erzeuge("Figur", "Turm", "weiß", 7, 0)
    laeufer = erzeuge("Figur", "Läufer", "weiß", 7, 2)
    rufe(weiss, "aufnehmen", turm)
    rufe(weiss, "aufnehmen", laeufer)
    sicherung = rufe(weiss, "sichern")
    rufe(turm, "ziehen", 4, 0)
    rufe(weiss, "entferne", laeufer)
    rufe(weiss, "zuruecksetzen", sicherung)
    zurueck = rufe(weiss, "finde_figur", 7, 0)
    erwarte(zurueck is not None and rufe(zurueck, "get_art") == "Turm", "Sichern, der Turm zieht nach Zeile 4, "
            "zurücksetzen: Auf Zeile 7, Spalte 0 steht danach kein Turm des Spielers. Hat der Zug die Sicherung "
            "getroffen?")
    weg = rufe(weiss, "finde_figur", 7, 2)
    erwarte(weg is not None and rufe(weg, "get_art") == "Läufer", "Sichern, der Läufer wird geschlagen, zurücksetzen: "
            "Der Läufer auf Zeile 7, Spalte 2 ist nicht wieder da.")
    anzahl = rufe(weiss, "anzahl")
    erwarte(anzahl == 2, "Nach dem Zurücksetzen hat der Spieler %s Figuren -- vorher waren es zwei." % anzahl)
    rufe(zurueck, "ziehen", 5, 0)
    rufe(weiss, "zuruecksetzen", sicherung)
    wieder = rufe(weiss, "finde_figur", 7, 0)
    erwarte(wieder is not None and rufe(wieder, "get_art") == "Turm" and rufe(weiss, "finde_figur", 5, 0) is None,
            "Zurücksetzen, der Turm zieht nach Zeile 5, noch einmal von derselben Sicherung zurücksetzen: Der Turm "
            "steht nicht wieder auf Zeile 7. Wer hält nach dem ersten Zurücksetzen dieselben Objekte wie die Sicherung?")


def pruefe_90_hints():
    """Hinweis · Jede neue Methode mit Type Hints (kein Stern)"""
    braucht(_ok(_kopie_stimmt), "Erst kann sich die Figur kopieren.")
    ohne, falsch, diagramm = [], [], []
    for datei in ("figur.py", "spieler.py", "spieler_sicher.py"):
        try:
            baum = ast.parse(quelltext(datei))
        except (SyntaxError, OSError, TypeError):
            continue
        for k in ast.walk(baum):
            if not isinstance(k, ast.FunctionDef):
                continue
            for a in k.args.args + [k]:
                typ = a.annotation if isinstance(a, ast.arg) else a.returns
                if typ is not None and any(isinstance(x, ast.Name) and x.id in DIAGRAMMTYPEN for x in ast.walk(typ)):
                    diagramm.append("%s (%s)" % (k.name, ast.unparse(typ)))
            parameter = [a for a in k.args.args if a.arg != "self"]
            if any(a.annotation is None for a in parameter) or (k.returns is None and k.name != "__init__"):
                ohne.append(k.name)
            elif k.name in HINTS and ast.unparse(k.returns).replace(" ", "") not in HINTS[k.name]:
                falsch.append("%s -> %s" % (k.name, " oder ".join(sorted(HINTS[k.name]))))
    erwarte(not diagramm, "Hier steht ein Typ in der Schreibweise des Diagramms: %s. In Python heißt er str, int, "
            "float oder bool." % ", ".join(diagramm))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer oder an einem Parameter): %s. Es läuft auch ohne; "
            "vereinbart ist es trotzdem." % ", ".join(sorted(set(ohne))))
    erwarte(not falsch, "Dieser Type Hint passt nicht zu dem, was zurückkommt -- erwartet: %s." % ", ".join(falsch))
