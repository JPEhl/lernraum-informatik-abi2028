# spieler_sicher.py -- Expertenaufgabe: ein
# Spieler, der seine Aufstellung sichert.
# Kopiert eure Klasse Spieler hierher.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
from zeichenflaeche import zeichne_bild
from figur import Figur
