# adresse.py -- wo die Dame wohnt.
# Die Figur wie in dame.py, ohne Brett.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations


class Figur:

    def __init__(self, art: str, farbe: str, zeile: int, spalte: int):
        self.__art = art
        self.__farbe = farbe
        self.__zeile = zeile
        self.__spalte = spalte

    def get_zeile(self) -> int:
        return self.__zeile

    def get_spalte(self) -> int:
        return self.__spalte

    def set_zeile(self, zeile: int) -> None:
        if zeile >= 0 and zeile <= 7:
            self.__zeile = zeile


dame = Figur("Dame", "weiß", 7, 3)
probe = dame
