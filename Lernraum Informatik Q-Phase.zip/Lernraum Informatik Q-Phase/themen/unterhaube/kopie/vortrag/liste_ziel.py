# liste.py -- Zahlen und Listen.
# Die Figur wie in dame.py, ohne Brett.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations


class Figur:

    def __init__(self, art: str, farbe: str, zeile: int, spalte: int):
        self.__art = art
        self.__farbe = farbe
        self.__zeile = zeile
        self.__spalte = spalte

    def get_zeile(self) -> int:
        return self.__zeile

    def get_spalte(self) -> int:
        return self.__spalte

    def set_zeile(self, zeile: int) -> None:
        if zeile >= 0 and zeile <= 7:
            self.__zeile = zeile


zahl = 7
gemerkt = zahl
zahl = zahl + 1
print(gemerkt)
print(id(zahl) == id(gemerkt))

turm = Figur("Turm", "weiß", 7, 0)
laeufer = Figur("Läufer", "weiß", 7, 2)
figuren = [turm, laeufer]
neue_liste = list(figuren)
print(neue_liste is figuren)
print(neue_liste == figuren)
figuren.remove(laeufer)
print(len(neue_liste))
print(neue_liste[0] is turm)
