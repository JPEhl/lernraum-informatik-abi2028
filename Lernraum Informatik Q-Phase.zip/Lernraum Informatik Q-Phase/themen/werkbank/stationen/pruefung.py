"""Selbstcheck „Ein Programm erweitern“ (Zugabe werkbank) -- prueft das Programm im Ordner schach/ (es laeuft partie.py).

Die Werkbank ist der Endstand von Teil I; jede Station baut eine Regel ein. Der Check prueft die Klassen ueber OBJEKTE,
die er selbst baut (LC8): Ein Spiel spielt die Zuege einer kurzen Partie ueber ziehe -- so, wie sie am Brett gespielt
wuerden. Nur fuer zwei Stufen stellt er eine Lage selbst ins Feld (Remis ★★, Computergegner): Er leert das Spielfeld
UND die Listen der Spieler und stellt jede Figur an beide Stellen, wie das Spiel selbst (spielfeld, Aufgabe 2 ★★).

Startzustand (Arbeitsordner = Endstand von Teil I): Offen ist genau Aufgabe 2 ★ (umwandeln fehlt), alles andere wartet
(LC1). Die Pflicht hat eine Folge (Aufgabe 4 wartet auf Aufgabe 2 ★); die Stationen unter Mehr sind frei -- jede
beginnt, sobald es ihre erste Methode gibt (sonst stuende an der frischen Werkbank alles offen).

Fallen (LC5): Umwandlung nur fuer Weiss (zeile == 0) -- deshalb wandelt auch Schwarz um. umwandeln ohne Pruefung -- der
Rueckblick auf kapsel: Ein Koenig oder ein „Pferd“ wird nicht daraus, und ein Turm wird nichts. hat_gezogen als
Klassenattribut -- zwei Figuren. Rochade nur kurz -- deshalb auch lang, fuer beide Farben; Rochade ohne Bedingungen --
deshalb drei Faelle, in denen sie nicht gilt; der Turm nur im Feld versetzt -- deshalb fragt der Check auch den Turm
selbst. En passant ohne den letzten Zug -- deshalb einmal einen Zug zu spaet und einmal nach zwei Einzelschritten.
Fuenfzig Zuege: nie zurueckgesetzt -- deshalb ein Bauernzug und ein Schlagen durch einen Springer dazwischen. Nur
noch Koenige: die Summe der Werte statt der Figuren (ein Bauer hat den Wert 1) -- deshalb ein einzelner Bauer.
nachspielen spielt nach einem falschen Zug weiter -- deshalb ein falscher Zug in der Mitte. Uhr: die laufende Zeit
erst beim Umschalten abgezogen -- deshalb rest() mitten im Zug; unter null -- deshalb rest() lange danach. Computer: Er
probiert am Spiel und stellt nicht zurueck -- deshalb vergleicht der Check die Stellung vorher und nachher; der gierige
Zug als „bester“ -- deshalb eine Lage, in der der wertvollste Fang gedeckt ist.

Das Netzwerkspiel (Aufgabe 9) prueft die Seite (zwei Fragen) -- die Verbindung selbst nicht (Schulversuch S21).
"""
import ast
import importlib
import random
import sys

import pruefen
from pruefen import erwarte, braucht, arbeit, flaeche, quelltext, erzeuge, rufe, attribute, klasse, angaben

TITEL = "Ein Programm erweitern · Selbstcheck"
EINGABEN = []
ARTEN_NEU = ["Dame", "Turm", "Läufer", "Springer"]
TYPEN_DIAGRAMM = {"String", "integer", "boolean", "Integer", "Boolean"}


# ------------------------------------------------------------------ Helfer

def _ok(pruefung):
    try:
        pruefung()
    except AssertionError:
        return False
    except pruefen.NochNichtDran:
        return False
    return True


def _modul(name):
    m = sys.modules.get(name)
    if m is not None:
        return m
    try:
        return importlib.import_module(name)
    except Exception:  # noqa: BLE001 -- dann gibt es das Modul fuer den Check nicht
        return None


def _klasse(name, modul):
    k = klasse(name)
    if k is None:
        k = getattr(_modul(modul), name, None)
    return k if isinstance(k, type) else None


def _hat_methode(name, modul, methode):
    k = _klasse(name, modul)
    return k is not None and angaben(k, methode) is not None


def _feld(name):
    """„e2“ -> (6, 4): die Spalte a bis h ist 0 bis 7, die Zeile 8 bis 1 ist 0 bis 7."""
    return (8 - int(name[1]), "abcdefgh".index(name[0]))


def _wo(feld):
    return "(%d, %d)" % tuple(feld)


def _spiel():
    return erzeuge(_klasse("Spiel", "spiel"))


def _zug(s, von, nach):
    figur = rufe(s, "figur_auf", *von)
    erwarte(figur is not None, "Auf %s steht keine Figur mehr -- eine Station hat einen Zug davor verändert." % _wo(von))
    return rufe(s, "ziehe", erzeuge(_klasse("Zug", "zug"), figur, *nach))


def _partie(zuege, wo, s=None):
    """Ein Spiel, in dem die Züge („e2e4 e7e5“) über ziehe gespielt sind -- jeder muss gelten."""
    s = s if s is not None else _spiel()
    for text in zuege.split():
        von, nach = _feld(text[:2]), _feld(text[2:])
        gilt = _zug(s, von, nach)
        erwarte(gilt is True, "%s: Der Zug von %s nach %s gilt nach den Regeln aus Teil I -- ziehe sagt aber %r. Die "
                "Partie bis dahin: %s" % (wo, _wo(von), _wo(nach), gilt, zuege[:zuege.index(text)] or "keine"))
    return s


def _was(figur):
    if figur is None:
        return "nichts"
    return "%s %s" % (rufe(figur, "get_art"), rufe(figur, "get_farbe"))


def _spieler(s, farbe):
    return attribute(s).get("__weiss" if farbe == "weiß" else "__schwarz")


def _liste(spieler):
    return attribute(spieler).get("__figuren") or []


def _hat(spieler, figur):
    return any(f is figur for f in _liste(spieler))


def _platz(figur):
    return (rufe(figur, "get_zeile"), rufe(figur, "get_spalte"))


def _am_zug(s):
    return rufe(rufe(s, "get_am_zug"), "get_farbe")


def _stellung(s):
    """Was wo steht -- im Spielfeld, in der Figur selbst und in den Listen."""
    feld = attribute(s).get("__feld")
    bild = [[(id(f), _platz(f), rufe(f, "get_art")) if f is not None else None for f in reihe] for reihe in feld]
    listen = [[id(f) for f in _liste(_spieler(s, farbe))] for farbe in ("weiß", "schwarz")]
    return bild, listen


def _lage(s, figuren):
    """Leert Spielfeld und Listen und stellt die Figuren [(art, farbe, „e1“), …] an beide Stellen."""
    feld = attribute(s).get("__feld")
    for reihe in feld:
        for i in range(len(reihe)):
            reihe[i] = None
    for farbe in ("weiß", "schwarz"):
        del _liste(_spieler(s, farbe))[:]
    for art, farbe, name in figuren:
        z, sp = _feld(name)
        f = erzeuge(_klasse("Figur", "figur"), art, farbe, z, sp)
        rufe(_spieler(s, farbe), "aufnehmen", f)
        feld[z][sp] = f
    return s


# ------------------------------------------------------------------ Grundlage

def pruefe_00_grundlage():
    """Grundlage · figur.py, spiel.py und partie.py laden, das Brett ist da"""
    erwarte(_klasse("Figur", "figur") is not None, "In figur.py steht keine Klasse Figur mehr -- seht in der Shell nach.")
    erwarte(_klasse("Spiel", "spiel") is not None, "In spiel.py steht keine Klasse Spiel -- oder spiel.py lässt sich "
            "nicht laden. Seht in der Shell nach.")
    erwarte(flaeche() is not None, "Das Programm bricht ab, bevor es ein Brett hat -- seht in der Shell nach.")


# ------------------------------------------------------------------ Aufgabe 2: die Umwandlung

def _figur(art, farbe="weiß", zeile=1, spalte=0):
    return erzeuge(_klasse("Figur", "figur"), art, farbe, zeile, spalte)


def pruefe_20_umwandeln():
    """Aufgabe 2 ★ · Die Figur wandelt sich um: umwandeln(art) -- nur ein Bauer, nur in Dame, Turm, Läufer, Springer"""
    erwarte(_hat_methode("Figur", "figur", "umwandeln"), "Die Figur kann ihre Art noch nicht ändern: In figur.py fehlt "
            "die Methode umwandeln(art). Damit beginnt Aufgabe 2.")
    for art in ("Dame", "Springer"):
        bauer = _figur("Bauer")
        rufe(bauer, "umwandeln", art)
        neu = rufe(bauer, "get_art")
        erwarte(neu == art, "Ein Bauer, der umwandeln(%r) bekommt, heißt danach %r -- nicht %r." % (art, neu, art))
    erwarte(rufe(bauer, "get_wert") == 3, "Ein Bauer, der Springer wurde, ist danach nicht 3 wert -- get_wert fragt die "
            "Art: Steht sie dort, wo get_wert nachsieht?")
    for falsch in ("König", "Pferd", "Bauer"):
        bauer = _figur("Bauer")
        rufe(bauer, "umwandeln", falsch)
        neu = rufe(bauer, "get_art")
        erwarte(neu == "Bauer", "umwandeln(%r) macht aus dem Bauern %r. Erlaubt sind nur Dame, Turm, Läufer und "
                "Springer -- sonst bleibt er ein Bauer." % (falsch, neu))
    turm = _figur("Turm", zeile=7)
    rufe(turm, "umwandeln", "Dame")
    neu = rufe(turm, "get_art")
    erwarte(neu == "Turm", "Ein Turm, der umwandeln(\"Dame\") bekommt, heißt danach %r -- umgewandelt wird nur ein "
            "Bauer." % neu)


def pruefe_22_letzte_reihe():
    """Aufgabe 2 ★★ · Erreicht ein Bauer die letzte Reihe, wird er Dame -- bei Weiß und bei Schwarz"""
    braucht(_ok(pruefe_20_umwandeln), "Erst umwandeln (Aufgabe 2 ★).")
    wo = "Aufgabe 2 ★★"
    s = _partie("a2a4 b7b5 a4b5 a7a6 b5a6 h7h6 a6a7", wo)
    vorher = rufe(s, "figur_auf", 1, 0)
    erwarte(rufe(vorher, "get_art") == "Bauer", "Ein weißer Bauer auf (1, 0) ist schon %s -- umgewandelt wird erst auf "
            "der letzten Reihe." % _was(vorher))
    _partie("h6h5 a7b8", wo, s)
    neu = rufe(s, "figur_auf", 0, 1)
    erwarte(neu is vorher, "Nach dem Zug des weißen Bauern auf (0, 1) steht dort ein anderes Objekt als der Bauer -- "
            "die Figur ändert ihre Art selbst, sie wird nicht ersetzt.")
    erwarte(rufe(neu, "get_art") == "Dame", "Der weiße Bauer hat die letzte Reihe erreicht (er schlug auf (0, 1)) -- und "
            "heißt noch %r. In ziehen weiß die Figur, wohin sie kommt." % rufe(neu, "get_art"))
    erwarte(_hat(_spieler(s, "weiß"), neu), "Die neue Dame steht nicht mehr in der Liste des weißen Spielers.")
    wert = rufe(s, "materialwert", "weiß")
    erwarte(wert == 47, "Weiß ist nach der Umwandlung %r wert, nicht 47 (39, ein Bauer weniger, eine Dame mehr)." % wert)
    s = _partie("a2a4 b7b5 h2h3 b5a4 h3h4 a4a3 h4h5 a3b2 h5h6", wo)
    _partie("b2a1", wo, s)
    neu = rufe(s, "figur_auf", 7, 0)
    erwarte(rufe(neu, "get_art") == "Dame", "Der schwarze Bauer hat die letzte Reihe erreicht (er schlug auf (7, 0)) -- "
            "und heißt noch %r. Für Schwarz ist die letzte Reihe die Zeile 7." % rufe(neu, "get_art"))


# ------------------------------------------------------------------ Aufgabe 4: die Rochade

def pruefe_40_gezogen():
    """Aufgabe 4 ★ · Die Figur weiß, ob sie schon gezogen hat: hat_gezogen()"""
    braucht(_ok(pruefe_20_umwandeln), "Erst Aufgabe 2 ★.")
    erwarte(_hat_methode("Figur", "figur", "hat_gezogen"), "Die Figur weiß noch nicht, ob sie schon gezogen hat: In "
            "figur.py fehlt die Methode hat_gezogen(). Damit beginnt Aufgabe 4.")
    turm = _figur("Turm", zeile=7, spalte=0)
    anderer = _figur("Turm", zeile=7, spalte=7)
    erwarte(rufe(turm, "hat_gezogen") is False, "Ein neuer Turm sagt bei hat_gezogen() schon %r -- er hat noch nicht "
            "gezogen." % rufe(turm, "hat_gezogen"))
    rufe(turm, "ziehen", 5, 2)
    erwarte(rufe(turm, "hat_gezogen") is False, "Ein Turm, dessen Zug nach (5, 2) nicht galt (das ist schräg), sagt "
            "danach bei hat_gezogen() True.")
    rufe(turm, "ziehen", 4, 0)
    erwarte(rufe(turm, "hat_gezogen") is True, "Ein Turm, der von (7, 0) nach (4, 0) gezogen ist, sagt bei "
            "hat_gezogen() noch %r." % rufe(turm, "hat_gezogen"))
    erwarte(rufe(anderer, "hat_gezogen") is False, "Ein zweiter Turm, der nie gezogen hat, sagt bei hat_gezogen() True, "
            "sobald der erste gezogen hat -- teilen sich alle Figuren eine Angabe?")


KURZ_WEISS = "e2e4 e7e5 g1f3 b8c6 f1c4 g8f6"
LANG = "d2d4 d7d5 b1c3 b8c6 c1f4 c8f5 d1d2 d8d7"


def _rochiert(s, farbe, koenig_von, koenig_nach, turm_von, turm_nach, turm, wo):
    k = rufe(s, "figur_auf", *koenig_nach)
    erwarte(k is not None and rufe(k, "get_art") == "König", "%s: Nach der Rochade steht auf %s %s, nicht der König."
            % (wo, _wo(koenig_nach), _was(k)))
    erwarte(_platz(k) == koenig_nach, "%s: Der König steht im Spielfeld auf %s, sagt selbst aber %s." % (wo, _wo(koenig_nach), _wo(_platz(k))))
    t = rufe(s, "figur_auf", *turm_nach)
    erwarte(t is turm, "%s: Der Turm von %s steht nach der Rochade nicht auf %s (dort steht %s)." % (wo, _wo(turm_von), _wo(turm_nach), _was(t)))
    erwarte(_platz(turm) == turm_nach, "%s: Der Turm steht im Spielfeld auf %s, sagt selbst aber %s -- beide Stellen."
            % (wo, _wo(turm_nach), _wo(_platz(turm))))
    for feld in (koenig_von, turm_von):
        erwarte(rufe(s, "figur_auf", *feld) is None, "%s: Nach der Rochade ist %s nicht leer." % (wo, _wo(feld)))
    erwarte(_am_zug(s) != farbe, "%s: Nach der Rochade ist %s noch am Zug -- sie ist ein Zug wie jeder andere." % (wo, farbe))


def pruefe_42_rochade():
    """Aufgabe 4 ★★ · Die Rochade, kurz und lang, für beide Farben -- und nur, wenn sie gilt"""
    braucht(_ok(pruefe_40_gezogen), "Erst hat_gezogen (Aufgabe 4 ★).")
    wo = "Aufgabe 4 ★★"
    s = _partie(KURZ_WEISS, wo)
    turm = rufe(s, "figur_auf", 7, 7)
    erwarte(_zug(s, (7, 4), (7, 6)) is True, "Kurze Rochade für Weiß: Zwischen König und Turm ist alles leer, beide "
            "haben nicht gezogen -- ziehe sagt beim König von (7, 4) nach (7, 6) aber nicht True.")
    _rochiert(s, "weiß", (7, 4), (7, 6), (7, 7), (7, 5), turm, wo + ", kurz, Weiß")
    _partie("f8c5 d2d3", wo, s)
    turm = rufe(s, "figur_auf", 0, 7)
    erwarte(_zug(s, (0, 4), (0, 6)) is True, "Kurze Rochade für Schwarz: ziehe sagt beim König von (0, 4) nach (0, 6) "
            "nicht True.")
    _rochiert(s, "schwarz", (0, 4), (0, 6), (0, 7), (0, 5), turm, wo + ", kurz, Schwarz")
    s = _partie(LANG, wo)
    turm = rufe(s, "figur_auf", 7, 0)
    erwarte(_zug(s, (7, 4), (7, 2)) is True, "Lange Rochade für Weiß: Zwischen König und Turm (Spalte 0) ist alles "
            "leer -- ziehe sagt beim König von (7, 4) nach (7, 2) aber nicht True.")
    _rochiert(s, "weiß", (7, 4), (7, 2), (7, 0), (7, 3), turm, wo + ", lang, Weiß")
    turm = rufe(s, "figur_auf", 0, 0)
    erwarte(_zug(s, (0, 4), (0, 2)) is True, "Lange Rochade für Schwarz: ziehe sagt beim König von (0, 4) nach (0, 2) "
            "nicht True.")
    _rochiert(s, "schwarz", (0, 4), (0, 2), (0, 0), (0, 3), turm, wo + ", lang, Schwarz")
    faelle = [("", "am Start stehen Läufer und Springer dazwischen"),
              (KURZ_WEISS + " e1e2 d7d6 e2e1 d6d5", "der König ist schon einmal gezogen (und zurück)"),
              (KURZ_WEISS + " h1g1 a8b8 g1h1 b8a8", "der Turm ist schon einmal gezogen (und zurück)")]
    for zuege, warum in faelle:
        s = _partie(zuege, wo) if zuege else _spiel()
        vorher = _stellung(s)
        gilt = _zug(s, (7, 4), (7, 6))
        erwarte(gilt is False, "%s: Die Rochade gilt hier nicht -- %s. ziehe sagt aber %r." % (wo, warum, gilt))
        erwarte(_stellung(s) == vorher, "%s: Die Rochade galt nicht (%s), aber danach steht etwas anders." % (wo, warum))


def pruefe_44_bedroht():
    """Aufgabe 4 ★★★ · Keine Rochade aus dem Schach und über ein bedrohtes Feld"""
    braucht(_ok(pruefe_42_rochade), "Erst die Rochade (Aufgabe 4 ★★).")
    wo = "Aufgabe 4 ★★★"
    s = _partie("e2e4 b7b6 g2g3 c8a6 f1g2 b8c6 g1f3 g8f6", wo)
    vorher = _stellung(s)
    gilt = _zug(s, (7, 4), (7, 6))
    erwarte(gilt is False, "Der schwarze Läufer auf (2, 0) bedroht (7, 5) -- über dieses Feld zieht der König bei der "
            "kurzen Rochade. ziehe sagt aber %r." % gilt)
    erwarte(_stellung(s) == vorher, "Die Rochade über das bedrohte Feld galt nicht, aber danach steht etwas anders.")
    s = _partie(KURZ_WEISS, wo)
    erwarte(_zug(s, (7, 4), (7, 6)) is True, "Ohne Bedrohung gilt die kurze Rochade weiter -- ziehe sagt beim König von "
            "(7, 4) nach (7, 6) jetzt aber nicht True.")


# ------------------------------------------------------------------ Aufgabe 5: en passant

def pruefe_50_letzter_zug():
    """Aufgabe 5 ★ · Das Spiel kennt den letzten Zug: get_letzter_zug()"""
    braucht(_hat_methode("Spiel", "spiel", "get_letzter_zug"), "Station en passant: noch keine Methode get_letzter_zug().")
    s = _spiel()
    erwarte(rufe(s, "get_letzter_zug") is None, "Vor dem ersten Zug gibt get_letzter_zug() nicht None zurück.")
    erster = erzeuge(_klasse("Zug", "zug"), rufe(s, "figur_auf", 6, 4), 4, 4)
    rufe(s, "ziehe", erster)
    erwarte(rufe(s, "get_letzter_zug") is erster, "Nach einem Zug, der galt, gibt get_letzter_zug() nicht genau diesen "
            "Zug zurück.")
    falsch = erzeuge(_klasse("Zug", "zug"), rufe(s, "figur_auf", 6, 3), 4, 3)
    rufe(s, "ziehe", falsch)
    erwarte(rufe(s, "get_letzter_zug") is erster, "Ein Zug, der nicht galt (Weiß noch einmal), ist danach der letzte "
            "Zug -- der letzte ist der, der galt.")
    zweiter = erzeuge(_klasse("Zug", "zug"), rufe(s, "figur_auf", 1, 4), 3, 4)
    rufe(s, "ziehe", zweiter)
    erwarte(rufe(s, "get_letzter_zug") is zweiter, "Nach dem zweiten Zug gibt get_letzter_zug() noch den ersten zurück.")


def pruefe_52_en_passant():
    """Aufgabe 5 ★★ · En passant: nur gleich nach dem Doppelschritt, und der Bauer daneben ist weg"""
    braucht(_ok(pruefe_50_letzter_zug), "Erst get_letzter_zug() (Aufgabe 5 ★).")
    wo = "Aufgabe 5 ★★"
    s = _partie("e2e4 a7a6 e4e5 d7d5", wo)
    opfer = rufe(s, "figur_auf", 3, 3)
    bauer = rufe(s, "figur_auf", 3, 4)
    gilt = _zug(s, (3, 4), (2, 3))
    erwarte(gilt is True, "Der schwarze Bauer zog eben von (1, 3) nach (3, 3), neben den weißen auf (3, 4): Der darf ihn "
            "en passant schlagen, nach (2, 3). ziehe sagt aber %r." % gilt)
    erwarte(rufe(s, "figur_auf", 2, 3) is bauer and _platz(bauer) == (2, 3), "Nach dem Schlagen en passant steht der "
            "weiße Bauer nicht an beiden Stellen auf (2, 3).")
    erwarte(rufe(s, "figur_auf", 3, 3) is None, "Nach dem Schlagen en passant steht der geschlagene Bauer noch auf (3, 3).")
    erwarte(not _hat(_spieler(s, "schwarz"), opfer), "Der geschlagene Bauer steht noch in der Liste des schwarzen Spielers.")
    for zuege, warum in (("e2e4 a7a6 e4e5 d7d5 h2h3 h7h6", "der Doppelschritt war nicht der letzte Zug"),
                         ("e2e4 d7d6 e4e5 d6d5", "der schwarze Bauer kam in zwei Einzelschritten")):
        s = _partie(zuege, wo)
        vorher = _stellung(s)
        gilt = _zug(s, (3, 4), (2, 3))
        erwarte(gilt is False, "En passant gilt hier nicht -- %s. ziehe sagt aber %r." % (warum, gilt))
        erwarte(_stellung(s) == vorher, "En passant galt nicht (%s), aber danach steht etwas anders." % warum)


# ------------------------------------------------------------------ Aufgabe 6: Remis

PENDEL = "g1f3 g8f6 f3g1 f6g8"
PENDEL_B = "b1c3 b8c6 c3b1 c6b8"


def _halbzuege(pendel, n):
    zuege = pendel.split()
    return " ".join(zuege[i % 4] for i in range(n))


def pruefe_60_fuenfzig():
    """Aufgabe 6 ★ · Fünfzig Züge ohne Schlagen und ohne Bauernzug: Remis"""
    braucht(_hat_methode("Spiel", "spiel", "ist_remis"), "Station Remis: noch keine Methode ist_remis().")
    wo = "Aufgabe 6 ★"
    s = _spiel()
    erwarte(rufe(s, "ist_remis") is False, "Am Start sagt ist_remis() schon %r." % rufe(s, "ist_remis"))
    s = _partie(_halbzuege(PENDEL, 99), wo)
    erwarte(rufe(s, "ist_remis") is False, "Nach 99 Halbzügen ohne Schlagen und ohne Bauernzug sagt ist_remis() schon "
            "True -- es sind fünfzig Züge je Seite, also 100 Halbzüge.")
    _partie(PENDEL.split()[99 % 4], wo, s)
    erwarte(rufe(s, "ist_remis") is True, "Nach 100 Halbzügen ohne Schlagen und ohne Bauernzug (die Springer pendeln) "
            "sagt ist_remis() noch %r." % rufe(s, "ist_remis"))
    s = _partie(_halbzuege(PENDEL, 96) + " e2e4 " + _halbzuege("g8f6 g1f3 f6g8 f3g1", 8), wo)
    erwarte(rufe(s, "ist_remis") is False, "Ein Bauernzug fängt das Zählen von vorn an: nach 96 Halbzügen, einem "
            "Bauernzug und acht weiteren sagt ist_remis() aber True.")
    s = _partie("e2e4 e7e5 " + _halbzuege(PENDEL_B, 96) + " g1f3 g8f6 f3e5 f6g8 e5f3", wo)
    erwarte(rufe(s, "ist_remis") is False, "Schlagen fängt das Zählen von vorn an: Der weiße Springer schlug auf (3, 4) "
            "-- trotzdem sagt ist_remis() True.")


def pruefe_62_koenige():
    """Aufgabe 6 ★★ · Nur noch die Könige (und höchstens ein Läufer oder Springer): Remis"""
    braucht(_ok(pruefe_60_fuenfzig), "Erst die fünfzig Züge (Aufgabe 6 ★).")
    koenige = [("König", "weiß", "e1"), ("König", "schwarz", "e8")]
    for dazu, soll in (([], True), ([("Springer", "weiß", "b1")], True), ([("Läufer", "schwarz", "c8")], True),
                       ([("Turm", "weiß", "a1")], False), ([("Bauer", "weiß", "a2")], False),
                       ([("Springer", "weiß", "b1"), ("Springer", "schwarz", "b8")], False)):
        s = _lage(_spiel(), koenige + dazu)
        ist = rufe(s, "ist_remis")
        was = " und ".join("%s %s" % (a, f) for a, f, _ in dazu) or "nichts"
        erwarte(ist is soll, "Auf dem Brett stehen nur die zwei Könige und %s: ist_remis() sagt %r, richtig ist %r."
                % (was, ist, soll))


# ------------------------------------------------------------------ Aufgabe 7: speichern

def pruefe_70_notation():
    """Aufgabe 7 ★ · Die Partie als Text: notation() -- je Zug, der galt, vier Ziffern"""
    braucht(_hat_methode("Spiel", "spiel", "notation"), "Station Speichern: noch keine Methode notation().")
    s = _spiel()
    erwarte(rufe(s, "notation") == [], "Vor dem ersten Zug gibt notation() nicht die leere Liste zurück.")
    _partie("e2e4 e7e5", "Aufgabe 7 ★", s)
    _zug(s, (7, 4), (5, 4))
    _partie("g1f3", "Aufgabe 7 ★", s)
    text = rufe(s, "notation")
    erwarte(text == ["6444", "1434", "7655"], "Nach drei Zügen, die galten (und einem, der nicht galt), gibt notation() "
            "%r zurück -- erwartet: ['6444', '1434', '7655']." % (text,))


def pruefe_72_nachspielen():
    """Aufgabe 7 ★★ · Eine Partie nachspielen: nachspielen(zeilen) -- bis zum ersten Zug, der nicht gilt"""
    braucht(_ok(pruefe_70_notation), "Erst notation() (Aufgabe 7 ★).")
    s = _spiel()
    gilt = rufe(s, "nachspielen", ["6444", "1434", "7655"])
    erwarte(gilt is True, "nachspielen(['6444', '1434', '7655']) gibt %r zurück, nicht True." % (gilt,))
    springer = rufe(s, "figur_auf", 5, 5)
    erwarte(_was(springer) == "Springer weiß", "Nach dem Nachspielen steht auf (5, 5) %s, nicht der weiße Springer."
            % _was(springer))
    erwarte(_am_zug(s) == "schwarz", "Nach drei nachgespielten Zügen ist nicht Schwarz am Zug.")
    s = _spiel()
    gilt = rufe(s, "nachspielen", ["6444", "6353", "1434"])
    erwarte(gilt is False, "nachspielen(['6444', '6353', '1434']): Der zweite Zug gilt nicht (Weiß noch einmal) -- "
            "zurück kommt aber %r." % (gilt,))
    erwarte(rufe(s, "figur_auf", 1, 4) is not None, "Nach einem Zug, der nicht galt, spielt nachspielen weiter: Der "
            "schwarze Bauer von (1, 4) ist gezogen.")
    gilt = rufe(_spiel(), "nachspielen", ["3333"])
    erwarte(gilt is False, "nachspielen(['3333']): Auf (3, 3) steht am Start keine Figur -- zurück kommt aber %r." % (gilt,))


# ------------------------------------------------------------------ Aufgabe 8: Schachuhr

def _uhr(sekunden):
    return erzeuge(_klasse("Uhr", "uhr"), sekunden)


def pruefe_80_uhr():
    """Aufgabe 8 ★ · Die Uhr: starte, umschalten, rest -- die Zeit dessen, der am Zug ist, läuft"""
    braucht(_klasse("Uhr", "uhr") is not None, "Station Schachuhr: in uhr.py noch keine Klasse Uhr.")
    uhr = _uhr(300)
    zweite = _uhr(300)
    rufe(uhr, "starte", 1000.0)
    rufe(zweite, "starte", 1000.0)
    erwarte(rufe(uhr, "rest", "weiß", 1010.0) == 290, "Uhr(300), gestartet bei 1000: Bei 1010 hat Weiß noch %r "
            "Sekunden, nicht 290 -- die laufende Zeit zählt schon mit." % rufe(uhr, "rest", "weiß", 1010.0))
    erwarte(rufe(uhr, "rest", "schwarz", 1010.0) == 300, "Bei 1010 hat Schwarz noch %r Sekunden, nicht 300 -- seine "
            "Uhr steht." % rufe(uhr, "rest", "schwarz", 1010.0))
    rufe(uhr, "umschalten", 1012.0)
    erwarte(rufe(uhr, "rest", "weiß", 1050.0) == 288, "Weiß hat bei 1012 umgeschaltet: Bei 1050 hat Weiß noch %r "
            "Sekunden, nicht 288 -- seine Uhr steht jetzt." % rufe(uhr, "rest", "weiß", 1050.0))
    erwarte(rufe(uhr, "rest", "schwarz", 1050.0) == 262, "Seit 1012 läuft die Zeit von Schwarz: Bei 1050 sind es noch "
            "%r Sekunden, nicht 262." % rufe(uhr, "rest", "schwarz", 1050.0))
    erwarte(rufe(zweite, "rest", "weiß", 1010.0) == 290, "Eine zweite Uhr ändert sich mit der ersten -- teilen sich "
            "alle Uhren eine Angabe?")


def pruefe_82_abgelaufen():
    """Aufgabe 8 ★★ · Die Zeit ist um: rest nie unter null, abgelaufen(farbe, jetzt)"""
    braucht(_ok(pruefe_80_uhr), "Erst die Uhr (Aufgabe 8 ★).")
    uhr = _uhr(60)
    rufe(uhr, "starte", 0.0)
    erwarte(rufe(uhr, "rest", "weiß", 100.0) == 0, "Uhr(60), Weiß denkt 100 Sekunden: rest sagt %r, nicht 0 -- unter "
            "null geht keine Uhr." % rufe(uhr, "rest", "weiß", 100.0))
    erwarte(rufe(uhr, "abgelaufen", "weiß", 100.0) is True, "Nach 100 von 60 Sekunden sagt abgelaufen(\"weiß\", 100.0) "
            "nicht True.")
    erwarte(rufe(uhr, "abgelaufen", "weiß", 30.0) is False, "Nach 30 von 60 Sekunden sagt abgelaufen(\"weiß\", 30.0) "
            "schon True.")
    erwarte(rufe(uhr, "abgelaufen", "schwarz", 100.0) is False, "Die Zeit von Schwarz lief nie -- abgelaufen("
            "\"schwarz\", 100.0) sagt aber True.")


# ------------------------------------------------------------------ Aufgabe 11: Computergegner

def _computer(farbe):
    return erzeuge(_klasse("Computer", "computer"), farbe)


def _ziele(s, farbe):
    """Alle Züge (von, nach), die darf erlaubt -- so wie das Spiel sie gelten ließe."""
    aus = set()
    for z in range(8):
        for sp in range(8):
            f = rufe(s, "figur_auf", z, sp)
            if f is not None and rufe(f, "get_farbe") == farbe:
                for zz in range(8):
                    for ss in range(8):
                        if rufe(f, "darf", zz, ss, s):
                            aus.add(((z, sp), (zz, ss)))
    return aus


def _als_paar(zug):
    erwarte(type(zug).__name__ == "Zug", "Zurück kommt %r -- erwartet ist ein Zug (ein Objekt der Klasse Zug)." % (zug,))
    return ((rufe(zug, "get_start_zeile"), rufe(zug, "get_start_spalte")), (rufe(zug, "get_zeile"), rufe(zug, "get_spalte")))


def _wert_auf(s, feld):
    f = rufe(s, "figur_auf", *feld)
    return 0 if f is None else rufe(f, "get_wert")


def _gewinn(s, paar, farbe):
    """Der Gewinn eines Zugs nach der Regel der Aufgabe: Wert des Opfers, minus den Wert der eigenen Figur, wenn danach
    ein Gegner auf das Ziel schlagen kann (schlaegt, freier Weg -- das Startfeld zählt als leer, das Opfer nicht mehr)."""
    von, nach = paar
    figur = rufe(s, "figur_auf", *von)
    opfer = rufe(s, "figur_auf", *nach)
    gewinn = _wert_auf(s, nach)
    for z in range(8):
        for sp in range(8):
            a = rufe(s, "figur_auf", z, sp)
            if a is None or a is opfer or rufe(a, "get_farbe") == farbe or not rufe(a, "schlaegt", *nach):
                continue
            frei = True
            if rufe(a, "get_art") != "Springer":
                dz = (nach[0] > z) - (nach[0] < z)
                ds = (nach[1] > sp) - (nach[1] < sp)
                zz, ss = z + dz, sp + ds
                while (zz, ss) != nach:
                    if (zz, ss) != von and rufe(s, "figur_auf", zz, ss) is not None:
                        frei = False
                    zz, ss = zz + dz, ss + ds
            if frei:
                return gewinn - rufe(figur, "get_wert")
    return gewinn


# Die Lage für ★★ und ★★★: Die weiße Dame auf (4, 4) kann drei Figuren schlagen. Der Turm auf (4, 1) ist am meisten
# wert, aber der Springer auf (2, 2) deckt ihn; der Springer selbst und der Bauer auf (2, 4) sind ungedeckt.
LAGE_FANG = [("König", "weiß", "e1"), ("Dame", "weiß", "e4"), ("König", "schwarz", "e8"), ("Turm", "schwarz", "b4"),
             ("Springer", "schwarz", "c6"), ("Bauer", "schwarz", "e6")]
# Jeder Fang ist gedeckt: Die Dame auf (7, 3) könnte den Bauern auf (2, 3) schlagen, den der Bauer auf (1, 2) deckt.
LAGE_FALLE = [("König", "weiß", "e1"), ("Dame", "weiß", "d1"), ("Bauer", "weiß", "a2"), ("König", "schwarz", "e8"),
              ("Bauer", "schwarz", "d6"), ("Bauer", "schwarz", "c7")]


def pruefe_110_alle_zuege():
    """Aufgabe 11 ★ · Der Computer kennt alle Züge seiner Farbe und zieht einen zufällig"""
    braucht(_klasse("Computer", "computer") is not None, "Station Computergegner: in computer.py noch keine Klasse "
            "Computer.")
    s = _spiel()
    for farbe in ("weiß", "schwarz"):
        zuege = rufe(_computer(farbe), "alle_zuege", s)
        erwarte(isinstance(zuege, list), "alle_zuege(spiel) gibt %r zurück -- erwartet ist eine Liste von Zügen." % (zuege,))
        paare = [_als_paar(z) for z in zuege]
        soll = _ziele(s, farbe)
        erwarte(len(paare) == len(set(paare)), "In der Liste von alle_zuege(spiel) steht ein Zug zweimal.")
        erwarte(set(paare) == soll, "Am Start hat %s 20 Züge (16 der Bauern, 4 der Springer) -- alle_zuege(spiel) "
                "liefert %d, davon %d richtige." % (farbe, len(paare), len(set(paare) & soll)))
    vorher = _stellung(s)
    soll = _ziele(s, "weiß")
    random.seed(7)
    gezogen = set()
    for _ in range(40):
        zug = rufe(_computer("weiß"), "zufallszug", s)
        paar = _als_paar(zug)
        erwarte(paar in soll, "zufallszug(spiel) gibt einen Zug zurück, den das Spiel nicht gelten ließe: "
                "von %s nach %s." % (_wo(paar[0]), _wo(paar[1])))
        gezogen.add(paar)
    erwarte(len(gezogen) >= 5, "Vierzig Mal zufallszug(spiel) -- und nur %d verschiedene Züge. Wählt er wirklich "
            "zufällig aus allen?" % len(gezogen))
    erwarte(_stellung(s) == vorher, "Nach alle_zuege und zufallszug steht auf dem Brett etwas anders: Der Computer "
            "fragt das Spiel nur -- ziehen tut das Spiel.")


def pruefe_112_gierig():
    """Aufgabe 11 ★★ · Der gierige Zug: der Fang, der am meisten wert ist"""
    braucht(_ok(pruefe_110_alle_zuege), "Erst alle Züge (Aufgabe 11 ★).")
    s = _lage(_spiel(), LAGE_FANG)
    vorher = _stellung(s)
    paar = _als_paar(rufe(_computer("weiß"), "gieriger_zug", s))
    erwarte(paar[1] == (4, 1), "Die weiße Dame auf (4, 4) kann den Turm auf (4, 1) schlagen (5), den Springer auf "
            "(2, 2) (3) und den Bauern auf (2, 4) (1). gieriger_zug(spiel) zieht aber von %s nach %s."
            % (_wo(paar[0]), _wo(paar[1])))
    erwarte(_stellung(s) == vorher, "Nach gieriger_zug steht auf dem Brett etwas anders -- der Computer fragt nur.")


def pruefe_114_blick():
    """Aufgabe 11 ★★★ · Ein Blick voraus: kein gedeckter Fang -- und das Spiel bleibt, wie es war"""
    braucht(_ok(pruefe_112_gierig), "Erst der gierige Zug (Aufgabe 11 ★★).")
    for lage, was in ((LAGE_FANG, "Der Turm auf (4, 1) ist gedeckt, der Springer auf (2, 2) nicht"),
                      (LAGE_FALLE, "Jeder Fang der Dame ist gedeckt")):
        s = _lage(_spiel(), lage)
        vorher = _stellung(s)
        alle = _ziele(s, "weiß")
        bestes = max(_gewinn(s, p, "weiß") for p in alle)
        zug = rufe(_computer("weiß"), "bester_zug", s)
        erwarte(_stellung(s) == vorher, "Die Auflage: Nach bester_zug steht jede Figur, wo sie vorher stand, im "
                "Spielfeld und in der Figur selbst -- bei euch nicht. Die Lage: %s." % was)
        paar = _als_paar(zug)
        erwarte(paar in alle, "bester_zug gibt einen Zug zurück, den das Spiel nicht gelten ließe.")
        gewinn = _gewinn(s, paar, "weiß")
        erwarte(gewinn == bestes, "%s. bester_zug zieht von %s nach %s und gewinnt so %d -- der beste Zug gewinnt %d."
                % (was, _wo(paar[0]), _wo(paar[1]), gewinn, bestes))


# ------------------------------------------------------------------ Hinweis

def pruefe_90_hints():
    """Hinweis · Jede Methode, die ihr schreibt, mit Type Hints (kein Stern)"""
    ohne, diagramm = [], []
    for datei in ("figur.py", "spiel.py", "computer.py", "uhr.py"):
        try:
            baum = ast.parse(quelltext(datei))
        except (SyntaxError, OSError, TypeError, ValueError):
            continue
        for k in ast.walk(baum):
            if not isinstance(k, ast.FunctionDef):
                continue
            for a in k.args.args + [k]:
                typ = a.annotation if isinstance(a, ast.arg) else a.returns
                if typ is not None and any(isinstance(x, ast.Name) and x.id in TYPEN_DIAGRAMM for x in ast.walk(typ)):
                    diagramm.append("%s (%s)" % (k.name, datei))
            parameter = [a for a in k.args.args if a.arg != "self"]
            if any(a.annotation is None for a in parameter) or (k.returns is None and k.name != "__init__"):
                ohne.append("%s (%s)" % (k.name, datei))
    erwarte(not diagramm, "Hier steht ein Typ in der Schreibweise des Diagramms: %s. In Python heißt er str, int, "
            "float oder bool." % ", ".join(diagramm))
    erwarte(not ohne, "Ohne Type Hint (hinter der Klammer oder an einem Parameter): %s. Es läuft auch ohne; vereinbart "
            "ist es trotzdem." % ", ".join(ohne))
