# computer.py -- Station Computergegner
# (Aufgabe 11). Der Computer fragt das
# Spiel nur: Wer steht wo, was darf eine
# Figur? Er gibt einen Zug zurück --
# ziehen tut das Spiel. partie.py lädt
# diese Datei erst, wenn ihr es wollt.

# erlaubt die eigene Klasse als Typ:
from __future__ import annotations
import random
from figur import richtung
from zug import Zug
