# netz.py -- gegeben: eine Verbindung zwischen
# zwei Rechnern. Lesen dürft ihr, ändern nicht.
# Über die Verbindung gehen Textzeilen, z. B.
# ein Zug als "6444". Ob zwei Rechner der
# Schule sich verbinden dürfen, ist nicht
# sicher -- zu Hause geht es fast immer.

import socket

PORT = 50505


class Verbindung:
    """Eine Leitung zum anderen Rechner: sende schickt eine Zeile,
    empfange holt die nächste -- oder "", wenn noch keine da ist."""

    def __init__(self, leitung: socket.socket):
        self.__leitung = leitung
        self.__leitung.setblocking(False)
        self.__eingang = ""

    def sende(self, text: str) -> None:
        """Schickt text als eine Zeile zum anderen Rechner."""
        self.__leitung.setblocking(True)
        self.__leitung.sendall((text + "\n").encode("utf-8"))
        self.__leitung.setblocking(False)

    def empfange(self) -> str:
        """Die nächste Zeile vom anderen Rechner -- "", wenn noch
        keine angekommen ist. Wartet nie."""
        try:
            stueck = self.__leitung.recv(4096)
            self.__eingang = self.__eingang + stueck.decode("utf-8")
        except BlockingIOError:
            pass
        if "\n" not in self.__eingang:
            return ""
        zeile, rest = self.__eingang.split("\n", 1)
        self.__eingang = rest
        return zeile

    def schliesse(self) -> None:
        self.__leitung.close()


def eigene_adresse() -> str:
    """Die Adresse dieses Rechners im Netz, z. B. "10.12.0.31"."""
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.connect(("10.255.255.255", 1))
        return probe.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        probe.close()


def warte_auf_partner(port: int = PORT) -> Verbindung:
    """Wartet, bis sich ein anderer Rechner meldet (der mit
    verbinde). Gibt die Verbindung zurück."""
    print("Warte auf Partner unter", eigene_adresse(), "...")
    tuer = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    tuer.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    tuer.bind(("", port))
    tuer.listen(1)
    leitung, partner = tuer.accept()
    tuer.close()
    print("Verbunden mit", partner[0])
    return Verbindung(leitung)


def verbinde(adresse: str, port: int = PORT) -> Verbindung:
    """Verbindet mit dem Rechner, der unter adresse wartet."""
    leitung = socket.create_connection((adresse, port), timeout=10)
    print("Verbunden mit", adresse)
    return Verbindung(leitung)
