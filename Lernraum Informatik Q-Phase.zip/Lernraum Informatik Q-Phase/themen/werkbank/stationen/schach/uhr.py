# uhr.py -- Station Schachuhr (Aufgabe 8).
# Die Uhr hält zwei Restzeiten und weiß,
# wessen Zeit läuft. Die Zeit selbst kommt
# von außen: time.time() in partie.py.
